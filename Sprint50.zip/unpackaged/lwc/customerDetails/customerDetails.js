import { LightningElement, track, api } from "lwc";
import CUSTOMER_HAS_SPECIAL_PRICE from "@salesforce/schema/Quote_Request_2__c.Customer__c";
import getSolutionEngineersList from "@salesforce/apex/NewQuoteRequestHandler.getSolutionEngineersList";
import getChannelsFinanceList from "@salesforce/apex/NewQuoteRequestHandler.getChannelsFinanceList";
import getUsersListForQRRoleAssignment from "@salesforce/apex/NewQuoteRequestHandler.getUsersListForQRRoleAssignment";
import createQuoteUserRequest from "@salesforce/apex/NewQuoteRequestHandler.createQuoteUserRequest";
import getExecutiveList from "@salesforce/apex/NewQuoteRequestHandler.getExecutiveList";
import deleteQRUser from "@salesforce/apex/NewQuoteRequestHandler.deleteSObjects";
import getAssignedUserPermission from "@salesforce/apex/NewQuoteRequestHandler.getAssignedUserPermission";
import hasSalesEngineer from "@salesforce/customPermission/A3_SalesEng_CRE";
import hasSplPricing from "@salesforce/customPermission/A3_SplPricing_CRE";
import hasChannelsQuoter from "@salesforce/customPermission/A3_ChannelsQuoter_CRE";
import hasOMAnalyst from "@salesforce/customPermission/A3_OMAnalyst_CRE";
import updateQuoteRequestCall from "@salesforce/apex/NewQuoteRequestHandler.updateQuoteRequest";
import hasPremier from "@salesforce/customPermission/A3_Premier_CRE";
import { NavigationMixin } from "lightning/navigation";
import getActionStatuses from "@salesforce/apex/NewQuoteRequestHandler.getActionStatuses";
import { updateRecord } from "lightning/uiRecordApi";
import COMPANY_NAME from "@salesforce/schema/Quote_Request_2__c.Company_Name__c";
import ID_FIELD from "@salesforce/schema/Quote_Request_2__c.Id";
import OPP_CUSTOMER_NAME from "@salesforce/schema/Opportunity.Customer_Name__c";
import OPP_ID_FIELD from "@salesforce/schema/Opportunity.Id";
import { ShowToastEvent } from "lightning/platformShowToastEvent";

const COLUMNS = [
  { label: "Name", fieldName: "name", type: "string" },
  { label: "Department", fieldName: "department", type: "string" }
];
export default class CustomerDetails extends NavigationMixin(LightningElement) {
  @api quoteRequestApi;
  @track quoteRequest = this.quoteRequestApi;
  originalQuoteRequestJSON;
  @track selectedUsersList = [];
  originalSelectedUserList = [];
  @track selectedOMAnalyst = [];
  originalSelectedOMAnalyst = [];
  @track selectChannelFinance = [];
  orginalSelectedChannelFinanceUser = [];
  @track isSPorOMAnyalyst = true;
  @track isFieldChanged = false;
  masterList = [];
  preSelectedRows = [];
  preSelectedRowBackup = [];
  showModal = false;
  days = 1;
  disableBusinessUnit = true;
  //quoteUserRequest = QUOTE_USER_REQUEST_OBJECT;
  customerHasSpecialPrice = CUSTOMER_HAS_SPECIAL_PRICE;
  showSpinner = false;
  errorMsg = "";
  columns = COLUMNS;
  @api viewOnly;
  users = [];
  exeutiveListOptions = [];
  slaTicker;
  quoteType = "Comparison";
  hasRendered = false;
  showSEUser = true;
  @track showCFUser = true;
  showChannelRep = false;
  showChangeOrder = true;
  isOMPresent = true;
  isSEPresent = true;
  isUserUncheck = false;
  @track editCompanyName = false;
  companyEdit = false;
  qrvalues;

  preSelectedSERows = [];
  preSelectedOMRows = [];
  preChannalFinanceRows = [];
  @track showExecutiveRequest = false;
  @track showExecutiveRequestValue;
  selectedNeworChangeOrder = "New";
  @track addBtnDisabled = true;
  actionStatuses = { customerDetails: {}, users: {} };

  isChangeOrder = true;

  disableDateInput(e) {
    e.preventDefault();
  }
  @api
  invokeFromOneIntakeComponent() {
    let quoteRequestJSON = JSON.stringify(this.quoteRequest);
    let omAnalystJSON = JSON.stringify(this.selectedOMAnalyst);
    let sUserListJSON = JSON.stringify(this.selectedUsersList);
    let channelFinance = JSON.stringify(this.selectChannelFinance);

    if (
      !(
        quoteRequestJSON === this.originalQuoteRequestJSON &&
        omAnalystJSON === this.originalSelectedOMAnalyst &&
        channelFinance === this.orginalSelectedChannelFinanceUser &&
        sUserListJSON === this.originalSelectedUserList
      )
    ) {
      this.warningMessageFlag = true;
    }

    const selectedEvent = new CustomEvent("warningmessageevent", {
      detail: {
        warningMessageModalFlag: this.warningMessageFlag
      }
    });

    // Dispatches the event.
    this.dispatchEvent(selectedEvent);
  }

  connectedCallback() {
    this.quoteRequest = this.quoteRequestApi;
    getExecutiveList().then((result) => {
      this.exeutiveListOptions = result;
      this.exeutiveListOptions.unshift({
        label: "None",
        value: ""
      });
    });

    this.originalQuoteRequestJSON = JSON.stringify(this.quoteRequest);
    getAssignedUserPermission().then((result) => {
      console.log("permission res : ", JSON.stringify(result));
      if (result === "ChannelRep") {
        this.showChannelRep = true;
      } else if (
        result === "premier" ||
        result === "SPorOM" ||
        result === "SE"
      ) {
        this.showChangeOrder = true;
      }
      else if(result === "SPorOMAnyalyst"){
        this.isSPorOMAnyalyst = false;
      }
    });

    getActionStatuses({ quoteRequestId: this.quoteRequest.Id,expiredDate:this.days })
      .then((response) => {
        this.actionStatuses = response.customerDetails;
        console.log(
          "customer details:getActionStatuses response => " +
            JSON.stringify(this.actionStatuses)
        );
      })
      .catch((error) => {
        console.log(
          "customer details:getActionStatuses error => " + JSON.stringify(error)
        );
      });
  }

  get displayGenerateQuote() {
    return hasPremier;
  }

  switchEditCompanyName() {
    this.editCompanyName = !this.editCompanyName;
  }
  renderedCallback() {
    //this.template.querySelector('.quoteType').value = this.quoteRequest.Quote_Type__c;
    if (!this.showChannelRep && !this.quoteRequest.Is_Submitted__c) {
      this.showChannelRep = false;
    }
    if (
      !this.showChannelRep &&
      this.template.querySelector(".executiveRequest")
    ) {
      console.log(
        "executive request value",
        this.quoteRequest.Executive_Request__c == null
      );
      if (this.quoteRequest.Executive_Request__c == null) {
        this.template.querySelector(".executiveRequest").value = "";
        // this.showExecutiveRequest = true;
      } else {
        this.template.querySelector(".executiveRequest").value =
          this.quoteRequest.Executive_Request__c;
        // this.showExecutiveRequest = false;

        // // get executivelistoptions
        // getExecutiveList().then((result) => {
        // const data = result.find((item) => {
        //     return item.value == this.quoteRequest.Executive_Request__c;
        // });

        // this.showExecutiveRequestValue = data.label;
        // console.log("exec value", data);
        // });

        // this.showExecutiveRequestValue = this.executiveListOptions.find(item => {
        //     return item.value == this.quoteRequest.Executive_Request__c;
        // })
        // console.log('exec', this.showExecutiveRequestValue)
        // this.showExecutiveRequestValue = this.quoteRequest.Executive_Request__c;
        // this.showExecutiveRequestValue = this.exeutiveListOptions.find(item => item.value === this.quoteRequest.Executive_Request__c);
        // console.log('data',data)
      }
    }
    // if(this.quoteRequest.Is_Submitted__c) {
    //     this.showSEUser = false;
    // } else {
    //     this.showSEUser = true;
    // }
    if (
      hasSalesEngineer &&
      this.quoteRequest.Quote_Request_Status__c === "Pending Pricing"
    ) {
      let result = new Date(
        this.quoteRequest.SLA_Timer__c.replace(/-/g, "/").replace(/T.+/, "")
      );
      result = this.getEndDate(result, 0);
      let dateToSet = this.getBusinessDatesCount(
        new Date(),
        new Date(result.toDateString())
      );
      this.slaTicker = dateToSet + " days";
    } else if (
      (hasOMAnalyst || hasSplPricing || hasChannelsQuoter) &&
      this.quoteRequest.Quote_Request_Status__c === "Assigned" &&
      this.quoteRequest.Quote_Type__c === "Comparison"
    ) {
      let result = new Date(
        this.quoteRequest.SLA_Timer__c.replace(/-/g, "/").replace(/T.+/, "")
      );
      result = this.getEndDate(result, 7);
      let dateToSet = this.getBusinessDatesCount(
        new Date(),
        new Date(result.toDateString())
      );
      this.slaTicker = dateToSet + " days";
    } else if (
      (hasOMAnalyst || hasSplPricing || hasChannelsQuoter) &&
      this.quoteRequest.Quote_Request_Status__c === "Assigned" &&
      this.quoteRequest.Quote_Type__c === "Non-Comparison"
    ) {
      let result = new Date(
        this.quoteRequest.SLA_Timer__c.replace(/-/g, "/").replace(/T.+/, "")
      );
      result = this.getEndDate(result, 1);
      let dateToSet = this.getBusinessDatesCount(
        new Date(),
        new Date(result.toDateString())
      );
      this.slaTicker = dateToSet + " days";
    }
    // if(this.quoteRequest.Quote_Request_Users_2__r) {
    //     if(!this.hasRendered) {
    //         this.quoteRequest.Quote_Request_Users_2__r.forEach(elem => {
    //             if(elem.User_Role__c === 'Sales Engineer') {
    //                 this.selectedUsersList.push({ id : elem.User__c, name : elem.User__r.Name, check : true, qruId : elem.Id });
    //                 this.preSelectedSERows.push(elem.User__c);
    //             } else if(elem.User_Role__c === 'OM Analyst') {
    //                 this.selectedOMAnalyst.push({ id : elem.User__c, name : elem.User__r.Name, check : true, qruId : elem.Id });
    //                 this.preSelectedOMRows.push(elem.User__c);
    //             }
    //         });
    //         this.hasRendered = true;
    //     }
    //     // if(this.selectedUsersList.length === 0){
    //     //     this.isSEPresent = true;
    //     // }else{
    //     //     this.isSEPresent = false;
    //     // }
    //     // if(this.selectedOMAnalyst.length === 0){
    //     //     this.isOMPresent = true;
    //     // }else{
    //     //     this.isOMPresent = false;
    //     // }
    // }
    this.notifyToSalesRepViewCmp();
    this.originalSelectedOMAnalyst = JSON.stringify(this.selectedOMAnalyst);
    this.originalSelectedUserList = JSON.stringify(this.selectedUsersList);
    this.orginalSelectedChannelFinanceUser = JSON.stringify(
      this.selectChannelFinance
    );
  }

  getEndDate(slaStartDate, slaDays) {
    for (let iCount = 0; iCount < slaDays; iCount++) {
      slaStartDate.setDate(slaStartDate.getDate() + 1);
      if (slaStartDate.getDay() === 6) {
        slaStartDate.setDate(slaStartDate.getDate() + 1);
      }
    }

    if (slaStartDate.getDay() === 0) {
      slaStartDate.setDate(slaStartDate.getDate() + 1);
    }
    return slaStartDate;
  }

  getBusinessDatesCount(startDate, endDate) {
    let count = 0;
    const curDate = new Date(startDate.toDateString());
    while (curDate <= endDate) {
      const dayOfWeek = curDate.getDay();
      if (dayOfWeek !== 0 && dayOfWeek !== 6) count++;
      curDate.setDate(curDate.getDate() + 1);
    }
    return count;
  }

  navigateToViewOpportunityPage(event) {
    event.stopPropagation();
    this[NavigationMixin.GenerateUrl]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.quoteRequest.Related_Opportunity__r.Id,
        objectApiName: "Opportunity",
        actionName: "view"
      }
    }).then((url) => {
      window.open(url);
    });
  }
  get OpportunityName() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.Name != null
      ? this.quoteRequest.Related_Opportunity__r.Name
      : "";
  }
  get NewOrExistingCustomer() {
    return this.quoteRequest != null && this.parentGrandParent.length > 0
      ? "Existing"
      : "New";
  }
  get SpecialPricingAvaiable() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.Special_Pricing__c != null
      ? "Yes"
      : "No";
  }
  get PrimarySalesRep() {
    return this.quoteRequest != null &&
      this.quoteRequest.Primary_Sales_Rep__r != null &&
      this.quoteRequest.Primary_Sales_Rep__r.Full_Name_copy__c
      ? this.quoteRequest.Primary_Sales_Rep__r.Full_Name_copy__c
      : "";
  }
  get BillingType() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Company__r != null &&
      this.quoteRequest.Related_Company__r.Billing_Type__c
      ? this.quoteRequest.Related_Company__r.Billing_Type__c
      : "";
  }
  get CompanyName() {
    // return this.quoteRequest!=null && this.quoteRequest.Related_Company__r !=null && this.quoteRequest.Related_Company__r.Name ? this.quoteRequest.Related_Company__r.Name : '';
    return this.quoteRequest != null &&
      this.quoteRequest.Company_Name__c != null
      ? this.quoteRequest.Company_Name__c
      : "";
  }
  get RDMRep() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Company__r != null &&
      this.quoteRequest.Related_Company__r.RDM_Name__r != null &&
      this.quoteRequest.Related_Company__r.RDM_Name__r.Full_Name_copy__c
      ? this.quoteRequest.Related_Company__r.RDM_Name__r.Full_Name_copy__c
      : "";
  }
  get notesContent() {
    return this.quoteRequest != null && this.quoteRequest.Notes__c != null
      ? this.quoteRequest.Notes__c
      : "";
  }
  get customerPricing() {
    return this.quoteRequest != null && this.quoteRequest.Customer__c != null
      ? this.quoteRequest.Customer__c
      : "Yes";
  }
  get ClientName() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.Customer_Name__c != null
      ? this.quoteRequest.Related_Opportunity__r.Customer_Name__c
      : "";
  }
  get MasterAgent() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.Master__c != null
      ? this.quoteRequest.Related_Opportunity__r.Master__r.Name
      : "";
  }
  get subAgent() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.AccountId != null
      ? this.quoteRequest.Related_Opportunity__r.Account.Name
      : "";
  }
  get channelSupportRep() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.AccountId != null &&
      this.quoteRequest.Related_Opportunity__r.Account.Channel_Support_Rep__c !=
        null
      ? this.quoteRequest.Related_Opportunity__r.Account.Channel_Support_Rep__c
      : "";
  }
  get RCMRep() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.AccountId != null &&
      this.quoteRequest.Related_Opportunity__r.Account
        .Channels_Sales_Executive__c != null
      ? this.quoteRequest.Related_Opportunity__r.Account
          .Channels_Sales_Executive__c
      : "";
  }
  get parentId() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.AccountId != null &&
      this.quoteRequest.Related_Opportunity__r.Account.AccountNumber != null
      ? this.quoteRequest.Related_Opportunity__r.Account.AccountNumber
      : "";
  }
  get grandParentId() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.AccountId != null &&
      this.quoteRequest.Related_Opportunity__r.Account
        .Cornerstone_Parent_Account__c != null
      ? this.quoteRequest.Related_Opportunity__r.Account
          .Cornerstone_Parent_Account__c
      : "";
  }
  get parentGrandParent() {
    if (this.parentId && this.grandParentId) {
      return `${this.parentId}/${this.grandParentId}`;
    }
    return "";
  }

  get grandParentNumber(){
    let gpNumber = "";
    if(this.quoteRequest.Business_Unit__c === "Channels"){
      gpNumber = this.quoteRequest.Related_Opportunity__r.Channels_Cornerstone_ID__c ? this.quoteRequest.Related_Opportunity__r.Channels_Cornerstone_ID__c : "";
    }
    else if(this.parentId && this.grandParentId){
      gpNumber = `${this.parentId}/${this.grandParentId}`;
    }

    return gpNumber;
  }
  get parentGrandParentChannels() {
    if (
      this.quoteRequest.Business_Unit__c === "Channels" &&
      this.quoteRequest.Related_Opportunity__r.Channels_Cornerstone_ID__c !=
        null
    ) {
      return this.quoteRequest.Related_Opportunity__r
        .Channels_Cornerstone_ID__c;
    }
    return "";
  }
  get NotesCssClass() {
    if (this.showChannelRep) {
      return `slds-col slds-size_1-of-3`;
    }
    return `slds-col slds-size_2-of-3`;
  }
  get quoteTypeOption() {
    return this.quoteRequest != null && this.quoteRequest.Quote_Type__c != null
      ? this.quoteRequest.Quote_Type__c
      : "Non-Comparison";
  }

  get neworChangeOrder() {
    if (this.quoteRequest != null && this.parentGrandParent.length > 0) {
      this.isNewCustomer = false;
    } else {
      this.isNewCustomer = true;
    }
    return this.quoteRequest != null &&
      this.quoteRequest.Change_Order__c != null
      ? this.quoteRequest.Change_Order__c
      : "New";
  }
  get businesstypeoption() {
    console.log("business", this.quoteRequest);
    return this.quoteRequest != null &&
      this.quoteRequest.Business_Unit__c != null
      ? this.quoteRequest.Business_Unit__c
      : "SLED";
  }

  get customerPriceOptions() {
    return [
      {
        label: "Yes",
        value: "Yes",
        selected: this.customerPricing === "Yes" ? true : false
      },
      {
        label: "No",
        value: "No",
        selected: this.customerPricing === "No" ? true : false
      }
    ];
  }

  get quoteTypeOptions() {
    return [
      {
        label: "Comparison",
        value: "Comparison",
        selected: this.quoteTypeOption === "Comparison" ? true : false
      },
      {
        label: "Non-Comparison",
        value: "Non-Comparison",
        selected: this.quoteTypeOption === "Non-Comparison" ? true : false
      }
    ];
  }

  get neworChangeOrderOptions() {
    return [
      {
        label: "New",
        value: "New",
        selected: this.neworChangeOrder === "New" ? true : false
      },
      {
        label: "Change Order",
        value: "Change Order",
        selected: this.neworChangeOrder === "Change Order" ? true : false
      }
    ];
  }
  get businesstypeoptions() {
    return [
      {
        label: "Standard",
        value: "Standard",
        selected: this.businesstypeoption === "Standard" ? true : false
      },
      {
        label: "SLED",
        value: "SLED",
        selected: this.businesstypeoption === "SLED" ? true : false
      },
      {
        label: "Wholesale",
        value: "Wholesale",
        selected: this.businesstypeoption === "Wholesale" ? true : false
      },
      {
        label: "Channels",
        value: "Channels",
        selected: this.businesstypeoption === "Channels" ? true : false
      }
    ];
  }

  get existingGRTAccount() {
    if (
      this.quoteRequest != null &&
      this.quoteRequest.Change_Order__c != null &&
      this.quoteRequest.Change_Order__c === "Change Order"
    ) {
      this.isChangeOrder = true;
    } else {
      this.isChangeOrder = false;
    }

    return this.quoteRequest && this.quoteRequest.Existing_GRT_Account__c
      ? this.quoteRequest.Existing_GRT_Account__c
      : "";
  }

  get qrSalesEngineer() {
    if(this.quoteRequest.Assigned_Solutions_Engineer1__c){
      return this.quoteRequest.Assigned_Solutions_Engineer1__r.Name
    }
    else{
      return "";
    }

   
  }
  get channelFinanceExists() {
    if(this.quoteRequest.Channel_Finance__c){
      return this.quoteRequest && this.quoteRequest.Channel_Finance__r
    }
    else{
      return false;
    }
   /* return this.quoteRequest && this.quoteRequest.Channel_Finance__r;*/
  }
  get channelFinanceuser() {
    if(this.quoteRequest.Channel_Finance__c){
      return this.quoteRequest.Channel_Finance__r.Name
    }
    else{
      return "";
    }
  }

  get qrOmAnalyst() {
    if(this.quoteRequest.Offer_Management__c){
      return this.quoteRequest.Offer_Management__r.Name
    }
    else{
      return "";
    }

    
  }
  get boradbandPrequal() {
    return this.quoteRequest != null &&
      this.quoteRequest.Broadband_Prequal__c != null
      ? this.quoteRequest.Broadband_Prequal__c
      : "";
  }
  get womId() {
    return this.quoteRequest != null && this.quoteRequest.WOM_ID__c != null
      ? this.quoteRequest.WOM_ID__c
      : "";
  }

  handleFormInputChange(event) {
    if (event.target.name === "Quote_Type__c") {
      this.quoteType = event.target.value;
    }
    if (event.target.name === "Company_Name__c") {
      this.companyEdit = event.target.value;
      this.updateOpportunityCustomerName();
    }
    if (event.target.name === "Business_Unit__c") {
      this.businessunit = event.target.value;
    }
    if (event.target.name === "new_or_change_order") {
      this.selectedNeworChangeOrder = event.target.value;
      this.quoteRequest = {
        ...this.quoteRequest,
        Change_Order__c: event.target.value
      };
      if (event.target.value === "Change Order") {
        this.isChangeOrder = true;
        this.quoteRequest.Customer__c = "Yes";
      } else {
        this.isChangeOrder = false;
      }
    } else {
      this.quoteRequest = {
        ...this.quoteRequest,
        [event.target.name]: event.target.value
      };
      console.log("handlechange", event.target.name, event.target.value);
    }
    console.log("requestobject", this.quoteRequest);
    this.dispatchEvent(
      new CustomEvent("handleqrinputchanges", {
        detail: {
          quoteRequestUpdates: this.quoteRequest,
          neworChangeOrder: this.selectedNeworChangeOrder
        }
      })
    );

    this.handleUpdateSave();
  }
  handleBroadBandPrequelWhoMId(){

      this.handleUpdateSave();
  }
  onhandleFormInputChangeBroadbandPrequal(event){
     if (event.target.name === "Broadband_Prequal__c") {
    this.quoteRequest = {
        ...this.quoteRequest,
        Broadband_Prequal__c: event.target.value
      };
      this.isFieldChanged = true;
     }
  }
  onhandleFormInputChangeWOMID(event){
    if (event.target.name === "WOM_ID__c") {
     this.womIdValue = event.target.value;
     this.quoteRequest = {
        ...this.quoteRequest,
        WOM_ID__c: event.target.value
      };
      this.isFieldChanged = true;
    }
  }

  handleUpdateSave() {
    this.showSpinner = true;
    updateQuoteRequestCall({ qrObj: this.quoteRequest })
      .then(() => {
        if(this.isFieldChanged){
        const successEvent = new ShowToastEvent( {title:'Success', message:"Ordering ID(s) Updated Sucessfully.",variant:'success'} );
		  	this.dispatchEvent( successEvent );
        }
        const custEvent = new CustomEvent("customerdetailchange", {
          detail: {
            quoteRequest: this.quoteRequest
          }
        });
        this.dispatchEvent(custEvent);
        this.showSpinner = false;
      })
      .catch((error) => {
        if(this.isFieldChanged){
        let errorEvent = "Ordering ID(s) Update Failed.";
        this.dispatchEvent(
        new ShowToastEvent( {title:'error:', message:errorEvent,variant:'error'} )
         );
        }
        this.errorMsg = error;
        //alert(''+error)
        this.showSpinner = false;
      });
  }

  handleGetUsers() {
    this.masterList = [];
    this.users = [];
    this.showSpinner = true;
    this.showSEUser = true;
    this.showCFUser = false;
    this.addBtnDisabled = true;

    getSolutionEngineersList()
      .then((result) => {
        let uList = [];
        for (let user of result) {
          let u = {
            id: user.Id,
            name: user.Name,
            department: user.Department_Role__c,
            check: false
          };
          uList.push({ ...u });
          if (user.Id === this.quoteRequest.Assigned_Solutions_Engineer1__c) {
            u.check = true;
          }
          this.users.push(u);
        }

        this.masterList = uList;
        //this.masterList = this.users;
        this.showModal = true;
        this.showSpinner = false;
      })
      .catch((error) => {
        this.errorMsg = error;
        //alert(''+error)
      });
  }

  handleGetChannelsFinanceUsers() {
    this.masterList = [];
    this.users = [];
    this.showSpinner = true;
    this.showCFUser = true;
    this.addBtnDisabled = true;

    getUsersListForQRRoleAssignment({ userRole: "Channels Finance Analyst" })
      .then((result) => {
        let uList = [];
        for (let user of result) {
          let u = {
            id: user.Id,
            name: user.Name,
            department: user.Department_Role__c,
            check: false
          };
          uList.push({ ...u });
          if (user.Id === this.quoteRequest.Channel_Finance__c) {
            u.check = true;
          }
          this.users.push(u);
        }

        this.masterList = uList;

        this.showModal = true;
        this.showSpinner = false;
      })
      .catch((error) => {
        this.errorMsg = error;
        //alert(''+error)
      });
  }

  handleUserCheckChange(event) {
    let cFlag = event.target.checked;
    let sUserId = event.target.value;

    if (cFlag) {
      this.addBtnDisabled = false;
      let uList = [];
      for (let user of this.users) {
        let u = {
          id: user.id,
          name: user.name,
          department: user.department,
          check: false
        };
        if (sUserId === u.id) {
          u.check = true;
        }
        uList.push(u);
      }
      this.users = uList;
    } else {
      this.addBtnDisabled = false;
      let uList = [];
      for (let user of this.users) {
        let u = {
          id: user.id,
          name: user.name,
          department: user.department,
          check: false
        };
        uList.push(u);
      }
      this.users = uList;
    }
  }

  onSelectAll(event) {
    this.preSelectedRowBackup = this.preSelectedRows;
    this.preSelectedRows = [];
    if (event.target.checked) {
      for (let user of this.users) {
        user.check = true;
        this.preSelectedRows.push(user.id);
      }
    } else {
      for (let user of this.users) {
        user.check = false;
        this.preSelectedRows = [];
      }
    }
  }

  searchText = "";
  onNameSearch(event) {
    let searchStr = event.target.value;
    this.users = this.masterList;
    this.users = [];
    this.addBtnDisabled = true;

    if (searchStr) {
      for (let user of this.masterList) {
        if (user.name.toLowerCase().includes(searchStr.toLowerCase())) {
          let u = {
            id: user.id,
            name: user.name,
            department: user.department,
            check: false
          };
          if (u.id === this.quoteRequest.Assigned_Solutions_Engineer1__c) {
            u.check = true;
          }
          this.users.push(u);
        }
      }
    } else {
      this.users = this.masterList;
      this.addBtnDisabled = true;
    }
  }
  handleDeleteChannelFinanceUsers() {
    let qr = {...this.quoteRequest};
    qr.Channel_Finance__c = null;

    this.quoteRequest = qr;
    this.handleUpdateSave();
  }
  onAddUsers(event) {
    let sUser;
    for (let user of this.users) {
      if (user.check) {
        sUser = user;
        break;
      }
    }

    if (event.currentTarget.name === "Sales Engineer") {
      if(sUser){
      this.quoteRequest = {
        ...this.quoteRequest,
        Assigned_Solutions_Engineer1__c: sUser.id
      };
      //this.quoteRequest.Assigned_Solutions_Engineer1__c = sUser.id;
      const seRefObject = { Id: sUser.id, Name: sUser.name };
      this.quoteRequest = {
        ...this.quoteRequest,
        Assigned_Solutions_Engineer1__r: seRefObject
      };
      }
      else{
        let qr = {...this.quoteRequest};
        qr.Assigned_Solutions_Engineer1__c = null;
        this.quoteRequest = qr;
      };

    } else if (event.currentTarget.name === "OM Analyst") {
      if(sUser){
      this.quoteRequest = {
        ...this.quoteRequest,
        Offer_Management__c: sUser.id
      };
      const seRefObject = { Id: sUser.id, Name: sUser.name };
      this.quoteRequest = {
        ...this.quoteRequest,
        Offer_Management__r: seRefObject
      };
      }else{
        let qr = {...this.quoteRequest};
        qr.Offer_Management__c = null;
        this.quoteRequest = qr;
      };
    } else if (event.currentTarget.name === "ChannelFinance") {
      this.quoteRequest = {
        ...this.quoteRequest,
        Channel_Finance__c: sUser.id
      };
      const seRefObject = { Id: sUser.id, Name: sUser.name };
      this.quoteRequest = {
        ...this.quoteRequest,
        Channel_Finance__r: seRefObject
      };
    }

    this.handleUpdateSave();
    this.closeModal();
  }

  onDeleteUser(event) {
    let localList;
    if (event.currentTarget.name === "Sales Engineer") {
      localList = this.selectedUsersList;
      this.selectedUsersList = [];
    } else if (event.currentTarget.name === "OM Analyst") {
      localList = this.selectedOMAnalyst;
      this.selectedOMAnalyst = [];
    } else if (event.currentTarget.name === "ChannelFinance") {
      localList = this.selectChannelFinance;
      this.selectChannelFinance = [];
    }
    console.log("delete   >>> " + event.currentTarget.dataset.id);
    try {
      let ind = event.currentTarget.dataset.id;
      deleteQRUser({ listOfObjs: localList[ind].qruId }).then(() => {});
      let item = localList.splice(ind, 1);
      console.log("after splice " + JSON.stringify(localList));
      let delInd = this.preSelectedRows.indexOf(item[0].id);
      this.preSelectedRows.splice(delInd, 1);
      if (event.currentTarget.name === "Sales Engineer") {
        let delIndSE = this.preSelectedSERows.indexOf(item[0].id);
        this.preSelectedSERows.splice(delIndSE, 1);
        this.selectedUsersList = localList;
        // if(this.selectedUsersList.length === 0){
        //     this.isSEPresent = true;
        // }else{
        //     this.isSEPresent = false;
        // }
      } else if (event.currentTarget.name === "OM Analyst") {
        this.preSelectedOMRows.splice(delInd, 1);
        this.selectedOMAnalyst = localList;
        // if(this.selectedOMAnalyst.length === 0){
        //     this.isOMPresent = true;
        // }else{
        //     this.isOMPresent = false;
        // }
      } else if (event.currentTarget.name === "ChannelFinance") {
        let delIndCF = this.preChannalFinanceRows.indexOf(item[0].id);
        this.preChannalFinanceRows.splice(delIndCF, 1);
        this.selectChannelFinance = localList;
        // if(this.selectedOMAnalyst.length === 0){
        //     this.isOMPresent = true;
        // }else{
        //     this.isOMPresent = false;
        // }
      }
      //this.notifyToSalesRepViewCmp();
    } catch (error) {
      console.log(error);
    }
  }

  createQuoteUserRequestApex(userRole) {
    let listOfUserRequest = [];
    let lstSelectedUser = [];
    if (userRole === "Sales Engineer") {
      lstSelectedUser = this.selectedUsersList;
    } else if (userRole === "OM Analyst") {
      lstSelectedUser = this.selectedOMAnalyst;
    } else if (userRole === "ChannelFinance") {
      lstSelectedUser = this.selectChannelFinance;
    }
    console.log(
      "this.selectedUsersList >>>>>" + JSON.stringify(lstSelectedUser)
    );
    for (let i of lstSelectedUser) {
      if (!i.qruId) {
        let quoteUserRequest = {};
        quoteUserRequest.objectApiName = "Quote_Request_User_2__c";
        quoteUserRequest.User__c = i.id;
        quoteUserRequest.Quote_Request__c = this.quoteRequest.Id;
        quoteUserRequest.User_Role__c = userRole;
        listOfUserRequest.push(quoteUserRequest);
      }
    }

    createQuoteUserRequest({ listofUser: listOfUserRequest })
      .then((result) => {
        if (result) {
          result.forEach((elem) => {
            if (elem.User_Role__c === "Sales Engineer") {
              // eslint-disable-next-line array-callback-return
              this.selectedUsersList.find((o, i) => {
                if (o.id === elem.User__c && !o.qruId) {
                  this.selectedUsersList[i].qruId = elem.Id;
                }
              });
              //this.preSelectedSERows.push(elem.User__c);
            } else if (elem.User_Role__c === "OM Analyst") {
              // eslint-disable-next-line array-callback-return
              this.selectedOMAnalyst.find((o, i) => {
                if (o.id === elem.User__c && !o.qruId) {
                  this.selectedOMAnalyst[i].qruId = elem.Id;
                }
              });
              //this.preSelectedOMRows.push(elem.User__c);
            } else if (elem.User_Role__c === "ChannelFinance") {
              // eslint-disable-next-line array-callback-return
              this.selectChannelFinance.find((o, i) => {
                if (o.id === elem.User__c && !o.qruId) {
                  this.selectChannelFinance[i].qruId = elem.Id;
                }
              });
            }
          });
        }
        let users = result;
        this.notifyChanges();
        //this.notifyToSalesRepViewCmp();
        this.preSelectedRows = [];
        this.preSelectedRowBackup = [];
        console.log("users" + JSON.stringify(users));
      })
      .catch((error) => {
        this.errorMsg = error;

        //alert(''+JSON.stringify(error))
      });
  }

  handleGetOMAnalyst() {
    this.masterList = [];
    this.users = [];
    this.showSpinner = true;
    this.showSEUser = false;
    this.showCFUser = false;
    this.addBtnDisabled = true;

    getUsersListForQRRoleAssignment({ userRole: "Finance Analyst" })
      .then((result) => {
        let uList = [];
        for (let user of result) {
          console.log("test user role", user);
          let u = {
            id: user.Id,
            name: user.Name,
            department: user.Department_Role__c,
            check: false
          };
          uList.push({ ...u });
          if (user.Id === this.quoteRequest.Offer_Management__c) {
            u.check = true;
          }
          this.users.push(u);
        }

        this.masterList = uList;

        this.showModal = true;
        this.showSpinner = false;
      })
      .catch((error) => {
        this.errorMsg = error;
        //alert(''+error)
      });
  }

  closeModal() {
    this.showModal = false;
    //this.preSelectedRows=this.preSelectedRowBackup;
    this.preSelectedRows = [];
    this.preSelectedRowBackup = [];
  }
  notifyChanges() {
    console.log("in notify changes");
    // to close modal set isModalOpen tarck value as false
    const custEvent = new CustomEvent("userdatachange", {});
    this.dispatchEvent(custEvent);
  }

  notifyToSalesRepViewCmp() {
    console.log("in notifyToSalesRepViewCmp changes");
    // to close modal set isModalOpen tarck value as false
    const custEvent = new CustomEvent("saleengineeromdatachange", {
      detail: {
        seEngineer: this.quoteRequest.Assigned_Solutions_Engineer1__r
          ? this.quoteRequest.Assigned_Solutions_Engineer1__r.Name
          : "",
        channelFinance: this.quoteRequest.Channel_Finance__r
          ? this.quoteRequest.Channel_Finance__r.Name
          : "",
        omAnalyst: this.quoteRequest.Offer_Management__r
          ? this.quoteRequest.Offer_Management__r.Name
          : ""
      }
    });
    this.dispatchEvent(custEvent);
  }
  onchangecompanyName(event) {
    this.companyEdit = event.detail.value;
  }

  updateOpportunityCustomerName() {
    // Create the recordInput object
    const fields = {};
    fields[ID_FIELD.fieldApiName] = this.quoteRequest.Id;
    fields[COMPANY_NAME.fieldApiName] = this.companyEdit;
    const recordInput = { fields };
    console.log(JSON.stringify(this.quoteRequest));
    updateRecord(recordInput)
      .then(async () => {
        console.log("Fields API", OPP_ID_FIELD, OPP_CUSTOMER_NAME);
        const oppFields = {};
        oppFields[OPP_ID_FIELD.fieldApiName] =
          this.quoteRequest.Related_Opportunity__c;
        oppFields[OPP_CUSTOMER_NAME.fieldApiName] = this.companyEdit;
        const oppRecordInput = { fields: oppFields };
        await updateRecord(oppRecordInput);
        console.log("Updated Opp object");
      })

      .catch((error) => {
        console.log("Error Message", error);
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error In Updating Status",
            message: error.message,
            variant: "error"
          })
        );
      });
  }

  handleLoaUpdateStart() {
    this.showSpinner = true;
  }

  handleLoaUpdateEnd() {
    this.showSpinner = false;
  }
}