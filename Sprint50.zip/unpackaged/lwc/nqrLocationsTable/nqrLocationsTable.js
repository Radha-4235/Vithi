import { LightningElement, api, track } from "lwc";
import getInitialLocations from "@salesforce/apex/NQRLocationsTableController.getInitialLocations";
import getMoreLocations from "@salesforce/apex/NQRLocationsTableController.getMoreLocations";
import getAllLocations from "@salesforce/apex/NQRLocationsTableController.getAllLocations";
import searchLocations from "@salesforce/apex/NQRLocationsTableController.searchLocations";
import nqrLocationsTableConfig from "c/nqrLocationsTableConfig";
import getQuoteRequestRatesList from "@salesforce/apex/NQRLocationsTableController.getQuoteRequestRatesList";
import updatePricingTierOfRate from "@salesforce/apex/NQRLocationsTableController.updatePricingTierOfRate";
import getTierPicklistValuesCall from "@salesforce/apex/NQRLocationsTableController.getTierPicklistValues";
import updatePricingTierOnBulkCall from "@salesforce/apex/NQRLocationsTableController.updatePricingTierOnBulk";
import markerIcon from "@salesforce/resourceUrl/MarkerIcon";
import fetchFieldLabels from "@salesforce/apex/QuoteOptionsController.getFieldLabels";
import fetchA3lookupCall from "@salesforce/apex/QuoteOptionsController.fetchA3LookupMap";
import QUOTE_REQUEST_RATES_OBJECT from "@salesforce/schema/Quote_Request_Rates__c";
import QUOTE_REQUEST_OBJECT from "@salesforce/schema/Quote_Request_2__c";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
// import getQRLocationDataFiltered from '@salesforce/apex/NQRLocationsTableController.getQRLocationDataFiltered';
// import getAllQRLocationData from '@salesforce/apex/NQRLocationsTableController.getAllQRLocationData';
import hassalesrep from "@salesforce/customPermission/A3_SalesRep_CRE";
import salesRepQrViewLoadCall from "@salesforce/apex/NewQuoteRequestHandler.salesRepQrViewLoad";
import spAppliedValueRefresh from "@salesforce/apex/NewQuoteRequestHandler.spAppliedValueChange";
import { getRecord, getFieldValue, updateRecord } from "lightning/uiRecordApi";
import ID_FIELD from "@salesforce/schema/Quote_Request_2__c.Id";
import Special_Pricing__Field from "@salesforce/schema/Quote_Request_2__c.Special_Pricing__c";
import getQuoteRequestRates from "@salesforce/apex/NQRLocationsTableController.getQuoteRequestRates";
import getRatesCall from "@salesforce/apex/NQRLocationsTableController.getRates";
import submitClosedWonCall from "@salesforce/apex/NQRLocationsTableController.submitClosedWon";
import { publish, createMessageContext } from "lightning/messageService";
import A3QuotingMessageChannel from "@salesforce/messageChannel/A3QuotingMessageChannel__c";
import getAllVendorsCall from "@salesforce/apex/NQRLocationsTableController.getAllVendors";

import getBulkPricingSpApplied from "@salesforce/apex/NQRLocationsTableController.getBulkPricingSpApplied";
const CLEAR_FILTERS_LABEL = "Clear Filters";
const SHOW_LESS_LABEL = "Show Less";

export default class NqrLocationsTable extends LightningElement {
  messageContext = createMessageContext();
  @api quoteRequestQuoteType;
  @api quoteRequestBusinessUnit;
  @api qrStatus;
  @api loggedInUser;
  @api surChargeCheckValue;
  showLoading = false;
  _quoteRequestId;
  _quoteOptionId;
  lastQrLocationId;
  srimage = markerIcon;
  isLoading = false;
  @track isOnCheckAll = false;
  @track onCheckAllStyle = 'check-box-style';
  isShowMore = false;
  @track qrLocationsData = [];
  totalErrors = 0;
  prodTierMap = {};
  @api showPricingModal;
  @track showPricingTier;
  @track pricingTierResetAllFlag = false;
  @track prodTierVals = [];
  @track loadSpinner = false;
  @track qrrObjPrefix;
  locationMap = new Map();
  @track selectedqloGUIIds = new Set();
  locationProdSizeMap = new Map();
  @track showSubmitClosedWon = false;

  @track responseJSON;
  @track isSelected = false;
  @track expandAll = false;
  @track showvendorbox = false;
  @track spApllied;

  @track prodVendorObj = {};
  @track showVendorModal = false;

  get qrStatusPendingPrice() {
    console.log("QR Status: ", this.qrStatus);
    return this.qrStatus === "Pending Pricing";
  }

  get qrStatusClosedWon() {
    console.log("QR Status: ", this.qrStatus);
    return this.qrStatus !== "Closed - WON";
  }

  get qrLocationDataPaginationComplete() {
    if (this.filteredQRLocations.length >= this.totalRecords) {
      return true;
    } else {
      return false;
    }
  }

  get displayGenerateQuote() {
    return hassalesrep;
  }

  get displayeditPricingTier() {
    return true;
  }

  get displayeditmrc() {
    let showFlag = false;
    if (this.loggedInUser && this.loggedInUser.userType == "SplPricing" || this.loggedInUser.userType == 'SplPricingManager' 
        || this.loggedInUser.userType == 'OMAnalyst' || this.loggedInUser.userType == 'OMAnalystManager'  ||
        this.loggedInUser.userType == 'ChannelsQuoter') {
      showFlag = true;
    }
    return showFlag;
  }


  @track filteredQRLocations = [];
  filters = {};
  locationPageSize = 0;
  hasServerSideFilterRun = false;
  totalRecords = 0;
  totalDisplayedRecords = 0;
  oldTimeoutRef = [];

  _isSubmittedQuote;

  @api get isSubmittedQuote() {
    return this._isSubmittedQuote;
  }
  set isSubmittedQuote(value) {
    this._isSubmittedQuote = value;
  }

  _isPendingSpOrSeReview;

  @api get isPendingSpOrSeReview() {
    return this._isPendingSpOrSeReview;
  }
  set isPendingSpOrSeReview(value) {
    console.log("isPendingSpOrSeReview value::" + value);
    this._isPendingSpOrSeReview = value;
  }

  get showLessLabel() {
    if (this.hasServerSideFilterRun === true) {
      return CLEAR_FILTERS_LABEL;
    } else {
      return SHOW_LESS_LABEL;
    }
  }

  isSurchargeColVisible = false;
  isCurrentTotalColVisible = false;
  isSavingAmountColVisible = false;
  isSavingPercentageColVisible = false;
  isIpMRCColVisible = false;
  isEquipMRCColVisible = false;
  isEquipNRCColVisible = false;
  isEquipCostColVisible = false;
  isCOSMRCColVisible = false;
  isCOSCostColVisible = false;
  isTotalMRCColVisible = false;
  isCircuitMRCColVisible = false;
  isFeatureMRCColVisible = false;
  isGCNRCPriceColVisible = false;
  isGCMRCPriceColVisible = false;
  isOnNetColVisible = false;
  isVendorColVisible = false;
  isActivationColVisible = false;
  isGroupNameColVisible = false;
  isCityColVisible = false;
  isStatesColVisible = false;
  isZipColVisible = false;
  isLocationNameColVisible = false;
  isBuildingAptColVisible = false;
  isFloorSuiteColVisible = false;
  isNpanxxColVisible = false;
  isGLCodeColVisible = false;
  isLocStoreColVisible = false;
  isPICCColVisible = false;

  allowMRCCalculation = false;
  showMRCBox = false;
  showPricingTier = false;
  showvendorbox = false;
  productIds = [];
  selectedLocationIds;
  finalProdArray = [];
  mapMRC = new Map();
  vendormap = new Map();
  qlovendormap = new Map();
  qloIds = [];
  @track selectedLocationsRecords = [];
  @track selectedProdLoacMap = new Map();
  selectedProdId = [];
  selectedLocationsInSelectedProducts = [];

  @track configWrap;

  prodMap = new Map([
    ["BROADBAND", "BB"],
    ["GUARDIAN", "GDN"],
    ["GUARDIAN SERVICES", "GDN"],
    ["NETWORK INTEGRATION", "NI"]
  ]);

  @api get quoteRequestId() {
    return this._quoteRequestId;
  }
  set quoteRequestId(value) {
    this._quoteRequestId = value;
  }

  @api get quoteOptionId() {
    return this._quoteOptionId;
  }
  set quoteOptionId(value) {
    this._quoteOptionId = value;
  }

  @api get selectedColumns() {
    return this._selectedColumns;
  }
  set selectedColumns(value) {
    this._selectedColumns = value;

    if (value && typeof value === "object" && value.length > 0) {
      value.forEach((column) => {
        switch (column) {
          case "currenttotal": {
            if (this.quoteRequestQuoteType == "Comparison") {
              /*if(!(this.loggedInUser && this.loggedInUser.lstPermissionSet 
                                             && (this.loggedInUser.lstPermissionSet.includes('SalesRep') 
                                                || this.loggedInUser.lstPermissionSet.includes('Premeir') || this.loggedInUser.lstPermissionSet.includes('ChannelsSalesRep')
                                                || this.loggedInUser.lstPermissionSet.includes ('ChannelsQuoter')|| this.loggedInUser.lstPermissionSet.includes ('ChannelsDirector')
                                                || this.loggedInUser.lstPermissionSet.includes ('ChannelsSalesEng')|| this.loggedInUser.lstPermissionSet.includes ('ChannelsSalesRepEng')
                                                || this.loggedInUser.lstPermissionSet.includes ('ChannelsSupport')))){*/
              this.isCurrentTotalColVisible = true;
            }
            break;
          }
          case "savingamount": {
            if (this.quoteRequestQuoteType == "Comparison") {
              this.isSavingAmountColVisible = true;
            }
            break;
          }

          case "savingpercentage": {
            if (this.quoteRequestQuoteType == "Comparison") {
              this.isSavingPercentageColVisible = true;
            }
            break;
          }
          case "surcharge": {
            if (this.surChargeCheckValue) {
              console.log("NQR Sur charge : ", this.surChargeCheckValue);
              this.isSurchargeColVisible = true;
            }
            break;
          }
          case "ipmrcrate": {
            this.isIpMRCColVisible = true;
            break;
          }
          case "equipmrcrate": {
            this.isEquipMRCColVisible = true;
            break;
          }
          case "equipnrcrate": {
            this.isEquipNRCColVisible = true;
            break;
          }
           case "equipcost": {
            if (
              this.loggedInUser &&
              this.loggedInUser.lstPermissionSet &&
              (
                this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
                this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
                this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter"))
            ) {
              this.isEquipCostColVisible = true;
            }
            break;
           }
          case "cosmrc": {
            this.isCOSMRCColVisible = true;
            break;
          }
           case "coscost": {
              this.isCOSCostColVisible = true;
            break;
          }
          case "totalmrc": {
            this.isTotalMRCColVisible = true;
            break;
          }
          case "circuitmrc": {
            this.isCircuitMRCColVisible = true;
            break;
          }
          case "featuremrc": {
            this.isFeatureMRCColVisible = true;
            break;
          }
          
          case "picc": {
            this.isPICCColVisible = true;
            break;
          }
         case "gcnrc": {            
              this.isGCNRCPriceColVisible = true;
            break;
          }
          case "gcmrc": {
              this.isGCMRCPriceColVisible = true;
            break;
          }
          case "onnet": {
            this.isOnNetColVisible = true;
            break;
          }
          case "vendor": {
            this.isVendorColVisible = true;
            break;
          }
          case "activation": {
            this.isActivationColVisible = true;
            break;
          }
          case "groupname": {
            this.isGroupNameColVisible = true;
            break;
          }
          case "city": {
          this.isCityColVisible = true;
          break;
        }
         case "state": {
          this.isStatesColVisible = true;
          break;
        }
         case "zip": {
          this.isZipColVisible = true;
          break;
        }
          case "locationname": {
            this.isLocationNameColVisible = true;
            break;
          }
          case "buildingApt": {
            this.isBuildingAptColVisible = true;
            break;
          }
          case "floorSuite": {
            this.isFloorSuiteColVisible = true;
            break;
          }
          case "npanxx": {
            this.isNpanxxColVisible = true;
            break;
          }
          case "glcCode": {
            this.isGLCodeColVisible = true;
            break;
          }
          case "locationStoreNum": {
            this.isLocStoreColVisible = true;
            break;
          }
        }
      });
    }
  }

  connectedCallback() {
    console.log("in locations and Product NQR::");
    let defaultColumns = [];

    nqrLocationsTableConfig
      .getColumns(this.isSubmittedQuote, this.isPendingSpOrSeReview)
      .forEach((column) => {
        if (column.checked === true) {
          defaultColumns.push(column.value);
        }
      });

    this.selectedColumns = defaultColumns;

    this.initializeTable();
  }

  initializeTable() {
    this.clearFilters();
    console.log("in initialize locations");
    this.isShowMore = false;
    this.expandAll = false;
    this.selectedqloGUIIds.clear();
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    getInitialLocations({ qoId: this._quoteOptionId,userPermList: permissions })
      .then((response) => {
        this.totalRecords = response.totalLocations;
        this.lastQrLocationId = response.lastLocationId;
        this.pushQRLocationsData(response.locations, true);
        this.qrrObjPrefix = response.qrrObjectPrefix;
      })
      .catch((error) => {
        console.log("error ==> " + JSON.stringify(error));
      });
    let qloGuiIds = Array.from(this.selectedqloGUIIds).join(',');
    console.log(qloGuiIds);
    this.dispatchEvent(
      new CustomEvent("seleclocationsandprod", {
        detail: {
        locandprod: this.locationMap,selectedGUIIds : qloGuiIds
        }
      })
    );
  }

  loadMoreLocations() {
    this.hasServerSideFilterRun = false;
    this.isShowMore = true;
    this.expandAll = false;
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    getMoreLocations({
      quoteOptionId: this._quoteOptionId,
      lastLocationId: this.lastQrLocationId,
      userPermList: permissions
    })
      .then((response) => {
        this.lastQrLocationId = response.lastLocationId;
        this.pushQRLocationsData(response.locations, false);
        this.qrrObjPrefix = response.qrrObjectPrefix;
      })
      .catch((error) => {
        console.log("error ==> " + JSON.stringify(error));
      });
  }

  onFilterChange() {
    this.debounce(this.applyFilters);
  }

  applyFilters(context) {
    context.hasServerSideFilterRun = false;
    if (context) {
      let filterInputs = context.template.querySelectorAll("lightning-input");
      context.filters = {};

      if (filterInputs) {
        filterInputs.forEach((input) => {
          if (input.value) {
            context.filters[input.name] = input.value;
          }
        });
      }

      // console.log('Updated filters: ' + JSON.stringify( context.filters ));

      if (JSON.stringify(context.filters).length > 2) {
        context.filteredQRLocations = [];
        context.hasServerSideFilterRun = true;
        context._getQRLocationDataFiltered();
      } else {
        context.refreshTable();
      }
      context.totalDisplayedRecords = context.filteredQRLocations.length;
      context.populateCheckboxes();
    }
  }

  populateCheckboxes() {
    setTimeout(() => {
      let inputs = this.template.querySelectorAll("lightning-input");

      if (inputs) {
        inputs.forEach((input) => {
          if (input.type == "checkbox") {
            this.qrLocationsData.forEach((location) => {
              if (input.name === location.Id) {
                input.checked = location.isChecked;
                return;
              }
            });
          }
        });
      } else {
        this.populateCheckboxes();
      }
    }, 100);
  }

  pushQRLocationsData(locations, isNew) {
    let updatedQRLocationsData =
      isNew === true ? [] : JSON.parse(JSON.stringify(this.qrLocationsData));
    if (this.isShowMore === false) {
      console.log("Show More false : ", this.isShowMore);
      this.totalErrors = 0;
    }
    let hasGSEPIP = false;
    let hasPOTS = false;
    let hasEquipment = false;
    let hasVoipEpotsGuardian = false;
    let selLocSize = 0;
    let fullCheckCnt = 0;
    let locSize = 0;
    for (const locationId in locations) {
      locSize++;
      let productStringName = locations[locationId].productString;
      if (
        (productStringName.match("GSE") || productStringName.match("PIP")) &&
        this.qrStatus != "Unsubmitted"
      ) {
        if (!hasGSEPIP) {
          hasGSEPIP = true;
          if (hasGSEPIP) {
            this.isCOSMRCColVisible = true;
             }
        }
      } else {
        this.isCOSMRCColVisible = false;
      }
       if ((productStringName.match("VOIP") || productStringName.match("GDN")
       || productStringName.match("EPOTS")) && this.qrStatus != "Unsubmitted") {
        if (!hasVoipEpotsGuardian) {
          hasVoipEpotsGuardian = true;
          if (hasVoipEpotsGuardian) {
            this.isFeatureMRCColVisible = true;
          }
        }
      } else {
        this.isFeatureMRCColVisible = false;
      }

      if (productStringName.match("POTS") && this.qrStatus != "Unsubmitted") {
        if (!hasPOTS) {
          hasPOTS = true;
          if (hasPOTS) {
            this.isPICCColVisible = true;
          }
        }
      } else {
        this.isPICCColVisible = false;
      }

      if (
        productStringName.match("EQUIPMENT") &&
        this.qrStatus != "Unsubmitted"
      ) {
        if (!hasEquipment) {
          hasEquipment = true;
          if (hasEquipment) {
            this.isEquipNRCColVisible = true;
          }
        }
      } else {
        this.isEquipNRCColVisible = false;
      }
      let locationData = locations[locationId].locationDetails;
      if(this.filters['Products']){
        let filteredValue = this.filters['Products'].toLowerCase();
        const prodMap = {
                            'BROADBAND': 'BB',
                            'GUARDIAN': 'GDN',
                            'GUARDIAN SERVICES': 'GDN',
                            'NETWORK INTEGRATION': 'NI'
                        };
        locationData.products = locations[locationId].products.filter((prod) => {
          let productD = prod.Product__c.toUpperCase();
          let mappedValue = prodMap[productD];
          if (!mappedValue) {
              mappedValue = productD; 
          }
          if (mappedValue == 'VOIP') {
              return (prod.Product_Detail1__c.toLowerCase().includes(filteredValue)
                          ||mappedValue.toLowerCase().includes(filteredValue));
          } else if (mappedValue == 'GDN') {
              return (prod.Access_Type_Description__c.toLowerCase().includes(filteredValue)
                          || mappedValue.toLowerCase().includes(filteredValue));
          } else if (mappedValue == 'MOBILITY') {
              return (prod.Product_Type__c.toLowerCase().includes(filteredValue)
                          || mappedValue.toLowerCase().includes(filteredValue));
          } else {
              return mappedValue.toLowerCase().includes(filteredValue);
          }
        }); 
        let filteredList = locationData.products.map((prod) => {
          let productD = prod.Product__c.toUpperCase();
          let mappedValue = prodMap[productD];
          if (!mappedValue) {
            mappedValue = productD;
          }
          return mappedValue;
        }).join(',');
        locationData.productsString = Array.from(new Set(filteredList.split(','))).join(',');
      } else {
        locationData.products = locations[locationId].products;
        locationData.productsString = locations[locationId].productString; 
      } 
      //locationData.products = locations[locationId].products;
	   locationData.qloQOI = locations[locationId].qloQOI;
      if (this.isOnCheckAll) {
        //locationData.isChecked = true;
      } else {
        //locationData.isChecked = false;
      }
      locationData.showProducts = false;
      //locationData.productsString = locations[locationId].productString;
      locationData.vendorsString = locations[locationId].vendorString;
      locationData.activationCost =
        locations[locationId].costSummary?.activationCost;
      //    if(productStringName.match("POTS")){
      //         locationData.circuitmrc = locations[ locationId ].costSummary?.flatrate;
      //     }else{
      locationData.circuitmrc = locations[locationId].costSummary?.circuitmrc;
      //}
      locationData.featuremrc = locations[locationId].costSummary?.featuremrc;
      locationData.ipmrcrate = locations[locationId].costSummary?.ipmrcrate;
      locationData.equipmrcrate =
        locations[locationId].costSummary?.equipmrcrate;
      locationData.equipcost = locations[locationId].costSummary?.equipcost;
      locationData.cosmrc =
        locations[locationId].productString == "BB" ||
        locations[locationId].productString == "DIA" ||
        locations[locationId].productString == "EPIK" ||
        locations[locationId].productString == "POTS" ||
        locations[locationId].productString == "GDN"
          ? "NA"
          : locations[locationId].costSummary?.cosmrc;
      locationData.coscost =
        locations[locationId].productString == "BB" ||
        locations[locationId].productString == "DIA" ||
        locations[locationId].productString == "EPIK" ||
        locations[locationId].productString == "POTS" ||
        locations[locationId].productString == "GDN"
          ? "NA"
          : locations[locationId].costSummary?.coscost;
      locationData.currenttotal =
        locations[locationId].costSummary?.currenttotal;
      locationData.surcharge = locations[locationId].costSummary?.surcharge;
      locationData.gcmrc = locations[locationId].costSummary?.gcmrc;
      locationData.gcnrc = locations[locationId].costSummary?.gcnrc;
      locationData.totalmrc = locations[locationId].costSummary?.totalmrc;
      locationData.savingamount =
        locations[locationId].costSummary?.savingamount;
      locationData.savingpercentage =
        locationData.currenttotal > 0
          ? (locationData.savingamount / locationData.currenttotal) * 100
          : 0;
      (locationData.className =
        locationData.savingamount < 0 ? "red-color" : "default-label"),
        (locationData.classSave =
          locationData.savingpercentage < 0 ? "red-color" : "default-label"),
        (locationData.equipnrcrate =
          locations[locationId].costSummary?.equipnrcrate);
      locationData.picc = locations[locationId].costSummary?.picc;
      locationData.readOnly =
        this.qrStatus === "Pending Pricing"
          ? locations[locationId].costSummary?.activationCost != null &&
            locations[locationId].costSummary?.activationCost != 0
          : true;
      locationData.recError = locations[locationId].costSummary?.recError;

      if(locations[locationId].hasAllProdsCerified){
        //locationData.locCheckBoxStyleCls = "check-box-style";
        locationData.locCertifiedColorIndicator = "colorOrangeIndicator";
		    locationData.indicatorColorTitle = 'Location(s) and or Product(s) Certified';
        //locationData.showCertifiedLocation = true;
        //locationData.isChecked = true;
        //this.showSubmitClosedWon = true;
        locationData.checkedType = 'All';
        selLocSize++;
        fullCheckCnt++;
      }
      else if(locations[locationId].hasPartialProdsCerified){
        //locationData.locCheckBoxStyleCls = "check-box-style1";
        locationData.locCertifiedColorIndicator = "colorBlueIndicator";
		    locationData.indicatorColorTitle = 'Location(s) is partially Certified';
        //locationData.isChecked = true;
        locationData.checkedType = 'Partial';
        selLocSize++;
      }
      else{
        //locationData.locCheckBoxStyleCls = "check-box-style";
		    locationData.locCertifiedColorIndicator = "";
        //locationData.isChecked = false;
        locationData.checkedType = 'All';
      }

      locationData.addressError =
        locations[locationId].costSummary?.addressError;
      locationData.spapplied = locations[locationId].costSummary?.spapplied;
      console.log("location data SP APplied +++: ", locationData.spapplied);
      console.log("locationData.recError++" + locationData.recError);

      updatedQRLocationsData.push(locationData);
      if (locationData.recError) {
        // if(this.isShowAll){
        //     this.totalErrors = this.totalRecords;
        // }else{
        this.totalErrors += locationData.recError;
        //}
      }
    }

    /*if(selLocSize == locSize){
      this.isOnCheckAll = true;
      if(fullCheckCnt == locSize){
        this.onCheckAllStyle = 'check-box-style';
      }
      else{
        this.onCheckAllStyle = 'check-box-style1';
      }
    }*/

    const custEvent = new CustomEvent("callpasstoparent", {
      detail: this.totalErrors
    });
    console.log(" this.totalErrors++" + this.totalErrors);
    this.dispatchEvent(custEvent);
    this.qrLocationsData = JSON.parse(JSON.stringify(updatedQRLocationsData));
    this.filteredQRLocations = JSON.parse(
      JSON.stringify(updatedQRLocationsData)
    );
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
    console.log("all locationsss==> " + JSON.stringify(updatedQRLocationsData));
    this.totalDisplayedRecords = this.filteredQRLocations.length;
  }
  // dispatching event by passing location Id to locations and products for Individual location view
  openSingleLocationProductsView(event) {
    let locationId = event.target.dataset.recordId;
    let location = this.filteredQRLocations.find(
      (locationItem) => locationItem.Id == locationId
    );
    console.log(location);
    this.dispatchEvent(
      new CustomEvent("opensinglelocationproductsview", {
        detail: {
          clickedLocation: location
        }
      })
    );
  }
  getOnNet(prods) {
    let onnet = "";
    if (prods) {
      prods.forEach((elem) => {
        onnet += elem.On_Net__c
          ? onnet == ""
            ? elem.On_Net__c
            : ", " + elem.On_Net__c
          : "";
      });
    }
    return onnet;
  }

  getVendor(prods) {
    let vendor = "";
    if (prods) {
      prods.forEach((elem) => {
        vendor += elem.Vendor__c
          ? vendor == ""
            ? elem.Vendor__c
            : ", " + elem.Vendor__c
          : "";
      });
    }
    return vendor;
  }

  getActivation(prods) {
    let activation = "";
    if (prods) {
      prods.forEach((elem) => {
        activation += elem.Activation__c
          ? activation == ""
            ? elem.Activation__c
            : ", " + elem.Activation__c
          : "";
      });
    }
    return activation;
  }

  getCurrentTotalPrice(prods) {
    let currenttotal = "";
    if (prods) {
      prods.forEach((elem) => {
        currenttotal += elem.Current_Total__c
          ? currenttotal == ""
            ? elem.Current_Total__c
            : ", " + elem.Current_Total__c
          : "";
      });
    }
    return currenttotal;
  }

  getSurcharge(prods) {
    let surcharge = "";
    if (prods) {
      prods.forEach((elem) => {
        surcharge += elem.Surcharge__c
          ? surcharge == ""
            ? elem.Surcharge__c
            : ", " + elem.Surcharge__c
          : "";
      });
    }
    return surcharge;
  }

  getIpMRCPrice(prods) {
    let ipmrc = "";
    if (prods) {
      prods.forEach((elem) => {
        ipmrc += elem.IP_MRC_Rate__c
          ? ipmrc == ""
            ? elem.IP_MRC_Rate__c
            : ", " + elem.IP_MRC_Rate__c
          : "";
      });
    }
    return ipmrc;
  }
  getEquipMRCPrice(prods) {
    let equipmrc = "";
    if (prods) {
      prods.forEach((elem) => {
        equipmrc += elem.Default_Router_Rate__c
          ? equipmrc == ""
            ? elem.Default_Router_Rate__c
            : ", " + elem.Default_Router_Rate__c
          : "";
      });
    }
    return equipmrc;
  }
  getEquipCostPrice(prods) {
    let equipcost = "";
    if (prods) {
      prods.forEach((elem) => {
        equipcost += elem.Default_Router_Cost__c
          ? equipcost == ""
            ? elem.Default_Router_Cost__c
            : ", " + equipcost.Default_Router_Cost__c
          : "";
      });
    }
    return equipcost;
  }

  getCOSMRCPrice(prods) {
    let cosmrc = "";
    if (prods) {
      prods.forEach((elem) => {
        cosmrc += elem.COS_MRC__c
          ? cosmrc == ""
            ? elem.COS_MRC__c
            : ", " + elem.COS_MRC__c
          : "";
      });
    }
    return equipmrc;
  }
  getCOSCostPrice(prods) {
    let coscost = "";
    if (prods) {
      prods.forEach((elem) => {
        coscost += elem.COS_Cost__c
          ? coscost == ""
            ? elem.COS_Cost__c
            : ", " + equipcost.COS_Cost__c
          : "";
      });
    }
    return equipcost;
  }

  getTotalMRCPrice(prods) {
    let totalmrc = "";
    if (prods) {
      prods.forEach((elem) => {
        totalmrc += elem.Total_MRC__c
          ? totalmrc == ""
            ? elem.Total_MRC__c
            : ", " + elem.Total_MRC__c
          : "";
      });
    }
    return totalmrc;
  }
  getSavingAmount(prods) {
    let savingamount = "";
    if (prods) {
      prods.forEach((elem) => {
        savingamount += elem.Saving_Amount__c
          ? savingamount == ""
            ? elem.Saving_Amount__c
            : ", " + elem.Saving_Amount__c
          : "";
      });
    }
    return savingamount;
  }

  getSavingPercentage(prods) {
    let savingpercentage = "";
    if (prods) {
      prods.forEach((elem) => {
        savingpercentage += elem.Saving_Percentage__c
          ? savingpercentage == ""
            ? elem.Saving_Percentage__c
            : ", " + elem.Saving_Percentage__c
          : "";
      });
    }
    return savingpercentage;
  }
  getCircuitMRCPrice(prods) {
    let circuitmrc = "";
    if (prods) {
      prods.forEach((elem) => {
        circuitmrc += elem.Circuit_MRC_Rate1__c
          ? circuitmrc == ""
            ? elem.Circuit_MRC_Rate1__c
            : ", " + elem.Circuit_MRC_Rate1__c
          : "";
      });
    }
    return circuitmrc;
  }
   getFeatureMRCPrice(prods) {
    let featuremrc = "";
    if (prods) {
      prods.forEach((elem) => {
        featuremrc += elem.Feature_MRC__c
          ? featuremrc == ""
            ? elem.Feature_MRC__c
            : ", " + elem.Feature_MRC__c
          : "";
      });
    }
    return featuremrc;
  }

  getProductNamesString(prods) {
    let productsSet = [];
    let _prodStr = "";

    if (prods) {
      prods.forEach((elem) => {
        let hasShortName = false;
        for (let [key, value] of this.prodMap) {
          let prodVal = elem.Product__c ? elem.Product__c.toUpperCase() : "";
          if (prodVal && key == prodVal) {
            productsSet.push(value);
            hasShortName = true;
            break;
          }
        }
        if (!hasShortName) {
          productsSet.push(elem.Product__c);
        }
      });
      productsSet.sort();
      _prodStr = "";
      for (let i = 0; i < productsSet.length; i++) {
        if (i == 0) {
          _prodStr = productsSet[i];
        } else if (i < 4) {
          _prodStr = _prodStr + ", " + productsSet[i];
        } else {
          _prodStr = _prodStr + "...";
          break;
        }
      }
    }
    return _prodStr;
  }

  _getQRLocationDataFiltered() {
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    searchLocations({
      quoteOptionId: this._quoteOptionId,
      filters: this.filters,
      userPermList: permissions
    })
    .then((response) => {
      this.totalRecords = response.totalLocations;
      this.pushQRLocationsData(response.locations, true);
    })
    .catch((error) => {
      console.log(
        "_getQRLocationDataFiltered error ==> " + JSON.stringify(error)
      );
    });
  }

  handleUpdatecurrentTotal(event) {
    this.dispatchEvent(
      new CustomEvent("updatecurrenttotal", {
        detail: { enableGenerateQuote: event.detail.enableGenerateQuote }
      })
    );
  }

  handleRefreshEvent(event) {
    let locationId = event.detail.locationId;
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    getInitialLocations({ qoId: this._quoteOptionId,userPermList: permissions })
    .then((response) => {
      this.refreshLocationHandler(response.locations);
      
      if(locationId){
        let locIds = [];
        locIds.push(locationId);
        let productIds = this.getProducts(locIds);
        this.expandApexCall(locIds,productIds,true,'Refresh');
      }
    })
    .catch((error) => {
      console.log("error ==> " + JSON.stringify(error));
    });
  }

  refreshLocationHandler(locations) {
    let updatedQRLocationsData = [];
    try {
      for (const i in this.filteredQRLocations) {
        let locationId = this.filteredQRLocations[i].Id;
        let productStringName = locations[locationId].productString;
        if (locations[locationId]) {
          let locationData = JSON.parse(
            JSON.stringify(this.filteredQRLocations[i])
          );
          locationData.vendorsString = locations[locationId].vendorString;
          locationData.activationCost =
            locations[locationId].costSummary?.activationCost;
          // if(productStringName.match("POTS")){
          //     locationData.circuitmrc = locations[ locationId ].costSummary?.flatrate;
          // }else{
          locationData.circuitmrc =
            locations[locationId].costSummary?.circuitmrc;
          // }
          locationData.featuremrc = locations[locationId].costSummary?.featuremrc;
          locationData.ipmrcrate = locations[locationId].costSummary?.ipmrcrate;
          locationData.equipmrcrate =
            locations[locationId].costSummary?.equipmrcrate;
          locationData.equipcost = locations[locationId].costSummary?.equipcost;
          locationData.cosmrc = locations[locationId].costSummary?.cosmrc;
          locationData.coscost = locations[locationId].costSummary?.coscost;
          locationData.currenttotal =
            locations[locationId].costSummary?.currenttotal;
          locationData.surcharge = locations[locationId].costSummary?.surcharge;
          locationData.gcmrc = locations[locationId].costSummary?.gcmrc;
          locationData.gcnrc = locations[locationId].costSummary?.gcnrc;
          locationData.totalmrc = locations[locationId].costSummary?.totalmrc;
          locationData.savingamount =
            locations[locationId].costSummary?.savingamount;
          locationData.savingpercentage =
            (locationData.savingamount / locationData.currenttotal) * 100;
          locationData.equipnrcrate =
            locations[locationId].costSummary?.equipnrcrate;
          locationData.picc = locations[locationId].costSummary?.picc;
          locationData.spapplied = locations[locationId].costSummary?.spapplied;
          updatedQRLocationsData.push(locationData);
        }
      }
    } catch (err) {
      console.log(err);
    }

    this.qrLocationsData = JSON.parse(JSON.stringify(updatedQRLocationsData));
    this.filteredQRLocations = JSON.parse(
      JSON.stringify(updatedQRLocationsData)
    );
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
    console.log("this.filteredQRLocations++", this.filteredQRLocations);
    this.totalDisplayedRecords = this.filteredQRLocations.length;
  }

  updateChildExpand(locationId, productIds) {
    let isSelected = false;
    if (this.isSubmittedQuote) {
      if (
        typeof this.selectedLocationsRecords != "undefined" &&
        this.selectedLocationsRecords.length > 0
      ) {
        for (let i = 0; i < this.selectedLocationsRecords.length; i++) {
          if (this.selectedLocationsRecords[i].Id == locationId) {
            isSelected = true;
          }
        }
      }
    }
    setTimeout(() => {
      let expnddChldrn = this.template.querySelectorAll("c-child-expand");

      if (expnddChldrn && expnddChldrn.length > 0) {
        expnddChldrn.forEach((child) => {
          child.getRatesData(locationId, productIds, isSelected);
        });
      } else {
        this.updateChildExpand(locationId, productIds);
      }
    }, 100);
  }

  permissionCheck(permissionList){
    let permissionExisted = false;
    let userPermissionsList = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    for(let i=0;i<permissionList.length;i++){
      let perm = permissionList[i];
      if(userPermissionsList.includes(perm)){
        permissionExisted = true;
        break;
      }
    } 

    return permissionExisted;
  }

  expandCollapseClick(event){
    let actionName = event.target.name;
    let expandAll = (actionName == 'Expand All') ? true : false;
    
    let locIds = [];
    let productIds = [];
    this.filteredQRLocations.forEach((location) => {
      locIds.push(location.Id);
      location.products.forEach((product) => {
        productIds.push(product.Id);
      });
      this.locationProdSizeMap.set(location.Id,productIds.length);
    });

    if(expandAll){
      this.expandApexCall(locIds,productIds,expandAll,'OnLoad');
    }
    else{
      this.collapseAll(expandAll);
    }
  }

  expandApexCall(locIds,productIds,expandAll,actionName){
     let permissionsList = ["SalesRep","GRID_SalesRep","SalesRepManager","ChannelSalesRep","ChannelSalesRepManager","SplPricing",
                          "OMAnalyst","OMAnalystManager","ChannelSalesEng","ChannelsDirector","ChannelsQuoter",
                          "ChannelsSupport","SplPricingManager","Premier","SalesEng","SalesEngManager"];
    let permExisted = this.permissionCheck(permissionsList);  

    let permissions = permExisted ? this.loggedInUser.lstPermissionSet : [];

    this.isLoading = true;
    getRatesCall({qrId:this.quoteRequestId,locIdList:locIds,userPermList: permissions,lstQoiId:productIds})
    .then((response) => {
        if(response){
          this.expandLocations(response,locIds,expandAll,actionName);
          this.isLoading = false;
        }
      })
      .catch((error) => {
        this.isLoading = false;
        console.log("getRatesData error ==>" + JSON.stringify(error));
    });
  }

  expandLocations(response,locIds,expandAll,actionName) {
    let resp = JSON.parse(response);
    this.configWrap = resp.configWrap;
    let allLocMap = resp.locWrap;
    let allQoiMap = resp.allQoiMap;
    let qloProdIdMap = resp.qloProdIdMap;
    
    let locsSize = 0;
    let expandLocsSize = 0;
    let updatedQRLocations = [];
    let productIds = [];
    let isExpanded = false;
    let currentQRLocation = {};
    this.filteredQRLocations.forEach((location) => {
      locsSize++;
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if(locIds.includes(location.Id)){
        updatedLocation.showProducts = true;
        if(allLocMap[location.Id]){
          updatedLocation['qoiVendorsMap'] = allLocMap[location.Id].qoiVendorsMap;
          updatedLocation['qoiRatesMap'] = allLocMap[location.Id].qoiRatesMap;
          updatedLocation['childQoiRateMap'] = allLocMap[location.Id].childQoiRateMap;
        }
        let dwnSpeedWrapperList = [];
        if(resp.mapQrrDwnSpeedWrapper && resp.mapQrrDwnSpeedWrapper[location.Id]){
          resp.mapQrrDwnSpeedWrapper[location.Id].forEach((dwnSpeedWrapper)=>{
          dwnSpeedWrapperList.push(dwnSpeedWrapper);  
        });
        }
        updatedLocation['dwnSpeedWrapperList'] = dwnSpeedWrapperList;
        let qoiList = [];
        updatedLocation.products.forEach((product) => {
          if(allQoiMap[product.Id]){
            qoiList.push(allQoiMap[product.Id]);
          }
        });
        updatedLocation['qoiList'] = qoiList;
        updatedLocation['qloProdIdMap'] = qloProdIdMap;
        currentQRLocation = updatedLocation;
      }
      if(updatedLocation.showProducts == true){
        expandLocsSize++;
      }
      updatedQRLocations.push(updatedLocation);
    });

    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.expandAll = locsSize == expandLocsSize ? true : false;
    
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );

    if(actionName == 'Refresh'){
      const objChild = this.template.querySelectorAll('c-child-expand');
      if(objChild){
        objChild.forEach(element => {
          if(locIds.includes(element.locationId)){
            element.refreshChildData(this.configWrap,currentQRLocation.qoiList,
                                    currentQRLocation.qoiVendorsMap,currentQRLocation.qoiRatesMap,currentQRLocation.childQoiRateMap,currentQRLocation.qloProdIdMap);
          }
        });  
      }
    }
  }

  collapseAll(expandAll){
    let updatedQRLocations = [];
    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      updatedLocation.showProducts = false;
      updatedQRLocations.push(updatedLocation);
    });

    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.expandAll = false;
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
  }

  collapseSelectedLocation(locId){
    let locsSize = 0;
    let collapseLocsSize = 0;
    let updatedQRLocations = [];
    this.filteredQRLocations.forEach((location) => {
      locsSize++;
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if (locId === location.Id) { 
        updatedLocation.showProducts = false;
      }
      if(updatedLocation.showProducts == false){
        collapseLocsSize++;
      }
      updatedQRLocations.push(updatedLocation);
    });
    this.expandAll = locsSize == collapseLocsSize ? false : true;
    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
  }

  hideProductsOnExpand(locationId) {
    let updatedQRLocations = [];
    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if (locationId === location.Id) {
        updatedLocation.showProducts = false;
      }
      updatedQRLocations.push(updatedLocation);
    });

    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
  }

  showProductsOnExpand(locationId) {
    let updatedQRLocations = [];
    let productIds = [];
    let isExpanded = false;

    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if (locationId === location.Id) {
        updatedLocation.showProducts = true;
        updatedLocation.products.forEach((product) => {
          productIds.push(product.Id);
        });
        isExpanded = updatedLocation.showProducts;
      }
      updatedQRLocations.push(updatedLocation);
    });

    if (isExpanded === true) {
      let isSelected = false;
      if (this.isSubmittedQuote && this.selectedLocationIds && this.selectedLocationIds.incudes(locationId)){
        isSelected = true;
      }
      //this.showLoading = true;
      this.getRatesData(locationId, productIds,isSelected,updatedQRLocations);
      //this.showLoading = false;
    }
  }

  getRatesData(locationId, productIds,isSelected,updatedQRLocations) {
      let permissionsList = ["SalesRep","GRID_SalesRep","SalesRepManager","ChannelSalesRep","ChannelSalesRepManager","SplPricing",
                          "OMAnalyst","OMAnalystManager","ChannelSalesEng","ChannelsDirector","ChannelsQuoter",
                          "ChannelsSupport","SplPricingManager","Premier"];
      let permExisted = false;
      if(this.loggedInUser && this.loggedInUser.lstPermissionSet){
        for(let i=0;i<this.loggedInUser.lstPermissionSet.length;i++){
          let uPerm = this.loggedInUser.lstPermissionSet[i];
          if(permissionsList.includes(uPerm)){
            permExisted = true;
            break;
          }
        }
      } 

      let tempPermissions = permExisted ? this.loggedInUser.lstPermissionSet : [];
      
      this.getRequestRateApexCall(locationId,productIds,tempPermissions,isSelected,updatedQRLocations);
  }

  getRequestRateApexCall(locationId,productIds,permissions, isSelected,updatedQRLocations) {
    this.showLoading = true;
    getQuoteRequestRates({qrId:this.quoteRequestId,qoiIdList: productIds,locationId: locationId,userPermList: permissions})
    .then((response) => {
        if (response) {
          this.responseJSON = response;
          this.isSelected = isSelected;
          //this.renderProducts(response, isSelected);
          this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
          this.dispatchEvent(
            new CustomEvent("filteredqrlocations", {
              detail: {
                filteredQRLocations: this.filteredQRLocations
              }
            })
          );
          this.showLoading = false;
        }
      })
      .catch((error) => {
        this.showLoading = false;
        console.log("getRatesData error ==>" + JSON.stringify(error));
    });
  }

  showProductsFN(locationId) {
    let updatedQRLocations = [];
    let productIds = [];
    let isExpanded = false;

    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if (locationId === location.Id) {
        updatedLocation.showProducts = !updatedLocation.showProducts;
        updatedLocation.products.forEach((product) => {
          productIds.push(product.Id);
        });
        isExpanded = updatedLocation.showProducts;
      }
      updatedQRLocations.push(updatedLocation);
    });

    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
    console.log("this.filteredQRLocations++690", this.filteredQRLocations);

    if (isExpanded === true) {
      this.showLoading = true;
      setTimeout(() => {
        this.updateChildExpand(locationId, productIds);
      }, 2000);
      this.showLoading = false;
    }
  }

  handleProductSelected(event){
    this.generateLocationMapFromProduct(event.detail.checkedFlag,event.detail.originalFlag,event.detail.locId,event.detail.prodId);
  }
  mapQRLQOIForChild = new Map();
  generateLocationMapFromProduct(prodCheckedFlag,originalFlag,locId,prodId){
    let prodSize = this.locationProdSizeMap.has(locId) ? this.locationProdSizeMap.get(locId) : 0;
    let prodMap = new Map();
    let qloGuiId=this._quoteOptionId+locId+prodId;
    if(this.mapQRLQOIForChild.has(locId)){
      prodMap = this.mapQRLQOIForChild.get(locId);
    }
    if(prodCheckedFlag){
      
      //if(!originalFlag){
        prodMap.set(prodId,originalFlag);
        this.selectedqloGUIIds.add(qloGuiId);
      
    } else {
      prodMap.delete(prodId);
      if(this.selectedqloGUIIds.has(qloGuiId)){
        this.selectedqloGUIIds.delete(qloGuiId);
      }
    }

    let pSize = 0;
    for(let [key, value] of prodMap) {
      if(value){
        pSize++;
      }
    }
    this.mapQRLQOIForChild.set(locId, prodMap);

    if(this.mapQRLQOIForChild.size > 0 ) {
      this.showSubmitClosedWon = true;
      this.allowMRCCalculation = true;
    } else {
      this.showSubmitClosedWon = false;
      this.allowMRCCalculation = false;
    }

    this.locationMap = this.mapQRLQOIForChild;
    
    let locChecked = false;
    
    //let cStyle = "check-box-style";
    let checkedType = 'All';
    if(prodSize == pSize){
      locChecked = true;  
    }
    else if(pSize > 0){
      
        locChecked = true;
        //cStyle = "check-box-style1";
        checkedType = 'Partial';
    }

    let totalLocSize = 0;
    let selLocSize = 0;
    let fullCheckCnt = 0;
    this.filteredQRLocations.forEach((location) => {
      totalLocSize++;
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if(locId === location.Id) {
        //location.isChecked = locChecked;
        //location.locCheckBoxStyleCls = cStyle;
        location.checkedType = checkedType;
      }

      /*if(location.isChecked){
        selLocSize++;
        if(location.checkedType == 'All'){
          fullCheckCnt++;
        }
      }*/
    });

    /*if(selLocSize == totalLocSize){
      this.isOnCheckAll = true;
      if(fullCheckCnt == totalLocSize){
        this.onCheckAllStyle = 'check-box-style';
        
      }
      else{
        this.onCheckAllStyle = 'check-box-style1';
      }
    }
    else{
      this.isOnCheckAll = false;
      this.onCheckAllStyle = 'check-box-style';
    }*/
    let qloGuiIds = Array.from(this.selectedqloGUIIds).join(',');
    console.log(qloGuiIds);
    this.dispatchEvent(
      new CustomEvent("seleclocationsandprod", {
        detail: {
        locandprod: this.locationMap,selectedGUIIds : qloGuiIds
        }
      })
    );
  }

  generateLocationMapFromLocation(locCheckedFlag,locId,prodMap){
    this.showSubmitClosedWon = true;
    this.allowMRCCalculation = true;
    if(locCheckedFlag){
      if(!this.locationMap.has(locId)){
        this.locationMap.set(locId,prodMap);
      }
    }
    else{
      if(!this.locationMap.has(locId)){
        this.locationMap.set(locId,prodMap);
      }
    }

    const objChild = this.template.querySelectorAll('c-child-expand');
    if(objChild){
      objChild.forEach(element => {
        if(locId == element.locationId){
          element.updateProdCheckFlag(locCheckedFlag,'All');
        }
      });  
    }
    let qloGuiIds = Array.from(this.selectedqloGUIIds).join(',');
    this.dispatchEvent(
      new CustomEvent("seleclocationsandprod", {
        detail: {
        locandprod: this.locationMap ,selectedGUIIds : qloGuiIds
        }
      })
    );
  }

  onCheck(event) {
    let checkedFlag = event.target.checked;
    let locId = event.target.name;
    let prodMap = new Map();

    let updatedQRLocations = [];
    let selectedRecords;
    this.productIds = [];
    const selectedIndex = event.target.dataset.index;

    let totalLocSize = 0;
    let selLocSize = 0;
    let fullCheckCnt=0;
    this.filteredQRLocations.forEach((location) => {
      totalLocSize++;
      let updatedLocation = JSON.parse(JSON.stringify(location));

      if (event.target.name === location.Id) {
        updatedLocation.isChecked = checkedFlag;
        updatedLocation.checkedType = 'All';
        updatedLocation.products.forEach((product) => {
          let qloGuiId=this._quoteOptionId+location.Id+product.Id;
          if(checkedFlag){
            this.selectedqloGUIIds.add(qloGuiId);
          } else {
            if(this.selectedqloGUIIds.has(qloGuiId)){
                this.selectedqloGUIIds.delete(qloGuiId);
            }
          }
          this.productIds.push(product.Id);
          if(updatedLocation.qloQOI[product.Id]) {
            prodMap.set(product.Id,true);
          } else {
            prodMap.set(product.Id,false);
          }
          
        });
      }
      if (updatedLocation.isChecked === true) {
        selLocSize++;
        if(updatedLocation.checkedType == 'All'){
          fullCheckCnt++;
        }
        if (!selectedRecords) {
          selectedRecords = [];
          this.selectedLocationIds = [];
          this.allowMRCCalculation = false;
        }
        selectedRecords.push(this.getTransfromedData(location.Id, true));
        this.selectedLocationIds.push(location.Id);
        this.allowMRCCalculation = true;
      }
      
      updatedQRLocations.push(updatedLocation);
    });

    this.generateLocationMapFromLocation(checkedFlag,locId,prodMap);
    this.locationMap.set(locId,prodMap);
    if(selLocSize == totalLocSize){
      this.isOnCheckAll = true;
      if(fullCheckCnt == totalLocSize){
        this.onCheckAllStyle = 'check-box-style';
      }
      else{
        this.onCheckAllStyle = 'check-box-style1';
      }
    }
    else{
      this.isOnCheckAll = false;
      this.onCheckAllStyle = 'check-box-style1';
    }

    if (!selectedRecords) {
      this.allowMRCCalculation = false;
      this.showSubmitClosedWon = false;
    }

    this.qrLocationsData = JSON.parse(JSON.stringify(updatedQRLocations));
    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
    console.log("this.filteredQRLocations++737", this.filteredQRLocations);
    //let expnddChldrn = this.template.querySelector('c-child-expand');
    //expnddChldrn.handleOnSelectLocationForMRC(event.target.name, productIds, selectedIndex);
    this.populateCheckboxes();
    this.selectedLocationsRecords = selectedRecords;
    if (this.isSubmittedQuote) {
      let expnddChldrn = this.template.querySelectorAll("c-child-expand");

      if (expnddChldrn && expnddChldrn.length > 0) {
        expnddChldrn.forEach((child) => {
          child.getRatesData(
            event.target.name,
            this.productIds,
            event.target.checked
          );
        });
      }
    }
    this.dispatchEvent(
      new CustomEvent("rowselection", {
        detail: { locations: selectedRecords }
      })
    );
  }

  onCheckAll(event) {
    let checkedFlag = event.target.checked;
    let updatedQRLocations = [];
    let selectedRecords;
    this.productIds = [];
    if (event.target.checked === true) {
      this.isOnCheckAll = true;
      this.allowMRCCalculation=true;
      //this.onCheckAllStyle = 'check-box-style';
    } else {
      this.isOnCheckAll = false;
      this.allowMRCCalculation=false;
      //this.onCheckAllStyle = 'check-box-style1';
    }

    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      let proIds = [];
      let prodMap = new Map();
      updatedLocation.isChecked = checkedFlag;
      updatedLocation.checkedType = 'All';
      //updatedLocation.locCheckBoxStyleCls = 'check-box-style';
      updatedLocation.products.forEach((product) => {
        let qloGuiId=this._quoteOptionId+location.Id+product.Id;
        if(checkedFlag){
          this.selectedqloGUIIds.add(qloGuiId);
        } else {
          if(this.selectedqloGUIIds.has(qloGuiId)){
              this.selectedqloGUIIds.delete(qloGuiId);
          }
        }
        this.productIds.push(product.Id);
        proIds.push(product.Id);
        //prodMap.set(product.Id,checkedFlag);
        if(updatedLocation.qloQOI[product.Id]) {
          prodMap.set(product.Id,true);
        } else {
          prodMap.set(product.Id,false);
        }
      });

      this.locationProdSizeMap.set(location.Id,proIds.length);
      
      this.generateLocationMapFromLocation(checkedFlag,location.Id,prodMap);
      this.locationMap.set(location.Id,prodMap);
      if (updatedLocation.isChecked === true) {
        if (!selectedRecords) {
          selectedRecords = [];
          this.selectedLocationIds = [];
        }

        selectedRecords.push(this.getTransfromedData(location.Id, true));
        this.selectedLocationIds.push(location.Id);
        this.allowMRCCalculation = true;
      }
      if (this.isSubmittedQuote) {
        let expnddChldrn = this.template.querySelectorAll("c-child-expand");

        if (expnddChldrn && expnddChldrn.length > 0) {
          expnddChldrn.forEach((child) => {
            //child.getRatesData(location.Id, proIds, event.target.checked);
          });
        }
      }
      updatedQRLocations.push(updatedLocation);
    });
    if (!selectedRecords) {
      this.allowMRCCalculation = false;
      this.showSubmitClosedWon = false;
    }
    this.qrLocationsData = JSON.parse(JSON.stringify(updatedQRLocations));

    this.filteredQRLocations = JSON.parse(JSON.stringify(updatedQRLocations));
    this.dispatchEvent(
      new CustomEvent("filteredqrlocations", {
        detail: {
          filteredQRLocations: this.filteredQRLocations
        }
      })
    );
    console.log("this.filteredQRLocations++775 ", this.filteredQRLocations);

    this.populateCheckboxes();
    if (event.target.checked) {
      this.selectedLocationsRecords = selectedRecords;
    } else {
      this.selectedLocationsRecords = [];
    }
    this.dispatchEvent(
      new CustomEvent("rowselection", {
        detail: { locations: selectedRecords }
      })
    );
    //console.log('selected records',selectedRecords.length);
    //console.log('updated records',updatedQRLocations.length);
  }

  @api refreshTable() {
    this.qrLocationsData = [];
    this.filteredQRLocations = [];
    this.filters = {};
    this.locationPageSize = 0;
    this.hasServerSideFilterRun = false;
    this.totalRecords = 0;
    this.totalDisplayedRecords = 0;
    this.initializeTable();
  }

  getProducts(locIds){
    let productIds = [];
    this.filteredQRLocations.forEach((location) => {
      if(locIds.includes(location.Id)){
        location.products.forEach((product) => {
          productIds.push(product.Id);
        });
      }
    });
    return productIds;
  }

  handleRowAction(event) {
    if (event?.detail?.actionName === "Show Products") {
      let isSelected = false;
      if (this.isSubmittedQuote && this.selectedLocationIds && this.selectedLocationIds.includes(event.detail.rowId)){
        isSelected = true;
      }
      this.isSelected = isSelected;
      let locIds = [];
      locIds.push(event.detail.rowId);
      let productIds = this.getProducts(locIds);
      this.locationProdSizeMap.set(event.detail.rowId,productIds.length);
      this.expandApexCall(locIds,productIds,false,'OnLoad');
    } 
    else if(event?.detail?.actionName === "Hide Products"){
      this.collapseSelectedLocation(event.detail.rowId);
    }
    else if (event?.detail?.actionName) {
      let actionName = event.detail.actionName == "Delete" ? "delete" : "edit";
      let record = this.getTransfromedData(event.detail.rowId);
      this.dispatchEvent(
        new CustomEvent("rowaction", {
          detail: { actionName, rowId: event.detail.rowId, record }
        })
      );
    }
  }

  handleUpdateLocation() {
    this.dispatchEvent(new CustomEvent("updatelocation", { detail: "update" }));
  }

  debounce(func) {
    this.oldTimeoutRef.forEach((oldRef) => {
      clearTimeout(oldRef);
    });

    this.oldTimeoutRef = [];

    this.oldTimeoutRef.push(
      setTimeout(() => {
        func(this);
      }, 1500)
    );
  }

  showAll(event) {
    this.isShowMore = false;
    this.hasServerSideFilterRun = false;
    this.expandAll = false;
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    getAllLocations({ quoteOptionId: this._quoteOptionId,userPermList: permissions })
      .then((response) => {
        // console.log('response ==> ' + JSON.stringify( response ));
        this.totalRecords = response.totalLocations;
        this.lastQrLocationId = response.lastLocationId;
        this.pushQRLocationsData(response.locations, true);
        this.qrrObjPrefix = response.qrrObjectPrefix;
      })
      .catch((error) => {
        console.log("error ==> " + JSON.stringify(error));
      });
  }

  clearFilters() {
    let filterInputs = this.template.querySelectorAll("lightning-input");

    if (filterInputs) {
      filterInputs.forEach((input) => {
        input.value = "";
      });
    }
  }

  getTransfromedData(recordId) {
    let record = {};

    this.filteredQRLocations.forEach((location) => {
      if (recordId === location.Id) {
        record.Id = location.Id;
        record.address = location.Address__c;
        record.city = location.City__c;
        record.state = location.State__c;
        record.zip = location.Zip__c;
        record.glcCode = location.GL_Code__c;
        record.vendor = location.vendorsString;
        record.groupName = location.Group_Name__c;
        record.isChecked = location.isChecked;
        record.isDisabled = false;
        record.showProducts = location.showProducts;
        record.products = location.productsString;
        record.productsData = location.products;
		record.qloQOI = location.qloQOI;
        record.popup = "productPopupShow";
        //record.locCheckBoxStyleCls = "check-box-style";
        record.checkedType = 'All';
        return;
      }
    });

    return record;
  }

  getTransfromedData(recordId, isChecked) {
    let record = {};

    this.filteredQRLocations.forEach((location) => {
      if (recordId === location.Id) {
        record.Id = location.Id;
        record.address = location.Address__c;
        record.city = location.City__c;
        record.state = location.State__c;
        record.zip = location.Zip__c;
        record.glcCode = location.GL_Code__c;
        //record.vendor = location.Vendor__c;
        record.vendor = location.vendorsString;
        record.groupName = location.Group_Name__c;
        record.isChecked = isChecked;
        record.isDisabled = false;
        record.showProducts = location.showProducts;
        record.products = location.productsString;
        record.productsData = location.products;
        record.popup = "productPopupShow";
        //record.locCheckBoxStyleCls = "check-box-style";
        record.checkedType = 'All';
        return;
      }
    });
    return record;
  }

  showdiscountmodal(event) {
    this.selectedLocationIds = [];
    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if (updatedLocation.isChecked) { 
        updatedLocation.products.forEach((product) => {
          this.productIds.push(product.Id);
        });
        
        this.selectedLocationIds.push(location.Id);
      }
    });
    getQuoteRequestRatesList({
      quoteOptionItemIds: this.productIds,
      locationIds: this.selectedLocationIds
    })
      .then((response) => {
        console.log("Response surcharge : ", JSON.stringify(response));
        this.finalProdArray = [];
        this.renderProducts(response);
      })
      .catch((error) => {
        console.log("getRatesData error ==>" + JSON.stringify(error));
      });
  }

  renderProducts(ratesData) {
    ratesData.forEach((prodItem) => {
      let secondaryProduct;
      if(prodItem.Product__c=="VoIP"){
        secondaryProduct = prodItem.Product_Detail1__c;
      }
      else if(prodItem.Product__c=="Mobility"){
        secondaryProduct = prodItem.Product_Type__c;
      }

      if (prodItem.Quote_Request_Rates__r) {
        prodItem.Quote_Request_Rates__r.forEach((ratesItem) => {
          let rateFieldsData = {
            quoteRqRatesId: ratesItem.Id,
            mrc: ratesItem.Circuit_MRC_Rate1__c,
            featuremrc: ratesItem.Feature_MRC__c,
            margin: ratesItem.Margin_Amount__c,
            marginPercent: ratesItem.Margin_Percent__c,
            cost: ratesItem.GC_MRC_Rate__c,
            surcharge: ratesItem.Surcharge__c,
            prodName: ratesItem.Product__c,
            surchargePercent: ratesItem.Surcharge_Percentage__c,
            locationId: ratesItem.Quote_Location_Option__r.Quote_Request_Location__c,
            rates: ratesItem,
            secondaryProduct: secondaryProduct,
            qty: ratesItem.Quote_Option_Item__r.QTY__c
          };
          this.mapMRC.set(ratesItem.Unique_Key__c, rateFieldsData);
        });
      } else {
        this.allowMRCCalculation = false;
      }
    });
    if (this.mapMRC.size > 0) {
      console.log("Clicked");
      this.showMRCBox = true;
    } else {
      this.showMRCBox = false;
    }
  }

  onMRCPopupClose(event) {
    this.showMRCBox = false;
  }

  onPricingPopupClose(event) {
    this.showPricingTier = false;
  }

  submitClosedWon(event){
	console.log('Inside submitClosedWon');
	let locIdList = [];
	let prodIdList = [];
	let qloMap = [];
	let uniqueKeyMap = new Map();
	
	for(let [key, value] of this.locationMap) {
		let newLocationMap = new Map();
		let uniqueKey = this.quoteOptionId+''+key;
		locIdList.push(key);
		let colorFilteredQRLocation = this.filteredQRLocations.find(element => {
			return element.Id === key;
		});
		
		for(let [key1, value1] of value) {
			prodIdList.push(key1);
			let finalKey = uniqueKey+''+key1;
			if(!value1){ 
				uniqueKeyMap.set(finalKey,true);
				//newLocationMap.set(key1,true);
        colorFilteredQRLocation.qloQOI[key1] = true;
				this.locationMap.get(key).set(key1, true);
			}
			else{
				uniqueKeyMap.set(finalKey,false);
				//newLocationMap.set(key1,false);
        colorFilteredQRLocation.qloQOI[key1] = false;
				this.locationMap.get(key).set(key1, false);
			}
    }
    
		let totalCertifiedProducts = Array.from(Object.entries(colorFilteredQRLocation.qloQOI)).filter(([_key, item]) => {
			return item === true;
		});
    let totalUnCertifiedProducts = Array.from(Object.entries(colorFilteredQRLocation.qloQOI)).filter(([_key, item]) => {
			return item === false;
		});
		if(totalCertifiedProducts.length === Object.entries(colorFilteredQRLocation.qloQOI).length) {
			colorFilteredQRLocation.locCertifiedColorIndicator = "colorOrangeIndicator";
			colorFilteredQRLocation.indicatorColorTitle = 'Location(s) and or Product(s) Certified';
		} else if(totalCertifiedProducts.length !== Object.entries(colorFilteredQRLocation.qloQOI).length && totalUnCertifiedProducts.length !== Object.entries(colorFilteredQRLocation.qloQOI).length) {
			colorFilteredQRLocation.locCertifiedColorIndicator = "colorBlueIndicator";
			colorFilteredQRLocation.indicatorColorTitle = 'Location(s) is partially Certified';
		} else {
			colorFilteredQRLocation.locCertifiedColorIndicator = "";
			colorFilteredQRLocation.indicatorColorTitle = '';
		}
		colorFilteredQRLocation.isChecked = false;
		
    }

    var obj = Object.fromEntries(uniqueKeyMap);
    var jsonString = JSON.stringify(obj);

    this.isLoading = true;
    submitClosedWonCall({qloMapJSON:jsonString}).then((response) => 
    {		
		this.isLoading = false;
		this.showSubmitClosedWon = false;
      this.allowMRCCalculation = false;
		//let productIds = this.getProducts(locIdList);
		//this.expandApexCall(locIdList,productIds,false,'Refresh');
		let expnddChldrn = this.template.querySelectorAll("c-child-expand");
		
		if (expnddChldrn && expnddChldrn.length > 0) {
			expnddChldrn.forEach((child) => {
				child.setCertfiedLocation(Object.fromEntries(this.locationMap));
			});
		}
    //this.initializeTable();
		  this.mapQRLQOIForChild.clear();
      this.selectedqloGUIIds.clear();
      this.isOnCheckAll = false;
			const successEvent = new ShowToastEvent( {title:'Success', message:'Location(s)/Product(s) have been Uncertified/Certified Successfully',variant:'success'} );
			this.dispatchEvent( successEvent );
      publish(this.messageContext, A3QuotingMessageChannel, {
        eventData: { source: "nqrLocationsTable" },
        eventTitle: "enableClosedWon"
      });
      let qloGuiIds = Array.from(this.selectedqloGUIIds).join(',');
      this.dispatchEvent(
      new CustomEvent("seleclocationsandprod", {
        detail: {
        locandprod: this.locationMap ,selectedGUIIds : qloGuiIds
        }
      })
      );
		}).catch((error) => 
		{
			this.isLoading = false;
			const errorEvent = new ShowToastEvent( {title:'Error', message:'Location(s)/Product(s) Update Failed',variant:'error'} );
			this.dispatchEvent( errorEvent );
		});
  }

  showpricingtiermodal(event) {
    let prodNamesSet = [];
    let prodDetailSet =[];
    let proIds = [];
    let selectedLocationIds = [];
    let prodDetail = {};
    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));
      if (updatedLocation.isChecked) {
        updatedLocation.products.forEach((product) => {
          proIds.push(product.Id);
          if (!prodNamesSet.includes(product.Product__c)) {
            prodNamesSet.push(product.Product__c);
          }
          if (!prodDetail[product.Product__c]){
            prodDetail[product.Product__c] = '';
          }
          if (prodDetail[product.Product__c] !== '') {
            prodDetail[product.Product__c] += ', ';
          }
          prodDetail[product.Product__c] += product.Product_Detail1__c?product.Product_Detail1__c:'';
          
        });
        selectedLocationIds.push(location.Id);
      }

      for (const productCategory in prodDetail) {
        let resultObject = {};
        resultObject[productCategory] = prodDetail[productCategory];
        prodDetailSet.push(resultObject);
      }

      

    });
    let jsonResult = JSON.stringify(prodDetailSet);
    this.prodTierVals = [];
    this.getTierPicklistValues(prodNamesSet,jsonResult);
  }
  
  get typeOfBBSelection() {
    if (
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager"))
    ) {
      return [
        { label: "Select", value: "Select" },
        { label: "1", value: "1" }
      ];
    } else if (
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("ChannelSalesRep") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelSalesRepManager") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelSalesEng") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsDirector") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsSupport"))
    ) {
      return [
        { label: "Select", value: "Select" },
        { label: "10%", value: "10%" },
        { label: "12.50%", value: "12.50%" },
        { label: "17.50%", value: "17.50%" },
        { label: "20%", value: "20%" }
      ];
    }
  }

  handleUpdateProdTierMap(event) {
    if (event.detail.selectedLabel && event.detail.selectedLabel != "Select") {
      this.prodTierMap[event.detail.prodName] = event.detail.selectedLabel;
    } else if (this.prodTierMap.hasOwnProperty(event.detail.prodName)) {
      delete this.prodTierMap[event.detail.prodName];
    }

    //this.prodTierMap[event.detail.prodName]=event.detail.selectedLabel;
  }

  closeModal() {
    // Setting boolean variable to false, this will hide the Modal
    this.showPricingModal = false;
    this.showPricingTier = false;
    this.pricingTierResetAllFlag = false;
    const selectedEvent = new CustomEvent("closepopup", {
      detail: ""
    });
    this.dispatchEvent(selectedEvent);
  }
  
  handleSave() {
    //this.showPricingTier = false;
    //this.updateChildExpand( locationId, productIds );
    this.saveBulkTier();
  }

  setDefaultValues(indx) {
    let prodTierValstemp = [];
    this.prodTierMap = {};

    for (let i = 0; i < this.prodTierVals.length; i++) {
      let prodTier = this.prodTierVals[i];
      if (prodTier.showProd) {
        let opts = [];
        for (let j = 0; j < prodTier.options.length; j++) {
          let opt = prodTier.options[j];
          if (j == indx) {
            opt["selected"] = true;
            if (opt.label != "Select") {
              this.prodTierMap[prodTier.prodName] = opt.label;
            }
          } else {
            opt["selected"] = false;
          }
          opts.push(opt);
        }

        prodTier["options"] = opts;
        prodTierValstemp.push(prodTier);
      } else {
        prodTierValstemp.push(prodTier);
      }
    }

    this.prodTierVals = prodTierValstemp;
  }

  pricingTierResetAllChange(event) {
    this.pricingTierResetAllFlag = event.target.checked;
    if (this.pricingTierResetAllFlag) {
      this.setDefaultValues(1);
    } else {
      this.setDefaultValues(0);
    }
  }

  generateTierMap(key, options, showProd) {
    let opts = [];
    opts.push({ label: "Select", value: "Select", selected: true });
    for (let i = 0; i < options.length; i++) {
      //const [key, value] of Object.entries(options)) {
      opts.push({
        label: options[i].label,
        value: options[i].value,
        selected: false
      });
    }

    this.prodTierVals.push({
      prodName: key,
      options: opts,
      showProd: showProd
    });
  }
   
  getTierPicklistValues(prodNamesSet,jsonResult) {
    getTierPicklistValuesCall({ qrId: this.quoteRequestId,prodDetail:jsonResult })
      .then((response) => {
        let pValues = JSON.parse(response);
        for (const [key, value] of Object.entries(pValues)) {
          let showProd = prodNamesSet.includes(key) ? true : false;
          this.generateTierMap(key, value, showProd);
        }

        this.showPricingTier = true;
        this.pricingTierResetAllFlag = false;
        this.prodTierMap = {};
      })
      .catch((error) => {
      });
  }

  saveBulkTier() {
    if (Object.keys(this.prodTierMap).length == 0) {
      const errorEvent = new ShowToastEvent({
        title: "Error",
        message: "No Changes found!",
        variant: "error"
      });
      this.dispatchEvent(errorEvent);
      return;
    }
    this.loadSpinner = true;
    let proIds = [];
    let selectedLocationIds = [];
    this.filteredQRLocations.forEach((location) => {
      let updatedLocation = JSON.parse(JSON.stringify(location));

      if (updatedLocation.isChecked) {
        updatedLocation.products.forEach((product) => {
          proIds.push(product.Id);
        });

        selectedLocationIds.push(location.Id);
      }
    });

    updatePricingTierOnBulkCall({
      locIdList: selectedLocationIds,
      prodIdList: proIds,
      tierMap: this.prodTierMap
    })
      .then((response) => {
        console.log('response bulk tier : ',response);
        getBulkPricingSpApplied({qrId: this.quoteRequestId}).then((response) => {
          this.spApllied = response;
          if(this.spApllied !== 'undefined' && this.spApllied != null){
             this.updateSPAppliedSave();
          }
        }).catch((error) => {
          console.log("SP error ==>" + JSON.stringify(error));
        });
        this.showPricingTier = false;
        this.pricingTierResetAllFlag = false;
        this.isOnCheckAll = false;
        this.onCheckAllStyle = 'check-box-style';
        this.initializeTable();
        this.loadSpinner = false;
        this.allowMRCCalculation = false;
        this.locationMap = new Map();
        this.mapQRLQOIForChild = new Map();
      })
      .catch((error) => {
        console.log("getRatesData error ==>" + JSON.stringify(error));
        this.loadSpinner = false;
        this.showPricingTier = false;
        this.pricingTierResetAllFlag = false;
        const errorEvent = new ShowToastEvent({
          title: "Error",
          message: error,
          variant: "error"
        });
        this.dispatchEvent(errorEvent);
      });
  }

  closePopUpAndRefresh(event) {
    this.showMRCBox = false;
    this.allowMRCCalculation = false;
    this.selectedLocationIds = [];
    this.initializeTable();
  }

  handleSelectedProductCheck(event) {
    this.selectedProdId = event.detail.selectedProdId;
    this.selectedLocationsInSelectedProducts = event.detail.locationId;
    this.selectedProdLoacMap = event.detail.selectedProdLoacMap;
    if (
      typeof this.selectedProdLoacMap != "undefined" &&
      this.selectedProdLoacMap.size > 0
    ) {
      this.dispatchEvent(
        new CustomEvent("productvalueselect", {
          detail: { isSelected: true }
        })
      );
    } else {
      this.dispatchEvent(
        new CustomEvent("productvalueselect", {
          detail: { isSelected: false }
        })
      );
    }
  }

  @api
  updatePricingTier(pricingTier) {
    this.isLoading = true;
    if (
      typeof this.selectedProdLoacMap != "undefined" &&
      this.selectedProdLoacMap.size > 0
    ) {
      let mapSelectedLocProd = new Map();
      let productIdsValue = [];
      let selectedLocations = [];
      for (const key of this.selectedProdLoacMap.keys()) {
        console.log(
          "this.selectedLocationIds::" +
            this.selectedLocationIds +
            "key::" +
            key
        );
        selectedLocations.push(key);
        let arrProd = [];
        arrProd = this.selectedProdLoacMap.get(key);
        mapSelectedLocProd.set(key, arrProd);

        if (
          typeof this.selectedLocationIds != "undefined" &&
          this.selectedLocationIds.includes(key)
        ) {
          //this.selectedProdLoacMap.delete(key);
          let arr = this.selectedProdLoacMap.get(key);
          for (let i = 0; i < arr.length; i++) {
            if (!productIdsValue.includes(arr[i])) {
              productIdsValue.push(arr[i]);
            }
          }
        } else {
          let arr = this.selectedProdLoacMap.get(key);
          this.filteredQRLocations.forEach((location) => {
            if (location.Id == key) {
              let updatedLocation = JSON.parse(JSON.stringify(location));
              updatedLocation.products.forEach((product) => {
                for (let i = 0; i < arr.length; i++) {
                  if (product.Id == arr[i]) {
                    productIdsValue.push(arr[i]);
                  }
                }
              });
            }
          });
        }
      }
      if (typeof this.selectedLocationIds != "undefined") {
        this.selectedLocationIds.forEach((locationId) => {
          if (!selectedLocations.includes(locationId)) {
            selectedLocations.push(locationId);
            this.filteredQRLocations.forEach((location) => {
              if (location.Id == locationId) {
                let updatedLocation = JSON.parse(JSON.stringify(location));
                updatedLocation.products.forEach((product) => {
                  productIdsValue.push(product.Id);
                  if (mapSelectedLocProd.has(locationId)) {
                    mapSelectedLocProd.get(locationId).push(product.Id);
                  } else {
                    let arr = [];
                    arr.push(product.Id);
                    mapSelectedLocProd.set(locationId, arr);
                  }
                });
              }
            });
          }
        });
      }
      const obj = Object.fromEntries(mapSelectedLocProd);
      this.callApexToUpdatePricingTier(
        JSON.stringify(obj),
        productIdsValue,
        selectedLocations,
        pricingTier
      );
    } else {
      let productIdsValue = [];
      this.filteredQRLocations.forEach((location) => {
        if (this.selectedLocationIds.includes(location.Id)) {
          let updatedLocation = JSON.parse(JSON.stringify(location));
          updatedLocation.products.forEach((product) => {
            productIdsValue.push(product.Id);
          });
        }
      });
      let strBlank = " ";
      this.callApexToUpdatePricingTier(
        strBlank,
        productIdsValue,
        this.selectedLocationIds,
        pricingTier
      );
    }
  }
  callApexToUpdatePricingTier(
    prodLocStr,
    productIdValue,
    selectedLocations,
    pricingTier
  ) {
    updatePricingTierOfRate({
      quoteOptionItemIds: productIdValue,
      locationIds: selectedLocations,
      pricingTierStr: pricingTier,
      selectedLocProdStr: prodLocStr
    })
      .then((response) => {
        console.log("updatePricingTierOfRate::" + JSON.stringify(response));
        selectedLocations.forEach((locationId) => {
          let allexpandedProduct = [];
          this.showLoading = true;
          this.filteredQRLocations.forEach((location) => {
            if (location.Id == locationId) {
              let updatedLocation = JSON.parse(JSON.stringify(location));
              updatedLocation.products.forEach((product) => {
                allexpandedProduct.push(product.Id);
              });
            }
          });
          this.selectedProdLoacMap = new Map();
          this.updateChildExpand(locationId, allexpandedProduct);
          this.showLoading = false;
          this.initializeTable();
          this.isLoading = false;
        });
      })
      .catch((error) => {
        console.log("getRatesData error ==>" + JSON.stringify(error));
      });
  }

  updateSPAppliedSave() {
    const fields = {};
    fields[ID_FIELD.fieldApiName] = this.quoteRequestId;
    fields[Special_Pricing__Field.fieldApiName] = this.spApllied;
    const recordInput = { fields };

    updateRecord(recordInput)
      .then(() => {
        console.log("Updated Special Pricing value",this.spApllied);
        publish(this.messageContext, A3QuotingMessageChannel, {
          eventData: { source: "nqrLocationsTable" },
          eventTitle: "bulkTierSPApplied",
          eventValue: this.spApllied
        });
        //spAppliedValueRefresh({ qrId: this.quoteRequestId });
      })
      .catch((error) => {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error Updating Special Pricing",
            message: error.body.message,
            variant: "error"
          })
        );
      });
  }

  getBroadbandProducts(locIds){
    let productIds = [];
    this.filteredQRLocations.forEach((location) => {
      if(locIds.includes(location.Id)){
        location.products.forEach((product) => {
          if(product.Product__c == 'Broadband'){
            productIds.push(product.Id);
          }  
        });
      }
    });
    return productIds;
  }

  handleMassVendorUpdate(event){
    this.showVendorModal = false;
    this.refreshTable();
  }

  handleCloseVendorModal(event){
    this.showVendorModal = false;
  }

  showMassEditVendorModal(event){
    let selectedLocIds = this.selectedLocationIds;
    let productIds = this.getBroadbandProducts(selectedLocIds);

    this.isLoading = true;
    getAllVendorsCall({qrId:this.quoteRequestId,locIdList:selectedLocIds,lstQoiId:productIds})
    .then((response) => {
      if(response){
        this.prodVendorObj = JSON.parse(response);
        this.showVendorModal = true;
      }
      this.isLoading = false;
    })
    .catch((error) => {
        this.isLoading = false;
        console.log("getRatesData error ==>" + JSON.stringify(error));
        this.isLoading = false;
    });
  }
}