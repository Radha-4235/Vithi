//sreebox
import { LightningElement, track, api } from "lwc";
import fetchQuoteRequestRelatedDataForLocation from "@salesforce/apex/NewQuoteRequestHandler.quoteRequestRelatedDataByLocation";
import deleteRecords from "@salesforce/apex/NewQuoteRequestHandler.deleteSObjects";
import fetchFieldLabels from "@salesforce/apex/QuoteOptionsController.getFieldLabels";
import QUOTE_OPTION_ITEM_OBJECT from "@salesforce/schema/Quote_Option_Item__c";
import { deleteRecord } from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
export default class SingleLocationProducts extends LightningElement {
  @api quoteRequestId;
  @api quoteRequest;
  @api quoteOptId;
  @track openDeleteModal = false;
  @track showLoading = false;
  @api selectedLocation;
  @track selectedLocations = [];
  @track finalQoArray = [];
  @track openAddProduct = false;
  @track quoteOptionsResponse;
  _qoItemLocations = [];
  @track productsArray = [];
  @track finalProdArray = [];
  @track applyToAllCheck = false;
  isSecondarySIM = false;
  isCallPath = false;
  isHighAvail = false;
  isSeat = false;
  isUsage = false;
  isNewInstall = false;
  isCurrentCarrier = false;
  isConversionType = false;
  _selectedProductId;
  _hideTabs = true;
  @track subHeader = "";
  _fieldLabelMap = new Map();
  _quoteOptionItemToProducts = new Map();
  @api loggedInUser;

  connectedCallback() {
    this.fetchExistingData();
    this.subHeader = `${this.selectedLocation.Address__c} ${this.selectedLocation.City__c} ${this.selectedLocation.State__c} ${this.selectedLocation.Zip__c}`;
  }

  applyToAllVal() {
    this.applyToAllCheck = !this.applyToAllCheck;
  }

  fetchExistingData() {
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    this.showLoading = true;
    Promise.all([
      fetchFieldLabels({ objApiName: QUOTE_OPTION_ITEM_OBJECT.objectApiName }),
      fetchQuoteRequestRelatedDataForLocation({
        recordId: this.quoteRequestId,
        locationId: this.selectedLocation.Id,
        userPermList: permissions
      })
    ])
      .then(([fieldLabelResult, qoData]) => {
        console.log(fieldLabelResult);
        this._fieldLabelMap = new Map(Object.entries(fieldLabelResult));
        console.log(qoData);
        this.fetchAndSetExistingData(qoData, fieldLabelResult);
        if (qoData.quoteOptionWrapperMap) {
          for (const key in qoData.quoteOptionWrapperMap) {
            qoData.quoteOptionWrapperMap[key].Quote_Location_Option__r.forEach(
              (elem) => {
                this._qoItemLocations.push(elem);
                let _locations = this._quoteOptionItemToProducts.has(
                  elem.Quote_Option_Item__c
                )
                  ? this._quoteOptionItemToProducts.get(
                      elem.Quote_Option_Item__c
                    )
                  : [];
                _locations.push(elem.Id);
                this._quoteOptionItemToProducts.set(
                  elem.Quote_Option_Item__c,
                  _locations
                );
              }
            );
          }
        }
      })
      .catch((error) => console.log("" + JSON.stringify(error)));
  }

  fetchAndSetExistingData(qoData, fieldLabelResult) {
    let fieldMap = new Map(Object.entries(fieldLabelResult));
    let qoProdMap = new Map();
    let qoName = new Map();
    let quoteProductList;
    this.finalQoArray = [];
    let fieldsToBeExcludedDisplay = new Set([
      "Id",
      "Name",
      "Quote_Option__c",
      "Product_Family__c"
    ]);

    for (const qoItem in qoData.quoteOptionWrapperMap) {
      // qoName.set();
      quoteProductList = qoData.quoteOptionItemWrapperMap[qoItem];
      quoteProductList.forEach((item, index) => {
        let qoiFeatureMap = qoData.qoiAdditionalFeaturesMap[item.Id];
        let qoiOptionalServiceMap = qoData.qoiOptionalServicesMap[item.Id];
        let qoiAddOnFeatureMap = qoData.qoiAddOnFeaturesMap[item.Id];
        let qoiAddOnOfferMap = qoData.qoiAddOnOffersMap[item.Id];
        let existingProductData = qoProdMap.get(item.Quote_Option__c)
          ? qoProdMap.get(item.Quote_Option__c)
          : [];
        let lookupMap = qoData.prodLookupMap;
        if (
          lookupMap &&
          lookupMap[item.Product__c] &&
          lookupMap[item.Product__c].Product_Unique_Identification__c
        ) {
          let fieldApiList =
            lookupMap[item.Product__c].Product_Unique_Identification__c.split(
              "~"
            );
          let prdFields = [];
          for (var i = 0; i < fieldApiList.length; i++) {
            let field = fieldApiList[i];
            let fieldvalues = item[field];
            let fieldLabel = this._fieldLabelMap.get(field.toLowerCase());
            if (item.Product__c == "Broadband" && field == "Ip_Block__c") {
              fieldLabel = "IP Block";
            }
            if (item.Product__c == "GRID" && field == "Grid_Voice_Package__c") {
              fieldLabel = "Voice/CPE Package";
              if (
                fieldvalues == "Grid Voice Package A - Netvanta 3140 - HT812"
              ) {
                fieldvalues = "A";
              } else if (
                fieldvalues == "Grid Voice Package B - Netvanta 3140 - HT814"
              ) {
                fieldvalues = "B";
              } else if (
                fieldvalues == "Grid Voice Package C - Netvanta 3140 - HT818"
              ) {
                fieldvalues = "C";
              } else if (fieldvalues == "Grid Voice Package D - Adtran 908.B") {
                fieldvalues = "D";
              } else if (fieldvalues == "Grid Voice Package E - Adtran 916.B") {
                fieldvalues = "E";
              } else {
                fieldvalues = "-";
              }
            }

            if (item.Product__c == "Mobility") {
              if (field == "Product_Type__c") {
                fieldLabel = "Service Category";
              } else if (field == "Type__c") {
                fieldLabel = "Device Type";
              } else if (field == "Billing_Type__c") {
                fieldLabel = "Conversion Type";
              } else if (field == "ProductCode_Description__c") {
                fieldLabel = "Current Carrier";
              } else if (field == "Definition__c") {
                fieldLabel = "New Carrier";
              } else if (field == "Minimum_Speed__c") {
                fieldLabel = "Mobility Plan";
              } else if (field == "Product_Code_Description__c") {
                fieldLabel = "Mobility Device";
              } else if (field == "Product_Description__c") {
                fieldLabel = "Current Carrier Other";
              } else if (field == "Ip_Block__c") {
                fieldLabel = "Secondary SIM";
              } else if (field == "IP_Type__c") {
                fieldLabel = "Secondary Carrier";
              } else if (field == "Display_Speed__c") {
                fieldLabel = "Secondary Mobility Plan";
              }
            }
            if (item.Product__c == "VoIP" ){
              if(field == "Product_Detail1__c"){
                fieldLabel = "Product Category";
              }else if(field == "Preferred_Product_1__c"){
                fieldLabel = "Call Path";
              }else if(field == "Preferred_Product__c"){
                fieldLabel = "Usage Options";
              }
            }
            if (item.Product__c == "Guardian" ){
              if(field == "Billing_Type__c"){
                fieldLabel = "High Availability";
              }else if(field == "Product_Code_Description__c"){
                fieldLabel = "Service";
              }
            }

            if (item.Product__c == "VoIP" && field == "Name") {
              fieldLabel = "Additional Features";
              if(qoiAddOnFeatureMap != null){
                fieldvalues = qoiAddOnFeatureMap;
              }else {
                fieldvalues = "-";
              }
                
            }
            if (item.Product__c == "VoIP"  && field == "Product_Detail1_Description__c") {
              fieldLabel = "Seat";
              if(qoiAddOnOfferMap != null){
                fieldvalues = qoiAddOnOfferMap;
              }else {
                fieldvalues = "-";
              }
            }
            if (item.Product__c == "VoIP" && field == "Product_Detail1__c") {
              if (fieldvalues == "SIP") {
                this.isCallPath = true;
              } else if (fieldvalues == "HPBX") {
                this.isCallPath = false;
              }else if(fieldvalues == "Operator Connect for Microsoft Teams"){
                this.isUsage = true;
              }
            }
            if (item.Product__c  == "Guardian" && field == "Product_Code_Description__c") {
              if (fieldvalues == "Managed - SD WAN Branch" || fieldvalues == "Managed - SD WAN HQ") {
                this.isHighAvail = true;
              } else {
                this.isHighAvail = false;
              }
            }
            if (item.Product__c == "VoIP" && field == "Product_Detail1__c") {
              if (fieldvalues == "HPBX") {
                this.isSeat = true;
              } else if (fieldvalues == "SIP" || fieldvalues == "Operator Connect for Microsoft Teams") {
                this.isSeat = false;
              }
            }
            
            if (item.Product__c == "ePOTS" && field == "Name") {
              fieldLabel = "Additional Features";
              fieldvalues = qoiFeatureMap;
            }
            if (item.Product__c == "Voice over Cable Line" && field == "Name") {
              fieldLabel = "Feature(s)";
              if(qoiFeatureMap != null){
               fieldvalues = qoiFeatureMap;
              }else{
                fieldvalues = "-";
              }
            }
            if (item.Product__c == "Mobility" && field == "Name") {
              fieldLabel = "Optional Services";
              if (qoiOptionalServiceMap != null) {
                fieldvalues = qoiOptionalServiceMap;
              } else {
                fieldvalues = "-";
              }
            }
            if (item.Product__c == "Guardian" && field == "Name") {
              fieldLabel = "Add On Features";
              if (qoiOptionalServiceMap != null) {
                fieldvalues = qoiOptionalServiceMap;
              } else {
                fieldvalues = "-";
              }
            }
            if (item.Product__c == "Mobility" && field == "Product_Type__c") {
                if (fieldvalues == "Wireless Broadband") {
                  this.isCurrentCarrier = true;
                } else  {
                  this.isCurrentCarrier = false;
                }
              } 
              if (item.Product__c == "Mobility" && field == "Product_Type__c") {
                if (fieldvalues == "Wireless Broadband") {
                  this.isConversionType = true;
                } else {
                  this.isConversionType = false;
                }
              }
            if (item.Product__c == "Mobility" && field == "Ip_Block__c") {
              if (fieldvalues == "Yes") {
                this.isSecondarySIM = true;
              } else if (fieldvalues == "No") {
                this.isSecondarySIM = false;
              }
            } else if (
              item.Product__c == "Mobility" &&
              field == "Billing_Type__c"
            ) {
              if (fieldvalues == "New Install") {
                this.isNewInstall = true;
              } else {
                this.isNewInstall = false;
              }
            }
            if (
              !(
                !fieldvalues &&
                field == "Ip_Block__c" &&
                item.Product__c == "Broadband"
              ) &&
              !(
                !fieldvalues &&
                field == "Product_Description__c" &&
                item.Product__c == "Mobility"
                ) &&
              !(
                !this.isSecondarySIM &&
                item.Product__c == "Mobility" &&
                (field == "IP_Type__c" || field == "Display_Speed__c")
              ) &&
              !(
                !this.isCallPath &&
                item.Product__c == "VoIP" &&
                (field == "Preferred_Product_1__c" )
              ) &&
              !(
                  !this.isUsage &&
                  item.Product__c == "VoIP" &&
                  (field == "Preferred_Product__c" )
                ) &&
                !(
                  this.isUsage &&
                  item.Product__c == "VoIP" &&
                  (field == "Name" )
                ) &&
              !(
                !this.isHighAvail &&
                item.Product__c  == "Guardian" &&
                (field == "Billing_Type__c" )
              ) &&
              !(
                this.isCurrentCarrier && 
                item.Product__c == "Mobility" &&
                (field == "ProductCode_Description__c"  )
              ) &&
              !(
                this.isConversionType && 
                item.Product__c == "Mobility" &&
                ( field == "Billing_Type__c" )
              ) &&
              !(
                !this.isSeat &&
                item.Product__c == "VoIP" &&
                (field == "Product_Detail1_Description__c" )
              ) &&
              !(
                this.isNewInstall &&
                item.Product__c == "Mobility" &&
                field == "ProductCode_Description__c"
              )
            ) {
              prdFields.push({
                fieldName: field,
                fieldValue: fieldvalues,
                fieldLabel: fieldLabel
              });
            }
          }

          let childProds = [];
          if (item.Child_Quote_Option_Items__r) {
            let fieldApiListChild;
            if (item.Product__c == "ePOTS") {
              fieldApiListChild =
                lookupMap["ATA Equipment"].LookUpValue__c.split("~");
            }
            const childProdItem = item.Child_Quote_Option_Items__r;
            for (var j = 0; j < childProdItem.length; j++) {
              if(childProdItem[j].Child_Quote_item_Product_Type__c == "Router"){
                fieldApiListChild = lookupMap["ROUTER"].LookUpValue__c.split("~");
              }else if( childProdItem[j].Child_Quote_item_Product_Type__c =="AddonEdgeboot"){
                fieldApiListChild = lookupMap["AddonEdgeboot"].LookUpValue__c.split("~");
              }
              if (
                childProdItem[j].Child_Quote_item_Product_Type__c == "Router" ||
                childProdItem[j].Child_Quote_item_Product_Type__c ==
                  "ATA Equipment" ||
                childProdItem[j].Child_Quote_item_Product_Type__c ==
                  "AddonEdgeboot"
              ) {
                let childPrdFields = [];
                if (item.Product__c == "ePOTS") {
                  childPrdFields.push({
                    fieldName: "Product__c",
                    fieldValue: "ATA EQUIPMENT",
                    fieldLabel: "Product",
                    showEditableRow: false,
                    showInput: "SHOW_INPUT"
                  });
                } else if ((item.Product__c == "Broadband" || item.Product__c == "DIA") &&  childProdItem[j].Child_Quote_item_Product_Type__c ==
                  "AddonEdgeboot") {
                  childPrdFields.push({
                    fieldName: "Product__c",
                    fieldValue: childProdItem[j].Name,
                    fieldLabel: "Product",
                    showEditableRow: false,
                    showInput: "SHOW_INPUT"
                  });
                } else {
                  console.log("Router child : ");
                  childPrdFields.push({
                    fieldName: "Product__c",
                    fieldValue: "ROUTER",
                    fieldLabel: "Product",
                    showEditableRow: false,
                    showInput: "SHOW_INPUT"
                  });
                }

                if (fieldApiListChild && fieldApiListChild.length > 0) {
                  console.log("field list : ", fieldApiListChild);
                  for (var i = 0; i < fieldApiListChild.length; i++) {
                    let field = fieldApiListChild[i];
                    let fieldLabel = this._fieldLabelMap.get(field.toLowerCase());
                    console.log("field : ", field);
                    childPrdFields.push({
                      fieldName: field,
                      fieldValue:
                        field == "Equipment_Term__c"
                          ? item.Contract_Term__c
                          : childProdItem[j][field],
                      fieldLabel: fieldLabel,
                      showEditableRow: false,
                      showInput: "SHOW_INPUT"
                    });
                  }
                }
                childProds.push({
                  Index: childProds.length,
                  childFields: childPrdFields
                });
                console.log("child Prod fields: ", childProds);
              }
            }
          }
          existingProductData.push({
            prodData: item,
            prodFields: prdFields,
            childPrdsFields: childProds,
            showEditDeletePopoverLabel: "ShowPopover",
            showEditDeletePopoverCheck: false
          });
        } else {
          existingProductData.push({
            prodData: item,
            prodFields: Object.entries(item)
              .map(([k, v]) => ({
                fieldName: k,
                fieldValue: v,
                fieldLabel: this._fieldLabelMap.get(k.toLowerCase())
              }))
              .filter(
                (field) => !fieldsToBeExcludedDisplay.has(field.fieldName)
              ),
            showEditDeletePopoverLabel: "ShowPopover",
            showEditDeletePopoverCheck: false
          });
        }
        qoProdMap.set(item.Quote_Option__c, existingProductData);
      });
    }
    for (const qoItem in qoData.quoteOptionWrapperMap) {
      this.finalQoArray.push({
        quoteOption: qoData.quoteOptionWrapperMap[qoItem].Name,
        products:
          qoProdMap && qoProdMap.has(qoItem) ? qoProdMap.get(qoItem) : []
      });
    }
    console.log("Final array", this.finalQoArray);
    this.showLoading = false;
  }
  handlePopOverEvent(event) {
    event.preventDefault(event);
    console.log(event.target.accessKey);
    this.showEditDeletePopover(event.target.accessKey, event.target.name);
  }

  showEditDeletePopover(prodKey, popOverlabel) {
    this.finalQoArray.forEach((qoItem) => {
      qoItem.products.forEach((pItem) => {
        if (pItem.prodData.Id == prodKey) {
          if (popOverlabel == "ShowPopover") {
            this._selectedProductId = prodKey;
            pItem.showEditDeletePopoverLabel = "HidePopover";
            pItem.showEditDeletePopoverCheck = true;
          } else if (popOverlabel == "HidePopover") {
            pItem.showEditDeletePopoverLabel = "ShowPopover";
            pItem.showEditDeletePopoverCheck = false;
          }
        } else {
          pItem.showEditDeletePopoverLabel = "ShowPopover";
          pItem.showEditDeletePopoverCheck = false;
        }
      });
    });
  }

  redirectToProductAdd() {
    this.selectedLocations.push(this.selectedLocation.Id);
    this.openAddProduct = true;
    this.closeAllPopover();
  }
  saveLocationsAndProducts() {
    this.fetchExistingData();
    this.openAddProduct = false;
    this.closeAllPopover();
  }
  handleClosePopupModal() {
    //this.fetchExistingData();
    this.openAddProduct = false;
    this.closeAllPopover();
  }

  backToLocationsAndProducts() {
    this.saveLocationsAndProducts();
    this.openAddProduct = false;
    this.closeAllPopover();
    this.dispatchEvent(new CustomEvent("closesinglelocationproductmodal"));
  }

  closeAllPopover() {
    this.showEditDeletePopover("", "ShowPopover");
  }

  closeDeleteModal() {
    this.closeAllPopover();
    this.openDeleteModal = false;
  }

  deleteQuoteOption() {
    this.closeAllPopover();
    this.openDeleteModal = true;
  }

  async deleteProducts() {
    let _deleleRecords = [];
    if (this._selectedProductId) {
      _deleleRecords = this.deleteRelatedQOItemLocations(
        this._selectedProductId,
        this.selectedLocation.Id
      );
      if (
        this.applyToAllCheck === true ||
        (this._quoteOptionItemToProducts.has(this._selectedProductId) &&
          this._quoteOptionItemToProducts.get(this._selectedProductId).length ==
            _deleleRecords.length)
      )
        _deleleRecords.push(this._selectedProductId);
      if (_deleleRecords.length > 0) {
        await deleteRecords({
          listOfObjs: _deleleRecords
        })
          .then(() => {
            this.showToast(
              "Success",
              "Products deleted successfully",
              "success"
            );
            this.fetchExistingData();
          })
          .catch((err) => {
            console.log(err);
            this.showToast(
              "Some unexpected error occurred",
              "Unable to delete the products",
              "error"
            );
          });
      }
    }
    this.closeDeleteModal();
  }

  deleteRelatedQOItemLocations(qoId, _selectedLocations) {
    let _deleteLocationsPromises = [];
    this._qoItemLocations.forEach((item) => {
      if (
        item.Quote_Option_Item__c == qoId &&
        _selectedLocations == item.Quote_Request_Location__c
      )
        _deleteLocationsPromises.push(item.Id);
    });
    return _deleteLocationsPromises;
  }

  showToast(title, message, variant) {
    const evt = new ShowToastEvent({
      title: title,
      message: message,
      variant: variant,
      mode: "dismissable"
    });
    this.dispatchEvent(evt);
  }
}