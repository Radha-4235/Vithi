import { LightningElement, track, api, wire } from "lwc";
//import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import getQuoteOptions from "@salesforce/apex/QuoteOptionsController.getQuoteOptions";
import deteteProductandRelatedQLOCall from "@salesforce/apex/QuoteOptionsController.deteteProductandRelatedQLO";
import fetchFieldLabels from "@salesforce/apex/QuoteOptionsController.getFieldLabels";
import fetchA3lookupCall from "@salesforce/apex/QuoteOptionsController.fetchA3LookupMap";
import { getPicklistValues } from "lightning/uiObjectInfoApi";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import { deleteRecord } from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import QRR_ID from "@salesforce/schema/Quote_Request_Rates__c.Id";
import UNIT_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Unit__c";
import ON_NET_FIELD from "@salesforce/schema/Quote_Request_Rates__c.On_Net__c";
import ACTIVATION_COST_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Activation_Cost__c";
import ACTIVATION_MRC_NRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Activation_MRC_NRC_Rate__c";
import QUOTE_OPTION_ITEM_OBJECT from "@salesforce/schema/Quote_Option_Item__c";
import QUOTE_REQUEST_RATES_OBJECT from "@salesforce/schema/Quote_Request_Rates__c";
import GC_MRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.GC_MRC__c";
import GC_NRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.GC_NRC__c";
import { getRecord, getFieldValue, updateRecord } from "lightning/uiRecordApi";
import updateVendorQRRatesCall from "@salesforce/apex/NQRLocationsTableController.updateVendorQRRates";
import salesRepQrViewLoadCall from "@salesforce/apex/NewQuoteRequestHandler.salesRepQrViewLoad";
import getActionStatuses from "@salesforce/apex/NewQuoteRequestHandler.getActionStatuses";
import { publish, createMessageContext } from "lightning/messageService";
import A3QuotingMessageChannel from "@salesforce/messageChannel/A3QuotingMessageChannel__c";

//import jQuery from '@salesforce/resourceUrl/jquery331';
//import dataTable from '@salesforce/resourceUrl/jQueryDataTable';
const COLS = [
  {
    label: "All Groups",
    fieldName: "Name",
    type: "text",
    hideDefaultActions: "true"
  },
  {
    label: "All Locations",
    fieldName: "Name",
    type: "text",
    hideDefaultActions: "true"
  },
  {
    label: "All Addresses",
    fieldName: "Address__c",
    type: "text",
    hideDefaultActions: "true"
  },
  {
    label: "All Cities",
    fieldName: "City__c",
    type: "text",
    hideDefaultActions: "true"
  },
  {
    label: "All States",
    fieldName: "State__c",
    type: "text",
    hideDefaultActions: "true"
  },
  {
    label: "All Zips",
    fieldName: "Zip__c",
    type: "text",
    hideDefaultActions: "true"
  },
  {
    label: "All NPA/NXX",
    fieldName: "LocationStore_Number__c",
    type: "text",
    hideDefaultActions: "true"
  }
];
export default class ByProductViewComponent extends LightningElement {
  locHeaders = COLS;
  @api isQuoteSubmitted;
  @api quoteRequestId;
  @api quoteOptId;
  @track quoteOptNm;
  @track qoItemCheck = false;
  @track finalQoArray = [];
  @api selectAll = false;
  @track quoteOptionsResponse;
  locationArray = [];
  days = 1;
  @track productsArray = [];
  @track qoiFeatureNames;
  @track qoiOptionalServiceNames;
  @track qoiAdditionalFeatureNames;
  @track qoiOffersNames;
  _isRendered = false;
  //list to manage all filter column name
  @track groupNameOption = [];
  @track addressOption = [];
  @track locationNameOption = [];
  @track cityOption = [];
  @track stateOption = [];
  @track zipOption = [];
  @track phoneOption = [];
  @track showMRCBox = false;
  allowMRCCalculation = false;
  @track mapMRC = new Map();
  fieldLabelMap = {};
  showLoading = false;
  isSecondarySIM = false;
  isCallPath = false;
  isUsage = false;
  isHighAvail = false;
  isCurrentCarrier = false;
  isConversionType = false;
  isSeat = false;
  isNewInstall = false;
  @api quoteRequestQuoteType;
  @api loggedInUser;
  actionStatuses = {};
  actionsCSS = {};
  enabledCSS =
    "color: white; width: 100%; padding: 5px; display: inline-block;";
  disabledCSS =
    "color: white; width: 100%; padding: 5px; display: inline-block; background-color: gray; cursor: default";

  // @wire(getQuoteOptions,{ quoteReqId : this.quoteRequestId }) quoteOptionsResponse;
  @wire(getRecord, { recordId: "$quoteRequestRatesId", fields })
  quoteRequestRates;
  @wire(getObjectInfo, { objectApiName: QUOTE_REQUEST_RATES_OBJECT })
  quoteRequestRates;
  @wire(getPicklistValues, {
    recordTypeId: "$quoteRequestRates.data.defaultRecordTypeId",
    fieldApiName: UNIT_FIELD
  })
  unitPicklist;
  @wire(getPicklistValues, {
    recordTypeId: "$quoteRequestRates.data.defaultRecordTypeId",
    fieldApiName: ON_NET_FIELD
  })
  onNetPicklist;
  connectedCallback() {
    this.getQuotesInProductView();
  }
  constructor() {
    super();
  }
  get editmrc() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SplPricing") ||
      this.loggedInUser.userType == "SplPricingManager" ||
      this.loggedInUser.userType == "OMAnalyst" ||
      this.loggedInUser.userType == "OMAnalystManager"
    ) {
      showFlag = true;
    }
    return showFlag;
  }

  messageContext = createMessageContext();

  onSelectAll(event) {
    let isAllChecked = event.target.checked;
    this.selectAll = isAllChecked;
    let tempLocationsArray = JSON.parse(JSON.stringify(this.allLocations));
    for (let i = 0; i < tempLocationsArray.length; i++) {
      tempLocationsArray[i].locSelected = isAllChecked;
    }
    console.log(tempLocationsArray);
    this.allLocations = tempLocationsArray;
  }
  onSelect(event) {
    let locSelect;
    let isChecked = event.target.checked;
    let indx = event.target.dataset.recordId;
    this.allLocations[indx].locSelected = isChecked;
    console.log("checked>> " + isChecked);
    if (!isChecked) {
      this.selectAll = false;
    } else {
      for (let i = 0; i < this.locationArray.length; i++) {
        if (this.allLocations[i].locSelected) {
          console.log(
            i + "checked true onselect" + this.allLocations[i].locSelected
          );
          locSelect = true;
        } else {
          locSelect = false;
          console.log(
            i + "checked false onselect" + this.allLocations[i].locSelected
          );
          break;
        }
      }
      this.selectAll = locSelect;
      console.log("checked locSelect" + locSelect);
    }
  }
  qoItemOnChange(event) {
    const qoiChecked = event.target.checked;
    const selectedProductIndex = event.target.dataset.index;
    if (qoiChecked) {
      if (
        this.finalProdArray[selectedProductIndex].ratesFields &&
        this.finalProdArray[selectedProductIndex].ratesFields.length > 0
      ) {
        let ratesObject = this.finalProdArray[
          selectedProductIndex
        ].ratesFields.find((obj) => {
          return obj.fieldName === "Circuit_MRC_Rate1__c";
        });
        if (ratesObject.mrc !== null) {
          this.mapMRC.set(
            this.finalProdArray[selectedProductIndex].product.Id,
            ratesObject
          );
          this.allowMRCCalculation = true;
        }
      }
    } else {
      if (
        this.mapMRC.has(this.finalProdArray[selectedProductIndex].product.Id)
      ) {
        this.mapMRC.delete(
          this.finalProdArray[selectedProductIndex].product.Id
        );
      }
    }
    if (this.mapMRC.size === 0) {
      this.allowMRCCalculation = false;
    }
  }
  @track finalProdArray = [];
  get finalProdArraylength() {
    return this.finalProdArray.length > 0;
  }
  getQuotesInProductView() {
    this.showLoading = true;
    this.finalQoArray = [];
    this.locationsArray = [];
    this.productsArray = [];
    this.finalProdArray = [];
    let permissions = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    getQuoteOptions({ quoteReqId: this.quoteRequestId ,userPermList: permissions})
      .then((result) => {
        this.fieldLabelMap = result.qoiFieldMap;
        this.rateFieldLabelMap = result.qrrFieldMap;
        this.quoteOptionsResponse = result;
        let a3LookupMap = result.prodLookupMap;
        let qoiVendorMap = result.qoiVendorsMap;
        let qoiFeatureMap = result.qoiAdditionalFeaturesMap;
        let qoiOptionalServiceMap = result.qoiOptionalServiceMap;
        let qoiAddOnFeaturesMap = result.qoiAddOnFeaturesMap;
        let qoiAddOnOffersMap = result.qoiAddOnOffersMap;

        if (this.quoteOptId) {
          this.quoteOptNm =
            this.quoteOptionsResponse.quoteOptionMap[this.quoteOptId].Name;
          this.productsArray =
            this.quoteOptionsResponse.qOptionVsqoItemMap[this.quoteOptId];
        }

        this.productsArray.forEach((locItem) => {
          this.locationsArray.push(
            this.quoteOptionsResponse.qoItemVsLocationMap[
              this.quoteOptId + "#" + locItem.Id
            ]
          );
        });

        console.log("this.productsArray" + this.productsArray);
        console.log("Locations Data==>" + this.locationsArray);
        this.productsArray.forEach((prodItem) => {
          let lookupMap = result.prodLookupMap;
          this.qoiFeatureNames = qoiFeatureMap[prodItem.Id];
          this.qoiOptionalServiceNames = qoiOptionalServiceMap[prodItem.Id];
          this.qoiAdditionalFeatureNames = qoiAddOnFeaturesMap[prodItem.Id];
          this.qoiOffersNames = qoiAddOnOffersMap[prodItem.Id];
          console.log("QOI Feature Names : ", this.qoiFeatureNames);

          if (
            lookupMap &&
            lookupMap[prodItem.Product__c] &&
            lookupMap[prodItem.Product__c].Product_Unique_Identification__c
          ) {
            let fieldApiList =
              lookupMap[
                prodItem.Product__c
              ].Product_Unique_Identification__c.split("~");
            let relatedFieldsList = [];
            if (lookupMap[prodItem.Product__c].Related_Fields__c) {
              relatedFieldsList =
                lookupMap[prodItem.Product__c].Related_Fields__c.split("~");
            }

            let vendorOptions = [];
            if (prodItem.Product__c == "DIA") {
              if (
                lookupMap[prodItem.Product__c] &&
                lookupMap[prodItem.Product__c].Vendor__c
              ) {
                let vendorList =
                  lookupMap[prodItem.Product__c].Vendor__c.split("~");
                vendorOptions = this.generateDropdownOptions(vendorList);
              }
            } else {
              if (qoiVendorMap && qoiVendorMap[prodItem.Id]) {
                let vendorRatesList = qoiVendorMap[prodItem.Id];
                vendorOptions =
                  this.generateDropdownOptionsFromRates(vendorRatesList);
              }
            }

            let prdFields = [];
            let rateFields = [];
            for (var i = 0; i < fieldApiList.length; i++) {
              let field = fieldApiList[i];
              let fieldvalue = prodItem[field];
              let fieldLabel = this.fieldLabelMap[field.toLowerCase()];
              if (
                prodItem.Product__c == "Broadband" &&
                field == "Ip_Block__c"
              ) {
                fieldLabel = "IP Block";
              }
              if (
                prodItem.Product__c == "GRID" &&
                field == "Grid_Voice_Package__c"
              ) {
                fieldLabel = "Voice/CPE Package";
                if (
                  fieldvalue == "Grid Voice Package A - Netvanta 3140 - HT812"
                ) {
                  fieldvalue = "A";
                } else if (
                  fieldvalue == "Grid Voice Package B - Netvanta 3140 - HT814"
                ) {
                  fieldvalue = "B";
                } else if (
                  fieldvalue == "Grid Voice Package C - Netvanta 3140 - HT818"
                ) {
                  fieldvalue = "C";
                } else if (
                  fieldvalue == "Grid Voice Package D - Adtran 908.B"
                ) {
                  fieldvalue = "D";
                } else if (
                  fieldvalue == "Grid Voice Package E - Adtran 916.B"
                ) {
                  fieldvalue = "E";
                } else {
                  fieldvalue = "-";
                }
              }
              if (
                prodItem.Product__c == "GRID" &&
                field == "Ip_Block__c"
              ) {
                fieldLabel = "IP Block";
                if(!fieldvalue){
                  fieldvalue = "-";
                }
              }

              if (prodItem.Product__c == "Mobility") {
                if (field == "Product_Type__c") {
                  fieldLabel = "Service Category";
                } else if (field == "Type__c") {
                  fieldLabel = "Device Type";
                } else if (field == "Billing_Type__c") {
                  fieldLabel = "Conversion Type";
                } else if (field == "ProductCode_Description__c") {
                  fieldLabel = "Current Carrier";
                } else if (field == "Definition__c") {
                  fieldLabel = "New Carrier";
                } else if (field == "Minimum_Speed__c") {
                  fieldLabel = "Mobility Plan";
                } else if (field == "Product_Code_Description__c") {
                  fieldLabel = "Mobility Device";
                }else if (field == "Ip_Block__c") {
                  fieldLabel = "Secondary SIM";
                } else if (field == "IP_Type__c") {
                  fieldLabel = "Secondary Carrier";
                } else if (field == "Display_Speed__c") {
                  fieldLabel = "Secondary Mobility Plan";
                }else if(field == "Product_Description__c"){
                  fieldLabel = "Current Carrier Other";
                }
              }
              if (prodItem.Product__c == "VoIP" ){
                if(field == "Product_Detail1__c"){
                  fieldLabel = "Product Category";
                }else if(field == "Preferred_Product_1__c"){
                  fieldLabel = "Call Path";
                }else if(field == "Preferred_Product__c"){
                  fieldLabel = "Usage Options";
                }
              }
              
              if (prodItem.Product__c == "Guardian" ){
                if(field == "Billing_Type__c"){
                  fieldLabel = "High Availability";
                }else if(field == "Product_Code_Description__c"){
                  fieldLabel = "Service";
                }
              }

              if (prodItem.Product__c == "ePOTS" && field == "Name") {
                fieldLabel = "Additional Features";
                fieldvalue = this.qoiFeatureNames;
              }
              if (prodItem.Product__c == "Mobility" && field == "Name") {
                fieldLabel = "Optional Services";
                if (this.qoiOptionalServiceNames != null) {
                  fieldvalue = this.qoiOptionalServiceNames;
                } else {
                  fieldvalue = "-";
                }
              }
              if (prodItem.Product__c == "Guardian" && field == "Name") {
                fieldLabel = "Add On Features";
                if (this.qoiOptionalServiceNames != null) {
                  fieldvalue = this.qoiOptionalServiceNames;
                } else {
                  fieldvalue = "-";
                }
              }
              if (prodItem.Product__c == "Voice over Cable Line" && field == "Name") {
                fieldLabel = "Feature(s)";
                if (this.qoiFeatureNames != null) {
                  fieldvalue = this.qoiFeatureNames;
                } else {
                  fieldvalue = "-";
                }
              }
              if (prodItem.Product__c == "VoIP" && field == "Name") {
                fieldLabel = "Additional Features";
                if (this.qoiAdditionalFeatureNames != null) {                  
                  fieldvalue = this.qoiAdditionalFeatureNames;
                } else {
                  fieldvalue = "-";
                }
              }
              if (prodItem.Product__c == "VoIP"  && field == "Product_Detail1_Description__c") {
                fieldLabel = "Seat";
                if (this.qoiOffersNames != null) {                  
                  fieldvalue = this.qoiOffersNames;
                } else {
                  fieldvalue = "-";
                }
              }
              if((prodItem.Product__c == "DIA" || prodItem.Product__c == "GSE" || prodItem.Product__c == "PIP" || prodItem.Product__c == "Guardian" ||
                  prodItem.Product__c == 'Equipment') && field == "Contract_Term__c"){
                fieldLabel = "Term";
              }
              if((prodItem.Product__c == "DIA" || prodItem.Product__c == "GSE" || prodItem.Product__c == "PIP") && field == "Speed__c"){
                fieldLabel = "Bandwidth";
              }
              if(prodItem.Product__c == 'Equipment' && field == "Quantiy__c"){
                fieldLabel = "QTY";
              }
              if (prodItem.Product__c == "VoIP" && field == "Product_Detail1__c") {
                if (fieldvalue == "SIP") {
                  this.isCallPath = true;
                } else if (fieldvalue == "HPBX") {
                  this.isCallPath = false;
                }else if( fieldvalue == "Operator Connect for Microsoft Teams"){
                  this.isUsage = true;
                }
              }
              if (prodItem.Product__c  == "Guardian" && field == "Product_Code_Description__c") {
                if (fieldvalue == "Managed - SD WAN Branch" || fieldvalue == "Managed - SD WAN HQ") {
                  this.isHighAvail = true;
                } else {
                  this.isHighAvail = false;
                }
              }
              if (prodItem.Product__c == "VoIP" && field == "Product_Detail1__c") {
                if (fieldvalue == "HPBX") {
                  this.isSeat = true;
                } else if (fieldvalue == "SIP" || fieldvalue == "Operator Connect for Microsoft Teams") {
                  this.isSeat = false;
                }
              }
              if (prodItem.Product__c == "Mobility" && field == "Product_Type__c") {
                if (fieldvalue == "Wireless Broadband") {
                  this.isCurrentCarrier = true;
                } else  {
                  this.isCurrentCarrier = false;
                }
              } 
              if (prodItem.Product__c == "Mobility" && field == "Product_Type__c") {
                if (fieldvalue == "Wireless Broadband") {
                  this.isConversionType = true;
                } else {
                  this.isConversionType = false;
                }
              }

              if (prodItem.Product__c == "Mobility" && field == "Ip_Block__c") {
                if (fieldvalue == "Yes") {
                  this.isSecondarySIM = true;
                } else if (fieldvalue == "No") {
                  this.isSecondarySIM = false;
                }
              } else if (
                prodItem.Product__c == "Mobility" &&
                field == "Billing_Type__c"
              ) {
                if (fieldvalue == "New Install") {
                  this.isNewInstall = true;
                } else {
                  this.isNewInstall = false;
                }
              }
              if (
                !(
                  !fieldvalue &&
                  field == "Ip_Block__c" &&
                  prodItem.Product__c == "Broadband"
                ) &&
                !(
                  !fieldvalue &&
                  field == "Product_Description__c" &&
                  prodItem.Product__c == "Mobility"
                ) &&
                !(
                  !this.isSecondarySIM &&
                  prodItem.Product__c == "Mobility" &&
                  (field == "IP_Type__c" || field == "Display_Speed__c")
                ) &&
                !(
                  !this.isCallPath &&
                  prodItem.Product__c == "VoIP" &&
                  (field == "Preferred_Product_1__c" )
                ) &&
                !(
                  !this.isUsage &&
                  prodItem.Product__c == "VoIP" &&
                  (field == "Preferred_Product__c" )
                ) &&
                !(
                  this.isUsage &&
                  prodItem.Product__c == "VoIP" &&
                  (field == "Name" )
                ) &&
                !(
                  !this.isHighAvail &&
                  prodItem.Product__c  == "Guardian" &&
                  (field == "Billing_Type__c" )
                ) &&
                !(
                  this.isCurrentCarrier && 
                  prodItem.Product__c == "Mobility" &&
                  (field == "ProductCode_Description__c"  )
                ) &&
                !(
                  this.isConversionType && 
                  prodItem.Product__c == "Mobility" &&
                  ( field == "Billing_Type__c" )
                ) &&
                !(
                  !this.isSeat &&
                  prodItem.Product__c == "VoIP" &&
                  (field == "Product_Detail1_Description__c" )
                ) &&
                !(
                  this.isNewInstall &&
                  prodItem.Product__c == "Mobility" &&
                  field == "ProductCode_Description__c"
                )
              ) {
                prdFields.push({
                  fieldName: field,
                  fieldValue: fieldvalue,
                  fieldLabel: fieldLabel,
                  showEditableRow: false,
                  showInput: "SHOW_INPUT"
                });
              }
            }

            let childProds = [];
            if (prodItem.Child_Quote_Option_Items__r) {
              let fieldApiListChild;
                          
              if (prodItem.Product__c == "ePOTS") {
                fieldApiListChild = a3LookupMap["ATA Equipment"].LookUpValue__c.split("~");
              }
              else if(prodItem.Product__c == "VoIP"){
                fieldApiListChild = a3LookupMap["HPBX Equipment"].LookUpValue__c.split("~");
              }

              const childProdItem = prodItem.Child_Quote_Option_Items__r;
              for (var j = 0; j < childProdItem.length; j++) {
                if(childProdItem[j].Child_Quote_item_Product_Type__c == "Router"){
                  fieldApiListChild = a3LookupMap["ROUTER"].LookUpValue__c.split("~");
                }
                if(childProdItem[j].Child_Quote_item_Product_Type__c == "AddonEdgeboot"){
                  fieldApiListChild = a3LookupMap["AddonEdgeboot"].LookUpValue__c.split("~");
                }
                if (childProdItem[j].Child_Quote_item_Product_Type__c == "Router" ||
                  childProdItem[j].Child_Quote_item_Product_Type__c == "ATA Equipment" || 
                  childProdItem[j].Child_Quote_item_Product_Type__c == "HPBX Equipment" ||
                  childProdItem[j].Child_Quote_item_Product_Type__c == "AddonEdgeboot") {
                  let childPrdFields = [];
                  if (prodItem.Product__c == "ePOTS") {
                    childPrdFields.push({
                      fieldName: "Product__c",
                      fieldValue: "ATA EQUIPMENT",
                      fieldLabel: "Product",
                      showEditableRow: false,
                      showInput: "SHOW_INPUT"
                    });
                  }
                  else if (prodItem.Product__c == "VoIP") {
                    childPrdFields.push({
                      fieldName: "Product__c",
                      fieldValue: childProdItem[j].Product_Detail1_Description__c?childProdItem[j].Product_Detail1_Description__c:'HBPX EQUIPMENT',
                      fieldLabel: "Product",
                      showEditableRow: false,
                      showInput: "SHOW_INPUT"
                    });
                  }else if ((prodItem.Product__c == "Broadband" || prodItem.Product__c =='DIA') && childProdItem[j].Child_Quote_item_Product_Type__c == "AddonEdgeboot") {
                    childPrdFields.push({
                      fieldName: "Product__c",
                      fieldValue: childProdItem[j].Name,
                      fieldLabel: "Product",
                      showEditableRow: false,
                      showInput: "SHOW_INPUT"
                    });
                  }
                  else {
                    childPrdFields.push({
                      fieldName: "Product__c",
                      fieldValue: "ROUTER",
                      fieldLabel: "Product",
                      showEditableRow: false,
                      showInput: "SHOW_INPUT"
                    });
                  }
                  
                  if (fieldApiListChild && fieldApiListChild.length > 0) {
                    for (var i = 0; i < fieldApiListChild.length; i++) {
                      let field = fieldApiListChild[i];
                      let fieldLabel = this.fieldLabelMap[field.toLowerCase()];
                      if(childProdItem[j].Child_Quote_item_Product_Type__c == "HPBX Equipment" && field === 'IP_Type__c'){
                       fieldLabel ="Billing SubType";
                      }
                      childPrdFields.push({
                        fieldName: field,
                        fieldValue:
                          field == "Equipment_Term__c"
                            ? prodItem.Contract_Term__c
                            : childProdItem[j][field],
                        fieldLabel: fieldLabel,
                        showEditableRow: false,
                        showInput: "SHOW_INPUT"
                      });
                    }
                  }
                  childProds.push({
                    Index: childProds.length,
                    childFields: childPrdFields
                  });
                }
              }
            }

            for (var i = 0; i < relatedFieldsList.length; i++) {
              let field = relatedFieldsList[i];
              if (field != "Id" && field != "Current_Total__c") {
                this.quoteRequestRatesId = prodItem.Quote_Request_Rates__r
                  ? prodItem.Quote_Request_Rates__r[0]["Id"]
                  : "";                
                if (
                  !(
                    (field == "GC_MRC_Rate__c" ||
                      field == "Activation_MRC_NRC_Rate__c") &&
                    !(
                      this.loggedInUser &&
                      this.loggedInUser.lstPermissionSet &&
                      (this.loggedInUser.lstPermissionSet.includes(
                        "SalesEng"
                      ) ||
                        this.loggedInUser.lstPermissionSet.includes(
                          "SplPricing"
                        ))
                    )
                  ) &&
                  !(
                    (field == "Default_Router_Cost__c" ||
                      field == "COS_Cost__c") &&
                    this.loggedInUser &&
                    this.loggedInUser.lstPermissionSet &&
                    this.loggedInUser.lstPermissionSet.includes("SalesRep")
                  ) &&
                  !(
                    field == "Vendor__c" &&
                    this.loggedInUser &&
                    this.loggedInUser.lstPermissionSet &&
                    this.loggedInUser.lstPermissionSet.includes("SalesRep") &&
                    !(
                      prodItem.Product__c == "Broadband" ||
                      prodItem.Product__c == "POTS" ||
                      prodItem.Product__c == "Mobility"
                    )
                  )
                ) {
                  let isCurrencyField = true;
                  let isCurrencyReadOnlyField = false;
                  if (
                    this.loggedInUser &&
                    this.loggedInUser.lstPermissionSet &&
                    !(
                      this.loggedInUser.lstPermissionSet.includes(
                        "SplPricing"
                      ) ||
                      this.loggedInUser.lstPermissionSet.includes("OMAnalyst")
                    ) &&
                    (field == "IP_MRC_Rate__c" ||
                      field == "Default_Router_Rate__c" ||
                      field == "COS_MRC__c" ||
                      field == "GC_MRC_Rate__c" ||
                      field == "Activation_MRC_NRC_Rate__c")
                  ) {
                    isCurrencyReadOnlyField = true;
                    isCurrencyField = false;
                  } else if (field == "Total_MRC__c") {
                    isCurrencyReadOnlyField = true;
                    isCurrencyField = false;
                  }

                  let isPicklist = false;
                  if (
                    field == "Unit__c" ||
                    field == "On_Net__c" ||
                    field == "Vendor__c"
                  ) {
                    isPicklist = true;
                    isCurrencyField = false;
                  }

                  rateFields.push({
                    quoteRqRatesId: prodItem.Quote_Request_Rates__r
                      ? prodItem.Quote_Request_Rates__r[0]["Id"]
                      : "",
                    fieldName: field,
                    fieldValue:
                      prodItem.Quote_Request_Rates__r &&
                      prodItem.Quote_Request_Rates__r[field]
                        ? prodItem.Quote_Request_Rates__r[field]
                        : "",
                    picklistFieldValue:
                      prodItem.Quote_Request_Rates__r &&
                      prodItem.Quote_Request_Rates__r[0][field]
                        ? prodItem.Quote_Request_Rates__r[0][field]
                        : "Select",
                    fieldLabel: this.rateFieldLabelMap[field.toLowerCase()],
                    isPicklistField: isPicklist,
                    isUnitField: field == "Unit__c" ? true : false,
                    isOnNetField: field == "On_Net__c" ? true : false,
                    isVendor: field == "Vendor__c" ? true : false,
                    isCurrencyField: isCurrencyField,
                    isTextField: false,
                    isCurrencyReadOnlyField: isCurrencyReadOnlyField,
                    isUnitField: field == "Unit__c" ? true : false,
                    showEditableRow: false,
                    showInput: "SHOW_INPUT",
                    mrc: prodItem.Quote_Request_Rates__r
                      ? prodItem.Quote_Request_Rates__r[0][
                          "Circuit_MRC_Rate1__c"
                        ]
                      : "",
                    margin: prodItem.Quote_Request_Rates__r
                      ? prodItem.Quote_Request_Rates__r[0]["Margin_Amount__c"]
                      : "",
                    marginPercent: prodItem.Quote_Request_Rates__r
                      ? prodItem.Quote_Request_Rates__r[0]["Margin_Percent__c"]
                      : "",
                    cost: prodItem.Quote_Request_Rates__r
                      ? prodItem.Quote_Request_Rates__r[0]["Cost__c"]
                      : "",
                    surcharge: prodItem.Quote_Request_Rates__r
                      ? prodItem.Quote_Request_Rates__r[0]["Surcharge__c"]
                      : ""
                  });
                }
              }
            }
            this.finalProdArray.push({
              showLocationsLabel: "ShowTable",
              showLocationTableCheck: false,
              showEditDeletePopoverLabel: "ShowPopover",
              showEditDeletePopoverCheck: false,
              product: prodItem,
              prodFields: prdFields,
              ratesFields: rateFields,
              childPrdsFields: childProds,
              vendorList: vendorOptions,
              disableSelection: rateFields.length > 0 ? false : true
            });
          } else {
            this.finalProdArray.push({
              showLocationsLabel: "ShowTable",
              showLocationTableCheck: false,
              showEditDeletePopoverLabel: "ShowPopover",
              showEditDeletePopoverCheck: false,
              product: prodItem,
              prodFields: [],
              ratesFields: [],
              vendorList: [],
              childPrdsFields: [],
              disableSelection: true
            });
          }
        });
        console.log(JSON.stringify(this.finalProdArray));
        this.showLoading = false;
      })
      .catch((error) => {
        console.log("Error=>" + error);
      });

    getActionStatuses({ quoteRequestId: this.quoteRequestId,expiredDate:this.days })
      .then((response) => {
        this.actionStatuses = response.childExpand;
        for (const key in this.actionStatuses) {
          if (this.actionStatuses[key].disabled == true) {
            this.actionsCSS[key] = this.disabledCSS;
          } else {
            this.actionsCSS[key] = this.enabledCSS;
          }
        }
        console.log(
          "byProductViewComponent getActionStatuses:response => " +
            JSON.stringify(response)
        );
      })
      .catch((error) => {
        console.log(
          "byProductViewComponent getActionStatuses:error => " +
            JSON.stringify(error)
        );
      });
  }

  generateDropdownOptions(lstVendors) {
    let options = [];
    options.push({ label: "Select", value: "" });
    for (let i = 0; i < lstVendors.length; i++) {
      options.push({ label: lstVendors[i], value: lstVendors[i] });
    }

    return options;
  }

  generateDropdownOptionsFromRates(lstRateVendors) {
    let options = [];
    options.push({ label: "Select", value: "" });
    for (let i = 0; i < lstRateVendors.length; i++) {
      options.push({
        label: lstRateVendors[i].Vendor__c,
        value: lstRateVendors[i].Id
      });
    }

    return options;
  }

  enableEditField(event) {
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    let prodId = event.target.dataset.recordId;
    this.finalProdArray.forEach((pItem) => {
      if (prodId == pItem.product.Id) {
        if (label == "SHOW_INPUT") {
          pItem.ratesFields[itemIndex].showInput = "HIDE_INPUT";
          pItem.ratesFields[itemIndex].showEditableRow = true;
        } else if (label == "HIDE_INPUT") {
          pItem.ratesFields[itemIndex].showInput = "SHOW_INPUT";
          pItem.ratesFields[itemIndex].showEditableRow = false;
        }
      }
    });
  }

  handleVendorChange(event) {
    this.onChangeVal = event.target.value;
    let prodName = event.target.dataset.productName;
    if (prodName == "DIA") {
      this.handleUpdateRates(event, true);
    } else {
      this.handleUpdateRates(event, false);
    }
  }

  onSaveRates(event) {
    this.handleUpdateRates(event, false);
  }

  handleUpdateRates(event, isPIMUpdateRequired) {
    if (this.onChangeVal) {
      const itemIndex = event.currentTarget.dataset.index;
      let label = event.target.name;
      let fieldNm = event.currentTarget.dataset.id;
      let quoteRqRatesId = event.target.dataset.recordId;
      let prodId = event.target.accessKey;
      let prodName = event.target.dataset.productName;

      this.finalProdArray.forEach((pItem) => {
        if (prodId == pItem.product.Id) {
          if (label == "SHOW_INPUT") {
            pItem.ratesFields[itemIndex].showInput = "HIDE_INPUT";
            pItem.ratesFields[itemIndex].showEditableRow = true;
          } else if (label == "HIDE_INPUT") {
            pItem.ratesFields[itemIndex].showInput = "SHOW_INPUT";
            pItem.ratesFields[itemIndex].showEditableRow = false;
          }
        }
      });

      let qrrUpdateList = [];
      if (
        fieldNm != "Vendor__c" ||
        (fieldNm == "Vendor__c" && prodName == "DIA")
      ) {
        const objRate = {};
        objRate["type"] = "Quote_Request_Rates__c";
        objRate[QRR_ID.fieldApiName] = quoteRqRatesId;
        objRate[fieldNm] = this.onChangeVal;

        qrrUpdateList.push(objRate);
      } else {
        const objRate1 = {};
        objRate1["type"] = "Quote_Request_Rates__c";
        objRate1[QRR_ID.fieldApiName] = quoteRqRatesId;
        objRate1["Cheapest_Product__c"] = false;

        qrrUpdateList.push(objRate1);

        const objRate2 = {};
        objRate2["type"] = "Quote_Request_Rates__c";
        objRate2["Id"] = event.detail.value;
        objRate2["Cheapest_Product__c"] = true;

        qrrUpdateList.push(objRate2);
      }

      this.finalProdArray = [];
      updateVendorQRRatesCall({
        lstQRRUpdate: qrrUpdateList,
        productName: prodName,
        isPIMUpdateRequired: isPIMUpdateRequired
      })
        .then((response) => {
          this.getQuotesInProductView();
        })
        .catch((error) => {
          console.log("getRatesData error ==>" + JSON.stringify(error));
        })
        .finally(() => {
          this.showLoading = false;
        });
    }
  }
  saveEditedField(event) {
    if (event.keyCode === 13) {
      this.onSaveRates(event);
    }
  }
  @track onChangeVal;
  onChangeRatesValue(event) {
    this.onChangeVal = event.target.value;
  }
  @api
  displayQuotesInProductView(quoteOptionId) {
    this.quoteOptId = quoteOptionId;
    this.finalQoArray = [];
    this.locationsArray = [];
    this.productsArray = [];
    this.finalProdArray = [];
    getQuoteOptions({ quoteReqId: this.quoteRequestId }).then((result) => {
      this.quoteOptionsResponse = result;
      console.log(result);
      if (this.quoteOptId) {
        this.quoteOptNm =
          this.quoteOptionsResponse.quoteOptionMap[this.quoteOptId].Name;
        this.productsArray =
          this.quoteOptionsResponse.qOptionVsqoItemMap[this.quoteOptId];
      }
      this.productsArray.forEach((locItem) => {
        if (
          this.quoteOptionsResponse.qoItemVsLocationMap[
            this.quoteOptId + "#" + locItem.Id
          ]
        ) {
          this.locationsArray.push(
            this.quoteOptionsResponse.qoItemVsLocationMap[
              this.quoteOptId + "#" + locItem.Id
            ]
          );
        }
      });
      this.productsArray.forEach((prodItem) => {
        let lookupMap = result.prodLookupMap;
        if (
          lookupMap &&
          lookupMap[prodItem.Product__c] &&
          lookupMap[prodItem.Product__c].LookUpValue__c
        ) {
          let fieldApiList =
            lookupMap[prodItem.Product__c].LookUpValue__c.split("~");
          let prdFields = [];
          for (var i = 0; i < fieldApiList.length; i++) {
            let field = fieldApiList[i];
            prdFields.push({
              fieldName: field,
              fieldValue: prodItem[field],
              fieldLabel: this.fieldLabelMap[field.toLowerCase()]
            });
          }

          this.finalProdArray.push({
            showLocationsLabel: "ShowTable",
            showLocationTableCheck: false,
            showEditDeletePopoverLabel: "ShowPopover",
            showEditDeletePopoverCheck: false,
            product: prodItem,
            prodFields: prdFields
          });
        } else {
          this.finalProdArray.push({
            showLocationsLabel: "ShowTable",
            showLocationTableCheck: false,
            showEditDeletePopoverLabel: "ShowPopover",
            showEditDeletePopoverCheck: false,
            product: prodItem
          });
        }
      });
    });
  }

  //Opening location table
  @track myLocations;
  @track locations = [];
  @track allLocations = [];
  async openLocationTable(event) {
    this.locations = [];
    this.allLocations = [];
    const qoItemIndex = parseInt(event.target.dataset.index);
    this.productsArray.forEach((locItem) => {
      this.locationsArray.push(
        this.quoteOptionsResponse.qoItemVsLocationMap[
          this.quoteOptId + "#" + locItem.Id
        ]
      );
    });
    var prodLocations = this.locationsArray[qoItemIndex];
    console.log("prodLocations" + prodLocations);
    if (prodLocations) {
      prodLocations.forEach((locItem) => {
        this.locations.push({
          Id: locItem.Id,
          locKey: locItem.Id,
          selected: true,
          grpName: locItem.Group_Name__c,
          locName: locItem.Name,
          address: locItem.Address__c,
          cityName: locItem.City__c,
          stateName: locItem.State__c,
          zipCode: locItem.Zip__c,
          phoneNum: locItem.Telephone_Number__c,
          locSelected: locItem.isSelected__c
        });
      });
    }
    this.allLocations = this.locations;
    try {
      this.populateFilterOptionValues(this.locations);
    } catch (ex) {}
    //table Open logic start from here
    let prodKey = event.currentTarget.accessKey;
    event.preventDefault(event);
    let label = event.currentTarget.name;

    this.finalProdArray.forEach((pItem) => {
      if (pItem.product.Id == prodKey) {
        if (label == "ShowTable") {
          pItem.showLocationsLabel = "HideTable";
          pItem.showLocationTableCheck = true;
        } else if (label == "HideTable") {
          pItem.showLocationsLabel = "ShowTable";
          pItem.showLocationTableCheck = false;
        }
      } else {
        pItem.showLocationsLabel = "ShowTable";
        pItem.showLocationTableCheck = false;
      }
    });

    // if ( label == 'ShowTable' ) {
    //    this.finalProdArray.forEach(pItem=>{
    //      if(pItem.product.Id == prodKey){
    //       pItem.showLocationsLabel = 'HideTable';
    //       pItem.showLocationTableCheck = true;
    //      }
    //    });
    // } else if  ( label == 'HideTable' ) {
    //   this.locations = [];
    //   this.allLocations = [];
    //   this.finalProdArray.forEach(pItem=>{
    //     if(pItem.product.Id == prodKey){
    //     pItem.showLocationsLabel = 'ShowTable';
    //     pItem.showLocationTableCheck = false;
    //     }
    //  });
    // }
  }

  showEditDeletePopover(event) {
    let prodKey = event.target.accessKey;
    event.preventDefault(event);
    let label = event.target.name;
    this.finalProdArray.forEach((pItem) => {
      if (pItem.product.Id == prodKey) {
        if (label == "ShowPopover") {
          pItem.showEditDeletePopoverLabel = "HidePopover";
          pItem.showEditDeletePopoverCheck = true;
        } else if (label == "HidePopover") {
          pItem.showEditDeletePopoverLabel = "ShowPopover";
          pItem.showEditDeletePopoverCheck = false;
        }
      } else {
        pItem.showEditDeletePopoverLabel = "ShowPopover";
        pItem.showEditDeletePopoverCheck = false;
      }
    });
  }

  filterGroupName(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "group");
    }
    console.log("selectedValue " + selectedValue);
  }
  filteraddress(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "address");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterPhone(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "phone");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterLocationName(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "location");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterCity(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "city");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterState(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "state");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterZip(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allLocations = this.locations;
      this.populateFilterOptionValues(this.allLocations);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "zip");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterData(selectedValue, fieldName) {
    this.allLocations = [];
    if (fieldName == "group") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].grpName == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "location") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].address == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "city") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].cityName == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "state") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].stateName == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "zip") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].zipCode == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "phone") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].phoneNum == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "npanxx") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].npanxx == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "products") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].products == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "address") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].address == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "buildingApt") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].buildingApt == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "floorSuite") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].floorSuite == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "glcCode") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].glcCode == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "locationStoreNum") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].locationStoreNum == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else if (fieldName == "units") {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].locationStoreNum == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    } else {
      for (let i = 0; i < this.locations.length; i++) {
        if (this.locations[i].allPriceColumns == selectedValue) {
          this.allLocations.push(this.locations[i]);
        }
      }
    }

    console.log("allLocations " + JSON.stringify(this.allLocations));
    this.populateFilterOptionValues(this.allLocations);
  }

  //dynamic filter related values
  populateFilterOptionValues(locationData) {
    // Group Name
    var arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.grpName;
          }
        })
      )
    ];
    this.groupNameOption = ["All Groups"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.groupNameOption.push(arraycheck[item]);
      }
    }

    // Location Name
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.address;
          }
        })
      )
    ];
    this.locationNameOption = ["All Locations"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.locationNameOption.push(arraycheck[item]);
      }
    }

    //city
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.cityName;
          }
        })
      )
    ];
    this.cityOption = ["All Cities"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.cityOption.push(arraycheck[item]);
      }
    }

    //State
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.stateName;
          }
        })
      )
    ];
    this.stateOption = ["All States"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.stateOption.push(arraycheck[item]);
      }
    }

    //zip
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.zipCode;
          }
        })
      )
    ];
    this.zipOption = ["All Zip Codes"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.zipOption.push(arraycheck[item]);
      }
    }

    //npaOption
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.npanxx;
          }
        })
      )
    ];
    this.nPAOption = ["All NPA?NXX"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.nPAOption.push(arraycheck[item]);
      }
    }
    ///Start - Added for US Customize.

    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.address;
          }
        })
      )
    ];
    this.addressOption = ["All Address"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.addressOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.phoneNum;
          }
        })
      )
    ];
    this.phoneOption = ["All Phones"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.phoneOption.push(arraycheck[item]);
      }
    }

    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.buildingApt;
          }
        })
      )
    ];
    this.buildingAptOption = ["All Building/Apt"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.buildingAptOption.push(arraycheck[item]);
      }
    }

    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.floorSuite;
          }
        })
      )
    ];
    this.floorSuiteOption = ["All Floor/Suite"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.floorSuiteOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.glcCode;
          }
        })
      )
    ];
    this.glcCodeOption = ["All Floor/Suite"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.glcCodeOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.locationStoreNum;
          }
        })
      )
    ];
    this.locationStoreNumOption = ["All Location/Store Number"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.locationStoreNumOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.units;
          }
        })
      )
    ];
    this.unitsOption = ["All Units"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.unitsOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.allPriceColumns;
          }
        })
      )
    ];
    this.allPriceColumnsOption = ["All Price Columns"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.allPriceColumnsOption.push(arraycheck[item]);
      }
    }
    ///End - Added for US Customize.
  }
  callChildMethodToResetEditText() {
    var autoComp = this.template.querySelectorAll("c-auto-complete-text");
    for (let i = 0; i < autoComp.length; i++) {
      autoComp[i].reserFilterColumns();
    }
  }
  enableQOInput(event) {
    if (this.actionStatuses["byProductEditProduct"].disabled == false) {
      console.log(event.target.name);
      this.openLocationTable(event);
      let tempLocationsArray = JSON.parse(JSON.stringify(this.allLocations));
      for (let i = 0; i < tempLocationsArray.length; i++) {
        tempLocationsArray[i].locSelected = true;
      }
      const selectedEvent = new CustomEvent("editproductview", {
        detail: {
          selectedLocations: tempLocationsArray
        }
      });
      // Dispatches the event.
      this.dispatchEvent(selectedEvent);
    }
  }

  deleteQuoteOption(event) {
    if (this.actionStatuses["byProductDeleteProduct"].disabled == false) {
      if (this.finalProdArray.length > 0) {
        let deleteId = event.currentTarget.dataset.name
          ? event.currentTarget.dataset.name
          : event.target.name;
        deteteProductandRelatedQLOCall({ qoiId: deleteId })
          .then((response) => {
            if (response == "SUCCESS") {
              this.dispatchEvent(
                new ShowToastEvent({
                  title: "Success",
                  message: "Product deleted successfully",
                  variant: "success"
                })
              );

              // To delete the record from UI
              /*this.finalProdArray.forEach(pItem=>{
                if(pItem.product.Id == deleteId){
                    this.finalProdArray.splice(pItem, 1);
                }
            });*/
              console.log(
                "this.finalProdArray" + JSON.stringify(this.finalProdArray)
              );
              const selectedEvent = new CustomEvent("deleteponproductview", {
                detail: {
                  productId: event.target.name
                }
              });
              // Dispatches the event.
              this.dispatchEvent(selectedEvent);
              this.getQuotesInProductView();
            } else {
              this.dispatchEvent(
                new ShowToastEvent({
                  title: "Error",
                  message: response,
                  variant: "error"
                })
              );
            }
          })
          .catch((error) => {
            this.dispatchEvent(
              new ShowToastEvent({
                title: "Error",
                message: error,
                variant: "error"
              })
            );
          });
      } else {
        /*this.dispatchEvent(
          new ShowToastEvent({
              title: 'Error',
              message: 'You are tyring to delete the last product. A quote option should have at least one product.',
              variant: 'error'
          })
        );*/
      }
    }
  }

  showdiscountmodal(event) {
    if (this.mapMRC.size > 0) {
      console.log("Clicked");
      this.showMRCBox = true;
    }
  }

  onMRCPopupClose(event) {
    this.showMRCBox = false;
  }

  closePopUpAndRefresh(event) {
    this.showMRCBox = false;
    this.allowMRCCalculation = false;
    this.getQuotesInProductView();
  }
}