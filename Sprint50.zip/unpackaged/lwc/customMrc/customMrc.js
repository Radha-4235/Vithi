import { LightningElement, api, track, wire } from "lwc";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import saveRateRequest from "@salesforce/apex/CustomMrc.updateQRR";
import saveRateRequestByLocation from "@salesforce/apex/CustomMrc.updateQRRByLocation";
import getEditMRCFields from "@salesforce/apex/CustomMrc.getEditMRCFields";

//import
const STANDARD_SURCHARGE = 1.07;

export default class CustomMrc extends LightningElement {
    @api showMRCModal;
    @api mapMRC;
    @track updatedQOIMRC = new Map();
    @track showMRCBox;
    @track className = "selected";
    selectedType = new Map(); // Dollar or Percentage
    selectedTypeOfSettlement = "Discount"; // Discount or Margin
    settlementValue = new Map(); // Value either in dollor or percentage for discount and margin
    mrcAmountUpdated;
    loadSpinner = false;
    @track displayMap;
    prodAdded = new Map();
    mapProdWithFields = new Map();
    @track selectedProduct = new Map();
    selectedFields = new Map();
    showChargeType = true;
    totalMRCConsideredFieldsMap = new Map();
    uniqueKeyForOtherLocation = new Map();
    secondaryProductSet = new Set([ 'Mobility', 'VoIP' ]);

    connectedCallback() {
        getEditMRCFields()
        .then( result => {
            if(result) {
                this.displayMap = [];
                let lstOfKeys = [];
                this.mapMRC.forEach((value, key) => {
                    let lstFields = [];
                    let prodName = value.prodName;
                    if(value.secondaryProduct && this.secondaryProductSet.has(prodName)){
                        prodName = value.prodName+"_"+value.secondaryProduct.replaceAll(" ","");
                    }
                    if(!this.prodAdded.has(prodName/*value.prodName*/)) {
                        if( result.hasOwnProperty(prodName) ) {
                            result[prodName].productFieldMapping.Fields__c.split(',').forEach(item => {
                                if(result[prodName].schemaFieldMapping[value.prodName+'-'+item.trim()]) {
                                    lstFields.push({ label : result[prodName].schemaFieldMapping[value.prodName+'-'+item.trim()].Display_Label__c, value: item.trim()});
                                    if(result[prodName].schemaFieldMapping[value.prodName + '-' + item.trim()].Edit_MRC_Total_MRC__c) {
                                        this.totalMRCConsideredFieldsMap.set(prodName/*value.prodName*/ + '-' + item.trim(), item.trim());
                                    }
                                }
                            });
                        }
                        this.displayMap.push({key: key, value: value, fieldsOptions: lstFields, chkbxChecked: false });          
                        this.prodAdded.set(prodName/*value.prodName*/, key);
                    } else {
                        if(!this.uniqueKeyForOtherLocation.has(Object.fromEntries(this.prodAdded)[prodName/*value.prodName*/])) {
                            lstOfKeys = [];
                            lstOfKeys.push(key)
                            this.uniqueKeyForOtherLocation.set(Object.fromEntries(this.prodAdded)[prodName/*value.prodName*/], lstOfKeys);
                        } else {
                            this.uniqueKeyForOtherLocation.get(Object.fromEntries(this.prodAdded)[prodName/*value.prodName*/]).push(key);
                        }
                    }
                });
            }
        })
        .catch(error => {
            console.log('error:: ' + error);
        });
        
    }
    openModal() {
        // Setting boolean variable to true, this will show the Modal
        this.showMRCModal = true;
    }

    get typeOfSelection() {
        return [{
                label: "None",
                value: ""
            },
            {
                label: "Dollar",
                value: "Dollar"
            },
            {
                label: "Percentage",
                value: "Percent"
            }
        ];
    }

    switchdiscount(event) {
        this.template.querySelector(".marginblock").className = "buttonbox marginblock";
        this.template.querySelector(".discountblock").className = "buttonbox discountblock selected";
        this.selectedTypeOfSettlement = "Discount";
        this.showChargeType = true;
    }

    switchmargin(event) {
        this.template.querySelector(".marginblock").className = "buttonbox marginblock selected";
        this.template.querySelector(".discountblock").className = "buttonbox discountblock";
        this.selectedTypeOfSettlement = "Margin";
        this.showChargeType = false;
    }

    handleFieldsChange(event) {
        const key = event.currentTarget.dataset.prodkey;
        this.selectedFields.set(key, event.target.value);
        if(event.target.value.length === 0) {
            this.displayMap[event.currentTarget.dataset.index].chkbxChecked = false;
            this.selectedProduct.set(event.currentTarget.dataset.prodkey, false);
        } else {
            this.displayMap[event.currentTarget.dataset.index].chkbxChecked = true;
            this.selectedProduct.set(event.currentTarget.dataset.prodkey, true);
        }
        
        this.displayMap.splice(event.currentTarget.dataset.index, 1, this.displayMap[event.currentTarget.dataset.index]);
        
    }

    handleProdSelection(event) {
        if(this.selectedTypeOfSettlement === "Margin") {
            let arrCircuitMRC = [];
            arrCircuitMRC.push('Circuit_MRC_Rate1__c')
            this.selectedFields.set(event.currentTarget.dataset.prodkey, arrCircuitMRC);            
        }
        this.selectedProduct.set(event.currentTarget.dataset.prodkey, event.target.checked);
    }

    handleFormInputChange(event) {
        const key = event.currentTarget.dataset.prodkey;
        if (event.target.name === "typeOfSelection") {
            this.selectedType.set(key, event.target.value);
        }
        if (event.target.name === "settlementValue") {
            this.settlementValue.set(key, parseFloat(event.target.value));
        }
    }

    handleSave(event) {
        const isInputsCorrect = [
            ...this.template.querySelectorAll(".settlementValue")
        ].reduce((validSoFar, inputField) => {
            inputField.reportValidity();
            return validSoFar && inputField.checkValidity();
        }, true);
        if (isInputsCorrect) {
            this.loadSpinner = true;
            let mapLocation = new Map();
            
            this.mapMRC.forEach((value, key) => {
                try {
                    let prodName = value.prodName;
                    if(value.secondaryProduct && this.secondaryProductSet.has(prodName)){
                        prodName = value.prodName+"_"+value.secondaryProduct.replaceAll(" ","");
                    }
                    let settlementAmount = 0;
                    let settlementType;
                    // Add other selected location as currently only one product of single location get added in above methods
                    if(this.uniqueKeyForOtherLocation.has(key)) {
                            if(this.selectedProduct.has(this.prodAdded.get(prodName/*value.prodName*/))) {
                            let arrCircuitMRC;
                            this.uniqueKeyForOtherLocation.get(key).forEach(item => {
                                this.selectedType.set(item, Object.fromEntries(this.selectedType)[key]);
                                this.settlementValue.set(item, Object.fromEntries(this.settlementValue)[key]);
                                if(this.selectedTypeOfSettlement === "Margin") {
                                    arrCircuitMRC = [];
                                    arrCircuitMRC.push('Circuit_MRC_Rate1__c')
                                    this.selectedFields.set(item, arrCircuitMRC);
                                } else {
                                    this.selectedFields.set(item, Object.fromEntries(this.selectedFields)[key]);
                                }
                                this.selectedProduct.set(item, Object.fromEntries(this.selectedProduct)[key]);
                            });
                        }
                    }

                    if(!this.selectedProduct.has(this.prodAdded.get(prodName/*value.prodName*/))) {
                        return;
                    }

                    if(this.selectedFields.has(key)) {
                        if(this.selectedType.has(key)) {
                            settlementType = this.selectedType.get(key);
                        } else if(this.prodAdded.has(prodName/*value.prodName*/) && this.selectedType.has(this.prodAdded.get(prodName/*value.prodName*/))) {
                            settlementType = this.selectedType.get(this.prodAdded.get(prodName/*value.prodName*/));
                        }

                        if(settlementType) {
                            let mapQRR = new Map();
                            let marginCalculatedInDollar = 0;
                            let marginCalculatedInPercentage = 0;
                            let totalMRC = 0;
                            if (!value.cost) {
                                value.cost = 0;
                            }
                            
                            if (value.locationId) {
                                mapLocation.set(value.locationId, value.locationId);
                            }
                            
                            if(this.settlementValue.has(key)) {
                                settlementAmount = this.settlementValue.get(key);
                            } else if(this.prodAdded.has(prodName/*value.prodName*/) && this.settlementValue.has(this.prodAdded.get(prodName/*value.prodName*/))) {
                                settlementAmount = this.settlementValue.get(this.prodAdded.get(prodName/*value.prodName*/));
                            }                    

                            this.selectedFields.get(key).forEach((fieldName, fieldKey) => {
                                let affectedFieldValue = 0;
                                let selectedFieldValue = value.rates ? value.rates[fieldName] : 0;
                                if (this.selectedTypeOfSettlement === "Discount") {
                                    if (settlementType === "Percent") {
                                        affectedFieldValue = selectedFieldValue - (selectedFieldValue * settlementAmount) / 100;
                                        if (affectedFieldValue < 100) {
                                            affectedFieldValue = Math.round(affectedFieldValue);
                                        } else if (affectedFieldValue >= 100) {
                                            affectedFieldValue = Math.round(affectedFieldValue / 10) * 10;
                                        }
                                        mapQRR.set('Discount_Percent__c', settlementAmount);
                                    } else if (settlementType === "Dollar") {
                                        affectedFieldValue = selectedFieldValue - settlementAmount;
                                        mapQRR.set('Discount_Amount__c', settlementAmount);
                                    }
                                    if(this.totalMRCConsideredFieldsMap.has(prodName/*value.prodName*/ + '-' + fieldName)) {
                                        if(totalMRC === 0) {
                                            totalMRC = value.rates['Total_MRC__c'] - value.rates[fieldName] + affectedFieldValue;
                                        } else {
                                            totalMRC = totalMRC - value.rates[fieldName] + affectedFieldValue;
                                        }
                                    }
                                    marginCalculatedInDollar = totalMRC - value.cost;
                                    marginCalculatedInPercentage = ((totalMRC - value.cost) / totalMRC) * 100;
                                    mapQRR.set('Margin_Amount__c', marginCalculatedInDollar);
                                    mapQRR.set('Margin_Percent__c', marginCalculatedInPercentage );
                                } else if (this.selectedTypeOfSettlement === "Margin") {
                                    let costValue = 0;
                                    if(prodName.toLowerCase() === 'guardian') {
                                        costValue = value.rates['Total_Cost__c'];
                                    } else {
                                        costValue = value.rates['GC_MRC_Rate__c'];
                                    }
                                    if (settlementType === "Percent") {
                                        let marginDollar = (value.rates['Total_MRC__c'] * settlementAmount)/100;
                                        affectedFieldValue = value.rates[fieldName] - (value.rates['Total_MRC__c'] - costValue - marginDollar);
                                        mapQRR.set('Margin_Amount__c', marginDollar);
                                        mapQRR.set('Margin_Percent__c', settlementAmount);
                                    } else if (settlementType === "Dollar") {
                                        affectedFieldValue = value.rates[fieldName] - ((value.rates['Total_MRC__c'] / value.qty) - costValue - settlementAmount) ;
                                        mapQRR.set('Margin_Amount__c', settlementAmount);
                                        mapQRR.set('Margin_Percent__c', (settlementAmount / value.rates['Total_MRC__c']) * 100);
                                    }
                                    
                                }                                
                                mapQRR.set(fieldName, affectedFieldValue);
                            });
                            
                            this.updatedQOIMRC.set(key, Object.fromEntries(mapQRR));
                        }
                    }
                } catch(err) {
                    this.loadSpinner = false;
                    this.showNotification("Error!", err.message, "error");
                }
            });
            if (mapLocation != null && mapLocation.size > 0) {
                saveRateRequestByLocation({
                    mapQOI: Object.fromEntries(this.updatedQOIMRC),
                    selectedType: Object.fromEntries(this.selectedType),
                    selectedTypeOfSettlement: this.selectedTypeOfSettlement,
                    settlementAmount: Object.fromEntries(this.settlementValue),
                    locationIds: Object.fromEntries(mapLocation)
                })
                .then((result) => {
                    if (result && result.isSuccess) {
                        const selectedEvent = new CustomEvent("closepopupandrefresh", {
                            detail: ""
                        });
                        this.dispatchEvent(selectedEvent);
                    }
                    this.loadSpinner = false;
                })
                .catch((error) => {
                    console.log(JSON.stringify(error));
                    this.loadSpinner = false;
                });
            }
        } else {
            this.showNotification("Error!", "Please enter valid value", "error");
            this.loadSpinner = false;
        }
    }

    closeModal() {
        // Setting boolean variable to false, this will hide the Modal
        this.showMRCModal = false;
        this.showMRCBox = false;
        const selectedEvent = new CustomEvent("closepopup", {
            detail: ""
        });
        this.dispatchEvent(selectedEvent);
    }

    showNotification(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(evt);
    }
}