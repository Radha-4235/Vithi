import { LightningElement, track, api, wire } from "lwc";
import QUOTE_REQUEST_OBJECT from "@salesforce/schema/Quote_Request_2__c";
import { NavigationMixin } from "lightning/navigation";
import getQuoteDetails from "@salesforce/apex/NewQuoteRequestHandler.getQuoteDetails";
import saveNoteCall from "@salesforce/apex/NotesHandler.saveNotes";
import sendNotification from "@salesforce/apex/NotificationsUtility.sendNotification";
import getTeamsQueueId from "@salesforce/apex/NewQuoteRequestHandler.getQueueId";
import changeOwner from "@salesforce/apex/NewQuoteRequestHandler.updateOwner";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import submitQuoteRequeststatus from "@salesforce/apex/NewQuoteRequestHandler.submitQuoteRequeststatus";
import getQuoteRequeststatusvalue from "@salesforce/apex/NewQuoteRequestHandler.getQuoteRequeststatusvalue";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import { getPicklistValues } from "lightning/uiObjectInfoApi";
import QUOTEREQSTATUS_FIELD from "@salesforce/schema/Quote_Request_2__c.Quote_Request_Status__c";
import QUOTEREQTYPE_FIELD from "@salesforce/schema/Quote_Request_2__c.Quote_Type__c";
import getLastSavedDate from "@salesforce/apex/NewQuoteRequestHandler.getLastSavedDate";
import getQuoteOptionsinfo from "@salesforce/apex/ExportCSVController.getQuoteOptionsinfo";
import salesRepQrViewLoadCall from "@salesforce/apex/NewQuoteRequestHandler.salesRepQrViewLoad";
import currenttotalcall from "@salesforce/apex/NewQuoteRequestHandler.getcurrenttotal";
import pushTo1S from "@salesforce/apex/OneSourceIntegration.pushTo1S";
import reSubmit from "@salesforce/apex/NewQuoteRequestHandler.reSubmit";
import validationCheckCall from "@salesforce/apex/NewQuoteRequestHandler.validationCheck";
import getQuoteRequestRateError from "@salesforce/apex/NewQuoteRequestHandler.getQuoteRequestRateError";
import getReportId from "@salesforce/apex/NewQuoteRequestHandler.getReportId";
import { updateRecord } from "lightning/uiRecordApi";
import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import ID_FIELD from "@salesforce/schema/Quote_Request_2__c.Id";
import SUBSTATUS_FIELD from "@salesforce/schema/Quote_Request_2__c.Sub_Status__c";
import completedBySPCall from "@salesforce/apex/NewQuoteRequestHandler.completedBySP";
import completedBySECall from "@salesforce/apex/NewQuoteRequestHandler.seCompletedValidationCheck";
import {
  subscribe,
  unsubscribe,
  onError,
  setDebugFlag,
  isEmpEnabled
} from "lightning/empApi";
import getActionStatuses from "@salesforce/apex/NewQuoteRequestHandler.getActionStatuses";
import spAppliedIcon from "@salesforce/resourceUrl/SPAppliedIcon";
import Special_Pricing__Field from "@salesforce/schema/Quote_Request_2__c.Special_Pricing__c";
import getSolutionEngineersList from "@salesforce/apex/NewQuoteRequestHandler.getSolutionEngineersList";
import updateQuoteRequestCall from "@salesforce/apex/NewQuoteRequestHandler.updateQuoteRequest";
import deleteQRUser from "@salesforce/apex/NewQuoteRequestHandler.deleteSObjects";
import createQuoteUserRequest from "@salesforce/apex/NewQuoteRequestHandler.createQuoteUserRequest";
import deleteQuoteRequestRatesCall from "@salesforce/apex/NewQuoteRequestHandler.deleteQuoteRequestRates";

import A3QuotingMessageChannel from "@salesforce/messageChannel/A3QuotingMessageChannel__c";
import {
  subscribe as subscribeLMS,
  createMessageContext
} from "lightning/messageService";
import restoreDeletedQRR from "@salesforce/apex/NewQuoteRequestHandler.restoreDeletedQRR";

export default class SalesRepQRView extends NavigationMixin(LightningElement) {
  @api recordId;
  isSpFinanceSupport = false;
  showSpinner = false;
  @api viewOnly;
  onDeleteButton = false;
  onAddButton = true;
  SEuserUpdated = true;
  @track radiocheckbox;
  @track loaRadioCheckbox;
  closedWonSucess = false;
  SendToCustomerSucess = false;
  _handler;
  isAnyPopupDisplayed = false;
  clickedExportLabel = "Show";
  ExportPopover = false;
  openOptionsPopover = false;
  openChangeStatus = false;
  showQRSubstatus = false;
  openGenerateQuote = false;
  openClosedWonPopup = false;
  openSendQuoteCustomer = false;
  qrStatus = "Pending";
  qrSubStatus = "Unassigned";
  qrSubStatusOnChange;
  qrvalues;
  qrInputValue;
  @track qrSalesEngineer = false;
  reportId;
  error;
  clickedOptionsLabel = "showOptions";
  openRequestSEReview = false;
  openRequestSPReview = false;
  @track objectInfo;
  @track quoteReqStatus;
  @track quoteReqSubStatus = [];
  @track lastSavedDate;
  @track qrrCreatedDate;
  @track expiredDate;
  @track loggedInUser = {};
  @track isLoaded = false;
  @track refreshQuote = false;
  @track sendQRCust = false;
  @track error;
  @track reSubmit = false;
  @track actionStatuses = {};
  @track spApplied;
  @track generateQuote = false;
  @track currentTotal;
  currentTotalLessThanZero = false;
  @track quoteRequestQuoteType;
  disableSave = false;
  isFilterClosedWon = true;
  @track locationandprodMap = [];
  @track selectedLocationGuiIds;
  errorMsg;
  sourceSEPopup;
  qEValue;
  actionStatuses = { customerDetails: {}, users: {} };
  spAppliedimg = spAppliedIcon;
  //@track QuoteOptions;

  subscription;
  channelName = "/event/Quote_Request_Status__e";

  @track isAddressErrorsMorethan30 = false;
  @track isAddressErrorsLessthan30 = false;
  @track isAddressErrorsLessThanorEqualto50 = false;
  @track isAddressErrorsMoreThan50 = false;
  @track addressErrorsCount = 0;
  @track telephoneNoErrorCount = 0;
  @track footPrintErrorCount = 0;
  @track telephonePopup = false;
  @track footPrintPopup = false;
  @track isSPReviewAddressError = true;
  @track showAssignedTo = false;
  @track assignedTo = "";
  @track totalErrors;
  @track excelHeader = [];
  @track xlsData = []; // store all tables data
  @track excelworkSheetNameList = []; // store all the sheets name of the the tables
  @track excelfilename = "Quote_Request.xlsx"; // store file name
  isSubmittedtoSEReview = false;
  ratesDeleteWarningPopup = false;
  noLocationOrProductSelected = false;
  deleteSource;
  excelHeader = [
    "Location Name",
    "City",
    "State",
    "BTN",
    "Granite Access",
    "Bandwidth",
    "Another Product Parameter",
    "Access MRC (Dynamic)",
    "Granite Access",
    "Data Plan",
    "Another Product Parameter",
    "Access MRC",
    "Total Site MRC"
  ];

  @wire(getReportId, { reportName: "Quote Request Rates Error Info" })
  report({ data, error }) {
    if (data) {
      this.reportId = data;
    } else if (error) {
      this.error = error;
    }
  }

  /*@wire(getRecord, { recordId: '$recordId', fields: FIELDS })
    quoteReqStatus;
    get quoteReqStatus() {
      //alert('Testing'+this.quoteReqStatus.data.fields.Quote_Type__c.value);
        return this.quoteReqStatus.data.fields.Quote_Type__c.value;
    }*/
  @wire(getRecord, { recordId: "$recordId", fields: [QUOTEREQTYPE_FIELD] })
  quoteRequestQuoteType;

  get QuoteType() {
    console.log("*********test123*******");
    return getFieldValue(this.quoteRequestQuoteType.data, QUOTEREQTYPE_FIELD);
  }
  //quoteRequestQuoteType;

  viewReport(event) {
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.reportId,
        objectApiName: "Report",
        actionName: "view"
      },
      state: {
        fv0: this.recordId.slice(0, -3)
      }
    });
  }

  //get Quote Request object metadata which will also include Record type
  @wire(getObjectInfo, { objectApiName: QUOTE_REQUEST_OBJECT })
  objectInfo;

 @track quoteRequest = QUOTE_REQUEST_OBJECT;
  //fetch Quote Request status from Quote Request object
  @wire(getPicklistValues, {
    recordTypeId: "$objectInfo.data.defaultRecordTypeId",
    fieldApiName: QUOTEREQSTATUS_FIELD
  })
  quoteReqStatus;

  get quoteReqStatusOptions() {
    return [
      {
        label: "Additional Customer Info Needed",
        value: "Additional Customer Info Needed"
      },
      { label: "Action Needed", value: "Action Needed" },
      { label: "Cancelled", value: "Cancelled" },
      { label: "Closed - LOST", value: "Closed - LOST" },
      { label: "Needs More Information", value: "Needs More Information" },
      { label: "Pending Carrier Info", value: "Pending Carrier Info" },
      { label: "Pending Pricing", value: "Pending Pricing" },
      // { label: 'Unsubmitted', value: 'Unsubmitted' },
      //{ label: 'Pricing Complete', value: 'Pricing Complete' },
      { label: "Pending Sales", value: "Pending Sales" },
      { label: "Pending Finance Review", value: "Pending Finance Review" },
      { label: "Pricing Complete", value: "Pricing Complete" },
      {
        label: "Putting together proposals/Pending Docs",
        value: "Putting together proposals/Pending Docs"
      },
      { label: "Under Negotiation", value: "Under Negotiation" },
      { label: "Unsubmitted", value: "Unsubmitted" }
    ];
  }

  days;
 
 getCurrentDateColor(expiredDate) {
  var currentDate = new Date();
  
  var predate = currentDate.toISOString().slice(0,10);
  const expirationDateObj = new Date(expiredDate);
  var expdate =  expirationDateObj.toISOString().slice(0,10);
  this.days =  Math.ceil((expirationDateObj-currentDate)/8.64e7);
  console.log('days @@'+this.days);
 }

get expireDateColour() {
  return `${this.days < 0 ? "red-txt" : "black"}`; 
}

  //fetch Quote Options
  @wire(getQuoteOptionsinfo, { QRId: "$recordId" })
  wiredRecord({ error, data }) {
    if (error) {
      this.error = "Unknown error";
      if (Array.isArray(error.body)) {
        this.error = error.body.map((e) => e.message).join(", ");
      } else if (typeof error.body.message === "string") {
        this.error = error.body.message;
      }
      this.record = undefined;
    } else if (data) {
      console.log("***recordId::", this.recordId);
      console.log("***data::", data);
      this.QuReqId = this.recordId;
      this.xlsData = data;
      console.log("***xlsData::", JSON.stringify(this.xlsData));
    }
  }
  //fetch total errors from Quote_Request_Rates__c
  @wire(getQuoteRequestRateError, { QRId: "$recordId" })
  countRec({ error, data }) {
    if (data) {
      console.log("inside function+++");
      if (data != null) {
        console.log(JSON.stringify(data[0]));
        this.totalErrors = data.filter(
          (item) => item.Record_Error_Info__c != null
        ).length;
        var addressErrors = data.filter(
          (item) => item.Record_Error_Info__c == "AddressStdError"
        );
        var telephonenoerror = data.filter(
          (item) => item.Record_Error_Info__c == "PendingNPANXX"
        );
        let footPrintError = data.filter(
          (item) => item.Record_Error_Info__c == "FootprintFailedPots"
        );
        if (telephonenoerror.length > 0) {
          this.telephoneNoErrorCount = telephonenoerror.length;
          this.telephonePopup = true;
          //this.updateQuoteRequest("Action Needed");
        } else if (footPrintError.length > 0) {
          this.footPrintErrorCount = footPrintError.length;
          this.footPrintPopup = true;
          //this.updateQuoteRequest("Action Needed");
        } else if (addressErrors.length > 0) {
          this.addressErrorsCount = addressErrors.length;
          var errorPercentage = (addressErrors.length / data.length) * 100;
          if (
            data[0].Quote_Location_Option__r.Quote_Option__r.Quote_Request__r
              .Quote_Request_Status__c != "Pending Finance Review" &&
            data[0].Quote_Location_Option__r.Quote_Option__r.Quote_Request__r
              .Quote_Request_Status__c != "Pending Pricing"
          ) {
            this.isSPReviewAddressError = false;
            // if(errorPercentage > 30){
            //   this.isAddressErrorsMorethan30 = true;
            // }
            if (errorPercentage > 50) {
              // this.isAddressErrorsLessThanorEqualto50 = true;
              this.isAddressErrorsMoreThan50 = true;
              // this.updateQuoteRequest("Pending SP Review");
            } else {
              // this.isAddressErrorsLessthan30 = true;
              this.isAddressErrorsLessThanorEqualto50 = true;
              //this.updateQuoteRequest("Pricing Complete");
            }
          } else {
            this.isSPReviewAddressError = true;
          }
        }
      } else {
        this.totalErrors = 0;
      }
      console.log("inside function+++" + this.totalErrors);
    } else if (error) {
      console.log("inside error+++");
      if (Array.isArray(error.body)) {
        this.error = error.body.map((e) => e.message).join(", ");
      } else if (typeof error.body.message === "string") {
        this.error = error.body.message;
      }
      console.log("this.error+++" + this.error);
    }
  }

  showHistory = false;
  showDocuments = false;
  showLayout = false;
  notifyTargetID;
  otherNotifyTargetID;
  notifySEorSPCheck = false;
  viewOnly = false;

  @track actionsCSS = {};
  enabledCSS = "";
  disabledCSS =
    "pointer-events: none; background-color: gray; cursor: not-allowed;";

  hasSubscribedToA3QuotingChannel = false;
  messageContext = createMessageContext();

  async connectedCallback() {
    if (this.hasSubscribedToA3QuotingChannel == false) {
      subscribeLMS(this.messageContext, A3QuotingMessageChannel, (message) => {
        if(message.eventTitle=="enableClosedWon"){			
          this.closedWonButtonEnableCheck()			
        }			
        else{			
          this._getActionStatuses();			
        }
        // console.log('Subscription successful');
        console.log(
          "received an event: Source: " +
            message.eventData.source +
            "; event title: " +
            message.eventTitle
        );
        if (this.hasSubscribedToA3QuotingChannel == false) {
          this.hasSubscribedToA3QuotingChannel = true;
        }
      });
    }

    subscribeLMS(this.messageContext, A3QuotingMessageChannel, (message) => {
      if(message.eventTitle=="spApplied" || message.eventTitle == "bulkTierSPApplied"){
        this.spApplied = 	message.eventValue;
      }
      // console.log('Subscription successful');
      console.log(
        "received an event: Source: " +
          message.eventValue +
          "; event title: " +
          message.eventTitle
      );
    });

    currenttotalcall({ qrId: this.recordId }).then((currentTotal) => {
      const filterCurrentTotal = currentTotal.filter(
        (item) => item.Current_Total__c <= 0
      );
      this.currentTotalLessThanZero = filterCurrentTotal.length > 0;
      // if(!this.currentTotalLessThanZero ){
      //   this.actionsCSS.generateQuote = this.disabledCSS;
      // }
      console.log(
        "currenttotal",
        this.quoteRequestQuoteType,
        filterCurrentTotal,
        this.actionsCSS["generateQuote"],
        this.disabledCSS
      );
    });

    this.salesRepQrViewOnLoad();

    //this.getQuote();
    //await this.qrValues();

    // document.addEventListener('click', this._handler = this.close.bind(this));

    window.setTimeout(
      () =>
        document.addEventListener(
          "click",
          (this._handler = this.close.bind(this))
        ),
      500
    );
  }

  _getActionStatuses() {
    console.log(
      "currentTotalLessThanZero 328",
      this.currentTotalLessThanZero,
      this.quoteRequest,
      this.quoteRequest.Quote_Type__c == "Comparison"
    );
    getActionStatuses({ quoteRequestId: this.recordId, expiredDate:this.days})
      .then((response) => {
        this.actionStatuses = response.salesRepQRView;
        for (const key in this.actionStatuses) {
          //  if(key === 'generateQuote' && this.currentTotalLessThanZero && this.quoteRequest.Quote_Type__c == 'Comparison' && this.loggedInUser && this.loggedInUser.userType !== 'SplPricing' && this.loggedInUser.userType !== 'SplPricingManager' && this.loggedInUser.userType !== 'OMAnalyst' && this.loggedInUser.userType !== 'OMAnalystManager'){
          //   this.actionsCSS[ key ] = this.disabledCSS;
          // }
          //  else
          if (this.actionStatuses[key].disabled == true) {
            this.actionsCSS[key] = this.disabledCSS;
          } else {
            this.actionsCSS[key] = this.enabledCSS;
          }
        }
      })
      .catch((error) => {
        console.log(
          "nqrLocationsTableActions getActionStatuses:salesrepQRView => ",
          JSON.stringify(error),
          error
        );
      });
  }

  renderedCallback() {
    this.handleSubscribe(this.recordId);

    this.notifyToSalesRepViewCmp();
  }

  handleUpdatecurrentTotal(event) {
    this.dispatchEvent(
      new CustomEvent("updatecurrenttotal", {
        detail: { enableGenerateQuote: event.detail.enableGenerateQuote }
      })
    );
    currenttotalcall({ qrId: this.recordId }).then((currentTotal) => {
      const filterCurrentTotal = currentTotal.filter(
        (item) => item.Current_Total__c <= 0
      );
      this.currentTotalLessThanZero = filterCurrentTotal.length > 0;
      this._getActionStatuses();
    });
  }

  handleUpdateQrStatus(event) {
    this.qrStatus = event.detail.qrStatus;
    this.qrInputValue = event.detail.qrStatus;
    this.qrSubStatus = event.detail.qrSubStatus;
    this.subStatusOnSpReview();
    this.formateDateValue(event.detail.qrLastSavedDate);
  }

  get displaySrSrmCsrCsrmPr() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesRep") ||
      this.loggedInUser.userType == "SalesRepManager" ||
      this.loggedInUser.userType == "ChannelSalesRep" ||
      this.loggedInUser.userType == "ChannelSalesRepManager" ||
      this.loggedInUser.userType == "Premier" ||
      this.loggedInUser.userType == "ChannelsSupport" ||
      this.loggedInUser.userType == "GRID_SalesRep"
    ) {
      showFlag = true;
    }
    return showFlag;
  }

  get displaySrSrmCsrCsrmPrSpOM() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesRep") ||
      this.loggedInUser.userType == "SalesRepManager" ||
      this.loggedInUser.userType == "ChannelSalesRep" ||
      this.loggedInUser.userType == "ChannelSalesRepManager" ||
      this.loggedInUser.userType == "Premier" ||
      this.loggedInUser.userType == "SplPricing" ||
      this.loggedInUser.userType == "OMAnalyst" ||
      this.loggedInUser.userType == "SplPricingManager" ||
      this.loggedInUser.userType == "OMAnalystManager" ||
      this.loggedInUser.userType == "SalesEng" ||
      this.loggedInUser.userType == "SalesEngManager" ||
      this.loggedInUser.userType == "ChannelsQuoter" ||
      this.loggedInUser.userType == "ChannelsSupport" ||
      this.loggedInUser.userType == "GRID_SalesRep"
    ) {
      showFlag = true;
    }
    return showFlag;
  }

  get displayGeneratequote() {
    let showFlag = false;
    if (this.actionStatuses["generateQuote"].visible == true) {
      showFlag = true;
    }
    // if(this.totalErrors === 0 && this.qrInputValue === 'Pricing Complete'){
    // if (
    //   (this.loggedInUser && this.loggedInUser.userType == "SalesEng") ||
    //   this.loggedInUser.userType == "SalesEngManager" ||
    //   this.loggedInUser.userType == "SplPricing" ||
    //   this.loggedInUser.userType == "SplPricingManager" ||
    //   this.loggedInUser.userType == "OMAnalyst" ||
    //   this.loggedInUser.userType == "OMAnalystManager" ||
    //   this.loggedInUser.userType == "ChannelsQuoter"
    // ) {
    //   showFlag = true;
    // }
    //}
    return showFlag;
  }
  get displaySe() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesRep") ||
      this.loggedInUser.userType == "SalesRepManager" ||
      this.loggedInUser.userType == "ChannelSalesRep" ||
      this.loggedInUser.userType == "ChannelSalesRepManager" ||
      this.loggedInUser.userType == "Premier" ||
      this.loggedInUser.userType == "SalesEng" ||
      this.loggedInUser.userType == "SalesEngManager" ||
      this.loggedInUser.userType == "ChannelsQuoter" ||
      this.loggedInUser.userType == "ChannelsSupport" ||
      this.loggedInUser.userType == "GRID_SalesRep"
    ) {
      showFlag = true;
    }
    return showFlag;
  }
  get displaySecomplete() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesEng") ||
      this.loggedInUser.userType == "SalesEngManager" ||
      this.loggedInUser.userType == "SplPricing" ||
      this.loggedInUser.userType == "SplPricingManager" ||
      this.loggedInUser.userType == "OMAnalyst" ||
      this.loggedInUser.userType == "OMAnalystManager" ||
      this.loggedInUser.userType == "ChannelsQuoter"
    ) {
      showFlag = true;
    }
    return showFlag;
  }
  get displaySpOm() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesRep") ||
      this.loggedInUser.userType == "SalesRepManager" ||
      this.loggedInUser.userType == "ChannelSalesRep" ||
      this.loggedInUser.userType == "ChannelSalesRepManager" ||
      this.loggedInUser.userType == "Premier" ||
      this.loggedInUser.userType == "SalesEng" ||
      this.loggedInUser.userType == "SalesEngManager" ||
      this.loggedInUser.userType == "SplPricing" ||
      this.loggedInUser.userType == "SplPricingManager" ||
      this.loggedInUser.userType == "OMAnalyst" ||
      this.loggedInUser.userType == "OMAnalystManager" ||
      this.loggedInUser.userType == "ChannelsQuoter" ||
      this.loggedInUser.userType == "ChannelsSupport" ||
      this.loggedInUser.userType == "GRID_SalesRep"
    ) {
      showFlag = true;
    }
    return showFlag;
  }
  get displaySrSrmCsrCsrmPrSpSpmOaOam() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesRep") ||
      this.loggedInUser.userType == "SalesRepManager" ||
      this.loggedInUser.userType == "ChannelSalesRep" ||
      this.loggedInUser.userType == "ChannelSalesRepManager" ||
      this.loggedInUser.userType == "Premier" ||
      this.loggedInUser.userType == "SplPricing" ||
      this.loggedInUser.userType == "SplPricingManager" ||
      this.loggedInUser.userType == "OMAnalyst" ||
      this.loggedInUser.userType == "OMAnalystManager" ||
      this.loggedInUser.userType == "ChannelsQuoter" ||
      this.loggedInUser.userType == "ChannelsSupport" ||
      this.loggedInUser.userType == "GRID_SalesRep"
    ) {
      showFlag = true;
    }
    return showFlag;
  }
  get displayResubmit() {
    let showFlag = false;
    if (
      this.loggedInUser &&
      (this.loggedInUser.userType == "SalesRep" ||
        this.loggedInUser.userType == "GRID_SalesRep" ||
        this.loggedInUser.userType == "SalesRepManager" ||
        this.loggedInUser.userType == "ChannelSalesRep" ||
        this.loggedInUser.userType == "ChannelSalesRepManager" ||
        this.loggedInUser.userType == "Premier" ||
        this.loggedInUser.userType == "SplPricing" ||
        this.loggedInUser.userType == "SplPricingManager" ||
        this.loggedInUser.userType == "OMAnalyst" ||
        this.loggedInUser.userType == "OMAnalystManager" ||
        this.loggedInUser.userType == "ChannelsQuoter" ||
        this.loggedInUser.userType == "SalesEng" ||
        this.loggedInUser.userType == "SalesEngManager" ||
        this.loggedInUser.userType == "ChannelsSupport") &&
      (this.qrInputValue == "Pricing Complete" ||
        this.qrInputValue == "Unsubmitted")
    ) {
      showFlag = true;
    }
    return showFlag;
  }
  get displayGenerateQuote() {
    let showFlag = true;
    if (this.loggedInUser && this.loggedInUser.userType == "SalesEng") {
      showFlag = false;
    }
    return showFlag;
  }

  get displayChangeStatus() {
    let showFlag = true;
    if (this.loggedInUser && this.loggedInUser.userType == "SalesRep" || this.loggedInUser.userType == "GRID_SalesRep") {
      showFlag = false;
    }
    return showFlag;
  }
  get displaySp() {
    let showFlag = false;
    if (
      (this.loggedInUser && this.loggedInUser.userType == "SalesRep") ||
      this.loggedInUser.userType == "GRID_SalesRep" ||
      this.loggedInUser.userType == "ChannelSalesRep" ||
      this.loggedInUser.userType == "OMAnalyst" ||
      this.loggedInUser.userType == "SplPricing" ||
      this.loggedInUser.userType == "ChannelsSupport"
    ) {
      showFlag = true;
    }
    return showFlag;
  }

  setSubStatusPicklistValues() {
    if (
      this.loggedInUser &&
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager"))
    ) {
      this.quoteReqSubStatus.push(
        //{ label: 'Unassigned', value: 'Unassigned' },
        { label: "Assigned", value: "Assigned" },
        { label: "Need More Information", value: "Need More Information" },
        { label: "Pending External Vendor", value: "Pending External Vendor" },
        { label: "Pending IT", value: "Pending IT" },
        { label: "Pending Margin Approval", value: "Pending Margin Approval" },
        { label: "Pending Sales", value: "Pending Sales" },
        { label: "Unassigned", value: "Unassigned" }
      );
    } else if (
      this.loggedInUser &&
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      this.loggedInUser.lstPermissionSet.includes("SalesEng")
    ) {
      this.quoteReqSubStatus.push(
        { label: "Assigned", value: "Assigned" },
        { label: "Completed", value: "Completed" },
        { label: "In Process", value: "In Process" },
        { label: "Review", value: "Review" },
        { label: "Unassigned", value: "Unassigned" }
      );
    } else if (
      this.loggedInUser &&
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter")
    ) {
      this.quoteReqSubStatus.push(
        { label: "Assigned", value: "Assigned" },
        { label: "Completed", value: "Completed" },
        { label: "In Process", value: "In Process" },
        { label: "Need More Information", value: "Need More Information" },
        { label: "Pending External Vendor", value: "Pending External Vendor" },
        { label: "Pending IT", value: "Pending IT" },
        { label: "Pending Margin Approval", value: "Pending Margin Approval" },
        { label: "Pending Sales", value: "Pending Sales" },
        { label: "Review", value: "Review" },
        { label: "Unassigned", value: "Unassigned" }
      );
    }
    console.log(
      " this.quoteReqSubStatus::",
      JSON.stringify(this.quoteReqSubStatus)
    );
  }

  sendQuotetoCustomer(event) {
    this.sendQRCust = event.detail.selected;
    console.log("customer", event, this.sendQRCust);
  }

  get displayRequestSPReview() {
    let showFlag = true;
    if (this.loggedInUser && !this.loggedInUser.userType) {
      showFlag = false;
    }
    return showFlag;
  }

  get displayRequestSEReview() {
    let showFlag = true;
    if (
      this.loggedInUser &&
      (!this.loggedInUser.userType || this.loggedInUser.userType == "SalesEng")
    ) {
      showFlag = false;
    }
    return showFlag;
  }

  get displaySendQuoteToCustomer() {
    let showFlag = true;
    return showFlag;
  }

  salesRepQrViewOnLoad() {
    salesRepQrViewLoadCall({ recordId: this.recordId })
      .then((result) => {
        if (result && result.qReq) {
          this.quoteRequest = result.qReq;
          if (this.quoteRequest.Is_Submitted__c) {
            this.viewOnly = true;
          }

          this.spApplied = this.quoteRequest.Special_Pricing__c;
          console.log("Sales Rep QR View SP Applied : ", this.spApplied);
          if (this.quoteRequest.Last_Saved__c) {
            this.formateDateValue(this.quoteRequest.Last_Saved__c);
          }
           if (result && result.ExpiredDate) {
            this.qrrCreatedDate = result.ExpiredDate.replace(/-/g, '\/');
            var d = new Date(this.qrrCreatedDate);
            d.setDate(d.getDate()+90);
            this.expiredDateValue(d);
        }
          else{
            this.expiredDate = 'NA';
          }
        }
        let QRcreatedDate = new Date(this.qrrCreatedDate);
        let next90days = new Date(QRcreatedDate.setDate(QRcreatedDate.getDate() + 90));
        const today = new Date();
        const quoteCreateddate = new Date(this.quoteRequest.CreatedDate);
        const diffTime = Math.abs(today - quoteCreateddate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (
          (this.quoteRequest.Quote_Request_Status__c === "Pending Pricing" &&
          diffDays > 60 && diffDays < 89) || (next90days < today)
        ) {
          this.refreshQuote = true;
        }

        if (result && result.lstQr && result.lstQr.length > 0) {
          this.qrStatus = result.lstQr[0].Quote_Request_Status__c;
          this.qrInputValue = result.lstQr[0].Quote_Request_Status__c;
          this.qrSubStatus = result.lstQr[0].Sub_Status__c;
          this.handleSubscribe(this.recordId);
        }

        if (result && result.loggedInUser) {
          this.loggedInUser = result.loggedInUser;
          this._getActionStatuses();
        }

        if(result && result.disableClosedWon){
          this.disableClosedWon = true;
        }
        else{
          this.disableClosedWon = false;  
        }

        this.showSpinner = false;
        this.isLoaded = true;
        //if(this.quoteRequest.Quote_Request_Users_2__r) {
        let isFound = true;
        let isFoundOM = true;

        //this.quoteRequest.Quote_Request_Users_2__r.forEach(elem => {
        if (this.quoteRequest.Assigned_Solutions_Engineer1__r) {
          if (
            this.loggedInUser &&
            this.loggedInUser &&
            this.loggedInUser.lstPermissionSet &&
            this.loggedInUser.lstPermissionSet.includes("SalesEng") &&
            this.qrSubStatus == "Assigned"
          ) {
            this.assignedTo =
              this.quoteRequest.Assigned_Solutions_Engineer1__r["Name"];
            isFound = false;
          }
        } else if (this.quoteRequest.Offer_Management__c) {
          if (
            this.loggedInUser &&
            this.loggedInUser &&
            this.loggedInUser.lstPermissionSet &&
            (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
              this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
              this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
              this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
              this.loggedInUser.lstPermissionSet.includes(
                "SplPricingManager"
              )) &&
            this.qrSubStatus == "Assigned"
          ) {
            this.assignedTo = this.quoteRequest.Offer_Management__r["Name"];
            isFoundOM = false;
          }
        }
        // });
        //}

        this.setSubStatusPicklistValues();
        this.subStatusOnSpReview();
      })
      .catch((error) => {
        this.errorMsg = error;
        this.showSpinner = false;
      });

    this._getActionStatuses();
    /* getActionStatuses({ quoteRequestId : this.recordId }).then( response => {
        this.actionStatuses = response.salesRepQRView;
        console.log("QuoteType",this.quoteRequest);
        for( const key in this.actionStatuses ) {
          
            if(key === 'generateQuote' && this.currentTotalLessThanZero && this.quoteRequest.Quote_Type__c == 'Comparision' && this.loggedInUser && this.loggedInUser.userType !== 'SplPricing' && this.loggedInUser.userType !== 'SplPricingManager' && this.loggedInUser.userType !== 'OMAnalyst' && this.loggedInUser.userType !== 'OMAnalystManager'){
              this.actionCSS[ key ] = this.disabledCSS;
            }
           else if(this.actionStatuses[ key ].disabled == true ) {
                this.actionCSS[ key ] = this.disabledCSS;
            } else {
                this.actionCSS[ key ] = this.enabledCSS;
            } 
        }
    } ).catch( error => {
    } );*/
  }

  formateDateValue(dateValue) {
    let dt = new Date(dateValue);
    const dtf = new Intl.DateTimeFormat("en", {
      year: "2-digit",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: "true"
    });
    const [
      { value: mo },
      ,
      { value: da },
      ,
      { value: ye },
      ,
      { value: hr },
      ,
      { value: mi },
      ,
      { value: hrt }
    ] = dtf.formatToParts(dt);

    let formatedDate = `${hr}:${mi}${hrt}  ${mo}/${da}/${ye}`;
    console.log("formatedDate ===> " + formatedDate);
    this.lastSavedDate = formatedDate;
  }
  expiredDateValue(dateValue) {
    let dt = new Date(dateValue);
    const dtf = new Intl.DateTimeFormat("en", {
      year: "2-digit",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      hour12: "true"
    });
    const [
      { value: mo },
      ,
      { value: da },
      ,
      { value: ye }
      
    ] = dtf.formatToParts(dt);

    let formatedDate = `${mo}/${da}/${ye}`;
    console.log("formatedDate ===> " + formatedDate);
    this.expiredDate = formatedDate;
    this.getCurrentDateColor(this.expiredDate);
  }
  disconnectedCallback() {
    document.removeEventListener("click", this._handler);
  }

  handleActive(event) {
    this.showHistory = event.target.value == "HISTORY" ? true : false;
    this.showDocuments = event.target.value == "DOCUMENT" ? true : false;
    this.showLayout = event.target.value === "LAYOUT" ? true : false;
  }

  getQuote() {
    getQuoteDetails({ recordId: this.recordId })
      .then((result) => {
        this.quoteRequest = result;
        if (this.quoteRequest.Is_Submitted__c) {
          this.viewOnly = true;
        }
        if (this.quoteRequest.Last_Saved__c) {
          this.formateDateValue(this.quoteRequest.Last_Saved__c);
        }
        this.showSpinner = false;
        this.isLoaded = true;
      })
      .catch((error) => {
        this.errorMsg = error;
        this.showSpinner = false;
      });
  }
  navigateToQuoteRequestPage() {
    window.history.back();
  }
  get qrName() {
    return this.quoteRequest != null && this.quoteRequest.Name != null
      ? this.quoteRequest.Name
      : "";
  }
  get OpportunityName() {
    return this.quoteRequest != null &&
      this.quoteRequest.Related_Opportunity__r != null &&
      this.quoteRequest.Related_Opportunity__r.Name != null
      ? this.quoteRequest.Related_Opportunity__r.Name
      : "";
  }
  get PrimarySalesRep() {
    return this.quoteRequest != null &&
      this.quoteRequest.Primary_Sales_Rep__r != null &&
      this.quoteRequest.Primary_Sales_Rep__r.Full_Name_copy__c
      ? this.quoteRequest.Primary_Sales_Rep__r.Full_Name_copy__c
      : "";
  }
  backToLocationsAndProducts() {
    this.dispatchEvent(new CustomEvent("closesalesrepqrview"));
  }

  async qrValues() {
    getQuoteRequeststatusvalue({ recordId: this.recordId })
      .then((result) => {
        console.log("picklistresult:", result[0].Quote_Request_Status__c);
        this.qrStatus = result[0].Quote_Request_Status__c;
        this.qrInputValue = result[0].Quote_Request_Status__c;
        this.qrSubStatus = result[0].Sub_Status__c;
        this.quoteRequest.Quote_Request_Status__c = result[0].Quote_Request_Status__c;
        this.subStatusOnSpReview();
      })
      .catch((error) => {
        console.log(error);
      });
  }

  //export feature
  showExportPopover(event) {
    const label = event.target.name;
    if (label === "Show") {
      this.clickedExportLabel = "Hide";
      this.openExportPopover = true;
      this.openOptionsPopover = false;
      this.isAnyPopupDisplayed = true;
      this.clickedOptionsLabel = "showOptions";
    } else if (label === "Hide") {
      this.clickedExportLabel = "Show";
      this.openExportPopover = false;
    }
  }
  //options feature
  showOptionsPopover(event) {
    const label = event.target.name;
    if (label === "showOptions") {
      this.clickedOptionsLabel = "hideOptions";
      this.openOptionsPopover = true;
      this.openExportPopover = false;
      this.clickedExportLabel = "Show";
      this.isAnyPopupDisplayed = true;
    } else if (label === "hideOptions") {
      this.clickedOptionsLabel = "showOptions";
      this.openOptionsPopover = false;
    }
  }
  handleExport() {
    console.log("download triggered.");
    try {
      if (this.allData.length == 0) {
        this.allData = [
          {
            isChecked: false,
            address: "test Address",
            city: "test Address",
            state: "test Address",
            zip: "test Address",
            npanxx: "test Address",
            products: "test Address",
            action: "test Address",
            isExpand: false,
            popup: "productPopupHide",
            productsData: [
              {
                pname: "product1",
                ptype: "type"
              },
              {
                pname: "product2",
                ptype: "type2"
              }
            ]
          },
          {
            isChecked: false,
            address: "2 test Address",
            city: "2 test Address",
            state: "2 test Address",
            zip: "2 test Address",
            npanxx: "2 test Address",
            products: "2 test Address",
            action: "2 test Address",
            isExpand: false,
            popup: "productPopupHide",
            productsData: [
              {
                pname: "product1",
                ptype: "type"
              },
              {
                pname: "product2",
                ptype: "type2"
              }
            ]
          }
        ];
      }
      var selectedList = [
        ...new Set(
          this.allData.map((x) => {
            if (x.selected) {
              return x;
            }
          })
        )
      ];
      exportCSVFile(this.headers, selectedList, this.selectedQuoteOption);
    } catch (ex) {
      console.log("ex " + ex);
    }
  }
  exportInExcelSheets() {
    this.template
      .querySelector("c-summary-pricing-component")
      .connectSalesRepLocationProducts(this.quoteRequest.Name);
    this.openExportPopover = false;
    this.clickedExportLabel = "Show";
    this.isAnyPopupDisplayed = true;
  }

  handlequoteoptions() {
    console.log("this.xlsData.length", this.xlsData.length);
    getQuoteOptionsinfo({ QRId: this.recordId })
      .then((result) => {
        this.xlsData = result;
        this.QuReqId = this.recordId;
        if (this.xlsData.length !== 0) {
            let excelExporter = this.template.querySelector("c-exportquoteoptions");
            excelExporter.closedWonSucess = this.closedWonSucess;
            excelExporter.exportdata();
        } else {
          const evt = new ShowToastEvent({
            title: "Error",
            message: "Quote Options are not available",
            variant: "error",
            mode: "dismissable"
          });
          this.dispatchEvent(evt);
        }
      })
      .catch((error) => {});
  }

  ignore(event) {
    event.stopPropagation();
    return false;
  }
  close() {
    if (
      this.isAnyPopupDisplayed &&
      (this.clickedExportLabel == "Hide" ||
        this.clickedOptionsLabel == "hideOptions")
    ) {
      this.clickedExportLabel = "Show";
      this.clickedOptionsLabel = "showOptions";
      this.openExportPopover = false;
      this.openOptionsPopover = false;
    }
  }
  showRequestSEReview() {
    if (this.actionStatuses["requestSEReview"].disabled == false) {
      this.notes = "";
      getTeamsQueueId({ queueName: "Solution_Engineers_Team" }).then(
        (respId) => {
          this.notifyTargetID = respId;
        }
      );
      this.openRequestSEReview = true;
      this.openRequestSPReview = false;
      this.sourceSEPopup = "Request SE Review";
    }
  }

  closeRequestSEReview() {
    this.isSubmittedtoSEReview = false;
  }

  showRequestSPReview() {
    if (this.actionStatuses["requestFinanceReview"].disabled == false) {
      if (this.isSpFinanceSupport) {
        this.notes =
          this.addressErrorsCount + " " + "Address came back as invalid";
      } else {
        this.notes = "";
      }
      getTeamsQueueId({ queueName: "Special_Pricing" }).then((respId) => {
        this.notifyTargetID = respId;
      });
      this.openRequestSPReview = true;
      this.openRequestSEReview = false;
      this.sourceSEPopup = "Request SP Review";
    }
  }
  // Latest update - change status
  changeStatus(e) {
    // this.qrStatus = e.target.value
    console.log("status changed", e.target.value);
    this.qrStatus = e.target.value;
    this.subStatusOnSpReview();
  }

  get showComplete() {
    let completeFlag = false;
    if (
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
        this.loggedInUser.lstPermissionSet.includes("SalesEng")) &&
      (this.qrStatus == "Pending Finance Review" ||
        this.qrStatus == "Pending SE Review")
    ) {
      completeFlag = true;
    }

    return completeFlag;
  }

  completeClick() {
    if (this.actionStatuses["complete"].disabled == false) {
      if (
        this.loggedInUser &&
        this.loggedInUser.lstPermissionSet &&
        (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
          this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
          this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
          this.loggedInUser.lstPermissionSet.includes("SplPricingManager"))
      ) {
        this.completeBySPClick();
      } else if (
        this.loggedInUser &&
        this.loggedInUser.lstPermissionSet &&
        this.loggedInUser.lstPermissionSet.includes("SalesEng")
      ) {
        this.completeBySEClick();
      }
    }
  }

  completeBySEClick() {
    this.showSpinner = true;
    completedBySECall({ quoteReqId: this.recordId })
      .then((response) => {
        if (!response.showRatesDeleteWarning) {
          this.showSpinner = false;
          this.qeValue = response.qEValue;
          let qtReq = response.qrObj;
          let errorMessage;
          if (this.qeValue) {
            if (qtReq.Last_Saved__c) {
              this.formateDateValue(qtReq.Last_Saved__c);
            }

            let statusCode = response.httpResponse.statusCode;
            let status = response.httpResponse.status;
            errorMessage = response.httpResponse.errorMessage;

            if (statusCode != 200) {
              const errorEvent = new ShowToastEvent({
                title: "Error in Push to QE API callout",
                message: `Status Code: ${statusCode}; Status: ${status}`,
                variant: "error"
              });
              this.dispatchEvent(errorEvent);
            } else {
              this.qrValues();
              if (errorMessage) {
                const errorEvent = new ShowToastEvent({
                  title: errorMessage,
                  message: `Status Code: ${statusCode}; Status: ${status}`,

                  variant: "error"
                });
                this.dispatchEvent(errorEvent);
              } else {
                this.reSubmit = true;
              }
            }
          } else {
            //errorMessage = e.errorMessage;
            errorMessage = errorMessage;
            this.qrInputValue = qtReq.Quote_Request_Status__c;
            const successEvent = new ShowToastEvent({
              title: "Approval",
              message: errorMessage,
              variant: "success"
            });
            this.dispatchEvent(successEvent);
          }
        } else {
            this.openRequestSEReview = false;
          this.ratesDeleteWarningPopup = true;
          this.deleteSource = "SEClick";
        }
      })
      .catch((error) => {
        this.error = error;
        this.dispatchEvent(
          new ShowToastEvent({
            title: "error!! " + error.message,
            message: error.message,
            variant: "error"
          })
        );
      })
      .finally(() => {
        this.showSpinner = false;
        this._getActionStatuses();
      });
  }

  completeBySPClick() {
    this.showSpinner = true;
    completedBySPCall({ objQrId: this.recordId })
      .then((response) => {
        let qtReq = response;
        if (qtReq.Last_Saved__c) {
          this.formateDateValue(qtReq.Last_Saved__c);
        }
        this.qrValues();
        this.dispatchEvent(
          new ShowToastEvent({
            title: "SUCCESS",
            message: "Pricing is completed Successfully.",
            variant: "success"
          })
        );
        this._getActionStatuses();
      })
      .catch((error) => {
        this.error = error;
        this.dispatchEvent(
          new ShowToastEvent({
            title: "error!! " + error.message,
            message: error.message,
            variant: "error"
          })
        );
      })
      .finally(() => {
        this.showSpinner = false;
      });
  }

  subStatusOnSpReview() {
    if (
      this.loggedInUser &&
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
        this.loggedInUser.lstPermissionSet.includes("SalesEng")) &&
      (this.qrStatus == "Pending Finance Review" ||
        this.qrStatus == "Pending SE Review")
    ) {
      this.showQRSubstatus = true;
      if (this.qrSubStatus == "Assigned" && this.assignedTo != "") {
        this.showAssignedTo = true;
      }
    } else {
      this.showQRSubstatus = false;
      this.qrSubStatusOnChange = "";
      this.showAssignedTo = false;
    }
  }
  // Latest update - change status
  changeSubStatus(event) {
    console.log("status sub changed", event.target.value);
    //this.qrSubStatus = event.target.value;
    this.qrSubStatusOnChange = event.target.value;
  }
  showChangeStatus() {
    if (this.actionStatuses["changeStatus"].disabled == false) {
      this.openChangeStatus = true;
    }
  }
  closeChangeStatus() {
    this.openChangeStatus = false;
  }
  closeRefreshQuote() {
    this.refreshQuote = false;
  }
  closeReSubmitQuote() {
    this.reSubmit = false;
    window.location.reload();
  }
  handleradiobuttonchange(event) {
    this.radiocheckbox = event.detail.prodRadioButton;
    this.loaRadioCheckbox = event.detail.loaRadioButton;
  }
  showGenerateQuote() {
  if(this.disableClosedWon){
    let errorEvent = 'No Location(s) and or Product(s) are Certified. Ensure at least one Location and Product is Certified to move forward with Generating a Quote and or Closed Won functionality.';
    this.dispatchEvent(
      new ShowToastEvent( {title:'ATTENTION:', message:errorEvent,variant:'error'} )
    );
  }else{
    if (this.actionStatuses["generateQuote"].disabled == false) {
      // custom event
      const custEvent = new CustomEvent("closeaddequipmentmodal", {
        detail: {
          equipmentData: this.equipmentData,
          resultData: this.resultData,
          selectedEquipmentList1: this.selectedEquipmentList,
          selectedEquipmentMap: this.selectedEquipmentMap,
          openEquipmentModal: false,
          quotId: this.quoteId,
          equipmentId: this.equipmentId
        }
      });

      // a9O760000004KjdEAE

          this.qrLayout = this.template.querySelector("c-qr-layout");
          if( this.qrLayout ) 
          {
              if( this.radiocheckbox === 'in_both' )
              {
                  this.qrLayout.showProcessingScreen();
                  this.qrLayout.redirectToConga();
                  this.handlequoteoptions();
              }
              else if( this.radiocheckbox === 'in_pdf' )
              {
                  this.qrLayout.showProcessingScreen();
                  this.qrLayout.redirectToConga();
              }
              else if( this.radiocheckbox === 'in_excel' || this.radiocheckbox == undefined )
              {
                  this.handlequoteoptions();
              }
              else if( this.radiocheckbox === "in_word" && this.loaRadioCheckbox === "in_msa" )
              {
                  this.qrLayout.showProcessingScreen();
                  this.qrLayout.redirectToConga();
              }
          }
      }
    }
  }
  closeGenerateQuote() {
    this.openGenerateQuote = false;
  }
  async saveChangeStatus() {
    try {
      // console.log('submitquoterequeststatus', this.recordId, this.qrStatus)
      if (
        this.qrInputValue !== "Closed - WON" ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter")
      ) {
        this.openChangeStatus = false;
        await submitQuoteRequeststatus({
          quoteReqId: this.recordId,
          qrstatus: this.qrStatus,
          qrSubStatus: this.qrSubStatusOnChange
        });
        this._getActionStatuses();
        await this.qrValues();
        console.log("updated qrstatus", this.qrInputValue);
      } else {
        const evt = new ShowToastEvent({
          title: "Error",
          message: "Cannot Change Status",
          variant: "error",
          mode: "dismissable"
        });
        this.dispatchEvent(evt);
        // alert('Cannot change status');
      }
    } catch (e) {
      console.log("error", e);
    }
  }
  get openRequestReviewPopup() {
    return this.openRequestSEReview == true || this.openRequestSPReview == true;
  }
  notesChange(event) {
    this.notes = event.detail.value;
  }

  updateQuoteRequest(statusVal) {
    // Create the recordInput object
    const fields = {};
    fields[ID_FIELD.fieldApiName] = this.recordId;
    fields[QUOTEREQSTATUS_FIELD.fieldApiName] = statusVal;

    if (statusVal == "Pricing Complete") {
      if (
        this.loggedInUser &&
        this.loggedInUser &&
        this.loggedInUser.lstPermissionSet &&
        this.loggedInUser.lstPermissionSet.includes("SalesEng")
      ) {
        fields[SUBSTATUS_FIELD.fieldApiName] = "Completed";
      }
    } else if (
      statusVal == "Pending Finance Review" ||
      statusVal == "Pending SE Review"
    ) {
      if (
        this.loggedInUser &&
        this.loggedInUser &&
        this.loggedInUser.lstPermissionSet &&
        (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
          this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
          this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
          this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
          this.loggedInUser.lstPermissionSet.includes("SalesEng"))
      ) {
        if (this.qrSubStatus != "Assigned") {
          fields[SUBSTATUS_FIELD.fieldApiName] = "Unassigned";
        }
      }
    }
    const recordInput = { fields };

    updateRecord(recordInput)
      .then(() => {
        console.log("in update record" + statusVal);
        this.qrValues();
        this._getActionStatuses();
      })
      .catch((error) => {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error In Updating Status",
            message: error.body.message,
            variant: "error"
          })
        );
      });
  }

  lastSaveddDateDetails() {
    getLastSavedDate({ recordId: this.recordId })
      .then((result) => {
        let qtReq = result;
        if (qtReq.Last_Saved__c) {
          this.formateDateValue(qtReq.Last_Saved__c);
        }
        console.log("Last Saved Date::" + JSON.stringify(qtReq));
      })
      .catch((error) => {
        this.errorMsg = error;
      });
  }
  getLastSaveDate() {
    this.lastSaveddDateDetails();
  }
  handleCustomerDetailChange(event) {
    this.isLoaded = false;
    this.quoteRequest = event.detail.quoteRequest;
    this.salesRepQrViewOnLoad();
  }

  pushTo1Source() {
    pushTo1S({ quoteRequestId: this.recordId })
      .then((response) => {
        let statusCode = response.httpResponse.statusCode;
        let status = response.httpResponse.status;

        if (statusCode != 200) {
          const errorEvent = new ShowToastEvent({
            title: "Error in Push to 1 Source API callout",
            message: `Status Code: ${statusCode}; Status: ${status}`,
            variant: "error"
          });
          this.dispatchEvent(errorEvent);
        } else {
          const successEvent = new ShowToastEvent({
            title: "Success",
            message: `Status Code:${statusCode}; Status:${status}`,
            variant: "success"
          });
          this.dispatchEvent(successEvent);
        }
      })
      .catch((error) => {
        const errorEvent = new ShowToastEvent({
          title: "Error",
          message: error.stringify,
          variant: "error"
        });
        this.dispatchEvent(errorEvent);
      });
  }

  pushToQE(event) {
    if(this.selectedLocationGuiIds && (this.selectedLocationGuiIds.size > 0 || this.selectedLocationGuiIds.length >0)){
        this.pushtoQEResubmit(true);
        this.noLocationOrProductSelected = false;
    } else{
        this.noLocationOrProductSelected = true;
    }
    
  }

  pushtoQEResubmit(requireValidate) {
    if (this.actionStatuses["resubmit"].disabled == false) {
      this.showSpinner = true;
      validationCheckCall({
        quoteReqId: this.recordId,
        qrObject: null,
        actionName: "Resubmit",
        requireValidate: requireValidate,
        qloGUID:this.selectedLocationGuiIds?Array.from(this.selectedLocationGuiIds):null
      })
        .then((response) => {
          if (response.isValidQuote) {
              if (!response.showRatesDeleteWarning) {
                  this.showSpinner = false;
                  let qtReq = response.qrObj;
                  if (qtReq.Quote_Request_Status__c == "Pending SE Review") {
                      this.isSubmittedtoSEReview = true;
                      this.updateQuoteRequest("Pending SE Review");
                  } else {
                      this.qeValue = response.qEValue;
                      console.log("response", response.qeValue);
                      let statusCode = response.httpResponse.statusCode;
                      let status = response.httpResponse.status;
                      const errorMessage = response.httpResponse.errorMessage;
                      if (statusCode != 200) {
                          const errorEvent = new ShowToastEvent({
                          title: "Error in Push to QE API callout",
                          message: `Error: ${status}`,
                          variant: "error"
                          });
                          this.dispatchEvent(errorEvent);
                      } else {
                        if (errorMessage) {
                            if(errorMessage.includes('You must wait at least 5 minutes between submissions')) {
                              restoreDeletedQRR({ lstQrrToDelete : this.deletedQRR })
                              .then(response => {
                                const errorEvent = new ShowToastEvent({
                                  title: errorMessage,
                                  message: `Error: ${status}`,
                                  variant: "error"
                                });
                                this.dispatchEvent(errorEvent);
                              })
                              .catch(error => {

                              })
                            } else {
                              const errorEvent = new ShowToastEvent({
                                title: errorMessage,
                                message: `Error: ${status}`,
                                variant: "error"
                              });
                              this.dispatchEvent(errorEvent);
                            }
                        } else {
                          this.reSubmit = true;
                          this.updateQuoteRequest("Pending Pricing");
                        }
                  }
              }
            } else {
              this.deleteSource = "Resubmit";
              if(this.selectedLocationGuiIds && this.selectedLocationGuiIds.size >0 ){
                this.ratesDeleteWarningPopup = true;
              } else {
                this.deleteRatesConfirmClick(null);
              }
            }
          } else {
            this.errorMsg = response.errorMessage;
            this.showSpinner = false;
            if(!this.quoteRequest["Assigned_Solutions_Engineer1__c"]) {
              this.openRequestSEReview = true;
            }
            this.sourceSEPopup = "No SalesEngineer";
            this.quoteRequest = { ...this.quoteRequest };
            if (response.qrObj.Assigned_Solutions_Engineer1__r) {
              this.quoteRequest["Assigned_Solutions_Engineer1__r"] =
                response.qrObj.Assigned_Solutions_Engineer1__r;
            }
            this.notifyTargetID = response.notifyTargetID;
          }
        })
        .catch((error) => {
          this.showSpinner = false;
          const errorEvent = new ShowToastEvent({
            title: "Error",
            message: error.message,
            variant: "error"
          });
          this.dispatchEvent(errorEvent);
        });
    }
  }

  deleteRatesCancelClick(event) {
    this.ratesDeleteWarningPopup = false;
    this.showSpinner = false;
  }
  locAndProdResubmitCancel() {
    this.noLocationOrProductSelected = false;
    this.showSpinner = false;
  }
  locAndProdSubmit(){
    this.noLocationOrProductSelected = false;
    this.pushtoQEResubmit(true);

  }

  deleteRatesConfirmClick(event) {
    this.closeRefreshQuote();
    this.showSpinner = true;
    deleteQuoteRequestRatesCall({ quoteReqId: this.recordId, deleteSource: this.deleteSource,
                                  qloGUID :this.selectedLocationGuiIds?Array.from(this.selectedLocationGuiIds):null})
      .then((response) => {
        if(response && response.message === "syncexecution"){
          this.deletedQRR = response.lstDeletedRates;
          if (this.deleteSource == "SEClick") {
            this.completeBySEClick();
          } else if (this.deleteSource == "Resubmit") {
            this.pushtoQEResubmit(false);
          }
        }
        else{
          this.showSpinner = false;	
          this.reSubmit = true;
        }
        this.openRequestSEReview = false;
        this.ratesDeleteWarningPopup = false;
        //this.showSpinner = false;
      })
      .catch((error) => {
        this.showSpinner = false;
        const errorEvent = new ShowToastEvent({
          title: "Error",
          message: error.message,
          variant: "error"
        });
        this.dispatchEvent(errorEvent);
      });
  }
  onClickClosedWon() {
    if(this.disableClosedWon){
      let errorEvent = 'No Location(s) and or Product(s) are Certified. Ensure at least one Location and Product is Certified to move forward with Generating a Quote and or Closed Won functionality.';
      this.dispatchEvent(
        new ShowToastEvent( {title:'ATTENTION:', message:errorEvent,variant:'error'} )
      );
    }else {
      if (this.actionStatuses["closedWon"].disabled == false) {
        this.openClosedWonPopup = true;
      }
    }
  }

  handleCloseWonPopupClose(event) {
    this.openClosedWonPopup = event.detail.openClosedWonPopup;
  }

  closedWonSucessCancel() {
    this.closedWonSucess = false;
    this.qrInputValue = "Closed - WON";
  }
  handleCloseWonPopupSucess(event) {
    console.log("closedwonsucess", this.closedWonSucess);
    this.closedWonSucess = event.detail;
    console.log("closedwonsucess1", this.closedWonSucess);
    this._getActionStatuses();
    this.openClosedWonPopup
    // this.showGenerateQuote();
    this.handlequoteoptions();
  }
  handleClosedWonPopupError(event){
    this.dispatchEvent(
      new ShowToastEvent( {title:'Error', message:event.detail,variant:'error'} )
    );
  }
  customerSendCancel() {
    this.SendToCustomerSucess = false;
  }
  handleSendQuoteCustomerSuccess(event) {
    console.log("SendToCustomersucess", this.SendToCustomerSucess);
    this.SendToCustomerSucess = event.detail;
    console.log("SendToCustomersucess1", this.SendToCustomerSucess);
  }
  onClickSendQuote() {
    if (this.actionStatuses["sendToCustomer"].disabled == false) {
      this.openSendQuoteCustomer = true;
    }
  }
  handleSendQuoteCustomer(event) {
    this.openSendQuoteCustomer = event.detail.openSendQuoteCustomer;
  }
  // closeAddressErrorsLessthan30(){
  //   this.isAddressErrorsLessthan30 = false;
  // }
  closeAddressErrorsLessThanorEqualto50() {
    this.isAddressErrorsLessThanorEqualto50 = false;
  }
  closeTelephoneErrors() {
    this.telephonePopup = false;
  }
  closefootPrintErrors() {
    this.footPrintPopup = false;
  }
  openRequestSPReviewPopup() {
    // this.isAddressErrorsMorethan30 = false;
    this.isAddressErrorsMoreThan50 = false;
    this.isSpFinanceSupport = true;
    this.showRequestSPReview();
  }
  closeAddressErrorsMorethan30() {
    // this.isAddressErrorsMorethan30 = false;
    this.isAddressErrorsMoreThan50 = false;
    this.isSPReviewAddressError = true;
  }
  invalidAddressespopup() {
    this.invalidAddresses = true;
    this.isAddressErrorsMoreThan50 = false;
  }

  handleSEOMDataChange(event) {
    this.qrValues();
    if (
      this.loggedInUser &&
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter"))
    ) {
      if (event.detail.omAnalyst) {
        this.assignedTo = event.detail.omAnalyst;
      } else {
        this.assignedTo = "";
      }
    } else if (
      this.loggedInUser &&
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      this.loggedInUser.lstPermissionSet.includes("SalesEng")
    ) {
      if (event.detail.seEngineer) {
        this.assignedTo = event.detail.seEngineer;
      } else {
        this.assignedTo = "";
      }
    }
  }

  // Handles subscribe button click
  handleSubscribe(qrRecordId) {
    let parentThis = this;
    //let qrRecordId = this.recordId;
    // Callback invoked whenever a new event message is received
    const messageCallback = function (response) {
      var obj = JSON.parse(JSON.stringify(response));
      console.log(
        "recordId==" +
          qrRecordId +
          " === obj.data.payload.QR_Id__c " +
          obj.data.payload.QR_Id__c
      );
      if (obj.data.payload.QR_Id__c === qrRecordId) {
        parentThis.qrSubStatus = obj.data.payload.QR_Sub_Status__c;
        parentThis.qrInputValue = obj.data.payload.QR_Status__c;
        parentThis.spApplied = obj.data.payload.QR_SP_Applied__c;
      }
      parentThis.handleUnsubscribe();
      console.log("New message received: ", JSON.stringify(response));
      // Response contains the payload of the new message received
    };

    // Invoke subscribe method of empApi. Pass reference to messageCallback
    subscribe(this.channelName, -1, messageCallback).then((res) => {
      // Response contains the subscription information on subscribe call
      console.log(
        "Subscription request sent to: ",
        JSON.stringify(res.channel)
      );
      this.subscription = res;
    });
  }

  // Handles unsubscribe button click
  handleUnsubscribe() {
    // Invoke unsubscribe method of empApi
    unsubscribe(this.subscription, (response) => {
      console.log("unsubscribe() response: ", JSON.stringify(response));
      // Response is true for successful unsubscribe
    });
  }

  registerErrorListener() {
    // Invoke onError empApi method
    onError((error) => {
      console.log("Received error from server: ", JSON.stringify(error));
      // Error contains the server-side error
    });
  }

  handleUpdateSaveEvent(event) {
    console.log("handledetails", event.detail.quoteRequest);
    this.quoteRequest = event.detail.quoteRequest;
    this.handleUpdateSave();
  }

  handlechangeownerEvent(event) {
    if (event.detail.sourceSEPopup == "No SalesEngineer") {
      this.openRequestSEReview = false;
      this.showSpinner = true;
      this.pushtoQEResubmit(false);
    } else {
      this.lastSaveddDateDetails();
      this.updateQuoteRequest(event.detail.status);
      this.isSPReviewAddressError = event.detail.isSPReviewAddressError;
      this.handleCloseSEorSPRequestEvent();
    }
  }

  handleCloseSEorSPRequestEvent(event) {
    if (this.openRequestSPReview) {
      if (!this.isSPReviewAddressError) {
        this.isAddressErrorsMorethan30 = true;
        this.isSpFinanceSupport = false;
      }
    }
    this.openRequestSEReview = false;
    this.openRequestSPReview = false;
  }

  handleUpdateSave() {
    this.showSpinner = true;
    console.log("handleupdate", this.quoteRequest);
    updateQuoteRequestCall({ qrObj: this.quoteRequest })
      .then((result) => {
        const custEvent = new CustomEvent("customerdetailchange", {});
        this.dispatchEvent(custEvent);
        this.showSpinner = false;
        this.quoteRequest = result;

        this.lastSaveddDateDetails();
      })
      .catch((error) => {
        this.errorMsg = error;
        //alert(''+error)
        this.showSpinner = false;
      });
  }

  notifyChanges() {
    console.log("in notify changes");
    // to close modal set isModalOpen tarck value as false
    const custEvent = new CustomEvent("userdatachange", {});
    this.dispatchEvent(custEvent);
  }

  notifyToSalesRepViewCmp() {
    console.log("in notifyToSalesRepViewCmp changes");
    // to close modal set isModalOpen tarck value as false
    const custEvent = new CustomEvent("saleengineeromdatachange", {
      detail: {
        seEngineer: this.quoteRequest.Assigned_Solutions_Engineer1__r
          ? this.quoteRequest.Assigned_Solutions_Engineer1__r["Name"]
          : "",
        omAnalyst: this.quoteRequest.Offer_Management__r
          ? this.quoteRequest.Offer_Management__r["Name"]
          : ""
      }
    });
    this.dispatchEvent(custEvent);
  }

  handleExcelExport(event) {
    console.log("Inside handleExcelExport: " + this.radiocheckbox);
    this.qrLayout = this.template.querySelector("c-qr-layout");
    if (this.qrLayout && this.radiocheckbox == "in_both") {
      // this.qrLayout.showProcessingScreen();
      setTimeout(() => {
        this.qrLayout.redirectToConga();
      }, event.detail.quoteOptions * 1000);
    }
  }
  handleclosedwonvaluechange(event){
    this.isFilterClosedWon = event.detail.filterClosedWon;
  }

  handleeleclocationsandprod(event) {
    console.log('**event.detail.locandprod :',event.detail.locandprod );
    //var obj = Object.fromEntries(event.detail.locandprod);
    //var jsonString = JSON.stringify(obj);
    this.locationandprodMap = Object.fromEntries(event.detail.locandprod);
    let qloGuiIds =  event.detail.selectedGUIIds;
    this.selectedLocationGuiIds = qloGuiIds? new Set(qloGuiIds.split(',')):[];
    console.log('selected Locations' +this.selectedLocationGuiIds)
  }
        
  closedWonButtonEnableCheck(){			
    salesRepQrViewLoadCall({ recordId: this.recordId })			
      .then((result) => {			
        if(result && result.disableClosedWon){			
          this.disableClosedWon = true;			
        }			
        else{			
          this.disableClosedWon = false;  			
        }  			
      });	
  }

  get displayPrivateChatter(){
    if(this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SalesEng") ||
      this.loggedInUser.lstPermissionSet.includes("SalesEngManager") ||
      this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
      this.loggedInUser.lstPermissionSet.includes("SplPricingManager")||
      this.loggedInUser.lstPermissionSet.includes("OMAnalyst")||
      this.loggedInUser.lstPermissionSet.includes("OMAnalystManager")||
      this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter"))){
        return true;
    }
    return false;
  }

}