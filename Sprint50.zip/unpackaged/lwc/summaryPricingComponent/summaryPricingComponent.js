import { LightningElement, api, wire, track } from "lwc";
import fetchQuoteOptions from "@salesforce/apex/SalesRepSummaryController.getQuoteOptionsDataByQRStatus";
//import getQuoteOptionsMapData from '@salesforce/apex/SalesRepSummaryController.getQuoteOptionsMapData';
import getQuotePricingData from "@salesforce/apex/SalesRepSummaryController.getQuotePricingDataByQRStatus";
//import getQuotePricingData from "@salesforce/apex/SalesRepSummaryController.getQuotePricingData";
export default class SummaryPricingComponent extends LightningElement {
  @api recordId;
  @track quoteOptionList = [];
  @track quoteOptionsMap;
  hasrendered = false;
  @api quoteRequest;
  @api loggedInUser;
  @track isQuoteOptionClick = false;
  @track className = "selected";
  @track isEditQuoteRequest = true;
  @track allProducts = [];
  @track salesEngProduct = [];
  @track quoteWrapperList = [];
  @track isSalesRep = false;
  @track isSalesEngOrEX = false;
  isSingleLocationProductsView = false;
  @track totalsOfAll = [];
  @track VendorNameList = [];
  productsMap = new Map();
  @track prodNameList = [];
  surchargeSummaryCheck = false;
  isPOTSProduct = false;
  isFilterClosedWon = true;
  isChecked = true;
  renderedCallback() {
    if (!this.hasrendered) {
      this.getQuoteOptions();
      this.hasrendered = true;
    }
  }
  totalError;
  getErrorRecords(event) {
    this.totalError = event.detail;
    console.log("inside summaryPringCmpnt++");
  }

  handleUpdateQrStatus(event) {
    this.dispatchEvent(
      new CustomEvent("updateqrstatus", {
        detail: {
          qrStatus: event.detail.qrStatus,
          qrSubStatus: event.detail.qrSubStatus,
          qrLastSavedDate: event.detail.qrLastSavedDate
        }
      })
    );
  }

  getQuoteOptions() {
    this.isSalesRep = false;
    this.isSalesEngOrEX = false;
    /*if(this.loggedInUser && this.loggedInUser.lstPermissionSet && (this.loggedInUser.lstPermissionSet.includes('SalesRep') || this.loggedInUser.lstPermissionSet.includes('ChannelSalesRep'))){
            this.isSalesRep=true;
        } */

    if (
      this.loggedInUser &&
      this.loggedInUser.lstPermissionSet &&
      (this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
        this.loggedInUser.lstPermissionSet.includes("SalesEng") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
        this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
        this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
        this.loggedInUser.lstPermissionSet.includes("SalesEngManager") ||
        this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter"))
    ) {
      this.isSalesEngOrEX = true;
    } else {
      this.isSalesRep = true;
    }

    fetchQuoteOptions({ recordId: this.recordId,isFilterClosedWon: this.isFilterClosedWon })
      .then((result) => {
        console.log("result Data:", result);
        this.error = undefined;
        if (this.isSalesRep) {
          this.allProducts = [];
          this.productsMap = new Map();
          this.processProductsData(
            result.quoteItemWrapperList,
            result.listOfQuoteOptions
          );
          this.error = undefined;
        } else if (this.isSalesEngOrEX) {
          getQuotePricingData({ recordId: this.recordId,isFilterClosedWon: this.isFilterClosedWon })
            .then((quoteOptionsData) => {
              console.log("getQuotePricingData result Data:", quoteOptionsData);
              this.salesEngProduct = [];
              this.processPricingData(
                quoteOptionsData,
                result.listOfQuoteOptions
              );
              this.error = undefined;
            })
            .catch((error) => {
              console.log(error);
            });
        }
      })
      .catch((error) => {
        console.log(error);
      });
  }
  processPricingData(quoteOptionsData, quoteOptions) {
    this.quoteWrapperList = quoteOptionsData;

    let productsData = [];
    for (var quoteOptionData of quoteOptionsData) {
      if (quoteOptionData != null) {
        for (var product of quoteOptionData.quoteOptionItemList) {
          var product1 = { ...product };
          productsData.push(product1);
          //this.salesEngProduct.push(product1);
          this.totalTheOptionItemPrices(product1);
        }
      }
    }

    this.totalTheVendorPrices(productsData);
  }

  processProductsData(quoteOptionsData, quoteOptions) {
    this.quoteOptionList = [];
    for (var quoteOption of quoteOptions) {
      let productsData = [];
      for (var quoteOptionData of quoteOptionsData) {
        this.surchargeSummaryCheck = quoteOptionData.isSurcharge;
        console.log(
          "Summary Pricing Surcharge value : ",
          this.surchargeSummaryCheck
        );
        let prodName;
        prodName = quoteOptionData.product;
        let productCategory = quoteOptionData.productCategory;
        if (prodName == "POTS") {
          this.isPOTSProduct = true;
        }
      if(productCategory != "Operator Connect for Microsoft Teams"){
        if (
          quoteOptionData != null &&
          quoteOption != null &&
          quoteOption.Id == quoteOptionData.quoteOptionId
        ) {
          let product = {
            id: quoteOptionData.quoteOptionItemId,
            quoteOption: quoteOptionData.quoteOptionId,
            product: quoteOptionData.product,
            qty: quoteOptionData.qty != null ? quoteOptionData.qty : 0,
            activation:
              quoteOptionData.activation != null
                ? typeof quoteOptionData.activation == "string"
                  ? parseFloat(quoteOptionData.activation)
                  : quoteOptionData.activation
                : 0,
            circuitmrc:
              quoteOptionData.circuitmrc != null
                ? quoteOptionData.circuitmrc
                : 0,
            surcharge:
              quoteOptionData.surcharge != null ? quoteOptionData.surcharge : 0,
            tax: quoteOptionData.tax != null ? quoteOptionData.tax : 0,
            totalmrc:
              quoteOptionData.totalmrc != null ? quoteOptionData.totalmrc : 0,
            equipmrcrate:
              quoteOptionData.equipmrcrate != null
                ? quoteOptionData.equipmrcrate
                : 0,
            ipmrcrate:
              quoteOptionData.ipmrcrate != null ? quoteOptionData.ipmrcrate : 0,
            equipnrcrate:
              quoteOptionData.equipnrcrate != null
                ? quoteOptionData.equipnrcrate
                : 0,
            picc: quoteOptionData.picc != null ? quoteOptionData.picc : 0,
            class: "table-column"
          };
          productsData.push(product);
          //this.allProducts.push(product);
          if (this.productsMap.has(product.product)) {
            this.productsMap.get(product.product).push(product);
          } else {
            let arr = [];
            arr.push(product);
            this.productsMap.set(product.product, arr);
          }
        }
      }
      }
      this.totalThePrices(productsData, false);
      this.quoteOptionList.push({
        Id: quoteOption.Id,
        Name: quoteOption.Name,
        QuoteOptionID__c: quoteOption.QuoteOptionID__c,
        products: productsData
      });
      console.log(
        JSON.stringify("final list" + JSON.stringify(this.productsMap))
      );
    }

    this.combineSameProduct(this.productsMap);
    this.totalThePrices(this.allProducts, true);
  }

  combineSameProduct(products) {
    for (var key of this.productsMap.keys()) {
      if (this.productsMap.get(key).length > 1) {
        let qty = 0;
        let activation = 0;
        let circuitmrc = 0;
        let surcharge = 0;
        let tax = 0;
        let totalmrc = 0;
        let equipmrcrate = 0;
        let ipmrcrate = 0;
        let equipnrcrate = 0;
        let picc = 0;
        let name = "";
        let id = "";
        let quoteOption = "";
        for (var item of this.productsMap.get(key)) {
          id = item.id;
          quoteOption = item.quoteOption;
          name = item.product;
          qty = qty + parseFloat(item.qty);
          activation = activation + item.activation;
          circuitmrc = circuitmrc + item.circuitmrc;
          surcharge = surcharge + item.surcharge;
          tax = tax + item.tax;
          picc = picc + item.picc;
          totalmrc = totalmrc + item.totalmrc;
          equipmrcrate = equipmrcrate + item.equipmrcrate;
          equipnrcrate = equipnrcrate + item.equipnrcrate;
          ipmrcrate = ipmrcrate + item.ipmrcrate;
        }
        this.allProducts.push({
          id: id,
          quoteOption: quoteOption,
          product: name,
          qty: qty,
          activation: activation,
          circuitmrc: circuitmrc,
          surcharge: surcharge,
          tax: tax,
          picc: picc,
          totalmrc: totalmrc,
          ipmrcrate: ipmrcrate,
          equipmrcrate: equipmrcrate,
          equipnrcrate: equipnrcrate,
          class: "table-column"
        });
      } else {
        this.allProducts.push(this.productsMap.get(key)[0]);
      }
    }
  }

  handleUpdatecurrentTotal(event) {
    this.dispatchEvent(
      new CustomEvent("updatecurrenttotal", {
        detail: { enableGenerateQuote: event.detail.enableGenerateQuote }
      })
    );
  }

  handleQuoteOptionsClick(event) {
    let quoteOptionId = event.detail;
    console.log("Inside handle selectQuoteOption" + quoteOptionId);
    this.isQuoteOptionClick = true;
    this.className = "notselected";
    if (this.template.querySelector("c-location-and-products")) {
      this.template
        .querySelector("c-location-and-products")
        .falseByProductView();
    }
  }
  handleSingleProductChange(event) {
    this.isSingleLocationProductsView =
      event.detail.isSingleLocationProductsView;
  }
  summarySelection(event) {
    this.className = "selected";
    this.isQuoteOptionClick = false;
    this.hasrendered = false;
    this.template
      .querySelector("c-location-and-products")
      .handleSummaryVariable();
  }

  totalTheOptionItemPrices(products) {
    if (
      this.VendorNameList &&
      !this.VendorNameList.includes(products.quoteOptionItemName)
    ) {
      this.VendorNameList.push(products.quoteOptionItemName);
      var objVT = {};
      objVT.VendorName = products.quoteOptionItemName;
      objVT.Qty = 0;
      objVT.Revenue = 0;
      objVT.Cost = 0;
      objVT.MarginDollar = 0;
      objVT.MarginPercent = 0;
      objVT.ARPU = 0;
      objVT.ACPU = 0;
      objVT.AMPU = 0;
      objVT.className = "table-columns";
      if (products.VendorDataList) {
        let item1 = [...products.VendorDataList];
        item1.pop();
        products.VendorDataList = item1;
        for (let objV of products.VendorDataList) {
          if (objV.VendorName != "Total") {
            objVT.Qty = objVT.Qty + objV.Qty;
            objVT.Revenue = objVT.Revenue + objV.Revenue;
            objVT.Cost = objVT.Cost + objV.Cost;
            objVT.MarginDollar = objVT.MarginDollar + objV.MarginDollar;
            objVT.MarginPercent = (
              (Number(objVT.MarginDollar) / Number(objVT.Revenue)) *
              100
            ).toFixed(2);
            objVT.ARPU = objVT.ARPU + objV.ARPU;
            objVT.ACPU = objVT.ACPU + objV.ACPU;
            objVT.AMPU = objVT.AMPU + objV.AMPU;
          }

          // item.VendorDataList.push(objVT);
        }
      }
      this.salesEngProduct.push(objVT);
    } else {
      for (let i = 0; i < this.salesEngProduct.length; i++) {
        if (
          this.salesEngProduct[i].VendorName == products.quoteOptionItemName
        ) {
          if (products.VendorDataList) {
            let item1 = [...products.VendorDataList];
            item1.pop();
            products.VendorDataList = item1;
            for (let objV of products.VendorDataList) {
              if (objV.VendorName != "Total") {
                this.salesEngProduct[i].Qty =
                  this.salesEngProduct[i].Qty + objV.Qty;
                this.salesEngProduct[i].Revenue =
                  this.salesEngProduct[i].Revenue + objV.Revenue;
                this.salesEngProduct[i].Cost =
                  this.salesEngProduct[i].Cost + objV.Cost;
                this.salesEngProduct[i].MarginDollar =
                  this.salesEngProduct[i].MarginDollar + objV.MarginDollar;
                this.salesEngProduct[i].MarginPercent = (
                  (Number(this.salesEngProduct[i].MarginDollar) /
                    Number(this.salesEngProduct[i].Revenue)) *
                  100
                ).toFixed(2);
                this.salesEngProduct[i].ARPU =
                  this.salesEngProduct[i].ARPU + objV.ARPU;
                this.salesEngProduct[i].ACPU =
                  this.salesEngProduct[i].ACPU + objV.ACPU;
                this.salesEngProduct[i].AMPU =
                  this.salesEngProduct[i].AMPU + objV.AMPU;
              }

              // item.VendorDataList.push(objVT);
            }
          }
        }
      }
    }
  }
  totalTheVendorPrices(products) {
    var objVT = {};
    objVT.VendorName = "Total";
    objVT.Qty = 0;
    objVT.Revenue = 0;
    objVT.Cost = 0;
    objVT.MarginDollar = 0;
    objVT.MarginPercent = 0;
    objVT.ARPU = 0;
    objVT.ACPU = 0;
    objVT.AMPU = 0;
    objVT.className = "table-total";
    for (let item of products) {
      if (item.VendorDataList) {
        for (let objV of item.VendorDataList) {
          if (objV.VendorName != "Total") {
            objVT.Qty = objVT.Qty + objV.Qty;
            objVT.Revenue = objVT.Revenue + objV.Revenue;
            objVT.Cost = objVT.Cost + objV.Cost;
            objVT.MarginDollar = objVT.MarginDollar + objV.MarginDollar;
            objVT.MarginPercent = (
              (Number(objVT.MarginDollar) / Number(objVT.Revenue)) *
              100
            ).toFixed(2);
            objVT.ARPU = objVT.ARPU + objV.ARPU;
            objVT.ACPU = objVT.ACPU + objV.ACPU;
            objVT.AMPU = objVT.AMPU + objV.AMPU;
          }
        }

        // item.VendorDataList.push(objVT);
      }
    }
    this.totalsOfAll.push(objVT);
    this.salesEngProduct.push(objVT);
  }

  totalThePrices(products, isAll) {
    let qty = 0;
    let activation = 0;
    let circuitmrc = 0;
    let surcharge = 0;
    let tax = 0;
    let totalmrc = 0;
    let ipmrcrate = 0;
    let equipmrcrate = 0;
    let equipnrcrate = 0;
    let picc = 0;
    let prodList = [];

    for (let item of products) {
      qty = qty + parseFloat(item.qty);
      activation = activation + item.activation;
      circuitmrc = circuitmrc + item.circuitmrc;
      surcharge = surcharge + item.surcharge;
      tax = tax + item.tax;
      picc = picc + item.picc;
      totalmrc = totalmrc + item.totalmrc;
      ipmrcrate = ipmrcrate + item.ipmrcrate;
      equipmrcrate = equipmrcrate + item.equipmrcrate;
      equipnrcrate = equipnrcrate + item.equipnrcrate;
    }

    products.push({
      id: "",
      quoteOption: "",
      product: "Total",
      qty: qty,
      activation: activation,
      circuitmrc: circuitmrc,
      surcharge: surcharge,
      tax: tax,
      picc: picc,
      totalmrc: totalmrc,
      ipmrcrate: ipmrcrate,
      equipmrcrate: equipmrcrate,
      equipnrcrate: equipnrcrate,
      class: "table-total"
    });
  }
  //calling an export function from salesRep cmp to location and products
  @api connectSalesRepLocationProducts(quoteRequestName) {
    this.template
      .querySelector("c-location-and-products")
      .handleExportExcelFile(quoteRequestName);
  }

  handleeleclocationsandprod(event) {
    const selectedGUIIds = event.detail.selectedGUIIds;
    this.dispatchEvent(
      new CustomEvent("seleclocationsandprod", {
        detail: {
        locandprod: event.detail.locandprod ,selectedGUIIds : selectedGUIIds
        }
      })
    );
  }
  // getSurchargeSummaryValue(event){
  //     this.surchargeSummaryCheck = event.detail;
  //     console.log('Sur charge summary check : ',this.surchargeSummaryCheck);
  // }

  filterClosedWon(event){
    if(event.target.checked){
      this.isFilterClosedWon = true;
      this.isChecked = true;
    }
    else{
      this.isFilterClosedWon = false;
      this.isChecked = false;
    }
    this.hasrendered = false;
    this.renderedCallback();
  }
}