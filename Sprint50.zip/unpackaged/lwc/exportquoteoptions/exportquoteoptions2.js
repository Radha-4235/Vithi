/*import getLocations from "@salesforce/apex/ExportCSVController.getQuoteLocations";
import {
  getCurrencyfarmat,
  formatCell,
  formatQuoteOptionTableHeaders,
  formatCellBold,
  formatCellwithBold,
  footertext,
  getpercentagefarmat
} from "./exportquoteoptions1";

export async function getLocationsExcel(quoteOptionId,dynamicsheet, worksheetvisibleflag, worksheet, quoteoptions, i, indexcount, summryrow, setSummary, errorKey) {
  await getLocations({ ListofQOIDs: quoteOptionId })
        .then((result) => {
          if (result) {
            let qlocOp = result;
            let statrowcount;
            var EPIKflag = false;
            var EPIKWholesaleflag = false;
            var POTSflag = false;
            var DIAflag = false;
            var BBflag = false;
            var GSEPIPflag = false;
            var GRIDflag = false;
            var Mobilityflag = false;
            var surchargeflag = false;
            var POTSproductTypeflag = false;
            var VoIPflag = false;
            var POTSproductTypeLocalLDflag = false;
            var GMonthlyPrice = 0;
            var GAnnuallyPrice = 0;
            var MonthlySavings = 0;
            var AvgSavings = 0;
            var servicefirstval = 0;
            var avgspendpersite = 0;
            var servicefirstsubval = 0;
            var qlocsize = 0;
            var comparisionflag = false;
            var objNRC = {};
            objNRC.EquipProdName;objNRC.BBProdName;objNRC.BBModel;objNRC.BBQty = 0;objNRC.BBTTNRC = 0;objNRC.BBNRCDes;objNRC.BBAccessType;
            objNRC.DIAProdName;objNRC.DIAModel;objNRC.DIAQty = 0;objNRC.DIATTNRC = 0;objNRC.DIANRCDes;objNRC.DIAAccessType;
            objNRC.EPIKProdName;objNRC.EPIKModel;objNRC.EPIKQty = 0;objNRC.EPIKTTNRC = 0;objNRC.EPIKNRCDes;objNRC.EPIKAccessType;
            objNRC.EquipmentProdName;objNRC.EquipmentModel;objNRC.EquipmentQty = 0;objNRC.EquipmentTTNRC = 0;objNRC.EquipmentNRCDes; objNRC.EquipmentAccessType;
            objNRC.GSEProdName;objNRC.GSEModel;objNRC.GSEQty = 0;objNRC.GSETTNRC = 0;objNRC.GSENRCDes;objNRC.GSEAccessType;
            objNRC.GRIDProdName;objNRC.GRIDModel;objNRC.GRIDQty = 0;objNRC.GRIDTTNRC = 0; objNRC.GRIDNRCDes;objNRC.GRIDAccessType;
            objNRC.GDNProdName; objNRC.GDNModel;objNRC.GDNQty = 0;objNRC.GDNTTNRC = 0;objNRC.GDNNRCDes;objNRC.GDNAccessType;
            objNRC.PIPProdName;objNRC.PIPModel;objNRC.PIPQty = 0;objNRC.PIPTTNRC = 0;objNRC.PIPNRCDes;objNRC.PIPAccessType;
            objNRC.POTSProdName;objNRC.POTSModel; objNRC.POTSQty = 0;objNRC.POTSTTNRC = 0;objNRC.POTSNRCDes;objNRC.POTSAccessType;
            objNRC.EPOTSProdName;objNRC.EPOTSModel; objNRC.EPOTSQty = 0;objNRC.EPOTSTTNRC = 0;objNRC.EPOTSNRCDes;objNRC.EPOTSAccessType;
            objNRC.ProdName = "Total";
            objNRC.TTNRCQty = 0;
            objNRC.TTNRCCost = 0;
            var ss = {};
            ss.BBProdName;ss.BBQty = 0;ss.BBMT = 0; ss.BBAT = 0;ss.BBCMT = 0;ss.BBCAT = 0;ss.BBCSD = 0;ss.BBCSP = 0;
            ss.DIAProdName;ss.DIAQty = 0;ss.DIAMT = 0;ss.DIAAT = 0;ss.DAICMT = 0;ss.DIACAT = 0;ss.DAICSD = 0;ss.DIACSP = 0;
            ss.EPIKProdName;ss.EPIKQty = 0;ss.EPIKMT = 0;ss.EPIKAT = 0;ss.EPIKCMT = 0;ss.EPIKCAT = 0;ss.EPIKCSD = 0;ss.EPIKCSP = 0;
            ss.EquipmentProdName;ss.EquipmentQty = 0;ss.EQUIPMT = 0;ss.EQUIPAT = 0;ss.EQUIPCMT = 0;ss.EQUIPCAT = 0;ss.EQUIPCSD = 0;ss.EQUIPCSP = 0;
            ss.GSEProdName;ss.GSEQty = 0;ss.GSEMT = 0;ss.GSEAT = 0;ss.GSECMT = 0;ss.GSECAT = 0;ss.GSECSD = 0;ss.GSECSP = 0;
            ss.GRIDProdName;ss.GRIDQty = 0;ss.GRIDMT = 0;ss.GRIDAT = 0;ss.GRIDCMT = 0;ss.GRIDCAT = 0;ss.GRIDCSD = 0;ss.GRIDCSP = 0;
            ss.GDNProdName;ss.GDNQty = 0;ss.GDNMT = 0;ss.GDNAT = 0;ss.GDNCMT = 0;ss.GDNCAT = 0;ss.GDNCSD = 0;ss.GDNCSP = 0;
            ss.PIPProdName;ss.PIPQty = 0;ss.PIPMT = 0;ss.PIPAT = 0;ss.PIPCMT = 0;ss.PIPCAT = 0;ss.PIPCSD = 0;ss.PIPCSP = 0;
            ss.POTSProdName;ss.POTSQty = 0;ss.POTSMT = 0;ss.POTSAT = 0;ss.POTCMT = 0;ss.POTCAT = 0;ss.POTCSD = 0;ss.POTCSP = 0;
            ss.EPOTSProdName;ss.EPOTSQty = 0;ss.EPOTSMT = 0;ss.EPOTSAT = 0;ss.EPOTCMT = 0;ss.EPOTCAT = 0;ss.EPOTCSD = 0;ss.EPOTCSP = 0;
            for (const [index, [key, value]] of Object.entries(
              Object.entries(qlocOp)
            )) {
              let rowcount = +8 + +index;
              
              console.log("rowcount:", rowcount);
              qlocsize++;
            }
            for (const [index, [key, value]] of Object.entries(
              Object.entries(qlocOp)
            )) {
              let rowcount = +8 + +index;
              
              console.log("rowcount:", rowcount);
              var BBCurnttotalMRC = 0;var DIACurnttotalMRC = 0;var EPIKCurnttotalMRC = 0;var EquipmentCurnttotalMRC = 0;var GSECurnttotalMRC = 0;
              var GRIDCurnttotalMRC = 0;var GuradianCurnttotalMRC = 0;var MobalityCurnttotalMRC = 0;var PIPCurnttotalMRC = 0;var POTSCurnttotalMRC = 0;
              var EPOTSCurnttotalMRC = 0;
              var CurnttotalMRC = 0;var CurnttotalsitesavingsDol = 0;var CurnttotalsitesavingsPer = 0;
              qlocsize++;
              for (let p = 0; p < value.length; p++) {
                let BBTotalMRC = 0;let DIATotalMRC = 0;let EPIKTotalMRC = 0;let EquipmentTotalMRC = 0;let GSETotalMRC = 0;
                let GRIDTotalMRC = 0;let GuardianTotalMRC = 0;let MobilityTotalMRC = 0;let PIPTotalMRC = 0;let POTSTotalMRC = 0;let EPOTSTotalMRC = 0;
                let TotalSiteMRC = 0;
                if (value[p].Quote_Option_Item__r.Billing_Type__c === "NRC") {
                  const NRCRow = dynamicsheet.getRow(rowcount);
                  NRCRow.hidden = true;
                }
                if (value[p].Quote_Option_Item__r.Billing_Type__c != "NRC") {
                  dynamicsheet.getCell("A" + rowcount).value =value[p].Quote_Request_Location__r.Address__c != null? value[p].Quote_Request_Location__r.Address__c: "";
                  dynamicsheet.getCell("B" + rowcount).value =value[p].Quote_Request_Location__r.City__c != null? value[p].Quote_Request_Location__r.City__c: "";
                  dynamicsheet.getCell("C" + rowcount).value =value[p].Quote_Request_Location__r.State__c != null? value[p].Quote_Request_Location__r.State__c: "";
                  dynamicsheet.getCell("D" + rowcount).value =value[p].Quote_Request_Location__r.Zip__c != null? value[p].Quote_Request_Location__r.Zip__c: "";
                }
                if (value[p].Quote_Option_Item__r.Name === "Broadband") {
                  BBflag = true;
                  dynamicsheet.getCell("E" + rowcount).value =value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("F" + rowcount).value =value[p].Quote_Option_Item__r.Term__c != null? value[p].Quote_Option_Item__r.Term__c: "";
                  if (
                    value[p].Quote_Option_Item__r.Ip_Block__c ==="4 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/30";
                  } else if (value[p].Quote_Option_Item__r.Ip_Block__c ==="8 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/29";
                  } else if (value[p].Quote_Option_Item__r.Ip_Block__c ==="16 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/28";
                  } else if (value[p].Quote_Option_Item__r.Ip_Block__c ==="32 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/27";
                  } else if (value[p].Quote_Option_Item__r.Ip_Block__c ==="64 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/26";
                  } else if (value[p].Quote_Option_Item__r.Ip_Block__c ==="128 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/25";
                  } else if (value[p].Quote_Option_Item__r.Ip_Block__c ==="256 IP Addresses"
                  ) {dynamicsheet.getCell("N" + rowcount).value = "/24";
                  } else {dynamicsheet.getCell("N" + rowcount).value = " ";
                  }
                  if (
                    value[p].Quote_Request_Rates__r &&value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("G" + rowcount).value =value[p].Quote_Request_Rates__r[0].Vendor__c != null? value[p].Quote_Request_Rates__r[0].Vendor__c: "";
                    dynamicsheet.getCell("H" + rowcount).value =value[p].Quote_Request_Rates__r[0].Download_Speed__c !=null? value[p].Quote_Request_Rates__r[0].Download_Speed__c: "";
                    dynamicsheet.getCell("I" + rowcount).value =value[p].Quote_Request_Rates__r[0].Upload_Speed__c != null? value[p].Quote_Request_Rates__r[0].Upload_Speed__c: "";
                    dynamicsheet.getCell("P" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("Q" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("R" + rowcount).value =getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("J" + rowcount).value =
                      getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    dynamicsheet.getCell("K" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].IP_MRC_Rate__c);
                    dynamicsheet.getCell("L" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("M" + rowcount).value = "";
                      surchargeflag = true;
                    }
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("M" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                    }
                    dynamicsheet.getCell("O" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    BBTotalMRC =value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    BBCurnttotalMRC =value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("J" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("K" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("L" + rowcount).value =getCurrencyfarmat();
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false
                    ) {
                      dynamicsheet.getCell("M" + rowcount).value = "";
                      surchargeflag = true;
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("M" + rowcount).value = getCurrencyfarmat();
                    }
                    dynamicsheet.getCell("O" + rowcount).value =getCurrencyfarmat();
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.BBProdName = "Broadband";
                    objNRC.BBQty =objNRC.BBQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                      objNRC.BBTTNRC =objNRC.BBTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.BBProdName = "Broadband";
                  ss.BBQty =ss.BBQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.BBMT =ss.BBMT +Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.BBCMT =ss.BBCMT +Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.BBCSD =ss.BBCSD +Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.BBCSP =ss.BBCSP +Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "DIA") {
                  DIAflag = true;
                  dynamicsheet.getCell("S" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
                  dynamicsheet.getCell("T" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  dynamicsheet.getCell("X" + rowcount).value =value[p].Quote_Option_Item__r.Speed__c != null? value[p].Quote_Option_Item__r.Speed__c: "";
                  dynamicsheet.getCell("W" + rowcount).value =value[p].Quote_Request_Rates__r[0].On_Net__c != null? value[p].Quote_Request_Rates__r[0].On_Net__c: "No";
                  dynamicsheet.getCell("U" + rowcount).value =value[p].Quote_Option_Item__r.Access_Type__c != null? value[p].Quote_Option_Item__r.Access_Type__c: "";
                  dynamicsheet.getCell("AB" + rowcount).value =value[p].Quote_Option_Item__r.Access_Type__c != null? value[p].Quote_Option_Item__r.Access_Type__c: "";
                  if (
                    value[p].Quote_Request_Rates__r &&value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("AE" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("AF" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("AG" + rowcount).value =getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("V" + rowcount).value =value[p].Quote_Request_Rates__r[0].Vendor__c != null? value[p].Quote_Request_Rates__r[0].Vendor__c: "";
                    dynamicsheet.getCell("Y" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    dynamicsheet.getCell("Z" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].IP_MRC_Rate__c);
                    dynamicsheet.getCell("AA" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("AC" + rowcount).value = "";
                      surchargeflag = true;
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("AC" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                    }
                    dynamicsheet.getCell("AD" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    DIATotalMRC =value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    DIACurnttotalMRC =value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("Y" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("Z" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("AA" + rowcount).value =getCurrencyfarmat();
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("AC" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("AC" + rowcount).value =getCurrencyfarmat();
                    }
                    dynamicsheet.getCell("AD" + rowcount).value =getCurrencyfarmat();
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.DIAProdName = "DIA";
                    objNRC.DIAQty =objNRC.DIAQty +Number(value[p].Quote_Option_Item__r.QTY__c);
                    if (objNRC.DIAAccessType != null) {
                      objNRC.DIAAccessType += ";" + value[p].Quote_Option_Item__r.Access_Type__c;
                    } else {
                      objNRC.DIAAccessType = value[p].Quote_Option_Item__r.Access_Type__c;
                    }
                    objNRC.DIATTNRC =objNRC.DIATTNRC +Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.DIAProdName = "DIA";
                  ss.DIAQty = ss.DIAQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.DIAMT = ss.DIAMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.DAICMT = ss.DAICMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.DAICSD = ss.DAICSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.DIACSP = ss.DIACSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "EPIK") {
                  EPIKflag = true;
                  dynamicsheet.getCell("AH" + rowcount).value =value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("AJ" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  if (
                    value[p].Quote_Request_Rates__r &&value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("AP" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("AQ" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("AR" + rowcount).value =getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("AK" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    dynamicsheet.getCell("AL" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("AM" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("AN" + rowcount).value =getCurrencyfarmat();
                    dynamicsheet.getCell("AO" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    EPIKTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    EPIKCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("AK" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("AL" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("AM" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("AN" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("AO" + rowcount).value = getCurrencyfarmat();
                  }
                  if (value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c === "Wholesale") {
                    EPIKWholesaleflag = true;
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.EPIKProdName = "EPIK";
                    objNRC.EPIKQty = objNRC.EPIKQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    objNRC.EPIKTTNRC = objNRC.EPIKTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.EPIKProdName = "EPIK";
                  ss.EPIKQty = ss.EPIKQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.EPIKMT = ss.EPIKMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.EPIKCMT = ss.EPIKCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.EPIKCSD = ss.EPIKCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.EPIKCSP = ss.EPIKCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "Equipment" &&value[p].Quote_Option_Item__r.Billing_Type__c === "MRC") {
                  dynamicsheet.getCell("AS" + rowcount).value =value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("AT" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  dynamicsheet.getCell("AU" + rowcount).value =value[p].Quote_Option_Item__r.Product_Description__c != null? value[p].Quote_Option_Item__r.Product_Description__c: "";
                  dynamicsheet.getCell("AV" + rowcount).value =value[p].Quote_Option_Item__r.Product_Code__c != null? value[p].Quote_Option_Item__r.Product_Code__c: "";
                  if (
                    value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("AY" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("AZ" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("BA" + rowcount).value =getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("AW" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                    dynamicsheet.getCell("AX" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    EquipmentTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    EquipmentCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("AW" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("AX" + rowcount).value = getCurrencyfarmat();Current_Total__c;
                  }
                  ss.EquipmentProdName = "Equipment";
                  ss.EquipmentQty = ss.EquipmentQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.EQUIPMT = ss.EQUIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  objNRC.EquipmentProdName = "Equipment";
                  ss.EQUIPCMT = ss.EQUIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.EQUIPCSD = ss.EQUIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.EQUIPCSP = ss.EQUIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "Equipment" && value[p].Quote_Option_Item__r.Billing_Type__c === "NRC") {
                  ss.EquipmentProdName = "Equipment";
                  ss.EquipmentQty =ss.EquipmentQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.EQUIPMT = ss.EQUIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.EQUIPCMT = ss.EQUIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.EQUIPCSD = ss.EQUIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.EQUIPCSP = ss.EQUIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "Equipment" && value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c ==="Wholesale") {
                  objNRC.EquipProdName = "Equip";
                }
                if (value[p].Quote_Option_Item__r.Name === "GSE") {
                  GSEPIPflag = true;
                  dynamicsheet.getCell("BB" + rowcount).value =value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("BD" + rowcount).value =value[p].Quote_Option_Item__r.Access_Type__c != null? value[p].Quote_Option_Item__r.Access_Type__c: 0;
                  dynamicsheet.getCell("BC" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  dynamicsheet.getCell("BF" + rowcount).value =value[p].Quote_Option_Item__r.Speed__c != null? value[p].Quote_Option_Item__r.Speed__c: "";
                  dynamicsheet.getCell("BI" + rowcount).value =value[p].Quote_Option_Item__r.Service_Level_Tier__c != null? value[p].Quote_Option_Item__r.Service_Level_Tier__c: "";
                  if (
                    value[p].Quote_Request_Rates__r &&value[p].Quote_Request_Rates__r.length > 0) {
                    dynamicsheet.getCell("BL" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("BM" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("BN" + rowcount).value =getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("BE" + rowcount).value =value[p].Quote_Request_Rates__r[0].Vendor__c != null? value[p].Quote_Request_Rates__r[0].Vendor__c: "";
                    dynamicsheet.getCell("BG" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    if (
                      value[p].Quote_Option_Item__r.Service_Level_Tier__c ==="Bronze") {
                      dynamicsheet.getCell("BG" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Service_Level_Tier__c !="Bronze") {
                      dynamicsheet.getCell("BH" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].COS_MRC__c);
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("BJ" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("BJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                    }
                    dynamicsheet.getCell("BK" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    GSETotalMRC =value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    GSECurnttotalMRC =value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("BH" + rowcount).value = getCurrencyfarmat();
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("BJ" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("BJ" + rowcount).value = getCurrencyfarmat();
                    }
                    dynamicsheet.getCell("BK" + rowcount).value = getCurrencyfarmat();
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.GSEProdName = "GSE";
                    objNRC.GSEQty = objNRC.GSEQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    if (objNRC.GSEAccessType != null) {
                      objNRC.GSEAccessType += ";" + value[p].Quote_Option_Item__r.Access_Type__c;
                    } else {
                      objNRC.GSEAccessType = value[p].Quote_Option_Item__r.Access_Type__c;
                    }
                    objNRC.GSETTNRC = objNRC.GSETTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.GSEProdName = "GSE";
                  ss.GSEQty = ss.GSEQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.GSEMT = ss.GSEMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.GSECMT = ss.GSECMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.GSECSD = ss.GSECSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.GSECSP = ss.GSECSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "GRID") {
                  GRIDflag = true;
                  ss.GRIDProdName = "GRID";
                  ss.GRIDQty = ss.GRIDQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  dynamicsheet.getCell("BO" + rowcount).value =value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("BP" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  dynamicsheet.getCell("BQ" + rowcount).value =value[p].Quote_Option_Item__r.Minimum_Speed__c != null? value[p].Quote_Option_Item__r.Minimum_Speed__c: "";
                  if (value[p].Quote_Request_Rates__r &&value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("BW" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("BX" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("BY" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("BR" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    dynamicsheet.getCell("BS" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].IP_MRC_Rate__c);
                    dynamicsheet.getCell("BT" + rowcount).value =getCurrencyfarmat();
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("BU" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("BU" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                    }
                    dynamicsheet.getCell("BV" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    GRIDTotalMRC =value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    GRIDCurnttotalMRC =value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("BR" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("BS" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("BT" + rowcount).value = getCurrencyfarmat();
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("BU" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("BU" + rowcount).value = getCurrencyfarmat();
                    }
                    dynamicsheet.getCell("BV" + rowcount).value = getCurrencyfarmat();
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.GRIDProdName = "GRID";
                    objNRC.GRIDQty = objNRC.GRIDQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    objNRC.GRIDTTNRC = objNRC.GRIDTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.GRIDProdName = "GRID";
                  ss.GRIDQty = ss.GRIDQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.GRIDMT = ss.GRIDMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.GRIDCMT = ss.GRIDCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.GRIDCSD = ss.GRIDCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.GRIDCSP = ss.GRIDCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "Guardian") {
                  dynamicsheet.getCell("BZ" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("CA" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  if (
                    value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("CF" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("CG" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("CH" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("CB" + rowcount).value = value[p].Quote_Option_Item__r.Product_Code_Description__c != null? value[p].Quote_Option_Item__r.Product_Code_Description__c: "";
                    dynamicsheet.getCell("CC" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null? value[p].Quote_Request_Rates__r[0].Vendor__c: "";
                    dynamicsheet.getCell("CD" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    dynamicsheet.getCell("CE" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    GuardianTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    GuradianCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("CB" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("CD" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("CE" + rowcount).value = getCurrencyfarmat();
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.GDNProdName = "Guardian";
                    objNRC.GDNQty = objNRC.GDNQty +Number(value[p].Quote_Option_Item__r.QTY__c);
                    objNRC.GDNTTNRC =objNRC.GDNTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.GDNProdName = "Guardian";
                  ss.GDNQty = ss.GDNQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.GDNMT = ss.GDNMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.GDNCMT = ss.GDNCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.GDNCSD = ss.GDNCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.GDNCSP = ss.GDNCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "Mobility") {
                  Mobilityflag = true;
                  dynamicsheet.getCell("CI" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("CJ" + rowcount).value =value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  dynamicsheet.getCell("CK" + rowcount).value =value[p].Quote_Option_Item__r.Provider__c != null? value[p].Quote_Option_Item__r.Provider__c: "";
                  dynamicsheet.getCell("CL" + rowcount).value = "";
                  dynamicsheet.getCell("CM" + rowcount).value = "";
                  if (
                    value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("CP" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("CQ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("CR" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("CN" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].GC_MRC_Rate__c);
                    dynamicsheet.getCell("CO" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    MobilityTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    MobalityCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    dynamicsheet.getCell("CN" + rowcount).value = getCurrencyfarmat();
                    dynamicsheet.getCell("BO" + rowcount).value = getCurrencyfarmat();
                  }
                }
                if (value[p].Quote_Option_Item__r.Name === "PIP") {
                  GSEPIPflag = true;
                  dynamicsheet.getCell("CS" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("CU" + rowcount).value = value[p].Quote_Option_Item__r.Access_Type__c != null? value[p].Quote_Option_Item__r.Access_Type__c: 0;
                  dynamicsheet.getCell("CT" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null? value[p].Quote_Option_Item__r.Contract_Term__c: "";
                  dynamicsheet.getCell("CV" + rowcount).value = value[p].Quote_Option_Item__r.Speed__c != null? value[p].Quote_Option_Item__r.Speed__c: "";
                  if (
                    value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
                    dynamicsheet.getCell("DA" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("DB" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("DC" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("CW" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    if (
                      value[p].Quote_Option_Item__r.Service_Level_Tier__c ==="Bronze") {
                      dynamicsheet.getCell("CX" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Service_Level_Tier__c !="Bronze") {
                      dynamicsheet.getCell("CX" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].COS_MRC__c);
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("CY" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("CY" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                    }
                    dynamicsheet.getCell("CZ" + rowcount).value =getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    PIPTotalMRC =value[p].Quote_Request_Rates__r[0].Total_MRC__c;PIPCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("CY" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("CY" + rowcount).value = getCurrencyfarmat();
                    }
                    dynamicsheet.getCell("CZ" + rowcount).value = getCurrencyfarmat();
                  }
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.PIPProdName = "PIP";
                    objNRC.PIPQty = objNRC.PIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    if (objNRC.PIPAccessType != null) {
                      objNRC.PIPAccessType += ";" + value[p].Quote_Option_Item__r.Access_Type__c;
                    } else {
                      objNRC.PIPAccessType = value[p].Quote_Option_Item__r.Access_Type__c;
                    }
                    objNRC.PIPTTNRC = objNRC.PIPTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.PIPProdName = "PIP";
                  ss.PIPQty = ss.PIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.PIPMT = ss.PIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.PIPCMT = ss.PIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.PIPCSD = ss.PIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.PIPCSP = ss.PIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }
                if (value[p].Quote_Option_Item__r.Name === "POTS") {
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.POTSProdName = "POTS";
                    objNRC.POTSQty = objNRC.POTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    objNRC.POTSTTNRC = objNRC.POTSTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.POTSProdName = "POTS";
                  ss.POTSQty = ss.POTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.POTSMT = ss.POTSMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  POTSflag = true;
                  if (value[p].Quote_Option_Item__r.Product_Type__c === "Local") {
                    POTSproductTypeflag = true;
                  }
                  if (value[p].Quote_Option_Item__r.Product_Type__c ==="Local + LD") {
                    POTSproductTypeLocalLDflag = true;
                  }
                  dynamicsheet.getCell("DD" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  if (
                    value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0
                  ) {
                    dynamicsheet.getCell("DE" + rowcount).value =value[p].Quote_Request_Rates__r[0].Vendor__c != null? value[p].Quote_Request_Rates__r[0].Vendor__c: "";
                  }
                  dynamicsheet.getCell("DF" + rowcount).value = value[p].Quote_Request_Location__r.Telephone_Number__c !=null? value[p].Quote_Request_Location__r.Telephone_Number__c: "";
                  dynamicsheet.getCell("DG" + rowcount).value =value[p].Quote_Option_Item__r.Term__c != null? value[p].Quote_Option_Item__r.Term__c: "MTM";
                  if (
                    value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
                    dynamicsheet.getCell("DO" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    dynamicsheet.getCell("DP" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    dynamicsheet.getCell("DQ" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                    dynamicsheet.getCell("DH" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                    if (
                      value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("DI" + rowcount).value = "";
                      dynamicsheet.getCell("DJ" + rowcount).value = "";
                      dynamicsheet.getCell("DK" + rowcount).value = "";
                      dynamicsheet.getCell("DL" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("DI" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].EUCL__c);
                      dynamicsheet.getCell("DJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].ARC__c);
                      dynamicsheet.getCell("DK" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].LNP__c);
                      dynamicsheet.getCell("DL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].PTA_PTR__c);
                      dynamicsheet.getCell("DM" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].PICC__c);
                    }
                    dynamicsheet.getCell("DN" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    POTSTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                    POTSCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  } else {
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                      dynamicsheet.getCell("DI" + rowcount).value = "";
                      dynamicsheet.getCell("DJ" + rowcount).value = "";
                      dynamicsheet.getCell("DK" + rowcount).value = "";
                      dynamicsheet.getCell("DL" + rowcount).value = "";
                      dynamicsheet.getCell("DM" + rowcount).value = "";
                    }
                    if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                      dynamicsheet.getCell("DI" + rowcount).value = getCurrencyfarmat();
                      dynamicsheet.getCell("DJ" + rowcount).value = getCurrencyfarmat();
                      dynamicsheet.getCell("DK" + rowcount).value = getCurrencyfarmat();
                      dynamicsheet.getCell("DL" + rowcount).value = getCurrencyfarmat();
                      dynamicsheet.getCell("DM" + rowcount).value = getCurrencyfarmat();
                    }
                    dynamicsheet.getCell("DN" + rowcount).value = getCurrencyfarmat();
                  }
                  ss.POTCMT = ss.POTCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.POTCSD = ss.POTCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.POTCSP = ss.POTCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }

                //if (value[p].Quote_Option_Item__r.Name === "VoIP") {
                  if (value[p].Quote_Option_Item__r.Name === "ePOTS") {
                  VoIPflag = true;                  
                  dynamicsheet.getCell("DR" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Option_Item__r.QTY__c: 0;
                  dynamicsheet.getCell("DS" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null? value[p].Quote_Option_Item__r.Term__c: "";                                     
                  
                  for(let i=0; i<value[p].Quote_Request_Rates__r.length; i++){  
                    if(value[p].Quote_Request_Rates__r[i].Parent_QR_Rate__c === true && value[p].Quote_Request_Rates__r[i].ProductRateType__c==='MONTHLY SERVICE'){
                      dynamicsheet.getCell("EF" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Circuit_MRC_Rate1__c);
                      dynamicsheet.getCell("EG" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Surcharge__c);
                      dynamicsheet.getCell("EH" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].PTA_PTR__c);
                      dynamicsheet.getCell("EI" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Default_Router_Cost__c);
                      dynamicsheet.getCell("EJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Feature_MRC__c);
                      dynamicsheet.getCell("EK" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Total_MRC__c);
                    }
                    if(value[p].Quote_Request_Rates__r[i].Parent_QR_Rate__c === false){
                      if(value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.Name === 'Local Usage Package'){
                        dynamicsheet.getCell("DT" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Local_Usage_Package__c);       
                        dynamicsheet.getCell("DU" + rowcount).value = value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c: 0;
                      }
                      if(value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.Name === 'LD Usage Package'){
                        dynamicsheet.getCell("DV" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].LD_Usage_Package__c);
                        dynamicsheet.getCell("DW" + rowcount).value = value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c: 0;
                      }                    
                      if(value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.Name === 'All Usage Package'){
                        dynamicsheet.getCell("DX" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].All_Usage_Package__c);
                        dynamicsheet.getCell("DY" + rowcount).value = value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c: 0;
                      }
                      if(value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.Name === 'Voicemail'){
                        dynamicsheet.getCell("DZ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Voicemail__c);
                        dynamicsheet.getCell("EA" + rowcount).value = value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c: 0;
                      }
                      if(value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.Name === 'Easy AA'){
                        dynamicsheet.getCell("EB" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Easy_AA__c);  
                        dynamicsheet.getCell("EC" + rowcount).value = value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c: 0;
                      }
                      if(value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.Name === 'Premium AA'){
                        dynamicsheet.getCell("ED" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[i].Premium_AA__c);
                        dynamicsheet.getCell("EE" + rowcount).value = value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c != null? value[p].Quote_Request_Rates__r[i].Quote_Option_Item__r.QTY__c: 0;
                      }
                    }
                  }
                  EPOTSTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                  EPOTSCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.EPOTSProdName = "ePOTS";
                    objNRC.EPOTSQty = objNRC.EPOTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    objNRC.EPOTSTTNRC =objNRC.EPOTSTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                  ss.EPOTSProdName = "ePOTS";
                  ss.EPOTSQty =ss.EPOTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  ss.EPOTSMT =ss.EPOTSMT +Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                  ss.EPOTCMT =ss.EPOTCMT +Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                  ss.EPOTCSD =ss.EPOTCSD +Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                  ss.EPOTCSP =ss.EPOTCSP +Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                }


                if (value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c ==="Wholesale") {
                  const hideModem = dynamicsheet.getColumn("L"); hideModem.hidden = true;
                  const hideIAR = dynamicsheet.getColumn("M"); hideIAR.hidden = true;
                  const hideAccess = dynamicsheet.getColumn("U"); hideAccess.hidden = true;
                  const hideCSR = dynamicsheet.getColumn("AC"); hideCSR.hidden = true;
                  const hideCSR1 = dynamicsheet.getColumn("BJ"); hideCSR1.hidden = true;
                }
                if (
                  value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c != "Wholesale") {
                  const hideIPblock = dynamicsheet.getColumn("N"); hideIPblock.hidden = true;
                  const hideOnnet = dynamicsheet.getColumn("W"); hideOnnet.hidden = true;
                  const hideCOStype = dynamicsheet.getColumn("BI"); hideCOStype.hidden = true;
                  const hideProvider = dynamicsheet.getColumn("BE"); hideProvider.hidden = true;
                  const hideAccess2 = dynamicsheet.getColumn("AB"); hideAccess2.hidden = true;
                }
                if (
                  value[p].Quote_Option__r.Quote_Request__r.Quote_Type__c === "Non-Comparison") {
                  comparisionflag = true;
                }
                formatQuoteOptionTableHeaders(rowcount, dynamicsheet);["A" + rowcount].map((key) => formatCell(dynamicsheet, key));
                TotalSiteMRC = BBTotalMRC + DIATotalMRC + EPIKTotalMRC + EquipmentTotalMRC + GSETotalMRC + GRIDTotalMRC + GuardianTotalMRC + MobilityTotalMRC + PIPTotalMRC + POTSTotalMRC + EPOTSTotalMRC;
                dynamicsheet.getCell("EL" + rowcount).value = getCurrencyfarmat(TotalSiteMRC);
                CurnttotalMRC = BBCurnttotalMRC + DIACurnttotalMRC + EPIKCurnttotalMRC + EquipmentCurnttotalMRC + GSECurnttotalMRC + GRIDCurnttotalMRC + GuradianCurnttotalMRC + MobalityCurnttotalMRC + PIPCurnttotalMRC + POTSCurnttotalMRC + EPOTSCurnttotalMRC;
                dynamicsheet.getCell("EM" + rowcount).value = getCurrencyfarmat(CurnttotalMRC);
                CurnttotalsitesavingsDol = CurnttotalMRC - TotalSiteMRC;
                dynamicsheet.getCell("EN" + rowcount).value = getCurrencyfarmat(CurnttotalsitesavingsDol);
                CurnttotalsitesavingsPer = CurnttotalMRC > 0 ? ( CurnttotalsitesavingsDol / CurnttotalMRC) * 100 : 0;
                //dynamicsheet.getCell("EO" + rowcount).value = getpercentagefarmat(CurnttotalsitesavingsPer.toFixed(2));
                dynamicsheet.getCell("EO" + rowcount).value = getpercentagefarmat(CurnttotalsitesavingsPer);
                GMonthlyPrice += Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                GAnnuallyPrice = GMonthlyPrice * 12;
                avgspendpersite = GMonthlyPrice / qlocsize;
                MonthlySavings += Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                AvgSavings = MonthlySavings / qlocsize;
              }
              statrowcount = rowcount + 3;
            }
            dynamicsheet.getCell("A" + statrowcount).value = "Summary: Non-Recurring Charges";
            dynamicsheet.getCell("A" + statrowcount).font = {
              color: { argb: "3B5AA9" },
              size: 20,
              bold: true
            };
            statrowcount++;
            statrowcount++;
            dynamicsheet.getCell("A" + statrowcount).value = "Product";
            dynamicsheet.getCell("B" + statrowcount).value = "Access Type";
            dynamicsheet.getCell("C" + statrowcount).value = "QTY";
            dynamicsheet.getCell("D" + statrowcount).value = "Description";
            dynamicsheet.getCell("E" + statrowcount).value = "Model";
            dynamicsheet.getCell("F" + statrowcount).value = "Total NRC";
            ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
              formatCellwithBold(dynamicsheet, key, "000000", 10);
              dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
            });
            if (worksheetvisibleflag === true) {
              worksheetvisibleflag = false;
              ["A1:A3", "B1:CE1", "B2:CE2", "B3:CE3"].map((key) => {
                worksheet.mergeCells(key);
              });
            }
            summryrow = indexcount;
            worksheet.getCell("A" + summryrow).value =
            quoteoptions[i].Name;
            ["A" + summryrow].map((key) => {
              worksheet.getCell(key).font = {
                color: { argb: "FF9537" },
                size: 15,
                bold: true
              };
            });
            summryrow++;summryrow++;
            console.log("SummaryValue", summryrow);
            worksheet.getCell("A" + summryrow).value = "Summary";
            ["A" + summryrow].map((key) => {
              worksheet.getCell("A" + summryrow).font = {
                color: { argb: "3B5AA9" },
                size: 15,
                bold: true
              };
            });
            summryrow++;summryrow++;
            worksheet.getCell("A" + summryrow).value = "Services";
            worksheet.getCell("C" + summryrow).value = "Granite Price";
            worksheet.getCell("I" + summryrow).value = "Your Savings";
            worksheet.getCell("O" + summryrow).value = "Per Site";
            ["A" + summryrow + ":" + "B" + summryrow,"C" + summryrow + ":" + "H" + summryrow,"I" + summryrow + ":" + "N" + summryrow, "O" + summryrow + ":" + "Q" + summryrow ].map((key) => {
              worksheet.mergeCells(key);
              worksheet.getCell(key).font = {
                color: { argb: "000000" },
                size: 15,
                bold: true
              };
              worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "center" };
              if (key === "I" + summryrow + ":" + "N" + summryrow) {
                worksheet.getCell(key).fill = {
                  type: "pattern",
                  pattern: "solid",
                  fgColor: { argb: "c7ddb5" }
                };
              }
              if (
                key === "C" + summryrow + ":" + "H" + summryrow || key === "O" + summryrow + ":" + "Q" + summryrow) {
                worksheet.getCell(key).fill = {
                  type: "pattern",
                  pattern: "solid",
                  fgColor: { argb: "B3CCF5" }
                };
              }
            });
            if (comparisionflag === true) {
              ["I", "J", "K", "L", "M", "N"].map((key) => {
                const summaryNonComparcol = worksheet.getColumn(key);
                summaryNonComparcol.hidden = true;
              });
            }
            var loopcount = 0;
            summryrow++;
            if (loopcount === 0) {
              servicefirstval = summryrow;
              loopcount++;
            }
            if (ss.BBProdName === "Broadband") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.BBQty + "    " + ss.BBProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.DIAProdName === "DIA") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.DIAQty + "    " + ss.DIAProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.EPIKProdName === "EPIK") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.EPIKQty + "    " + ss.EPIKProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.EquipmentProdName === "Equipment") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.EquipmentQty + "    " + ss.EquipmentProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.GSEProdName === "GSE") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.GSEQty + "    " + ss.GSEProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.GRIDProdName === "GRID") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.GRIDQty + "    " + ss.GRIDProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.GDNProdName === "Guardian") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.GDNQty + "    " + ss.GDNProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.PIPProdName === "PIP") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.PIPQty + "    " + ss.PIPProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.POTSProdName === "POTS") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.POTSQty + "    " + ss.POTSProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            if (ss.EPOTSProdName === "ePOTS") {
              summryrow++;
              worksheet.getCell("A" + summryrow).value = ss.EPOTSQty + "    " + ss.EPOTSProdName;
              ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
                worksheet.mergeCells(key);
                worksheet.getCell(key).font = {
                  color: { argb: "000000" },
                  size: 10,
                  bold: true
                };
                worksheet.getCell(key).border = {
                  top: { style: "double", color: { argb: "FFFFFF" } }
                };
                worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "Left"};
              });
            }
            worksheet.getCell("C" + servicefirstval).value = getCurrencyfarmat(GMonthlyPrice, true) + "         " +getCurrencyfarmat(GAnnuallyPrice, true);
            worksheet.getCell("I" + servicefirstval).value = getCurrencyfarmat(MonthlySavings, true) +"         " +getCurrencyfarmat(AvgSavings, true);
            worksheet.getCell("O" + servicefirstval).value = getCurrencyfarmat(avgspendpersite);
            ["C" + servicefirstval + ":" + "H" + servicefirstval,"I" + servicefirstval + ":" + "N" + servicefirstval,"O" + servicefirstval + ":" + "Q" + servicefirstval].map((key) => {
              if (
                key === "C" + servicefirstval + ":" + "H" + servicefirstval || key === "I" + servicefirstval + ":" + "N" + servicefirstval ||
                key === "O" + servicefirstval + ":" + "Q" + servicefirstval) {
                worksheet.mergeCells(key);
              }
              if (key === "I" + servicefirstval + ":" + "N" + servicefirstval) {
                worksheet.getCell(key).fill = {
                  type: "pattern",
                  pattern: "solid",
                  fgColor: { argb: "c7ddb5" }
                };
                worksheet.getCell(key).font = {
                  color: { argb: "50A038" },
                  size: 20,
                  bold: true
                };
                worksheet.getCell(key).alignment = {vertical: "bottom",horizontal: "center"};
              }
              if (
                key === "C" + servicefirstval + ":" + "H" + servicefirstval || key === "O" + servicefirstval + ":" + "Q" + servicefirstval) {
                worksheet.getCell(key).fill = {
                  type: "pattern",
                  pattern: "solid",
                  fgColor: { argb: "B3CCF5" }
                };
                worksheet.getCell(key).font = {
                  color: { argb: "0047AB" },
                  size: 20,
                  bold: true
                };
                worksheet.getCell(key).alignment = {vertical: "bottom",horizontal: "center"};
              }
            });
            summryrow++;
            servicefirstval++;
            worksheet.getCell("C" + servicefirstval).value = "Monthly" + "         " + "Annually";
            worksheet.getCell("I" + servicefirstval).value = "Annually Savings" + "         " + "Avg Savings Per Site";
            worksheet.getCell("O" + servicefirstval).value = "Avg Spend Per Site";
            ["A" + summryrow + ":" + "B" + summryrow,"C" + servicefirstval + ":" + "H" + summryrow,"I" + servicefirstval + ":" + "N" + summryrow, "O" + servicefirstval + ":" + "Q" + summryrow ].map((key) => {
              if (key === "A" + summryrow + ":" + "B" + summryrow) {
                worksheet.mergeCells(key);
                worksheet.getCell(key).border = {top: { style: "double", color: { argb: "FFFFFF" } }
              };}  
              if ( key === "C" + servicefirstval + ":" + "H" + summryrow || key === "I" + servicefirstval + ":" + "N" + summryrow || key === "O" + servicefirstval + ":" + "Q" + summryrow) {
                worksheet.mergeCells(key);
              }
              if (key === "I" + servicefirstval + ":" + "N" + summryrow) {
                worksheet.getCell(key).fill = {
                  type: "pattern",
                  pattern: "solid",
                  fgColor: { argb: "c7ddb5" }
                };
                worksheet.getCell(key).font = {
                  color: { argb: "50A038" },
                  size: 15,
                  bold: false
                };
                worksheet.getCell(key).alignment = {vertical: "top",horizontal: "center"};
              }
              if (
                key === "C" + servicefirstval + ":" + "H" + summryrow || key === "O" + servicefirstval + ":" + "Q" + summryrow) {
                worksheet.getCell(key).fill = {
                  type: "pattern",
                  pattern: "solid",
                  fgColor: { argb: "B3CCF5" }
                };
                worksheet.getCell(key).font = {
                  color: { argb: "003B73" },
                  size: 15,
                  bold: false
                };
                worksheet.getCell(key).alignment = {vertical: "top",horizontal: "center"};
              }
            });
            summryrow++;
            summryrow++;
            worksheet.getCell("A" + summryrow).value = "Summary # - Recurring Charges";
            ["A" + summryrow].map((key) => {
              worksheet.getCell("A" + summryrow).font = {
                color: { argb: "3B5AA9" },
                size: 15,
                bold: true
              };
            });
            summryrow++;
            worksheet.getCell("A" + summryrow).value = "Services";
            worksheet.getCell("C" + summryrow).value = "QTY";
            worksheet.getCell("E" + summryrow).value = "Granite Monthly Total";
            worksheet.getCell("H" + summryrow).value = "Granite Annual Total";
            worksheet.getCell("K" + summryrow).value = "Current Monthly Total";
            worksheet.getCell("N" + summryrow).value = "Current Annual Total";
            worksheet.getCell("Q" + summryrow).value = "Current Savings $";
            worksheet.getCell("T" + summryrow).value = "Current Savings %";
            ["A" + summryrow,"C" + summryrow,"E" + summryrow,"H" + summryrow,"K" + summryrow,"N" + summryrow,"Q" + summryrow,
              "T" + summryrow,"A" + summryrow + ":" + "B" + summryrow,"C" + summryrow + ":" + "D" + summryrow,"E" + summryrow + ":" + "G" + summryrow,
              "H" + summryrow + ":" + "J" + summryrow,"K" + summryrow + ":" + "M" + summryrow,"N" + summryrow + ":" + "P" + summryrow,"Q" + summryrow + ":" + "S" + summryrow,
              "T" + summryrow + ":" + "V" + summryrow].map((key) => {
              worksheet.getCell(key).font = {
                color: { argb: "000000" },
                size: 15,
                bold: true
              };
              if (
                key === "Q" + summryrow + ":" + "S" + summryrow || key === "T" + summryrow + ":" + "V" + summryrow) {
                worksheet.getCell(key).font = {
                  color: { argb: "50A038" },
                  size: 15,
                  bold: true
                };
              }
              worksheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              if ( key === "A" + summryrow + ":" + "B" + summryrow ||key === "C" + summryrow + ":" + "D" + summryrow
                 ||key === "E" + summryrow + ":" + "G" + summryrow || key === "H" + summryrow + ":" + "J" + summryrow ||
                key === "K" + summryrow + ":" + "M" + summryrow || key === "N" + summryrow + ":" + "P" + summryrow 
                || key === "Q" + summryrow + ":" + "S" + summryrow ||  key === "T" + summryrow + ":" + "V" + summryrow ) {
                worksheet.mergeCells(key);
              }
            });
            if (comparisionflag === true) {
              [  "K" + summryrow, "N" + summryrow,"Q" + summryrow,"T" + summryrow].map((key) => {
                worksheet.getCell(key).value = "";
              });
            }
            var totQty = 0;
            var totGraMonthPrice = 0;
            var totHGraAnnuPrice = 0;
            var CurrentMonthlyTotal = 0;
            var CurrentAnnualTotal = 0;
            var CurrentSavingsDol = 0;
            var CurrentSavingsPer = 0;
            let GMonthPrice = 0;
            let GAnnualPrice = 0;
            let sumfirstrowcv = 0;
            let sumlastrowcv = 0;
            summryrow++;
            sumfirstrowcv = summryrow;
            if (ss.BBProdName === "Broadband") {
              worksheet.getCell("A" + summryrow).value = "Broadband";
              worksheet.getCell("C" + summryrow).value = ss.BBQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(
                ss.BBMT,
                true
              );
              ss.BBAT = ss.BBMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat( ss.BBAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat( ss.BBCMT,true);
                ss.BBCAT = ss.BBCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.BBCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.BBCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.BBCSP,true);
              }
              summryrow++;
            }
            if (ss.DIAProdName === "DIA") {
              worksheet.getCell("A" + summryrow).value = "DIA";
              worksheet.getCell("C" + summryrow).value = ss.DIAQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.DIAMT,true);
              ss.DIAAT = ss.DIAMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.DIAAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.DAICMT,true);
                ss.DIACAT = ss.DAICMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.DIACAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.DAICSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.DIACSP,true);
              }
              summryrow++;
            }
            if (ss.EPIKProdName === "EPIK") {
              worksheet.getCell("A" + summryrow).value = "EPIK";
              worksheet.getCell("C" + summryrow).value = ss.EPIKQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EPIKMT,true);
              ss.EPIKAT = ss.EPIKMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EPIKAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EPIKCMT,true);
                ss.EPIKCAT = ss.EPIKCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EPIKCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EPIKCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EPIKCSP,true);
              }
              summryrow++;
            }
            if (ss.EquipmentProdName === "Equipment") {
              worksheet.getCell("A" + summryrow).value = "Equipment";
              worksheet.getCell("C" + summryrow).value = ss.EquipmentQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EQUIPMT,true);
              ss.EQUIPAT = ss.EQUIPMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EQUIPAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EQUIPCMT,true);
                ss.EQUIPCAT = ss.EQUIPCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EQUIPCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EQUIPCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EQUIPCSP,true);
              }
              summryrow++;
            }
            if (ss.GSEProdName === "GSE") {
              worksheet.getCell("A" + summryrow).value = "GSE";
              worksheet.getCell("C" + summryrow).value = ss.GSEQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.GSEMT,true);
              ss.GSEAT = ss.GSEMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.GSEAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.GSECMT,true);
                ss.GSECAT = ss.GSECMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.GSECAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.GSECSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.GSECSP,true);
              }
              summryrow++;
            }
            if (ss.GRIDProdName === "GRID") {
              worksheet.getCell("A" + summryrow).value = "GRID";
              worksheet.getCell("C" + summryrow).value = ss.GRIDQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.GRIDMT,true);
              ss.GRIDAT = ss.GRIDMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.GRIDAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.GRIDCMT,true);
                ss.GRIDCAT = ss.GRIDCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.GRIDCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.GRIDCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.GRIDCSP,true);
              }
              summryrow++;
            }
            if (ss.GDNProdName === "Guardian") {
              worksheet.getCell("A" + summryrow).value = "Guardian";
              worksheet.getCell("C" + summryrow).value = ss.GDNQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.GDNMT,true);
              ss.GDNAT = ss.GDNMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.GDNAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.GDNCMT,true);
                ss.GDNCAT = ss.GDNCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.GDNCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.GDNCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.GDNCSP,true);
              }
              summryrow++;
            }
            if (ss.PIPProdName === "PIP") {
              worksheet.getCell("A" + summryrow).value = "PIP";
              worksheet.getCell("C" + summryrow).value = ss.PIPQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.PIPMT,true);
              ss.PIPAT = ss.PIPMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.PIPAT,true
              );
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.PIPCMT,true
                );
                ss.PIPCAT = ss.PIPCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.PIPCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.PIPCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.PIPCSP,true);
              }
              summryrow++;
            }
            if (ss.POTSProdName === "POTS") {
              worksheet.getCell("A" + summryrow).value = "POTS";
              worksheet.getCell("C" + summryrow).value = ss.POTSQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.POTSMT,true);
              ss.POTSAT = ss.POTSMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.POTSAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.POTCMT,true);
                ss.POTCAT = ss.POTCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.POTCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.POTCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.POTCSP,true);
              }
              summryrow++;
            }
            if (ss.EPOTSProdName === "ePOTS") {
              worksheet.getCell("A" + summryrow).value = "ePOTS";
              worksheet.getCell("C" + summryrow).value = ss.EPOTSQty;
              worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EPOTSMT,true);
              ss.EPOTSAT = ss.EPOTSMT * 12;
              worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EPOTSAT,true);
              if (comparisionflag === false) {
                worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EPOTCMT,true);
                ss.EPOTCAT = ss.EPOTCMT * 12;
                worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EPOTCAT,true);
                worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EPOTCSD,true);
                worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EPOTCSP,true);
              }
              summryrow++;
            }
            sumlastrowcv = summryrow;
            for (let i = sumfirstrowcv; i <= sumlastrowcv; i++) {
              ["A" + i,"C" + i,"E" + i,"H" + i,"A" + i + ":" + "B" + i,"C" + i + ":" + "D" + i,"E" + i + ":" + "G" + i,
                "H" + i + ":" + "J" + i,"K" + i + ":" + "M" + i,"N" + i + ":" + "P" + i,"Q" + i + ":" + "S" + i,"T" + i + ":" + "V" + i].map((key) => {
                if (key === "A" + i) {
                  worksheet.getCell(key).font = {
                    color: { argb: "000000" },
                    size: 10,
                    bold: true};
                }
                if (key === "C" + i || key === "E" + i || key === "H" + i || key === "K" + i + ":" + "M" + i ||
                  key === "N" + i + ":" + "P" + i || key === "Q" + i + ":" + "S" + i || key === "T" + i + ":" + "V" + i) {
                  worksheet.getCell(key).font = {
                    color: { argb: "000000" },
                    size: 10,
                    bold: false
                  };
                }
                worksheet.getCell(key).alignment = {
                  vertical: "middle",
                  horizontal: "center"
                };
                if (key === "A" + i + ":" + "B" + i || key === "C" + i + ":" + "D" + i || key === "E" + i + ":" + "G" + i ||
                  key === "H" + i + ":" + "J" + i || key === "K" + i + ":" + "M" + i || key === "N" + i + ":" + "P" + i || key === "Q" + i + ":" + "S" + i ||
                  key === "T" + i + ":" + "V" + i) {
                  worksheet.mergeCells(key);
                }
              });
            }
            totQty += Number(ss.BBQty) + Number(ss.DIAQty) + Number(ss.EPIKQty) + Number(ss.EquipmentQty) + Number(ss.GSEQty) + Number(ss.GRIDQty) + Number(ss.GDNQty) + Number(ss.PIPQty) + Number(ss.POTSQty)+ Number(ss.EPOTSQty);
            totGraMonthPrice += Number(ss.BBMT) + Number(ss.DIAMT) + Number(ss.EPIKMT) + Number(ss.EQUIPMT) + Number(ss.GSEMT) + Number(ss.GRIDMT) + Number(ss.GDNMT) + Number(ss.PIPMT) + Number(ss.POTSMT)+ Number(ss.EPOTSMT);
            totHGraAnnuPrice += Number(ss.BBAT) + Number(ss.DIAAT) + Number(ss.EPIKAT) + Number(ss.EQUIPAT) + Number(ss.GSEAT) + Number(ss.GRIDAT) + Number(ss.GDNAT) + Number(ss.PIPAT) + Number(ss.POTSAT) + Number(ss.EPOTSAT);
            CurrentMonthlyTotal += Number(ss.BBCMT) + Number(ss.DAICMT) + Number(ss.EPIKCMT) + Number(ss.EQUIPCMT) + Number(ss.GSECMT) + Number(ss.GRIDCMT) + Number(ss.GDNCMT) + Number(ss.PIPCMT) + Number(ss.POTCMT)+ Number(ss.EPOTCMT);
            CurrentAnnualTotal += Number(ss.BBCAT) + Number(ss.DIACAT) +Number(ss.EPIKCAT) + Number(ss.EQUIPCAT) +Number(ss.GSECAT) + Number(ss.GRIDCAT) + Number(ss.GDNCAT) + Number(ss.PIPCAT) + Number(ss.POTCAT)+ Number(ss.EPOTCAT);
            CurrentSavingsDol += Number(ss.BBCSD) + Number(ss.DAICSD) + Number(ss.EPIKCSD) + Number(ss.EQUIPCSD) + Number(ss.GSECSD) + Number(ss.GRIDCSD) + Number(ss.GDNCSD) + Number(ss.PIPCSD) + Number(ss.POTCSD)+ Number(ss.EPOTCSD);
            CurrentSavingsPer += Number(ss.BBCSP) + Number(ss.DIACSP) + Number(ss.EPIKCSP) + Number(ss.EQUIPCSP) + Number(ss.GSECSP) + Number(ss.GRIDCSP) + Number(ss.GDNCSP) + Number(ss.PIPCSP) + Number(ss.POTCSP) + Number(ss.EPOTCSP);
            worksheet.getCell("A" + summryrow).value = "Total";
            worksheet.getCell("C" + summryrow).value = totQty;
            worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(totGraMonthPrice,true);
            worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(totHGraAnnuPrice,true);
            worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(CurrentMonthlyTotal,true);
            worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(CurrentAnnualTotal,true);
            worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(CurrentSavingsDol,true);
            worksheet.getCell("T" + summryrow).value = getpercentagefarmat(CurrentSavingsPer,true);
            if (comparisionflag === true) {
              ["K" + summryrow,"N" + summryrow,"Q" + summryrow,"T" + summryrow].map((key) => {
                worksheet.getCell(key).value = "";
              });
              ["P","Q","R","AE","AF","AG","AP","AQ","AR","AY","AZ","BA","BL","BM","BN","BW","BX","BY","CF","CH","CG","CP","CQ",
                "CR","DA","DB","DC","DO","DP","DQ"].map((key) => {
                const dynNonComparcol = dynamicsheet.getColumn(key);
                dynNonComparcol.hidden = true;
              });
            }
            indexcount = summryrow + 2;
            if (objNRC.EquipProdName === "Equip") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "Equipment";
              dynamicsheet.getCell("F" + statrowcount).value = "Modem $199.99 1 year cost will be loaded as an NRC";
              ["A" + statrowcount, "F" + statrowcount].map((key) => {
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
                formatCellBold(dynamicsheet, key, "000000", 10);
                if (key === "F" + statrowcount)
                  dynamicsheet.getCell(key).alignment = { wrapText: true };
              });
            }
            if (objNRC.BBProdName === "Broadband") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "Broadband";
              dynamicsheet.getCell("B" + statrowcount).value = "";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.BBQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.BBTTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.DIAProdName === "DIA") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "DIA";
              dynamicsheet.getCell("B" + statrowcount).value = objNRC.DIAAccessType;
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.DIAQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.DIATTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.EPIKProdName === "EPIK") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "EPIK";
              dynamicsheet.getCell("B" + statrowcount).value = "";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.EPIKQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.EPIKTTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (ss.EquipmentProdName === "Equipment") {
              const NRCMAP = new Map();
              const NRCqtyMAP = new Map();
              const NRCcelMap = new Map();
              const NRCvalMAP = new Map();
              for (const [index, [key, value]] of Object.entries(
                Object.entries(qlocOp))) {
                for (let p = 0; p < value.length; p++) {
                  if (value[p].Quote_Option_Item__r.Billing_Type__c === "NRC") {
                    objNRC.EquipmentQty = objNRC.EquipmentQty + parseInt(value[p].Quote_Option_Item__r.Quantiy__c);
                    objNRC.EquipmentTTNRC = objNRC.EquipmentTTNRC + Number(value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c);
                  if (NRCMAP.has(value[p].Quote_Option_Item__r.Product_Code__c? value[p].Quote_Option_Item__r.Product_Code__c: "")
                    ) {
                      let temcel = NRCMAP.get(value[p].Quote_Option_Item__r.Product_Code__c);
                      let existqty = NRCqtyMAP.get(value[p].Quote_Option_Item__r.Product_Code__c);
                      let aval = existqty ? parseInt(existqty) : 0;console.log(p + "aval:", aval);
                      let bval = value[p].Quote_Option_Item__r.Quantiy__c? parseInt(value[p].Quote_Option_Item__r.Quantiy__c): 0;
                      console.log(p + "bval:", bval);
                      dynamicsheet.getCell(temcel).value = aval + bval;
                      let temNRCTTcel = NRCcelMap.get(value[p].Quote_Option_Item__r.Product_Code__c? value[p].Quote_Option_Item__r.Product_Code__c: "");
                      let existnrcval = NRCvalMAP.get(value[p].Quote_Option_Item__r.Product_Code__c? value[p].Quote_Option_Item__r.Product_Code__c: "");
                      let tempnrcval = existnrcval ? parseInt(existnrcval) : 0;
                      let tempequipval = value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c ? parseInt(value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c) : 0;
                      if (
                        value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
                        dynamicsheet.getCell(temNRCTTcel).value = getCurrencyfarmat(tempnrcval + tempequipval);
                        NRCvalMAP.set(value[p].Quote_Option_Item__r.Product_Code__c? value[p].Quote_Option_Item__r.Product_Code__c : "", tempnrcval + tempequipval);
                      }
                      NRCqtyMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", aval + bval );
                    } else {
                      statrowcount++;
                      dynamicsheet.getCell("A" + statrowcount).value = "Equipment";
                      dynamicsheet.getCell("B" + statrowcount).value = "";
                      dynamicsheet.getCell("C" + statrowcount).value = value[p].Quote_Option_Item__r.Quantiy__c;
                      dynamicsheet.getCell("D" + statrowcount).value = value[p].Quote_Option_Item__r.Product_Description__c;
                      dynamicsheet.getCell("E" + statrowcount).value = value[p].Quote_Option_Item__r.Product_Code__c;
                      if (
                        value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0
                      ) {
                        dynamicsheet.getCell("F" + statrowcount).value = value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c;
                      }
                      let temrowcount = "C" + statrowcount; let temTTNRcount = "F" + statrowcount;
                      NRCMAP.set( value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c: "",temrowcount);
                      NRCqtyMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c: "",value[p].Quote_Option_Item__r.Quantiy__c);
                      NRCcelMap.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c: "",temTTNRcount);
                      if (
                        value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
                        NRCvalMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c: "",value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c);}
                    }
                    ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                      formatCellBold(dynamicsheet, key, "000000", 10);
                      dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
                    });
                  }}
              }}
            if (objNRC.GSEProdName === "GSE") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "GSE";
              dynamicsheet.getCell("B" + statrowcount).value = objNRC.GSEAccessType;
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.GSEQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GSETTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.GRIDProdName === "GRID") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "GRID";
              dynamicsheet.getCell("B" + statrowcount).value = "";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.GRIDQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GRIDTTNRC);
              [ "A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.GDNProdName === "Guardian") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "Guardian";
              dynamicsheet.getCell("B" + statrowcount).value = "";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.GDNQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GDNTTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.PIPProdName === "PIP") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "PIP";
              dynamicsheet.getCell("B" + statrowcount).value = objNRC.PIPAccessType;
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.PIPQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.PIPTTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.POTSProdName === "POTS") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "POTS";
              dynamicsheet.getCell("B" + statrowcount).value = "";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.POTSQty;
              dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.POTSTTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            if (objNRC.POTSProdName === "ePOTS") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "ePOTS";
              dynamicsheet.getCell("B" + statrowcount).value = "";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.POTSQty;
              dynamicsheet.getCell("D" + statrowcount).value = "";
              dynamicsheet.getCell("E" + statrowcount).value = "";
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.ePOTSTTNRC);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            objNRC.TTNRCQty = objNRC.BBQty + objNRC.DIAQty + objNRC.EPIKQty + objNRC.EquipmentQty + objNRC.GSEQty + objNRC.GRIDQty +objNRC.GDNQty + objNRC.PIPQty + objNRC.POTSQty + objNRC.EPOTSQty;
            objNRC.TTNRCCost = objNRC.BBTTNRC + objNRC.DIATTNRC + objNRC.EPIKTTNRC + objNRC.EquipmentTTNRC + objNRC.GSETTNRC + objNRC.GRIDTTNRC + objNRC.GDNTTNRC + objNRC.PIPTTNRC + objNRC.POTSTTNRC + objNRC.ePOTSTTNRC;
            if (objNRC.ProdName === "Total") {
              statrowcount++;
              dynamicsheet.getCell("A" + statrowcount).value = "Total";
              dynamicsheet.getCell("C" + statrowcount).value = objNRC.TTNRCQty;
              dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.TTNRCCost);
              ["A" + statrowcount,"B" + statrowcount,"C" + statrowcount,"D" + statrowcount,"E" + statrowcount,"F" + statrowcount].map((key) => {
                formatCellBold(dynamicsheet, key, "000000", 10);
                dynamicsheet.getCell(key).alignment = {vertical: "middle",horizontal: "center"};
              });
            }
            footertext(statrowcount,dynamicsheet,surchargeflag,EPIKflag,EPIKWholesaleflag,POTSflag,POTSproductTypeflag,POTSproductTypeLocalLDflag,DIAflag,BBflag,GSEPIPflag,GRIDflag,Mobilityflag,VoIPflag);
          }
          setSummary(summryrow);
        })
        .catch((error) => {
          console.log("errror", error);
          errorKey = error;
        });
}
*/