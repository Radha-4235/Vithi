import getLocations from "@salesforce/apex/ExportCSVController.getQuoteLocations";
import { getCurrencyfarmat, formatCell, formatQuoteOptionTableHeaders, formatCellBold, formatCellwithBold, summarysect, nrcSection, footertext, getpercentagefarmat, uniqueBy, countStrings } from "./exportquoteoptions1";
import getOptionItemSer from "@salesforce/apex/ExportCSVController.getOptionItemServices";
import Exportquoteoptions from "./exportquoteoptions";
import { LightningElement, track } from "lwc";
var indexcount = 6;
var tempIterateCount;
export async function getLocationsExcel(quoteOptionId, dynamicsheet, worksheetvisibleflag, worksheet, quoteoptions, i, summryrow, setSummary, errorKey, totalLength, isA3SplPricingUser, isfilterclosedwon) {
  await getLocations({ ListofQOIDs: quoteOptionId, isfilterclosedwon: isfilterclosedwon })
    .then(async (result) => {
      if (result) {
        let qlocOp = result;
        let statrowcount;
        var EPIKflag = false;
        var EPIKWholesaleflag = false;
        var POTSflag = false;
        var DIAflag = false;
        var BBflag = false;
        var GSEPIPflag = false;
        var GRIDflag = false;
        var Mobilityflag = false;
        var mobilitywirelessflag = false;
        var surchargeflag = false;
        var POTSproductTypeflag = false;
        var VoIPflag = false;
        var SHVoIPflag = false;
        var SHVoIPflagsur = false;
        var ocMflag = false;
        var vocflagl = false;
        var vocFlagsur = false;
        var vocFlagNosur = false;
        var POTSproductTypeLocalLDflag = false;
        var GMonthlyPrice = 0;
        var GAnnuallyPrice = 0;
        var MonthlySavings = 0;
        var Monthsav = 0;
        var AvgSavings = 0;
        var servicefirstval = 0;
        var avgspendpersite = 0; var qlocsize = 0;
        var comparisionflag = false;
        var MobilitySMflag = false;
        var stroagoption = [];
        var modelHpbx = [];
        var equipQty = [];
        var hpbxRate = [];
        var disEquip = [];
        var bNrc = false;
        var MobilitySMNOflag = false;
        var edgebootyes = false;
        var edgebootno = false;
        var objNRC = {};
        objNRC.EquipProdName;
        objNRC.BBProdName;
        objNRC.BBModel;
        objNRC.BBQty = 0;
        objNRC.BBTTNRC = 0;
        objNRC.BBNRCDes;
        objNRC.BBAccessType;
        objNRC.DIAProdName;
        objNRC.DIAModel;
        objNRC.DIAQty = 0;
        objNRC.DIATTNRC = 0;
        objNRC.DIANRCDes;
        objNRC.DIAAccessType;
        objNRC.EPIKProdName;
        objNRC.EPIKModel;
        objNRC.EPIKQty = 0;
        objNRC.EPIKTTNRC = 0;
        objNRC.EPIKNRCDes;
        objNRC.EPIKAccessType;
        objNRC.EquipmentProdName;
        objNRC.EquipmentModel;
        objNRC.EquipmentQty = 0;
        objNRC.EquipmentTTNRC = 0;
        objNRC.EquipmentNRCDes;
        objNRC.EquipmentAccessType;
        objNRC.GSEProdName;
        objNRC.GSEModel;
        objNRC.GSEQty = 0;
        objNRC.GSETTNRC = 0;
        objNRC.GSENRCDes;
        objNRC.GSEAccessType;
        objNRC.GRIDProdName;
        objNRC.GRIDModel;
        objNRC.GRIDQty = 0;
        objNRC.SIgridNQty = 0;
        objNRC.GRIDTTNRC = 0;
        objNRC.GRIDNRCDes = [];
        objNRC.GRIDNRCTCDes = [];
        objNRC.GRIDAccessType;
        objNRC.GDNTIProdName;
        objNRC.GDNACProdName;
        objNRC.GDNProdName;
        objNRC.GDNModel;
        objNRC.GDNQty = 0;
        objNRC.GDNCQty = 0;
        objNRC.GDNTIQty = 0;
        objNRC.GDNTTNRC = 0;
        objNRC.GDNCTTNRC = 0;
        objNRC.GDNTITTNRC = 0;
        objNRC.GDNNRCDes;
        objNRC.GDNAccessType = [];
        objNRC.MOBIProdName;
        objNRC.MOBIModel;
        objNRC.MOBIQty = 0;
        objNRC.MOBITTNRC = 0;
        objNRC.MOBINRCDes;
        objNRC.MOBIAccessType;
        objNRC.PIPProdName;
        objNRC.PIPModel;
        objNRC.PIPQty = 0;
        objNRC.PIPTTNRC = 0;
        objNRC.PIPNRCDes;
        objNRC.PIPAccessType;
        objNRC.POTSProdName;
        objNRC.POTSModel;
        objNRC.POTSQty = 0;
        objNRC.POTSTTNRC = 0;
        objNRC.POTSNRCDes;
        objNRC.POTSAccessType;
        objNRC.EPOTSProdName;
        objNRC.EPOTSModel;
        objNRC.EPOTSQty = 0;
        objNRC.EPOTSTTNRC = 0;
        objNRC.EPOTSNRCDes;
        objNRC.EPOTSAccessType;
        objNRC.VOIPProdName;
        objNRC.VOIPHProdName;
        objNRC.VOIPModel;
        objNRC.VOIPQty = 0;
        objNRC.VOIPTTTNRC = 0;
        objNRC.VOIPTTNRC = [];
        objNRC.VOIPNRCDes;
        objNRC.VOIPAccessType;
        objNRC.VOIPSIPProdName;
        objNRC.VOIPSIPModel;
        objNRC.VOIPSIPQty = 0;
        objNRC.VOIPSIPTTNRC = 0;
        objNRC.VOIPSIPNRCDes;
        objNRC.VOIPSIPAccessType;
        objNRC.VOCProdName;
        objNRC.VOCModel;
        objNRC.VOCQty = 0;
        objNRC.VOCTTNRC = 0;
        objNRC.VOCNRCDes;
        objNRC.VOCAccessType;
        objNRC.EDGEProdName;
        objNRC.EDGEModel;
        objNRC.EDGEQty = 0;
        objNRC.EDGETTNRC = 0;
        objNRC.EDGENRCDes;
        objNRC.EDGEAccessType;
        objNRC.ProdName = "Total";
        objNRC.TTNRCQty = 0;
        objNRC.TTNRCCost = 0;
        var ss = {};
        ss.BBProdName;
        ss.BBQty = 0;
        ss.BBMT = 0;
        ss.BBAT = 0;
        ss.BBCMT = 0;
        ss.BBCAT = 0;
        ss.BBCSD = 0;
        ss.BBCSP = 0;
        ss.DIAProdName;
        ss.DIAQty = 0;
        ss.DIAMT = 0;
        ss.DIAAT = 0;
        ss.DAICMT = 0;
        ss.DIACAT = 0;
        ss.DAICSD = 0;
        ss.DIACSP = 0;
        ss.EPIKProdName;
        ss.EPIKQty = 0;
        ss.EPIKMT = 0;
        ss.EPIKAT = 0;
        ss.EPIKCMT = 0;
        ss.EPIKCAT = 0;
        ss.EPIKCSD = 0;
        ss.EPIKCSP = 0;
        ss.EquipmentProdName;
        ss.EquipmentQty = 0;
        ss.EQUIPMT = 0;
        ss.EQUIPAT = 0;
        ss.EQUIPCMT = 0;
        ss.EQUIPCAT = 0;
        ss.EQUIPCSD = 0;
        ss.EQUIPCSP = 0;
        ss.GSEProdName;
        ss.GSEQty = 0;
        ss.GSEMT = 0;
        ss.GSEAT = 0;
        ss.GSECMT = 0;
        ss.GSECAT = 0;
        ss.GSECSD = 0;
        ss.GSECSP = 0;
        ss.GRIDProdName;
        ss.GRIDQty = 0;
        ss.GRIDMT = 0;
        ss.GRIDAT = 0;
        ss.GRIDCMT = 0;
        ss.GRIDCAT = 0;
        ss.GRIDCSD = 0;
        ss.GRIDCSP = 0;
        ss.GDNProdName;
        ss.GDNQty = 0;
        ss.GDNMT = 0;
        ss.GDNAT = 0;
        ss.GDNCMT = 0;
        ss.GDNCAT = 0;
        ss.GDNCSD = 0;
        ss.GDNCSP = 0;
        ss.MOBIProdName;
        ss.MOBIQty = 0;
        ss.MOBIMT = 0;
        ss.MOBIAT = 0;
        ss.MOBICMT = 0;
        ss.MOBICAT = 0;
        ss.MOBICSD = 0;
        ss.MOBICSP = 0;
        ss.OCTProdName;
        ss.OCTQty = 0;
        ss.OCTMT = 0;
        ss.OCTAT = 0;
        ss.OCTCMT = 0;
        ss.OCTCAT = 0;
        ss.OCTCSD = 0;
        ss.OCTCSP = 0;
        ss.PIPProdName;
        ss.PIPQty = 0;
        ss.PIPMT = 0;
        ss.PIPAT = 0;
        ss.PIPCMT = 0;
        ss.PIPCAT = 0;
        ss.PIPCSD = 0;
        ss.PIPCSP = 0;
        ss.POTSProdName;
        ss.POTSQty = 0;
        ss.POTSMT = 0;
        ss.POTSAT = 0;
        ss.POTCMT = 0;
        ss.POTCAT = 0;
        ss.POTCSD = 0;
        ss.POTCSP = 0;
        ss.EPOTSProdName;
        ss.EPOTSQty = 0;
        ss.EPOTSMT = 0;
        ss.EPOTSAT = 0;
        ss.EPOTCMT = 0;
        ss.EPOTCAT = 0;
        ss.EPOTCSD = 0;
        ss.EPOTCSP = 0;
        ss.VOIPProdName;
        ss.VOIPQty = 0;
        ss.VOIPMT = 0;
        ss.VOIPAT = 0;
        ss.VOIPCMT = 0;
        ss.VOIPCAT = 0;
        ss.VOIPCSD = 0;
        ss.VOIPCSP = 0;
        ss.VOIPSIPProdName;
        ss.VOIPSIPQty = 0;
        ss.VOIPSIPMT = 0;
        ss.VOIPSIPAT = 0;
        ss.VOIPSIPCMT = 0;
        ss.VOIPSIPCAT = 0;
        ss.VOIPSIPCSD = 0;
        ss.VOIPSIPCSP = 0;
        ss.VOCProdName;
        ss.VOCQty = 0;
        ss.VOCMT = 0;
        ss.VOCAT = 0;
        ss.VOCCMT = 0;
        ss.VOCCAT = 0;
        ss.VOCCSD = 0;
        ss.VOCCSP = 0;
        ss.EDGEProdName;
        ss.EDGEQty = 0;
        ss.EDGEMT = 0;
        ss.EDGEAT = 0;
        ss.EDGECMT = 0;
        ss.EDGECAT = 0;
        ss.EDGECSD = 0;
        ss.EDGECSP = 0;
        var hpbxqty = 0;
        var voipTn = 0;
        for (const [index, [key, value]] of Object.entries(Object.entries(qlocOp))) {
          let rowcount = +8 + +index;
          console.log("rowcount:", rowcount);
          var BBCurnttotalMRC = 0;
          var DIACurnttotalMRC = 0;
          var EPIKCurnttotalMRC = 0;
          var EquipmentCurnttotalMRC = 0;
          var GSECurnttotalMRC = 0;
          var GRIDCurnttotalMRC = 0;
          var GuradianCurnttotalMRC = 0;
          var MobalityCurnttotalMRC = 0;
          var PIPCurnttotalMRC = 0;
          var POTSCurnttotalMRC = 0;
          var EPOTSCurnttotalMRC = 0;
          var VOIPCurnttotalMRC = 0;
          var VOCCurnttotalMRC = 0;
          var EDGECurnttotalMRC = 0;
          var CurnttotalMRC = 0;
          var CurnttotalsitesavingsDol = 0;
          var CurnttotalsitesavingsPer = 0;
          qlocsize++;
          const hidesecsim = dynamicsheet.getColumn("ER");
          const hidesecsin = dynamicsheet.getColumn("ES");
          const hidesecsio = dynamicsheet.getColumn("ET");
          const hidestrgoption = dynamicsheet.getColumn("GZ");
          const hidePort = dynamicsheet.getColumn("AS"); hidePort.hidden = true;
          const hideUser = dynamicsheet.getColumn("GO"); hideUser.hidden = true;
          var BBTotalMRC = 0;
          var DIATotalMRC = 0;
          var EPIKTotalMRC = 0;
          var EquipmentTotalMRC = 0;
          var GSETotalMRC = 0;
          var GRIDTotalMRC = 0;
          var GuardianTotalMRC = 0;
          var MobilityTotalMRC = 0;
          var PIPTotalMRC = 0;
          var POTSTotalMRC = 0;
          var EPOTSTotalMRC = 0;
          var VOIPTotalMRC = 0;
          var VOCTotalMRC = 0;
          var EDGETotalMRC = 0;
          var TotalSiteMRC = 0;
          var productArr=[];
          for (let p = 0; p < value.length; p++) {
            productArr.push(value[p].Quote_Option_Item__r.Name);
            if (value[p].Quote_Option_Item__r.Billing_Type__c === "NRC") {
              const NRCRow = dynamicsheet.getRow(rowcount);
              NRCRow.hidden = true;
            }
            if (value[p].Quote_Option_Item__r.Billing_Type__c != "NRC") {
              dynamicsheet.getCell("A" + rowcount).value = value[p].Quote_Request_Location__r.LocationStore_Number__c != null ? value[p].Quote_Request_Location__r.LocationStore_Number__c : "";
              dynamicsheet.getCell("B" + rowcount).value = value[p].Quote_Request_Location__r.Address__c != null ? value[p].Quote_Request_Location__r.Address__c : "";
              if (value[p].Quote_Request_Location__r.BuildingApt__c || value[p].Quote_Request_Location__r.FloorSuite__c) {
                let bApp = value[p].Quote_Request_Location__r.BuildingApt__c != null ? value[p].Quote_Request_Location__r.BuildingApt__c : "";
                let fSuite = value[p].Quote_Request_Location__r.FloorSuite__c != null ? value[p].Quote_Request_Location__r.FloorSuite__c : "";
                dynamicsheet.getCell("C" + rowcount).value = bApp.concat(" ", fSuite)
              }
              dynamicsheet.getCell("D" + rowcount).value = value[p].Quote_Request_Location__r.City__c != null ? value[p].Quote_Request_Location__r.City__c : "";
              dynamicsheet.getCell("E" + rowcount).value = value[p].Quote_Request_Location__r.State__c != null ? value[p].Quote_Request_Location__r.State__c : "";
              dynamicsheet.getCell("F" + rowcount).value = value[p].Quote_Request_Location__r.Zip__c != null ? value[p].Quote_Request_Location__r.Zip__c : "";
            }

            if (value[p].Quote_Option_Item__r.Name === "Broadband") {
              BBflag = true;
              dynamicsheet.getCell("G" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("H" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
              dynamicsheet.getCell("L" + rowcount).value = value[p].Quote_Option_Item__r.IP_Type__c != null ? value[p].Quote_Option_Item__r.IP_Type__c : "";
              dynamicsheet.getCell("M" + rowcount).value = value[p].Quote_Option_Item__r.Ip_Block__c != null ? value[p].Quote_Option_Item__r.Ip_Block__c : "";
              let AddonEdgebootfeature = [];
              let qqoptionitemser = await getOptionItemSer({ QOIId: value[p].Quote_Option_Item__r.Id });
              if (qqoptionitemser) {
                for (var h = 0; h < qqoptionitemser.length; h++) {
                  if (qqoptionitemser[h].Child_Quote_item_Product_Type__c === "AddonEdgeboot") {
                    AddonEdgebootfeature.push(qqoptionitemser[h].Name);
                  }
                }
                if (AddonEdgebootfeature.length > 0) {
                  let bbFe = AddonEdgebootfeature.join(", ");
                  dynamicsheet.getCell("Q" + rowcount).value = bbFe;
                }
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("I" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                let dSpeed = value[p].Quote_Request_Rates__r[0].Download_Speed__c != null ? value[p].Quote_Request_Rates__r[0].Download_Speed__c : "";
                let uSpeed = value[p].Quote_Request_Rates__r[0].Upload_Speed__c != null ? value[p].Quote_Request_Rates__r[0].Upload_Speed__c : "";
                dynamicsheet.getCell("J" + rowcount).value = "(" + dSpeed.concat("/", uSpeed) + ")";
                dynamicsheet.getCell("T" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("U" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("V" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                dynamicsheet.getCell("K" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("N" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].IP_MRC_Rate__c);
                dynamicsheet.getCell("O" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                dynamicsheet.getCell("R" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Add_On_Service_MRC__c);
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("P" + rowcount).value = "";
                  surchargeflag = true;
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("P" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                }
                dynamicsheet.getCell("S" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                BBTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                BBCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                dynamicsheet.getCell("K" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("N" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("O" + rowcount).value = getCurrencyfarmat();
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("P" + rowcount).value = "";
                  surchargeflag = true;
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("P" + rowcount).value = getCurrencyfarmat();
                }
                dynamicsheet.getCell("S" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.BBProdName = "Broadband";
                  objNRC.BBQty = objNRC.BBQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  objNRC.BBTTNRC = objNRC.BBTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.BBProdName = "Broadband";
              ss.BBQty = ss.BBQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.BBMT = ss.BBMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.BBCMT = ss.BBCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.BBCSD = ss.BBCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.BBCSP = ss.BBCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "DIA") {
              DIAflag = true;
              let AddonEdgebootdiafeature = [];
              let qqoptionitemser = await getOptionItemSer({ QOIId: value[p].Quote_Option_Item__r.Id });
              if (qqoptionitemser) {
                for (var h = 0; h < qqoptionitemser.length; h++) {
                  if (qqoptionitemser[h].Child_Quote_item_Product_Type__c === "AddonEdgeboot") {
                    AddonEdgebootdiafeature.push(qqoptionitemser[h].Name);
                  }
                }
                if (AddonEdgebootdiafeature.length > 0) {
                  let diaFe = AddonEdgebootdiafeature.join(", ");
                  dynamicsheet.getCell("AI" + rowcount).value = diaFe;
                }
              }
              dynamicsheet.getCell("W" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("X" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null ? value[p].Quote_Option_Item__r.Contract_Term__c : "";
              dynamicsheet.getCell("Z" + rowcount).value = value[p].Quote_Option_Item__r.Access_Type__c != null ? value[p].Quote_Option_Item__r.Access_Type__c : "";
              dynamicsheet.getCell("AA" + rowcount).value = value[p].Quote_Option_Item__r.Speed__c != null ? value[p].Quote_Option_Item__r.Speed__c : "";
              dynamicsheet.getCell("AD" + rowcount).value = value[p].Quote_Option_Item__r.ProductCode_Description__c != null ? value[p].Quote_Option_Item__r.ProductCode_Description__c : "";
              dynamicsheet.getCell("AF" + rowcount).value = value[p].Quote_Option_Item__r.Router_Added__c != null ? value[p].Quote_Option_Item__r.Router_Added__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("Y" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("AB" + rowcount).value = value[p].Quote_Request_Rates__r[0].Building_Status__c != null ? value[p].Quote_Request_Rates__r[0].Building_Status__c : "";
                dynamicsheet.getCell("AL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("AM" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("AN" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                dynamicsheet.getCell("AC" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("AE" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].IP_MRC_Rate__c);
                dynamicsheet.getCell("AG" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                dynamicsheet.getCell("AJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Add_On_Service_MRC__c);
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("AE" + rowcount).value = ""; surchargeflag = true;
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("AH" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                }
                dynamicsheet.getCell("AK" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                DIATotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                DIACurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                dynamicsheet.getCell("AC" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("AE" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("AG" + rowcount).value = getCurrencyfarmat();
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("AE" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("AE" + rowcount).value = getCurrencyfarmat();
                }
                dynamicsheet.getCell("AK" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.DIAProdName = "DIA";
                  objNRC.DIAQty = objNRC.DIAQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  if (objNRC.DIAAccessType != null) {
                    objNRC.DIAAccessType += ";" + value[p].Quote_Option_Item__r.Access_Type__c;
                  } else {
                    objNRC.DIAAccessType = value[p].Quote_Option_Item__r.Access_Type__c;
                  }
                  objNRC.DIATTNRC = objNRC.DIATTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.DIAProdName = "DIA";
              ss.DIAQty = ss.DIAQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.DIAMT = ss.DIAMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.DAICMT = ss.DAICMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.DAICSD = ss.DAICSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.DIACSP = ss.DIACSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            //if(isA3SplPricingUser === "A3_SplPricing_CRE" || isA3SplPricingUser === "A3_OMAnalyst_CRE" || isA3SplPricingUser === "A3_SalesEng_CRE" || isA3SplPricingUser === "A3_ChannelsQuoter_CRE" || isA3SplPricingUser === "A3_OMAnalystManager_CRE" ||   isA3SplPricingUser ==="A3_SalesEngManager_CRE"){
            if (value[p].Quote_Option_Item__r.Name === 'edgeboot') {
              if (value[p].Quote_Option_Item__r.Ip_Block__c === "Yes") {
                var serAct = "SERVICE ACTIVATION";
                edgebootyes = true
              }
              if (value[p].Quote_Option_Item__r.Ip_Block__c === "No") {
                edgebootno = true
              }
              dynamicsheet.getCell("AO" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("AP" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("AQ" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("AR" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("AS" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Port_MRC__c);
                dynamicsheet.getCell("AT" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                dynamicsheet.getCell("AU" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("AV" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("AW" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                EDGETotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                EDGECurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.EDGEProdName = "edgeboot";
                  objNRC.EDGEQty = objNRC.EDGEQty + Number(1);
                  objNRC.EDGETTNRC = objNRC.EDGETTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.EDGEProdName = "edgeboot";
              ss.EDGEQty = ss.EDGEQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.EDGEMT = ss.EDGEMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.EDGECMT = ss.EDGECMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.EDGECSD = ss.EDGECSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.EDGECSP = ss.EDGECSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            //}
            if (value[p].Quote_Option_Item__r.Name === "EPIK") {
              EPIKflag = true;
              dynamicsheet.getCell("AX" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("AY" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null ? value[p].Quote_Option_Item__r.Contract_Term__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("BE" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("BF" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("BG" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                dynamicsheet.getCell("AZ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("BA" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BB" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BC" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BD" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                EPIKTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                EPIKCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                dynamicsheet.getCell("AZ" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BA" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BB" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BC" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("BD" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c === "Wholesale") {
                EPIKWholesaleflag = true;
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.EPIKProdName = "EPIK";
                  objNRC.EPIKQty = objNRC.EPIKQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  objNRC.EPIKTTNRC = objNRC.EPIKTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.EPIKProdName = "EPIK";
              ss.EPIKQty = ss.EPIKQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.EPIKMT = ss.EPIKMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.EPIKCMT = ss.EPIKCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.EPIKCSD = ss.EPIKCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.EPIKCSP = ss.EPIKCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "ePOTS") {
              const hidelocal = dynamicsheet.getColumn("BK"); hidelocal.hidden = true
              const hidelqty = dynamicsheet.getColumn("BL"); hidelqty.hidden = true;
              const hideld = dynamicsheet.getColumn("BM"); hideld.hidden = true;
              const hideldqty = dynamicsheet.getColumn("BN"); hideldqty.hidden = true;
              const hideall = dynamicsheet.getColumn("BO"); hideall.hidden = true;
              const hideallqty = dynamicsheet.getColumn("BP"); hideallqty.hidden = true;
              const hidev = dynamicsheet.getColumn("BQ"); hidev.hidden = true;
              const hidevqty = dynamicsheet.getColumn("BR"); hidevqty.hidden = true;
              const hideeasyqty = dynamicsheet.getColumn("BS"); hideeasyqty.hidden = true;
              const hideeasy = dynamicsheet.getColumn("BT"); hideeasy.hidden = true;
              const hidep = dynamicsheet.getColumn("BU"); hidep.hidden = true;
              const hidepqty = dynamicsheet.getColumn("BV"); hidepqty.hidden = true;
              VoIPflag = true;
              dynamicsheet.getCell("BH" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("BI" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                for (var j = 0; j < value[p].Quote_Request_Rates__r.length; j++) {
                  if (value[p].Quote_Request_Rates__r[j].Parent_QR_Rate__c === true) {
                    dynamicsheet.getCell("BJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Circuit_MRC_Rate1__c);
                    dynamicsheet.getCell("BY" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Surcharge__c);
                    dynamicsheet.getCell("BW" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Feature_MRC__c);
                    dynamicsheet.getCell("BX" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Default_Router_Rate__c);
                    let pta = value[p].Quote_Request_Rates__r[j].PTA__c;
                    let asf = value[p].Quote_Request_Rates__r[j].ASF__c;
                    dynamicsheet.getCell("BZ" + rowcount).value = pta + asf;
                    dynamicsheet.getCell("CA" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Total_MRC__c);
                    dynamicsheet.getCell("CB" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Current_Total__c);
                    dynamicsheet.getCell("CC" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Saving_Amount__c);
                    dynamicsheet.getCell("CD" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[j].Saving_Percentage__c);
                    EPOTSTotalMRC = value[p].Quote_Request_Rates__r[j].Total_MRC__c;
                    EPOTSCurnttotalMRC = value[p].Quote_Request_Rates__r[j].Current_Total__c;
                    if (value[p].Quote_Request_Rates__r[j].Activation_Cost__c) {
                      objNRC.EPOTSProdName = "ePOTS";
                      objNRC.EPOTSQty = objNRC.EPOTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                      objNRC.EPOTSTTNRC = objNRC.EPOTSTTNRC + Number(value[p].Quote_Request_Rates__r[j].Activation_Cost__c);
                    }
                    ss.EPOTSProdName = "ePOTS";
                    ss.EPOTSQty = ss.EPOTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    ss.EPOTSMT = ss.EPOTSMT + Number(value[p].Quote_Request_Rates__r[j].Total_MRC__c);
                    ss.EPOTCMT = ss.EPOTCMT + Number(value[p].Quote_Request_Rates__r[j].Current_Total__c);
                    ss.EPOTCSD = ss.EPOTCSD + Number(value[p].Quote_Request_Rates__r[j].Saving_Amount__c);
                    ss.EPOTCSP = ss.EPOTCSP + Number(value[p].Quote_Request_Rates__r[j].Saving_Percentage__c);
                  }
                  if (value[p].Quote_Request_Rates__r[j].Parent_QR_Rate__c === false) {
                    var field = (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name);
                    if (field.includes("Local Usage Package")) {
                      hidelocal.hidden = false;
                      hidelqty.hidden = false;
                    }
                    if (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name === "Local Usage Package") {
                      dynamicsheet.getCell("BK" + rowcount).value = value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c : 0;
                      dynamicsheet.getCell("BL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Local_Usage_Package__c);
                    }
                    if (field.includes("LD Usage Package")) {
                      hideld.hidden = false;
                      hideldqty.hidden = false;
                    }
                    if (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name === "LD Usage Package") {
                      dynamicsheet.getCell("BM" + rowcount).value = value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c : 0;
                      dynamicsheet.getCell("BN" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].LD_Usage_Package__c); console.log("value[p].Quote_Request_Rates__r[j].LD_Usage_Package__c123", value[p].Quote_Request_Rates__r[j].LD_Usage_Package__c)
                    }
                    if (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name === "All Usage Package") {
                      dynamicsheet.getCell("BO" + rowcount).value = value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c : 0;
                      dynamicsheet.getCell("BP" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].All_Usage_Package__c);
                    }
                    if (field.includes("All Usage Package")) {
                      hideall.hidden = false;
                      hideallqty.hidden = false;
                    }
                    if (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name === "Voicemail") {
                      dynamicsheet.getCell("BQ" + rowcount).value = value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c : 0;
                      dynamicsheet.getCell("BR" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Voicemail__c);
                    }
                    if (field.includes("Voicemail")) {
                      hidev.hidden = false;
                      hidevqty.hidden = false;
                    }
                    if (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name === "Easy AA") {
                      dynamicsheet.getCell("BS" + rowcount).value = value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c : 0;
                      dynamicsheet.getCell("BT" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Easy_AA__c);
                    }
                    if (field.includes("Easy AA")) {
                      hideeasy.hidden = false;
                      hideeasyqty.hidden = false;
                    }
                    if (value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name === "Premium AA") {
                      dynamicsheet.getCell("BU" + rowcount).value = value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c : 0;
                      dynamicsheet.getCell("BV" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Premium_AA__c);
                    }
                    if (field.includes("Premium AA")) {
                      hidepqty.hidden = false;
                      hidep.hidden = false;
                    }
                  }
                }
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "Equipment" && value[p].Quote_Option_Item__r.Billing_Type__c === "MRC") {
              dynamicsheet.getCell("CE" + rowcount).value = value[p].Quote_Option_Item__r.Quantiy__c != null ? value[p].Quote_Option_Item__r.Quantiy__c : 0;
              dynamicsheet.getCell("CF" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null ? value[p].Quote_Option_Item__r.Contract_Term__c : "";
              dynamicsheet.getCell("CG" + rowcount).value = value[p].Quote_Option_Item__r.Vendor__c != null ? value[p].Quote_Option_Item__r.Vendor__c : "";
              dynamicsheet.getCell("CH" + rowcount).value = value[p].Quote_Option_Item__r.Product_Code__c != null ? value[p].Quote_Option_Item__r.Product_Code__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("CI" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                dynamicsheet.getCell("CJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                dynamicsheet.getCell("CK" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("CL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("CM" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                EquipmentTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                EquipmentCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                dynamicsheet.getCell("CI" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("CJ" + rowcount).value = getCurrencyfarmat();
              }
              ss.EquipmentProdName = "Equipment";
              ss.EquipmentQty = ss.EquipmentQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.EQUIPMT = ss.EQUIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                objNRC.EquipmentProdName = "Equipment";
                ss.EQUIPCMT = ss.EQUIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.EQUIPCSD = ss.EQUIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.EQUIPCSP = ss.EQUIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "Equipment" && value[p].Quote_Option_Item__r.Billing_Type__c === "NRC") {
              ss.EquipmentProdName = "Equipment";
              ss.EquipmentQty = ss.EquipmentQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.EQUIPMT = ss.EQUIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.EQUIPCMT = ss.EQUIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.EQUIPCSD = ss.EQUIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.EQUIPCSP = ss.EQUIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "Equipment" && value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c === "Wholesale") {
              objNRC.EquipProdName = "Equip";
            }
            if (value[p].Quote_Option_Item__r.Name === "GRID") {
              GRIDflag = true;
              dynamicsheet.getCell("CN" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("CO" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
              dynamicsheet.getCell("CQ" + rowcount).value = value[p].Quote_Option_Item__r.IP_Type__c != null ? value[p].Quote_Option_Item__r.IP_Type__c : "";
              if (value[p].Quote_Option_Item__r.Ip_Block__c === "1 IP Addresses") {
                dynamicsheet.getCell("CR" + rowcount).value = "/30";
              } else if (value[p].Quote_Option_Item__r.Ip_Block__c === "5 IP Addresses") {
                dynamicsheet.getCell("CR" + rowcount).value = "/29";
              } else if (value[p].Quote_Option_Item__r.Ip_Block__c === "16 IP Addresses") {
                dynamicsheet.getCell("CR" + rowcount).value = "/28";
              } else {
                dynamicsheet.getCell("CR" + rowcount).value = " ";
              }
              if (value[p].Quote_Option_Item__r.Grid_Voice_Package__c === "Grid Voice Package A - Netvanta 3140 - HT812") {
                dynamicsheet.getCell("CS" + rowcount).value = "A";
              } else if (value[p].Quote_Option_Item__r.Grid_Voice_Package__c === "Grid Voice Package B - Netvanta 3140 - HT814") {
                dynamicsheet.getCell("CS" + rowcount).value = "B";
              } else if (value[p].Quote_Option_Item__r.Grid_Voice_Package__c === "Grid Voice Package C - Netvanta 3140 - HT818") {
                dynamicsheet.getCell("CS" + rowcount).value = "C";
              } else if (value[p].Quote_Option_Item__r.Grid_Voice_Package__c === "Grid Voice Package D - Adtran 908.B") {
                dynamicsheet.getCell("CS" + rowcount).value = "D";
              } else if (value[p].Quote_Option_Item__r.Grid_Voice_Package__c === "Grid Voice Package E - Adtran 916.B") {
                dynamicsheet.getCell("CS" + rowcount).value = "E";
              } else dynamicsheet.getCell("CS" + rowcount).value = " - ";

              dynamicsheet.getCell("CV" + rowcount).value = value[p].Quote_Option_Item__r.Minimum_Speed__c != null ? value[p].Quote_Option_Item__r.Minimum_Speed__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("CP" + rowcount).value = value[p].Quote_Request_Rates__r[0].Access_Type__c != null ? value[p].Quote_Request_Rates__r[0].Access_Type__c : "";
                dynamicsheet.getCell("CT" + rowcount).value = value[p].Quote_Request_Rates__r[0].PropertyName__c != null ? value[p].Quote_Request_Rates__r[0].PropertyName__c : "";
                dynamicsheet.getCell("CU" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("CW" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("CX" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].IP_MRC_Rate__c);
                dynamicsheet.getCell("CY" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Voice_MRC__c);
                dynamicsheet.getCell("CZ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                dynamicsheet.getCell("DC" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("DD" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("DE" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("DA" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("DA" + rowcount).value = "";
                }
                dynamicsheet.getCell("DB" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                GRIDTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                GRIDCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.SIgridNQty = objNRC.SIgridNQty + Number(1);
                  objNRC.GRIDProdName = "GRID";
                  objNRC.GRIDQty = objNRC.GRIDQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  objNRC.GRIDTTNRC = objNRC.GRIDTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.GRIDProdName = "GRID";
              ss.GRIDQty = ss.GRIDQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.GRIDMT = ss.GRIDMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.GRIDCMT = ss.GRIDCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.GRIDCSD = ss.GRIDCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.GRIDCSP = ss.GRIDCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "GSE") {
              GSEPIPflag = true;
              dynamicsheet.getCell("DF" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("DG" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null ? value[p].Quote_Option_Item__r.Contract_Term__c : "";
              dynamicsheet.getCell("DI" + rowcount).value = value[p].Quote_Option_Item__r.Access_Type__c != null ? value[p].Quote_Option_Item__r.Access_Type__c : 0;
              dynamicsheet.getCell("DJ" + rowcount).value = value[p].Quote_Option_Item__r.Speed__c != null ? value[p].Quote_Option_Item__r.Speed__c : "";
              dynamicsheet.getCell("DK" + rowcount).value = value[p].Quote_Option_Item__r.Service_Level_Tier__c != null ? value[p].Quote_Option_Item__r.Service_Level_Tier__c : "";
              dynamicsheet.getCell("DN" + rowcount).value = value[p].Quote_Option_Item__r.Service_Level_Tier__c != null ? value[p].Quote_Option_Item__r.Service_Level_Tier__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("DQ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("DR" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("DS" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                dynamicsheet.getCell("DH" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("DL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                if (value[p].Quote_Option_Item__r.Service_Level_Tier__c === "Bronze") {
                  dynamicsheet.getCell("DL" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Service_Level_Tier__c != "Bronze") {
                  dynamicsheet.getCell("DM" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].COS_MRC__c);
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("DO" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("DO" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                }
                dynamicsheet.getCell("DP" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                GSETotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                GSECurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                dynamicsheet.getCell("DM" + rowcount).value = getCurrencyfarmat();
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("DO" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("DO" + rowcount).value = getCurrencyfarmat();
                }
                dynamicsheet.getCell("DP" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.GSEProdName = "GSE";
                  objNRC.GSEQty = objNRC.GSEQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  if (objNRC.GSEAccessType != null) {
                    objNRC.GSEAccessType += ";" + value[p].Quote_Option_Item__r.Access_Type__c;
                  } else {
                    objNRC.GSEAccessType = value[p].Quote_Option_Item__r.Access_Type__c;
                  }
                  objNRC.GSETTNRC = objNRC.GSETTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.GSEProdName = "GSE";
              ss.GSEQty = ss.GSEQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.GSEMT = ss.GSEMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.GSECMT = ss.GSECMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.GSECSD = ss.GSECSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.GSECSP = ss.GSECSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "Guardian") {
              dynamicsheet.getCell("DT" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("DU" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null ? value[p].Quote_Option_Item__r.Contract_Term__c : "";
              dynamicsheet.getCell("EB" + rowcount).value = value[p].Quote_Option_Item__r.Billing_Type__c != null ? value[p].Quote_Option_Item__r.Billing_Type__c : "";
              var gfqty = 0;
              var gurdianOptionName = [];
              let qoptionitemser = await getOptionItemSer({ QOIId: value[p].Quote_Option_Item__r.Id });
              if (qoptionitemser) {
                for (var g = 0; g < qoptionitemser.length; g++) {
                  gfqty = gfqty + Number(qoptionitemser[g].QTY__c);
                  if (qoptionitemser[g].Name === 'VPN Client Add On') {
                    gurdianOptionName.push(qoptionitemser[g].Name != null ? qoptionitemser[g].Name + "(" + qoptionitemser[g].QTY__c + ")" : "");
                  } else {
                    gurdianOptionName.push(qoptionitemser[g].Name != null ? qoptionitemser[g].Name : '')
                  }
                  dynamicsheet.getCell("DY" + rowcount).value = gfqty;
                }
                if (gurdianOptionName.length >= 0) {
                  let MOptionSerV = gurdianOptionName.filter(function (value) {
                    return !value.includes("Configuration") && !value.includes("Ticket Integration");
                  });
                  dynamicsheet.getCell("DZ" + rowcount).value = MOptionSerV.join(', ');
                }
                if (gurdianOptionName.includes("Configuration")) {
                  objNRC.GRIDNRCDes.push('Configuration')
                }
                if (gurdianOptionName.includes("Ticket Integration")) {
                  objNRC.GRIDNRCTCDes.push('Ticket Integration')
                }
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("DV" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("DW" + rowcount).value = value[p].Quote_Option_Item__r.Product_Code_Description__c != null ? value[p].Quote_Option_Item__r.Product_Code_Description__c : "";
                dynamicsheet.getCell("DX" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("EA" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Feature_MRC__c);
                dynamicsheet.getCell("EC" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                dynamicsheet.getCell("ED" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("EE" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("EF" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                GuardianTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                GuradianCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                dynamicsheet.getCell("EB" + rowcount).value = getCurrencyfarmat();
                dynamicsheet.getCell("EC" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Config_Branch_Location__c) {
                  objNRC.GDNProdName = "Guardian";
                  objNRC.GDNCQty = objNRC.GDNCQty + Number(value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0);
                  objNRC.GDNAccessType.push(value[p].Quote_Option_Item__r.Access_Type_Description__c);
                  objNRC.GDNCTTNRC = objNRC.GDNCTTNRC + Number(value[p].Quote_Request_Rates__r[0].Config_Branch_Location__c)
                }
                if (value[p].Quote_Request_Rates__r[0].Ticket_INT_ServiceNow__c) {
                  objNRC.GDNTIProdName = "GDNTI";
                  objNRC.GDNTIQty = objNRC.GDNTIQty + Number(value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0);
                  objNRC.GDNAccessType.push(value[p].Quote_Option_Item__r.Access_Type_Description__c);
                  objNRC.GDNTITTNRC = objNRC.GDNTITTNRC + Number(value[p].Quote_Request_Rates__r[0].Ticket_INT_ServiceNow__c)
                }
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.GDNACProdName = "GDNAC";
                  objNRC.GDNQty = objNRC.GDNQty + Number(value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0);
                  objNRC.GDNAccessType.push(value[p].Quote_Option_Item__r.Access_Type_Description__c);
                  objNRC.GDNTTNRC = objNRC.GDNTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c)
                }
              }
              ss.GDNProdName = "Guardian";
              ss.GDNQty = ss.GDNQty + Number(value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.GDNMT = ss.GDNMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.GDNCMT = ss.GDNCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.GDNCSD = ss.GDNCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.GDNCSP = ss.GDNCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "Mobility") {
              dynamicsheet.getCell("EG" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("EH" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
              dynamicsheet.getCell("EI" + rowcount).value = value[p].Quote_Option_Item__r.Product_Type__c != null ? value[p].Quote_Option_Item__r.Product_Type__c : "";
              dynamicsheet.getCell("EJ" + rowcount).value = value[p].Quote_Option_Item__r.Type__c != null ? value[p].Quote_Option_Item__r.Type__c : "";
              if (value[p].Quote_Option_Item__r.Product_Type__c === "Wireless Broadband") {
                dynamicsheet.getCell("EK" + rowcount).value = "-"; dynamicsheet.getCell("DP" + rowcount).value = "-";
              } else {
                dynamicsheet.getCell("EK" + rowcount).value = value[p].Quote_Option_Item__r.Billing_Type__c != null ? value[p].Quote_Option_Item__r.Billing_Type__c : "";
                dynamicsheet.getCell("EL" + rowcount).value = value[p].Quote_Option_Item__r.ProductCode_Description__c != null ? value[p].Quote_Option_Item__r.ProductCode_Description__c : "";
              }
              if (value[p].Quote_Option_Item__r.ProductCode_Description__c === "Other") {
                let CCPCD = value[p].Quote_Option_Item__r.ProductCode_Description__c != null ? value[p].Quote_Option_Item__r.ProductCode_Description__c : "";
                let CCOther = value[p].Quote_Option_Item__r.Product_Description__c != null ? value[p].Quote_Option_Item__r.Product_Description__c : "";
                dynamicsheet.getCell("EL" + rowcount).value = CCPCD.concat(" - ", CCOther);
              }
              if (value[p].Quote_Option_Item__r.Billing_Type__c === "New Install") {
                dynamicsheet.getCell("EL" + rowcount).value = "";
              }
              dynamicsheet.getCell("EM" + rowcount).value = value[p].Quote_Option_Item__r.Definition__c != null ? value[p].Quote_Option_Item__r.Definition__c : "";
              dynamicsheet.getCell("EN" + rowcount).value = value[p].Quote_Option_Item__r.Minimum_Speed__c != null ? value[p].Quote_Option_Item__r.Minimum_Speed__c : "";
              dynamicsheet.getCell("EO" + rowcount).value = value[p].Quote_Option_Item__r.Product_Code_Description__c != null ? value[p].Quote_Option_Item__r.Product_Code_Description__c : "";

              var MobilityOptionName = [];
              let qoptionitemser = await getOptionItemSer({ QOIId: value[p].Quote_Option_Item__r.Id });
              if (qoptionitemser) {
                for (var g = 0; g < qoptionitemser.length; g++) {
                  MobilityOptionName.push(qoptionitemser[g].Name != null ? qoptionitemser[g].Name : "");
                }
                if (MobilityOptionName.length >= 0) {
                  let MOptionSerV = MobilityOptionName.toString();
                  MOptionSerV.replaceAll('"', "");
                  dynamicsheet.getCell("EP" + rowcount).value = MOptionSerV;
                  if (value[p].Quote_Option_Item__r.Ip_Block__c === "Yes") {
                    MobilitySMflag = true;
                    dynamicsheet.getCell("ER" + rowcount).value = value[p].Quote_Option_Item__r.Ip_Block__c != null ? value[p].Quote_Option_Item__r.Ip_Block__c : "";
                    dynamicsheet.getCell("ES" + rowcount).value = value[p].Quote_Option_Item__r.IP_Type__c != null ? value[p].Quote_Option_Item__r.IP_Type__c : "";
                    dynamicsheet.getCell("ET" + rowcount).value = value[p].Quote_Option_Item__r.Display_Speed__c != null ? value[p].Quote_Option_Item__r.Display_Speed__c : "";
                  }
                  if (value[p].Quote_Option_Item__r.Ip_Block__c === "No") {
                    MobilitySMNOflag = true;
                    dynamicsheet.getCell("ER" + rowcount).value = value[p].Quote_Option_Item__r.Ip_Block__c != null ? value[p].Quote_Option_Item__r.Ip_Block__c : "";
                    dynamicsheet.getCell("ES" + rowcount).value = "";
                    dynamicsheet.getCell("ET" + rowcount).value = "";
                  }
                }
              }
              if (value[p].Quote_Option_Item__r.Product_Type__c === "Wireless Broadband") {
                mobilitywirelessflag = true;
              }
              if (value[p].Quote_Option__r.Quote_Request__r.Quote_Type__c === "Comparison" && value[p].Quote_Option_Item__r.Product_Type__c != "Wireless Broadband") {
                Mobilityflag = true;
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                console.log("qoptionitemser:Completed", qoptionitemser);
                dynamicsheet.getCell("EQ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Default_Router_Rate__c);
                dynamicsheet.getCell("EX" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("EY" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("EZ" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                dynamicsheet.getCell("EU" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("EV" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Static_IP__c);
                dynamicsheet.getCell("EW" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                MobilityTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                MobalityCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.MOBIProdName = "Mobility";
                  if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                    objNRC.MOBIProdName = "Mobility";
                    objNRC.MOBIQty = objNRC.MOBIQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    objNRC.MOBITTNRC = objNRC.MOBITTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                  }
                }
              }
              ss.MOBIProdName = "Mobility";
              ss.MOBIQty = ss.MOBIQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.MOBIMT = ss.MOBIMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.MOBICMT = ss.MOBICMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.MOBICSD = ss.MOBICSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.MOBICSP = ss.MOBICSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "PIP") {
              GSEPIPflag = true;
              dynamicsheet.getCell("FA" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("FB" + rowcount).value = value[p].Quote_Option_Item__r.Contract_Term__c != null ? value[p].Quote_Option_Item__r.Contract_Term__c : "";
              dynamicsheet.getCell("FD" + rowcount).value = value[p].Quote_Option_Item__r.Access_Type__c != null ? value[p].Quote_Option_Item__r.Access_Type__c : 0;
              dynamicsheet.getCell("FE" + rowcount).value = value[p].Quote_Option_Item__r.Speed__c != null ? value[p].Quote_Option_Item__r.Speed__c : "";
              dynamicsheet.getCell("FF" + rowcount).value = value[p].Quote_Option_Item__r.Service_Level_Tier__c != null ? value[p].Quote_Option_Item__r.Service_Level_Tier__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("FC" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("FK" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("FL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("FM" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                dynamicsheet.getCell("FG" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                if (value[p].Quote_Option_Item__r.Service_Level_Tier__c === "Bronze") {
                  dynamicsheet.getCell("FH" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Service_Level_Tier__c != "Bronze") {
                  dynamicsheet.getCell("FH" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].COS_MRC__c);
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("FI" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("FI" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Surcharge__c);
                }
                dynamicsheet.getCell("FJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                PIPTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                PIPCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("FI" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("FI" + rowcount).value = getCurrencyfarmat();
                }
                dynamicsheet.getCell("FJ" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.PIPProdName = "PIP";
                  objNRC.PIPQty = objNRC.PIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  if (objNRC.PIPAccessType != null) {
                    objNRC.PIPAccessType += ";" + value[p].Quote_Option_Item__r.Access_Type__c;
                  } else {
                    objNRC.PIPAccessType = value[p].Quote_Option_Item__r.Access_Type__c;
                  }
                  objNRC.PIPTTNRC = objNRC.PIPTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.PIPProdName = "PIP";
              ss.PIPQty = ss.PIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.PIPMT = ss.PIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.PIPCMT = ss.PIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.PIPCSD = ss.PIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.PIPCSP = ss.PIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === "POTS") {
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.POTSProdName = "POTS";
                  objNRC.POTSQty = objNRC.POTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  objNRC.POTSTTNRC = objNRC.POTSTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.POTSProdName = "POTS";
              ss.POTSQty = ss.POTSQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.POTSMT = ss.POTSMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
              }
              POTSflag = true;
              if (value[p].Quote_Option_Item__r.Product_Type__c === "Local") {
                POTSproductTypeflag = true;
              }
              if (value[p].Quote_Option_Item__r.Product_Type__c === "Local + LD") {
                POTSproductTypeLocalLDflag = true;
              }
              dynamicsheet.getCell("FN" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("FO" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "MTM";
              dynamicsheet.getCell("FQ" + rowcount).value = value[p].Quote_Request_Location__r.Telephone_Number__c != null ? value[p].Quote_Request_Location__r.Telephone_Number__c : "";
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                dynamicsheet.getCell("FP" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("FR" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("FY" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("FZ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("GA" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  surchargeflag = true;
                  dynamicsheet.getCell("FS" + rowcount).value = "";
                  dynamicsheet.getCell("FT" + rowcount).value = "";
                  dynamicsheet.getCell("FU" + rowcount).value = "";
                  dynamicsheet.getCell("FV" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("FS" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].EUCL__c);
                  dynamicsheet.getCell("FT" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].ARC__c);
                  dynamicsheet.getCell("FU" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].LNP__c);
                  dynamicsheet.getCell("FV" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].PTA_PTR__c);
                  dynamicsheet.getCell("FW" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].PICC__c);
                }
                dynamicsheet.getCell("FX" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                POTSTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                POTSCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              } else {
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  dynamicsheet.getCell("FS" + rowcount).value = "";
                  dynamicsheet.getCell("FT" + rowcount).value = "";
                  dynamicsheet.getCell("FU" + rowcount).value = "";
                  dynamicsheet.getCell("FV" + rowcount).value = "";
                  dynamicsheet.getCell("FW" + rowcount).value = "";
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  dynamicsheet.getCell("FS" + rowcount).value = getCurrencyfarmat();
                  dynamicsheet.getCell("FT" + rowcount).value = getCurrencyfarmat();
                  dynamicsheet.getCell("FU" + rowcount).value = getCurrencyfarmat();
                  dynamicsheet.getCell("FV" + rowcount).value = getCurrencyfarmat();
                  dynamicsheet.getCell("FW" + rowcount).value = getCurrencyfarmat();
                }
                dynamicsheet.getCell("FX" + rowcount).value = getCurrencyfarmat();
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.POTCMT = ss.POTCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.POTCSD = ss.POTCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.POTCSP = ss.POTCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            if (value[p].Quote_Option_Item__r.Name === 'Voice over Cable Line') {
              vocflagl = true;
              dynamicsheet.getCell("GB" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
              dynamicsheet.getCell("GC" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
              var vocFeatures = [];
              let qqoptionitemser = await getOptionItemSer({ QOIId: value[p].Quote_Option_Item__r.Id });
              if (qqoptionitemser) {
                for (var h = 0; h < qqoptionitemser.length; h++) {
                  vocFeatures.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                }
                if (vocFeatures.length > 0) {
                  let vocFe = vocFeatures.join(", ");
                  dynamicsheet.getCell("GF" + rowcount).value = vocFe;
                }
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true) {
                  vocFlagsur = true
                }
                if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false) {
                  vocFlagNosur = true
                  const hideeucl = dynamicsheet.getColumn("GH"); hideeucl.hidden = true;
                  const hidearp = dynamicsheet.getColumn("GI"); hidearp.hidden = true;
                  const hidelnp = dynamicsheet.getColumn("GJ"); hidelnp.hidden = true;

                }
                dynamicsheet.getCell("GD" + rowcount).value = value[p].Quote_Request_Rates__r[0].Vendor__c != null ? value[p].Quote_Request_Rates__r[0].Vendor__c : "";
                dynamicsheet.getCell("GE" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Circuit_MRC_Rate1__c);
                dynamicsheet.getCell("GG" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Feature_MRC__c);
                dynamicsheet.getCell("GH" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].EUCL__c);
                dynamicsheet.getCell("GI" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].ARC__c);
                dynamicsheet.getCell("GJ" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].LNP__c);
                dynamicsheet.getCell("GK" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                dynamicsheet.getCell("GL" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                dynamicsheet.getCell("GM" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                dynamicsheet.getCell("GN" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                VOCTotalMRC = value[p].Quote_Request_Rates__r[0].Total_MRC__c;
                VOCCurnttotalMRC = value[p].Quote_Request_Rates__r[0].Current_Total__c;
              }
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c) {
                  objNRC.VOCProdName = "VOC";
                  objNRC.VOCQty = objNRC.VOCQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                  objNRC.VOCTTNRC = objNRC.VOCTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c);
                }
              }
              ss.VOCProdName = "Voice over Cable Line";
              ss.VOCQty = ss.VOCQty + Number(value[p].Quote_Option_Item__r.QTY__c);
              if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                ss.VOCMT = ss.VOCMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                ss.VOCCMT = ss.VOCCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                ss.VOCCSD = ss.VOCCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                ss.VOCCSP = ss.VOCCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
              }
            }
            
            if (value[p].Quote_Option_Item__r.Name === "VoIP") {
              productArr.push(value[p].Quote_Option_Item__r.Product_Detail1__c);
              if (value[p].Quote_Option_Item__r.Product_Detail1__c === 'HPBX' || value[p].Quote_Option_Item__r.Product_Detail1__c === 'SIP' || (value[p].Quote_Option_Item__r.Product_Detail1__c === 'Operator Connect for Microsoft Teams' && (isA3SplPricingUser === "A3_SplPricing_CRE" || isA3SplPricingUser === "A3_OMAnalyst_CRE" || isA3SplPricingUser === "A3_SalesEng_CRE" || isA3SplPricingUser === "A3_ChannelsQuoter_CRE" || isA3SplPricingUser === "A3_OMAnalystManager_CRE" || isA3SplPricingUser === "A3_SalesEngManager_CRE"))) {
                dynamicsheet.getCell("GP" + rowcount).value = value[p].Quote_Option_Item__r.Product_Detail1__c != null ? value[p].Quote_Option_Item__r.Product_Detail1__c : "";
                dynamicsheet.getCell("GQ" + rowcount).value = value[p].Quote_Option_Item__r.QTY__c != null ? value[p].Quote_Option_Item__r.QTY__c : 0;
                dynamicsheet.getCell("GR" + rowcount).value = value[p].Quote_Option_Item__r.Term__c != null ? value[p].Quote_Option_Item__r.Term__c : "";
                dynamicsheet.getCell("GU" + rowcount).value = value[p].Quote_Option_Item__r.Preferred_Product_1__c != null ? value[p].Quote_Option_Item__r.Preferred_Product_1__c : "";
                if (value[p].Quote_Option_Item__r.Product_Detail1__c === 'Operator Connect for Microsoft Teams') {
                  ocMflag = true;
                  dynamicsheet.getCell("GW" + rowcount).value = value[p].Quote_Option_Item__r.Preferred_Product__c != null ? value[p].Quote_Option_Item__r.Preferred_Product__c : '';
                }
                var Seatoptions = [];
                var AddonFeatureOptions = [];
                var SIPAdditionalFeatures = [];
                var EquipmentOptions = [];
                var fqty = 0;
                let qqoptionitemser = await getOptionItemSer({ QOIId: value[p].Quote_Option_Item__r.Id });
                if (qqoptionitemser) {
                  for (var h = 0; h < qqoptionitemser.length; h++) {
                    if (qqoptionitemser[h].Child_Quote_item_Product_Type__c === "HPBX Equipment") {
                      if (qqoptionitemser[h].Billing_Type__c === 'MRC') {
                        EquipmentOptions.push(qqoptionitemser[h].Model_Number__c != null ? qqoptionitemser[h].Model_Number__c + "(" + qqoptionitemser[h].QTY__c + ")" : " ")
                      }
                      if (qqoptionitemser[h].Billing_Type__c === 'NRC') {
                        bNrc = true;
                        modelHpbx.push(qqoptionitemser[h].Model_Number__c);
                        disEquip.push(qqoptionitemser[h].Name);
                      }
                    }
                    if (qqoptionitemser[h].Child_Quote_item_Product_Type__c === "Offer") {
                      if (qqoptionitemser[h].Name === "Meeting Size Upgrade") {
                        Seatoptions.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + " (" + qqoptionitemser[h].Provider__c + ")" + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                      } else {
                        Seatoptions.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                      }
                    }
                    if (qqoptionitemser[h].Child_Quote_item_Product_Type__c === "AddOnFeatures") {
                      fqty = fqty + Number(qqoptionitemser[h].QTY__c);
                      dynamicsheet.getCell("GV" + rowcount).value = fqty;
                      if (qqoptionitemser[h].IP_Type__c != "Call Recording") {
                        stroagoption.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                      }
                      if (qqoptionitemser[h].IP_Type__c === "Call Recording") {
                        stroagoption.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                        dynamicsheet.getCell("GZ" + rowcount).value = qqoptionitemser[h].Minimum_Speed__c;
                      }
                      if (qqoptionitemser[h].Name === "Cloud Contact Center" || qqoptionitemser[h].Name === "Call Recording" || qqoptionitemser[h].Name === "Granite Connector") {
                        AddonFeatureOptions.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + "(" + qqoptionitemser[h].IP_Type__c + ")" + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                      } else {
                        AddonFeatureOptions.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + "(" + qqoptionitemser[h].QTY__c + ")" : "");
                      }
                    }
                    if (qqoptionitemser[h].Child_Quote_item_Product_Type__c === "SIPAdditionalFeatures") {
                      fqty = fqty + Number(qqoptionitemser[h].QTY__c);
                      dynamicsheet.getCell("GV" + rowcount).value = fqty;
                      if (qqoptionitemser[h].Name === "Cloud Contact Center" || qqoptionitemser[h].Name === "LD Usage Package") {
                        SIPAdditionalFeatures.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name + ":" + "(" + qqoptionitemser[h].IP_Type__c + ")" : "");
                      } else {
                        SIPAdditionalFeatures.push(qqoptionitemser[h].Name != null ? qqoptionitemser[h].Name : "");
                      }
                    }
                  }
                  if (EquipmentOptions.length > 0) {
                    let equipmentF = EquipmentOptions.join(", ");
                    dynamicsheet.getCell("HA" + rowcount).value = equipmentF;
                  }
                  if (Seatoptions.length > 0) {
                    let strSO = Seatoptions.join(", ");
                    dynamicsheet.getCell("GT" + rowcount).value = strSO;
                  }
                  if (AddonFeatureOptions.length > 0) {
                    let strAFO = AddonFeatureOptions.join(", ");
                    dynamicsheet.getCell("GX" + rowcount).value = strAFO;
                  }
                  if (SIPAdditionalFeatures.length > 0) {
                    let strSAFO = SIPAdditionalFeatures.join(", ");
                    dynamicsheet.getCell("GW" + rowcount).value = strSAFO;
                  }
                  if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                    for (var j = 0; j < value[p].Quote_Request_Rates__r.length; j++) {
                      if (value[p].Quote_Request_Rates__r[j].Parent_QR_Rate__c === false && bNrc === true) {
                        if (value[p].Quote_Request_Rates__r[j].EQUIP_NRC__c > 0) {

                          equipQty.push({ [value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name]: Number(value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c) })

                          hpbxqty = hpbxqty + Number(value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c)

                          objNRC.VOIPTTNRC.push({ [value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.Name]: Number(value[p].Quote_Request_Rates__r[j].EQUIP_NRC__c * Number(value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c)) })

                          voipTn = voipTn + Number(value[p].Quote_Request_Rates__r[j].EQUIP_NRC__c * Number(value[p].Quote_Request_Rates__r[j].Quote_Option_Item__r.QTY__c))
                        }
                      }
                    }
                  }
                }
                if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
                  for (var j = 0; j < value[p].Quote_Request_Rates__r.length; j++) {
                    if (value[p].Quote_Request_Rates__r[j].Parent_QR_Rate__c === true) {
                      if (!value[p].Quote_Option_Item__r.Preferred_Product__c === 'Per Minute'||value[p].Quote_Option_Item__r.Preferred_Product__c === 'Unlimited' || value[p].Quote_Option_Item__r.Product_Detail1__c === 'HPBX' || value[p].Quote_Option_Item__r.Product_Detail1__c === 'SIP') {
                        dynamicsheet.getCell("GY" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Feature_MRC__c);
                      }
                      dynamicsheet.getCell("GS" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Circuit_MRC_Rate1__c);
                      dynamicsheet.getCell("HB" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Default_Router_Rate__c);
                      dynamicsheet.getCell("HC" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Surcharge__c);
                      dynamicsheet.getCell("HD" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].PTA__c);
                      dynamicsheet.getCell("HE" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Total_MRC__c);
                      dynamicsheet.getCell("HF" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Current_Total__c);
                      dynamicsheet.getCell("HG" + rowcount).value = getCurrencyfarmat(value[p].Quote_Request_Rates__r[j].Saving_Amount__c);
                      dynamicsheet.getCell("HH" + rowcount).value = getpercentagefarmat(value[p].Quote_Request_Rates__r[j].Saving_Percentage__c);
                      if(value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c === "Wholesale" && value[p].Quote_Option_Item__r.Product_Detail1__c === "Operator Connect for Microsoft Teams"){
                        dynamicsheet.getCell("HC" + rowcount).value = '';
                        dynamicsheet.getCell("HD" + rowcount).value = '';
                      }
                      if (value[p].Quote_Option_Item__r.Is_Surcharge__c === true && (value[p].Quote_Option_Item__r.Product_Detail1__c === "HPBX" || value[p].Quote_Option_Item__r.Product_Detail1__c === "SIP")) {
                        SHVoIPflag = true;
                      }
                      if (value[p].Quote_Option_Item__r.Is_Surcharge__c === false && (value[p].Quote_Option_Item__r.Product_Detail1__c === "HPBX" || value[p].Quote_Option_Item__r.Product_Detail1__c === "SIP")) {
                        SHVoIPflagsur = true;
                      }
                      VOIPTotalMRC = value[p].Quote_Request_Rates__r[j].Total_MRC__c;
                      VOIPCurnttotalMRC = value[p].Quote_Request_Rates__r[j].Current_Total__c;
                      if (value[p].Quote_Option_Item__r.Product_Detail1__c === "HPBX") {
                        if (value[p].Quote_Request_Rates__r[j].Activation_Cost__c) {
                          objNRC.VOIPHProdName = "HPBX1";
                          objNRC.VOIPTTTNRC = objNRC.VOIPTTTNRC + Number(value[p].Quote_Request_Rates__r[j].Activation_Cost__c);
                          objNRC.VOIPQty = objNRC.VOIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                        }
                        if (value[p].Quote_Request_Rates__r[j].EQUIP_NRC__c) {
                          objNRC.VOIPProdName = 'HPBX'
                        }
                        ss.VOIPProdName = "HPBX";
                        ss.VOIPQty = ss.VOIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                        ss.VOIPMT = ss.VOIPMT + Number(value[p].Quote_Request_Rates__r[j].Total_MRC__c);
                        ss.VOIPCMT = ss.VOIPCMT + Number(value[p].Quote_Request_Rates__r[j].Current_Total__c);
                        ss.VOIPCSD = ss.VOIPCSD + Number(value[p].Quote_Request_Rates__r[j].Saving_Amount__c);
                        ss.VOIPCSP = ss.VOIPCSP + Number(value[p].Quote_Request_Rates__r[j].Saving_Percentage__c);
                      }
                    }
                  }
                  if (value[p].Quote_Option_Item__r.Product_Detail1__c === "SIP") {
                    if (value[p].Quote_Request_Rates__r[0].Activation_Cost__c || value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c) {
                      objNRC.VOIPSIPProdName = "SIP";
                      objNRC.VOIPSIPQty = objNRC.VOIPSIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                      objNRC.VOIPSIPTTNRC = objNRC.VOIPSIPTTNRC + Number(value[p].Quote_Request_Rates__r[0].Activation_Cost__c) + Number(value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c);
                    }
                    ss.VOIPSIPProdName = "SIP";
                    ss.VOIPSIPQty = ss.VOIPSIPQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    ss.VOIPSIPMT = ss.VOIPSIPMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    ss.VOIPSIPCMT = ss.VOIPSIPCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    ss.VOIPSIPCSD = ss.VOIPSIPCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    ss.VOIPSIPCSP = ss.VOIPSIPCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                  }
                  if (value[p].Quote_Option_Item__r.Product_Detail1__c === "Operator Connect for Microsoft Teams") {
                    ss.OCTProdName = "Operator Connect for Microsoft Teams";
                    ss.OCTQty = ss.OCTQty + Number(value[p].Quote_Option_Item__r.QTY__c);
                    ss.OCTMT = ss.OCTMT + Number(value[p].Quote_Request_Rates__r[0].Total_MRC__c);
                    ss.OCTCMT = ss.OCTCMT + Number(value[p].Quote_Request_Rates__r[0].Current_Total__c);
                    ss.OCTCSD = ss.OCTCSD + Number(value[p].Quote_Request_Rates__r[0].Saving_Amount__c);
                    ss.OCTCSP = ss.OCTCSP + Number(value[p].Quote_Request_Rates__r[0].Saving_Percentage__c);
                  }
                }
              }
            }
            if (value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c === "Wholesale") {
              const hideModem = dynamicsheet.getColumn("O");
              hideModem.hidden = true;
              const hideIAR = dynamicsheet.getColumn("P");
              hideIAR.hidden = true;
              const hideCSR = dynamicsheet.getColumn("AH");
              hideCSR.hidden = true;
              const hideCSR1 = dynamicsheet.getColumn("DO");
              hideCSR1.hidden = true;
              const hideASF = dynamicsheet.getColumn("HC");hideASF.hidden = true;
              const hideNAC = dynamicsheet.getColumn("HD");hideNAC.hidden = true;
              if(SHVoIPflag){
              hideASF.hidden = false;
              hideNAC.hidden = false;
              }
            }
            if (value[p].Quote_Option__r.Quote_Request__r.Business_Unit__c != "Wholesale") {
              const hideCOStype = dynamicsheet.getColumn("DN");
              hideCOStype.hidden = true;
            }
            if (value[p].Quote_Option__r.Quote_Request__r.Quote_Type__c === "Non-Comparison") {
              comparisionflag = true;
            }
            formatQuoteOptionTableHeaders(rowcount, dynamicsheet);
            ["A" + rowcount].map((key) => formatCell(dynamicsheet, key));
            TotalSiteMRC = BBTotalMRC + DIATotalMRC + EPIKTotalMRC + EquipmentTotalMRC + GSETotalMRC + GRIDTotalMRC + GuardianTotalMRC + MobilityTotalMRC + PIPTotalMRC + POTSTotalMRC + EPOTSTotalMRC + VOIPTotalMRC + VOCTotalMRC + EDGETotalMRC;
            dynamicsheet.getCell("HI" + rowcount).value = getCurrencyfarmat(TotalSiteMRC);
            CurnttotalMRC = BBCurnttotalMRC + DIACurnttotalMRC + EPIKCurnttotalMRC + EquipmentCurnttotalMRC + GSECurnttotalMRC + GRIDCurnttotalMRC + GuradianCurnttotalMRC + MobalityCurnttotalMRC + PIPCurnttotalMRC + POTSCurnttotalMRC + EPOTSCurnttotalMRC + VOIPCurnttotalMRC + VOCCurnttotalMRC + EDGECurnttotalMRC;
            dynamicsheet.getCell("HJ" + rowcount).value = getCurrencyfarmat(CurnttotalMRC);
            CurnttotalsitesavingsDol = CurnttotalMRC - TotalSiteMRC;
            dynamicsheet.getCell("HK" + rowcount).value = getCurrencyfarmat(CurnttotalsitesavingsDol);
            CurnttotalsitesavingsPer = CurnttotalMRC > 0 ? (CurnttotalsitesavingsDol / CurnttotalMRC) * 100 : 0;
            dynamicsheet.getCell("HL" + rowcount).value = getpercentagefarmat(CurnttotalsitesavingsPer);
            const uniqueProd = [...new Set(productArr)]
            if (value[p].hasOwnProperty("Quote_Request_Rates__r")) {
              for (var j = 0; j < value[p].Quote_Request_Rates__r.length; j++) {
             if((uniqueProd.includes('Operator Connect for Microsoft Teams') && uniqueProd.length >= 1) && (isA3SplPricingUser === "A3_SplPricing_CRE" || isA3SplPricingUser === "A3_OMAnalyst_CRE" || isA3SplPricingUser === "A3_SalesEng_CRE" || isA3SplPricingUser === "A3_ChannelsQuoter_CRE" || isA3SplPricingUser === "A3_OMAnalystManager_CRE" || isA3SplPricingUser === "A3_SalesEngManager_CRE")){
                if (value[p].Quote_Request_Rates__r[j].Total_MRC__c !== undefined && value[p].Quote_Request_Rates__r[j].Parent_QR_Rate__c === true) {
                  GMonthlyPrice += Number(value[p].Quote_Request_Rates__r[j].Total_MRC__c);
                }
                if (value[p].Quote_Request_Rates__r[j].Saving_Amount__c !== undefined) {
                  MonthlySavings += Number(value[p].Quote_Request_Rates__r[j].Saving_Amount__c);
                }
              }else if(!uniqueProd.includes('Operator Connect for Microsoft Teams') && uniqueProd.length >= 1){
                if (value[p].Quote_Request_Rates__r[j].Total_MRC__c !== undefined && value[p].Quote_Request_Rates__r[j].Parent_QR_Rate__c === true) {
                  GMonthlyPrice += Number(value[p].Quote_Request_Rates__r[j].Total_MRC__c);
                }
                if (value[p].Quote_Request_Rates__r[j].Saving_Amount__c !== undefined) {
                  MonthlySavings += Number(value[p].Quote_Request_Rates__r[j].Saving_Amount__c);
                }}
              }
            }
            GAnnuallyPrice = GMonthlyPrice * 12;
            const arrayQLocMap = Array.from(Object.values(qlocOp));
            const uniqueLoc = uniqueBy(arrayQLocMap, (qloc) => qloc[0].Quote_Request_Location__c);
            avgspendpersite = (GMonthlyPrice / uniqueLoc.length).toFixed(2);
            Monthsav = MonthlySavings * 12;
            AvgSavings = (Monthsav / uniqueLoc.length).toFixed(2);
          }
          if (stroagoption.includes("Call Recording")) {
            hidestrgoption.hidden = false;
          } else {
            hidestrgoption.hidden = true;
          }
          if ((MobilitySMflag === true && MobilitySMNOflag === false) || MobilitySMflag === true) {
            hidesecsim.hidden = false;
            hidesecsin.hidden = false;
            hidesecsio.hidden = false;
          }
          if ((MobilitySMflag === false && MobilitySMNOflag === true) || MobilitySMflag === false) {
            hidesecsim.hidden = true;
            hidesecsin.hidden = true;
            hidesecsio.hidden = true;
          }
          statrowcount = rowcount + 3;
        }
        dynamicsheet.getCell("A" + statrowcount).value = " Non-Recurring Charges";
        dynamicsheet.getCell("A" + statrowcount).font = {
          color: { argb: "3B5AA9" },
          size: 20,
          bold: true
        };
        statrowcount++;
        statrowcount++;
        dynamicsheet.getCell("A" + statrowcount).value = "Product";
        dynamicsheet.getCell("B" + statrowcount).value = "Access Type";
        dynamicsheet.getCell("C" + statrowcount).value = "QTY";
        dynamicsheet.getCell("D" + statrowcount).value = "Description";
        dynamicsheet.getCell("E" + statrowcount).value = "Model";
        dynamicsheet.getCell("F" + statrowcount).value = "Total NRC";
        ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
          formatCellwithBold(dynamicsheet, key, "000000", 10);
          dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
        });
        summryrow = 0;
        summryrow = indexcount;
        worksheet.getCell("A" + summryrow).value = quoteoptions[i].Name;
        ["A" + summryrow].map((key) => {
          worksheet.getCell(key).font = {
            color: { argb: "FF9537" },
            size: 15,
            bold: true
          };
        });
        summryrow++;
        summryrow++;
        console.log("SummaryValue", summryrow);
        worksheet.getCell("A" + summryrow).value = "Summary";
        ["A" + summryrow].map((key) => {
          worksheet.getCell("A" + summryrow).font = {
            color: { argb: "3B5AA9" },
            size: 15,
            bold: true
          };
        });
        summryrow++;
        summryrow++;
        worksheet.getCell("A" + summryrow).value = "Services";
        worksheet.getCell("C" + summryrow).value = "Granite Price";
        worksheet.getCell("I" + summryrow).value = "Your Savings";
        worksheet.getCell("O" + summryrow).value = "Per Site";
        ["A" + summryrow + ":" + "B" + summryrow, "C" + summryrow + ":" + "H" + summryrow, "I" + summryrow + ":" + "N" + summryrow, "O" + summryrow + ":" + "Q" + summryrow].map((key) => {
          worksheet.mergeCells(key);
          worksheet.getCell(key).font = {
            color: { argb: "000000" },
            size: 15,
            bold: true
          };
          worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
          if (key === "I" + summryrow + ":" + "N" + summryrow) {
            worksheet.getCell(key).fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "c7ddb5" }
            };
          }
          if (key === "C" + summryrow + ":" + "H" + summryrow || key === "O" + summryrow + ":" + "Q" + summryrow) {
            worksheet.getCell(key).fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "B3CCF5" }
            };
          }
        });
        if (comparisionflag === true) {
          ["I", "J", "K", "L", "M", "N"].map((key) => {
            const summaryNonComparcol = worksheet.getColumn(key);
            summaryNonComparcol.hidden = true;
          });
        }
        var loopcount = 0;
        summryrow++;
        if (loopcount === 0) {
          servicefirstval = summryrow;
          loopcount++;
        }
        if (ss.BBProdName === "Broadband") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.BBProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.DIAProdName === "DIA") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.DIAProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.EPIKProdName === "EPIK") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.EPIKProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.EquipmentProdName === "Equipment") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.EquipmentProdName; +
            ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
              worksheet.mergeCells(key);
              worksheet.getCell(key).font = {
                color: { argb: "000000" },
                size: 10,
                bold: true
              };
              worksheet.getCell(key).border = {
                top: { style: "double", color: { argb: "FFFFFF" } }
              };
              worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
            });
        }
        if (ss.EPOTSProdName === "ePOTS") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.EPOTSProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.EDGEProdName === "edgeboot") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.EDGEProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.GSEProdName === "GSE") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.GSEProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.GRIDProdName === "GRID") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.GRIDProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.GDNProdName === "Guardian") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.GDNProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.VOIPProdName === "HPBX") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.VOIPProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.MOBIProdName === "Mobility") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.MOBIProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.OCTProdName === "Operator Connect for Microsoft Teams") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.OCTProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.PIPProdName === "PIP") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.PIPProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.POTSProdName === "POTS") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.POTSProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.VOIPSIPProdName === "SIP") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.VOIPSIPProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        if (ss.VOCProdName === "Voice over Cable Line") {
          summryrow++;
          worksheet.getCell("A" + summryrow).value = "    " + ss.VOCProdName;
          ["A" + summryrow + ":" + "B" + summryrow].map((key) => {
            worksheet.mergeCells(key);
            worksheet.getCell(key).font = {
              color: { argb: "000000" },
              size: 10,
              bold: true
            };
            worksheet.getCell(key).border = {
              top: { style: "double", color: { argb: "FFFFFF" } }
            };
            worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "Left" };
          });
        }
        worksheet.getCell("C" + servicefirstval).value = getCurrencyfarmat(GMonthlyPrice, true) + "         " + getCurrencyfarmat(GAnnuallyPrice, true);
        worksheet.getCell("I" + servicefirstval).value = getCurrencyfarmat(Monthsav, true) + "         " + getCurrencyfarmat(AvgSavings, true);
        worksheet.getCell("O" + servicefirstval).value = getCurrencyfarmat(avgspendpersite);
        ["C" + servicefirstval + ":" + "H" + servicefirstval, "I" + servicefirstval + ":" + "N" + servicefirstval, "O" + servicefirstval + ":" + "Q" + servicefirstval].map((key) => {
          if (key === "C" + servicefirstval + ":" + "H" + servicefirstval || key === "I" + servicefirstval + ":" + "N" + servicefirstval || key === "O" + servicefirstval + ":" + "Q" + servicefirstval) {
            worksheet.mergeCells(key);
          }
          if (key === "I" + servicefirstval + ":" + "N" + servicefirstval) {
            worksheet.getCell(key).fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "c7ddb5" }
            };
            worksheet.getCell(key).font = {
              color: { argb: "50A038" },
              size: 20,
              bold: true
            };
            worksheet.getCell(key).alignment = { vertical: "bottom", horizontal: "center" };
          }
          if (key === "C" + servicefirstval + ":" + "H" + servicefirstval || key === "O" + servicefirstval + ":" + "Q" + servicefirstval) {
            worksheet.getCell(key).fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "B3CCF5" }
            };
            worksheet.getCell(key).font = {
              color: { argb: "0047AB" },
              size: 20,
              bold: true
            };
            worksheet.getCell(key).alignment = { vertical: "bottom", horizontal: "center" };
          }
        });
        summryrow++;
        servicefirstval++;
        worksheet.getCell("C" + servicefirstval).value = "Monthly" + "         " + "Annually";
        worksheet.getCell("I" + servicefirstval).value = "Annually Savings" + "         " + "Avg Savings Per Site";
        worksheet.getCell("O" + servicefirstval).value = "Avg Spend Per Site";
        ["A" + summryrow + ":" + "B" + summryrow, "C" + servicefirstval + ":" + "H" + summryrow, "I" + servicefirstval + ":" + "N" + summryrow, "O" + servicefirstval + ":" + "Q" + summryrow].map((key) => {
          if (key === "A" + summryrow + ":" + "B" + summryrow) {
            worksheet.mergeCells(key);
            worksheet.getCell(key).border = { top: { style: "double", color: { argb: "FFFFFF" } } };
          }
          if (key === "C" + servicefirstval + ":" + "H" + summryrow || key === "I" + servicefirstval + ":" + "N" + summryrow || key === "O" + servicefirstval + ":" + "Q" + summryrow) {
            worksheet.mergeCells(key);
          }
          if (key === "I" + servicefirstval + ":" + "N" + summryrow) {
            worksheet.getCell(key).fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "c7ddb5" }
            };
            worksheet.getCell(key).font = {
              color: { argb: "50A038" },
              size: 15,
              bold: false
            };
            worksheet.getCell(key).alignment = { vertical: "top", horizontal: "center" };
          }
          if (key === "C" + servicefirstval + ":" + "H" + summryrow || key === "O" + servicefirstval + ":" + "Q" + summryrow) {
            worksheet.getCell(key).fill = {
              type: "pattern",
              pattern: "solid",
              fgColor: { argb: "B3CCF5" }
            };
            worksheet.getCell(key).font = {
              color: { argb: "003B73" },
              size: 15,
              bold: false
            };
            worksheet.getCell(key).alignment = { vertical: "top", horizontal: "center" };
          }
        });
        summryrow++;
        summryrow++;
        worksheet.getCell("A" + summryrow).value = "Summary # - Recurring Charges";
        ["A" + summryrow].map((key) => {
          worksheet.getCell("A" + summryrow).font = {
            color: { argb: "3B5AA9" },
            size: 15,
            bold: true
          };
        });
        summryrow++;
        worksheet.getCell("A" + summryrow).value = "Services";
        worksheet.getCell("C" + summryrow).value = "QTY";
        worksheet.getCell("E" + summryrow).value = "Granite Monthly Total";
        worksheet.getCell("H" + summryrow).value = "Granite Annual Total";
        worksheet.getCell("K" + summryrow).value = "Current Monthly Total";
        worksheet.getCell("N" + summryrow).value = "Current Annual Total";
        worksheet.getCell("Q" + summryrow).value = "Current Savings $";
        worksheet.getCell("T" + summryrow).value = "Current Savings %";
        ["A" + summryrow, "C" + summryrow, "E" + summryrow, "H" + summryrow, "K" + summryrow, "N" + summryrow, "Q" + summryrow, "T" + summryrow, "A" + summryrow + ":" + "B" + summryrow, "C" + summryrow + ":" + "D" + summryrow, "E" + summryrow + ":" + "G" + summryrow, "H" + summryrow + ":" + "J" + summryrow, "K" + summryrow + ":" + "M" + summryrow, "N" + summryrow + ":" + "P" + summryrow, "Q" + summryrow + ":" + "S" + summryrow, "T" + summryrow + ":" + "V" + summryrow].map((key) => {
          worksheet.getCell(key).font = {
            color: { argb: "000000" },
            size: 15,
            bold: true
          };
          if (key === "Q" + summryrow + ":" + "S" + summryrow || key === "T" + summryrow + ":" + "V" + summryrow) {
            worksheet.getCell(key).font = {
              color: { argb: "50A038" },
              size: 15,
              bold: true
            };
          }
          worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
          if (key === "A" + summryrow + ":" + "B" + summryrow || key === "C" + summryrow + ":" + "D" + summryrow || key === "E" + summryrow + ":" + "G" + summryrow || key === "H" + summryrow + ":" + "J" + summryrow || key === "K" + summryrow + ":" + "M" + summryrow || key === "N" + summryrow + ":" + "P" + summryrow || key === "Q" + summryrow + ":" + "S" + summryrow || key === "T" + summryrow + ":" + "V" + summryrow) {
            worksheet.mergeCells(key);
          }
        });
        if (comparisionflag === true) {
          ["K" + summryrow, "N" + summryrow, "Q" + summryrow, "T" + summryrow].map((key) => {
            worksheet.getCell(key).value = "";
          });
        }
        var totQty = 0;
        var totGraMonthPrice = 0;
        var totHGraAnnuPrice = 0;
        var CurrentMonthlyTotal = 0;
        var CurrentAnnualTotal = 0;
        var CurrentSavingsDol = 0;
        var CurrentSavingsPer = 0;
        let GMonthPrice = 0;
        let GAnnualPrice = 0;
        let sumfirstrowcv = 0;
        let sumlastrowcv = 0;
        summryrow++;
        sumfirstrowcv = summryrow;
        sumlastrowcv = summarysect(ss, summryrow, worksheet, comparisionflag, sumfirstrowcv, sumlastrowcv, totQty, totGraMonthPrice, totHGraAnnuPrice, CurrentMonthlyTotal, CurrentAnnualTotal, CurrentSavingsDol, CurrentSavingsPer);
        sumlastrowcv++;
        for (let i = sumfirstrowcv; i <= sumlastrowcv; i++) {
          ["A" + i, "C" + i, "E" + i, "H" + i, "A" + i + ":" + "B" + i, "C" + i + ":" + "D" + i, "E" + i + ":" + "G" + i, "H" + i + ":" + "J" + i, "K" + i + ":" + "M" + i, "N" + i + ":" + "P" + i, "Q" + i + ":" + "S" + i, "T" + i + ":" + "V" + i].map((key) => {
            if (key === "A" + i) {
              worksheet.getCell(key).font = {
                color: { argb: "000000" },
                size: 10,
                bold: true
              };
            }
            if (key === "C" + i || key === "E" + i || key === "H" + i || key === "K" + i + ":" + "M" + i || key === "N" + i + ":" + "P" + i || key === "Q" + i + ":" + "S" + i || key === "T" + i + ":" + "V" + i) {
              worksheet.getCell(key).font = {
                color: { argb: "000000" },
                size: 10,
                bold: false
              };
            }
            worksheet.getCell(key).alignment = {
              vertical: "middle",
              horizontal: "center"
            };
            if (key === "A" + i + ":" + "B" + i || key === "C" + i + ":" + "D" + i || key === "E" + i + ":" + "G" + i || key === "H" + i + ":" + "J" + i || key === "K" + i + ":" + "M" + i || key === "N" + i + ":" + "P" + i || key === "Q" + i + ":" + "S" + i || key === "T" + i + ":" + "V" + i) {
              worksheet.mergeCells(key);
            }
          });
        }
        if (comparisionflag === true) {
          ["T", "U", "V", "AL", "AM", "AN", "AU", "AV", "AW", "BE", "BF", "BG", "CB", "CC", "CD", "CK", "CL", "CM", "DC", "DD", "DE", "DQ", "DR", "DS", "ED", "EE", "EF", "EX", "EY", "EZ", "FK", "FL", "FM", "FY", "FZ", "GA", "GL", "GM", "GN", "HH", "HF", "HG", "HL", "HJ", "HK"].map((key) => {
            const dynNonComparcol = dynamicsheet.getColumn(key);
            dynNonComparcol.hidden = true;
          });
        }
        indexcount = sumlastrowcv + 2;
        nrcSection(qlocOp, ss, objNRC, statrowcount, dynamicsheet, serAct, modelHpbx, equipQty, disEquip, hpbxqty, voipTn); statrowcount++;
        footertext(statrowcount, dynamicsheet, vocFlagNosur, vocflagl, vocFlagsur, surchargeflag, EPIKflag, EPIKWholesaleflag, POTSflag, POTSproductTypeflag, POTSproductTypeLocalLDflag, edgebootyes, edgebootno, DIAflag, BBflag, GSEPIPflag, GRIDflag, Mobilityflag, mobilitywirelessflag, VoIPflag, SHVoIPflag, SHVoIPflagsur, ocMflag);
      }
      setSummary(summryrow);
      if (i == totalLength - 1) {
        indexcount = 6;
      }
    })
    .catch((error) => {
      console.log("errror", error);
      errorKey = error;
    });
}