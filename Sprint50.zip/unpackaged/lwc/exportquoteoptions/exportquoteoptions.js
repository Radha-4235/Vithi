import { LightningElement, track, api, wire } from "lwc";
import splpricinguser from "@salesforce/apex/ExportCSVController.isA3SplPricingUser";
import fetchQuoteOptions from "@salesforce/apex/SalesRepSummaryController.getQuoteOptionsData";
import getQuotePricingData from "@salesforce/apex/SalesRepSummaryController.getQuotePricingData";
import { getRecord } from "lightning/uiRecordApi";
import LogoBase64 from "@salesforce/label/c.A3ExcelLogoId";
import { formatCellBold, formatCellwithBold, excelHeaders } from "./exportquoteoptions1";
import { getLocationsExcel } from "./importstaticlibrary";
const FIELDS = ["A3_Excel__mdt.base64__c"]
import excelDocSave from "@salesforce/apex/CongaQuoteGenerationController.excelDocSave";

export default class Exportquoteoptions extends LightningElement {
  @api quoterequestid;
  @api quoteoptions;
  @api qrrCreatedDate;
  @api closedWonSucess;
  @track isA3SplPricingUser = false;
  @track qlocOp;
  @api isfilterclosedwon;
  error;
  @track salesEngProduct = [];
  qrRec;
  @track base64img;
  @api A3LogoBase64 = LogoBase64;
  @wire(getRecord, { recordId: "$quoterequestid", fields: ["Quote_Request_2__c.Id", "Quote_Request_2__c.Name", "Quote_Request_2__c.Company_Name__c"] })
  wireCompanyName({ data, error }) {
    if (data) {
      this.qrRec = data;
    }
    if (error) {
      console.log("errorCompany", error);
    }
  }
  @wire(getRecord, { recordId: "$A3LogoBase64", fields: FIELDS })
  wirebase64img;
  get base64() {
    return this.wirebase64img.data.fields.base64__c.value;
  }
  date2str(x, y) {
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var z = {
      M: monthNames[x.getMonth()],
      d: x.getDate(),
      h: x.getHours(),
      m: x.getMinutes(),
      s: x.getSeconds()
    };
    y = y.replace(/(M+|d+|h+|m+|s+)/g, function (v) {
      return (v.length > 1 ? "" : "") + z[v.slice(-1)];
    });
    return y.replace(/(y+)/g, function (v) {
      return x.getFullYear().toString().slice(-v.length);
    });
  }
  renderedCallback() {
    if (this.librariesLoaded) return;
    this.librariesLoaded = true;
    const importLib = this.template.querySelector("c-import-static-library");
    console.log("Static Import");
    console.log("Static Excel");
    console.log("Static FileSave");
  }
  @api async exportdata() { 
    splpricinguser()
      .then((result) => {
         this.isA3SplPricingUser = result;
        this.getQuoteOptions(this.isA3SplPricingUser);
      })
      .catch((error) => {
        this.error = error;
      });
  }
  @api async exportdata1(isA3SplPricingUser) {
    var dynamicsheet;
    var dupechek = [];
    const pictureBase64 = this.base64;
    const workbook = new ExcelJS.Workbook();
    const imageId2 = workbook.addImage({
      base64: pictureBase64,
      extension: "png"
    });
    const worksheet = workbook.addWorksheet("Summary", {});
    worksheet.addImage(imageId2, "A1:A3");
    ["A1:A3", "B1:CE1", "B2:CE2", "B3:CE3"].map((key) => {
      worksheet.mergeCells(key);
    });

    //var indexcount = 6;
    var summryrow = 0;
    var worksheetvisibleflag = true;
    const setSummary = (num) => {
      if (num == null) {
        summryrow++;
      } else {
        summryrow = num;
      }
    };
    for (let i = 0; i < this.quoteoptions.length; i++) {
      dupechek.push(this.quoteoptions[i].Name);
      if (dupechek.includes(this.quoteoptions[i].Name)) {
        dynamicsheet = workbook.addWorksheet(this.quoteoptions[i].Name + "_" + [i]);
      } else {
        dynamicsheet = workbook.addWorksheet(this.quoteoptions[i].Name);
      }
      dynamicsheet.addImage(imageId2, "A1:A3");
      let QRcreatedDate = new Date(this.qrrCreatedDate);
      let FarmatedQRcreatedDate = QRcreatedDate.toDateString();
      let next90days = new Date(QRcreatedDate.setDate(QRcreatedDate.getDate() + 90));
      let Farmatednext90days = next90days.toDateString();
      worksheet.getCell("B2").value = this.qrRec.fields.Company_Name__c.value;
      worksheet.getCell("B3").value = FarmatedQRcreatedDate + " - " + Farmatednext90days + " - " + this.quoteoptions[i].Quote_Request__r.Name;
      dynamicsheet.getCell("B2").value = this.qrRec.fields.Company_Name__c.value;
      dynamicsheet.getCell("B3").value = FarmatedQRcreatedDate + " - " + Farmatednext90days + " - " + this.quoteoptions[i].Quote_Request__r.Name;
      ["B3"].map((key) => {
        if (key === "B3") {
          worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "left" };
          dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "left" };
        }
      });
      excelHeaders(dynamicsheet);
      const a1row = dynamicsheet.getRow(1);
      a1row.height = 1;
      const a3row = dynamicsheet.getRow(3);
      a3row.height = 40;
      const a4row = dynamicsheet.getRow(4);
      a4row.height = 35;
      const a1row1 = worksheet.getRow(1);
      a1row1.height = 1;
      const a3row1 = worksheet.getRow(3);
      a3row1.height = 40;
      const a4row1 = worksheet.getRow(4);
      a4row1.height = 35;
      ["A1:A3"].map((key) => {
        worksheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
        dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
      });
      ["A1:A3", "B1:CE1", "B2:HL2", "B3:HL3"].map((key) => {
        dynamicsheet.mergeCells(key);
        if (key === "B1:CE1") {
          formatCellBold(dynamicsheet, key, "FFFFFF", 0);
          formatCellBold(worksheet, key, "FFFFFF", 0);
        }
        if (key === "B2:HL2") {
          formatCellBold(worksheet, key, "FFFFFF", 25);
          worksheet.getCell(key).alignment = { vertical: "top", horizontal: "left" };
          dynamicsheet.getCell(key).font = {
            color: { argb: "FFFFFF" },
            size: 25,
            bold: true
          };
          dynamicsheet.getCell(key).alignment = { vertical: "top", horizontal: "left" };
        }
        if (key === "B3:HL3") {
          formatCellBold(worksheet, key, "FFFFFF", 10);
          formatCellBold(dynamicsheet, key, "FFFFFF", 10);
        }
        worksheet.getCell(key).fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "3B5AA9" }
        };
        dynamicsheet.getCell(key).fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "3B5AA9" }
        };
      });
      ["A7", "B7", "C7", "D7", "E7", "F7", "G7", "H7", "I7", "J7", "K7", "L7", "M7", "N7", "O7", "P7", "Q7", "R7", "S7", "T7", "U7", "V7", "W7", "X7", "Y7", "Z7", "AA7", "AB7", "AC7", "AD7", "AE7", "AF7", "AG7", "AH7", "AI7", "AJ7", "AK7", "AL7", "AM7", "AN7", "AO7", "AP7", "AQ7", "AR7", "AS7", "AT7", "AU7", "AV7", "AW7", "AX7", "AY7", "AZ7", "BA7", "BB7", "BC7", "BD7", "BE7", "BF7", "BG7", "BH7", "BI7", "BJ7", "BK7", "BL7", "BM7", "BN7", "BO7", "BP7", "BQ7", "BR7", "BS7", "BT7", "BU7", "BV7", "BW7", "BX7", "BY7", "BZ7", "CA7", "CB7", "CC7", "CD7", "CE7", "CF7", "CG7", "CH7", "CI7", "CJ7", "CK7", "CL7", "CM7", "CN7", "CO7", "CP7", "CQ7", "CR7", "CS7", "CT7", "CU7", "CV7", "CW7", "CX7", "CY7", "CZ7", "DA7", "DB7", "DC7", "DD7", "DE7", "DF7", "DG7", "DH7", "DI7", "DJ7", "DK7", "DL7", "DM7", "DN7", "DO7", "DP7", "DQ7", "DR7", "DS7", "DT7", "DU7", "DV7", "DW7", "DX7", "DY7", "DZ7", "EA7", "EB7", "EC7", "ED7", "EE7", "EF7", "EG7", "EH7", "EI7", "EJ7", "EK7", "EL7", "EM7", "EN7", "EO7", "EP7", "EQ7", "ER7", "ES7", "ET7", "EU7", "EV7", "EW7", "EX7", "EY7", "EZ7", "FA7", "FB7", "FC7", "FD7", "FE7", "FF7", "FG7", "FH7", "FI7", "FJ7", "FK7", "FL7", "FM7", "FN7", "FO7", "FP7", "FQ7", "FR7", "FS7", "FT7", "FU7", "FV7", "FW7", "FX7","FY7","FZ7","GA7","GB7","GC7","GD7","GE7","GF7","GG7","GH7","GI7","GJ7","GK7","GL7","GM7","GN7","GO7","GP7","GQ7","GR7","GS7","GT7","GU7","GV7","GW7","GX7","GY7","GZ7","HA7","HB7","HC7","HD7","HE7","HF7","HG7","HH7","HI7","HJ7","HK7","HL7"].map((key) => {
        if (key === "A7") {
          const str = key;
          const colum = str.slice(0, str.length - 1);
          const dobCol1 = dynamicsheet.getColumn(colum);
          const dobCol2 = worksheet.getColumn(colum);
          dobCol1.width = 25;
          dobCol2.width = 25;
        } else if (key === "HI7") {
          const str = key;
          const colum = str.slice(0, str.length - 1);
          const dobCol1 = dynamicsheet.getColumn(colum);
          dobCol1.width = 40;
        } else if (key === "HJ7" || key === "HK7" || key === "HL7") {
          const str = key;
          const colum = str.slice(0, str.length - 1);
          const dobCol1 = dynamicsheet.getColumn(colum);
          dobCol1.width = 45;
        } else if (key === "H7") {
          const str = key;
          const colum = str.slice(0, str.length - 1);
          const dobCol1 = worksheet.getColumn(colum);
          dobCol1.width = 40;
        } else {
          const str = key;
          const colum = str.slice(0, str.length - 1);
          const dobCol1 = dynamicsheet.getColumn(colum);
          dobCol1.width = 15;
        }
        if (
          key === "A7" ||
          key === "B7" ||
          key === "C7" ||
          key === "D7" ||
          key === "E7" ||
          key === "F7" ||
          key === "G7" ||
          key === "H7" ||
          key === "I7" ||
          key === "J7" ||
          key === "K7" ||
          key === "L7" ||
          key === "M7" ||
          key === "N7" ||
          key === "O7" ||
          key === "P7" ||
          key === "Q7" ||
          key === "R7" ||
          key === "S7" ||
          key === "T7" ||
          key === "U7" ||
          key === "V7" ||
          key === "W7" ||
          key === "X7" ||
          key === "Y7" ||
          key === "Z7" ||
          key === "AA7" ||
          key === "AB7" ||
          key === "AC7" ||
          key === "AD7" ||
          key === "AE7" ||
          key === "AF7" ||
          key === "AG7" ||
          key === "AH7" ||
          key === "AI7" ||
          key === "AJ7" ||
          key === "AK7" ||
          key === "AL7" ||
          key === "AM7" ||
          key === "AN7" ||
          key === "AO7" ||
          key === "AP7" ||
          key === "AQ7" ||
          key === "AR7" ||
          key === "AS7" ||
          key === "AT7" ||
          key === "AU7" ||
          key === "AV7" ||
          key === "AW7" ||
          key === "AX7" ||
          key === "AY7" ||
          key === "AZ7" ||
          key === "BA7" ||
          key === "BB7" ||
          key === "BC7" ||
          key === "BD7" ||
          key === "BE7" ||
          key === "BF7" ||
          key === "BG7" ||
          key === "BH7" ||
          key === "BI7" ||
          key === "BJ7" ||
          key === "BK7" ||
          key === "BL7" ||
          key === "BM7" ||
          key === "BN7" ||
          key === "BO7" ||
          key === "BP7" ||
          key === "BQ7" ||
          key === "BR7" ||
          key === "BS7" ||
          key === "BT7" ||
          key === "BU7" ||
          key === "BV7" ||
          key === "BW7" ||
          key === "BX7" ||
          key === "BY7" ||
          key === "BZ7" ||
          key === "CA7" ||
          key === "CB7" ||
          key === "CC7" ||
          key === "CD7" ||
          key === "CE7" ||
          key === "CF7" ||
          key === "CG7" ||
          key === "CH7" ||
          key === "CI7" ||
          key === "CJ7" ||
          key === "CK7" ||
          key === "CL7" ||
          key === "CM7" ||
          key === "CN7" ||
          key === "CO7" ||
          key === "CP7" ||
          key === "CQ7" ||
          key === "CR7" ||
          key === "CS7" ||
          key === "CT7" ||
          key === "CU7" ||
          key === "CV7" ||
          key === "CW7" ||
          key === "CX7" ||
          key === "CY7" ||
          key === "CZ7" ||
          key === "DA7" ||
          key === "DB7" ||
          key === "DC7" ||
          key === "DD7" ||
          key === "DE7" ||
          key === "DF7" ||
          key === "DG7" ||
          key === "DH7" ||
          key === "DI7" ||
          key === "DJ7" ||
          key === "DK7" ||
          key === "DL7" ||
          key === "DM7" ||
          key === "DN7" ||
          key === "DO7" ||
          key === "DP7" ||
          key === "DQ7" ||
          key === "DR7" ||
          key === "DS7" ||
          key === "DT7" ||
          key === "DU7" ||
          key === "DV7" ||
          key === "DW7" ||
          key === "DX7" ||
          key === "DY7" ||
          key === "DZ7" ||
          key === "EA7" ||
          key === "EB7" ||
          key === "EC7" ||
          key === "ED7" ||
          key === "EE7" ||
          key === "EF7" ||
          key === "EG7" ||
          key === "EH7" ||
          key === "EI7" ||
          key === "EJ7" ||
          key === "EK7" ||
          key === "EL7" ||
          key === "EM7" ||
          key === "EN7" ||
          key === "EO7" ||
          key === "EP7" ||
          key === "EQ7" ||
          key === "ER7" ||
          key === "ES7" ||
          key === "ET7" ||
          key === "EU7" ||
          key === "EV7" ||
          key === "EW7" ||
          key === "EX7" ||
          key === "EY7" ||
          key === "EZ7" ||
          key === "FA7" ||
          key === "FB7" ||
          key === "FC7" ||
          key === "FD7" ||
          key === "FE7" ||
          key === "FF7" ||
          key === "FG7" ||
          key === "FH7" ||
          key === "FI7" ||
          key === "FJ7" ||
          key === "FK7" ||
          key === "FL7" ||
          key === "FM7" ||
          key === "FO7" ||
          key === "FP7" ||
          key === "FQ7" ||
          key === "FR7" ||
          key === "FS7" ||
          key === "FT7" ||
          key === "FU7" ||
          key === "FN7" ||
          key === "FV7" ||
          key === "FW7" ||
          key === "FX7" || 
          key === "FY7" || 
          key === "FZ7" ||
          key === "GA7" ||
          key === "GB7" ||
          key === "GC7" ||
          key === "GD7" ||
          key === "GE7" ||
          key === "GF7" ||
          key === "GG7" ||
          key === "GH7" ||
          key === "GI7" ||
          key === "GJ7" ||
          key === "GK7" ||
          key === "GL7" ||
          key === "GM7" ||
          key === "GN7" ||
          key === "GO7" ||
          key === "GP7" ||
          key === "GQ7" ||
          key === "GR7" ||
          key === "GS7" ||
          key === "GT7" ||
          key === "GU7" ||
          key === "GV7" ||
          key === "GW7" ||
          key === "GX7" ||
          key === "GY7" ||
          key === "GZ7" ||
          key === "HA7" ||
          key === "HB7" ||
          key === "HC7" ||
          key === "HD7" ||
          key === "HE7" ||
          key === "HF7" ||
          key === "HG7" ||
          key === "HH7" ||
          key === "HI7" ||
          key === "HJ7" ||
          key === "HK7" ||
          key === "HL7" 
        ) {
          formatCellwithBold(dynamicsheet, key, "000000", 10);
          dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
        }
      });
      ["G5:V6", "W5:AN6", "AO5:AW6", "AX5:BG6", "BH5:CD6", "CE5:CM6", "CN5:DE6", "DF5:DS6", "DT5:EF6", "EG5:EZ6", "FA5:FM6", "FN5:GA6", "GB5:GN6","GO5:HH6", "HI5:HI6", "HJ5:HJ6","HK5:HK6","HL5:HL6"].map((key) => {
        dynamicsheet.mergeCells(key);
        if (key === "G5:V6" || key === "AO5:AW6" || key === "BH5:CD6" || key === "CN5:DE6" || key === "DT5:EF6" || key === "FA5:FM6" || key ==="GB5:GN6") {
          dynamicsheet.getCell(key).fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "FF9537" }
          };
          formatCellwithBold(dynamicsheet, key, "FFFFFF", 13);
        }
        if (key === "W5:AN6" || key === "AX5:BG6" || key === "CE5:CM6" || key === "DF5:DS6" || key === "EG5:EZ6" || key === "FN5:GA6"|| key === "GO5:HH6") {
          formatCellwithBold(dynamicsheet, key, "FF9537", 13);
        }
        if (key === "HI5:HI6") {
          dynamicsheet.getCell(key).fill = {
            type: "pattern",
            pattern: "solid",
            fgColor: { argb: "3B5AA9" }
          };
          formatCellwithBold(dynamicsheet, key, "FFFFFF", 13);
        }
        if (key === "HJ5:HJ6") {
          formatCellBold(dynamicsheet, key, "FF0000", 13);
        }
        if (key === "HK5:HK6" || key === "HL5:HL6") {
          formatCellBold(dynamicsheet, key, "00FF00", 13);
        }
        dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
      });
      await getLocationsExcel(this.quoteoptions[i].Id, dynamicsheet, worksheetvisibleflag, worksheet, this.quoteoptions, i, summryrow, setSummary, this.error, this.quoteoptions.length,this.isA3SplPricingUser,this.isfilterclosedwon);
      if (i === this.quoteoptions.length - 1) {
        const buf = await workbook.xlsx.writeBuffer();
         if(this.closedWonSucess && this.quoteoptions[i].Id){  
        const currentFileName = `${this.qrRec.fields.Name.value}-${this.date2str(new Date(), "MMM dd yyyy - hh_mm_ss")}.xlsx`;
        this.newFileName = `Certified Locations and Products-${currentFileName}`;
        console.log('excelclosedwon',this.closedWonSucess);
          this.handleExcelSave(buf,this.newFileName);
        }
        else if(this.quoteoptions[i].Id){
        saveAs(new Blob([buf]), `${this.qrRec.fields.Company_Name__c.value}-${this.qrRec.fields.Name.value}-${this.date2str(new Date(), "MMM dd yyyy - hh_mm_ss")}.xlsx`);
        const eventToDispatch = new CustomEvent("xlexportcomplete", { detail: { quoteOptions: this.quoteoptions.length } });
        this.dispatchEvent(eventToDispatch);
      }
    }
  }
  }
   handleExcelSave(bufferD,fileName){
    const base64Data = this.bufferToBase64(bufferD);
    excelDocSave({blobVersionData:base64Data,titleName:fileName,quoteRecId:this.quoterequestid})
    .then(response=>{
      console.log(response);
    }).catch(error=>{
      console.log(error)
    })
  }
 
 bufferToBase64(buffer){
   const bytes = new Uint8Array(buffer);
        let binary = '';
        for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
 }
  getQuoteOptions(isA3SplPricingUser) {
    let isSalesRep = false;
    let isSalesEngOrEX = false;
    if (isA3SplPricingUser === "A3_SalesRep_CRE" || isA3SplPricingUser === "A3_Premier_CRE" || isA3SplPricingUser === "A3_SalesRepManager_CRE" || isA3SplPricingUser === "A3_ChannelSalesRep_CRE" || isA3SplPricingUser === "A3_ChannelSalesRepManager_CRE" || isA3SplPricingUser === 'A3_GRID_SalesRep_CRE') {
      isSalesRep = true;
      isSalesEngOrEX = false;
    }
    if (isA3SplPricingUser === "A3_SalesEng_CRE" || isA3SplPricingUser === "A3_SplPricing_CRE" || isA3SplPricingUser === "A3_OMAnalyst_CRE" || isA3SplPricingUser === "A3_OMAnalystManager_CRE" || isA3SplPricingUser === "A3_ChannelsQuoter_CRE" || isA3SplPricingUser === 'A3_GRID_SalesRep_CRE') {
      isSalesRep = false;
      isSalesEngOrEX = true;
    }
    fetchQuoteOptions({ recordId: this.quoterequestid })
      .then((result) => {
        if (isSalesRep) {
          this.exportdata1(isA3SplPricingUser);
        } else if (isSalesEngOrEX) {
          getQuotePricingData({ recordId: this.quoterequestid })
            .then((quoteOptionsData) => {
              this.salesEngProduct = [];
              this.exportdata1(isA3SplPricingUser);
            })
            .catch((error) => {
              console.log(error);
            });
        }
      })
      .catch((error) => {
        console.log(error);
      })
      .finally((error) => {
        console.log(error);
      });
  }
}