var footerrowcount;
var summaryrow;
export function numberWithFormat(val) {
  return val.toString().replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",");
}

export function uniqueBy(arr, fn) {
  var unique = {};
  var distinct = [];
  arr.forEach(function (x) {
    var key = fn(x);
    if (!unique[key]) {
      distinct.push(key);
      unique[key] = true;
    }
  });
  return distinct;
}
export function getCurrencyfarmat(val, formatComma = false) {
  if (val) {
    let currval = val.toString();
    if (!currval.includes(".")) {
      return formatComma ? "$" + numberWithFormat(val) + ".00" : "$" + val.toLocaleString() + ".00";
    } else {
      return formatComma ? "$" + numberWithFormat(parseFloat(val).toFixed(2)) : "$" + parseFloat(val).toFixed(2);
    }
  }
  return "$0.00";
}

export function getpercentagefarmat(val) {
  if (val) {
    return val.toFixed(2) + "%";
  }
  return "0.00%";
}

export function formatCell(dynamicsheet, key, color = "000000", size = 10, vertical = "left", horizontal = "left") {
  {
    dynamicsheet.getCell(key).font = {
      color: { argb: color },
      size: size
    };
    dynamicsheet.getCell(key).alignment = { vertical: vertical, horizontal: horizontal };
  }
}

export function formatCellBold(dynamicsheet, key, color = "000000", size = 10, bold = false) {
  {
    dynamicsheet.getCell(key).font = {
      color: { argb: color },
      size: size,
      bold: bold
    };
    if (key === "DS5:DS6") {
      dynamicsheet.getCell(key).font = {
        color: { argb: color },
        size: size,
        bold: true
      };
    }
    if (key === "DT5:DT6" || key === "DU5:DU6") {
      dynamicsheet.getCell(key).font = {
        color: { argb: color },
        size: size,
        bold: true
      };
    }
  }
}
export function formatCellwithBold(dynamicsheet, key, color = "000000", size = 10, bold = true) {
  {
    dynamicsheet.getCell(key).font = {
      color: { argb: color },
      size: size,
      bold: bold
    };
    if (key === "U7" || key === "V7" || key === "AM7" || key === "AN7" || key === "AV7" || key === "AW7" || key === "BF7" || key === "BG7" || key === "CC7" || key === "CD7" || key === "CL7" || key === "CM7" || key === "DD7" || key === "DE7" || key === "DR7" || key === "DS7" || key === "EE7" || key === "EF7" || key === "EY7" || key === "EZ7" || key === "FL7" || key === "FM7" || key === "FZ7" || key === "GA7" || key === "GM7" || key === "GN7" || key === "HH7" || key === "HG7") {
      dynamicsheet.getCell(key).font = {
        color: { argb: "50A038" },
        size: size,
        bold: bold
      };
    }
  }
}

function countStrings(arr) {
  let stringCount = 0;
  for (let i = 0; i < arr.length; i++) {
    if (typeof arr[i] === "string") {
      stringCount++;
    }
  }
  return stringCount;
}
function sumBy(collection, iteratee) {
  return collection.reduce((sum, element) => {
    const value = typeof iteratee === 'function' ? iteratee(element) : element[iteratee];
    return sum + (isNaN(value) ? 0 : Number(value));
  }, 0);
}

export function formatQuoteOptionTableHeaders(rowcount, dynamicsheet) {
  [
    "C" + rowcount,
    "D" + rowcount,
    "E" + rowcount,
    "F" + rowcount,
    "G" + rowcount,
    "H" + rowcount,
    "I" + rowcount,
    "J" + rowcount,
    "K" + rowcount,
    "L" + rowcount,
    "M" + rowcount,
    "N" + rowcount,
    "O" + rowcount,
    "P" + rowcount,
    "Q" + rowcount,
    "R" + rowcount,
    "S" + rowcount,
    "T" + rowcount,
    "U" + rowcount,
    "V" + rowcount,
    "W" + rowcount,
    "X" + rowcount,
    "Y" + rowcount,
    "Z" + rowcount,
    "AA" + rowcount,
    "AB" + rowcount,
    "AC" + rowcount,
    "AD" + rowcount,
    "AE" + rowcount,
    "AF" + rowcount,
    "AG" + rowcount,
    "AH" + rowcount,
    "AI" + rowcount,
    "AJ" + rowcount,
    "AK" + rowcount,
    "AL" + rowcount,
    "AM" + rowcount,
    "AN" + rowcount,
    "AO" + rowcount,
    "AP" + rowcount,
    "AQ" + rowcount,
    "AR" + rowcount,
    "AS" + rowcount,
    "AT" + rowcount,
    "AU" + rowcount,
    "AV" + rowcount,
    "AW" + rowcount,
    "AX" + rowcount,
    "AY" + rowcount,
    "AZ" + rowcount,
    "BA" + rowcount,
    "BB" + rowcount,
    "BC" + rowcount,
    "BD" + rowcount,
    "BE" + rowcount,
    "BF" + rowcount,
    "BG" + rowcount,
    "BH" + rowcount,
    "BI" + rowcount,
    "BJ" + rowcount,
    "BK" + rowcount,
    "BL" + rowcount,
    "BM" + rowcount,
    "BN" + rowcount,
    "BO" + rowcount,
    "BP" + rowcount,
    "BQ" + rowcount,
    "BR" + rowcount,
    "BS" + rowcount,
    "BT" + rowcount,
    "BU" + rowcount,
    "BV" + rowcount,
    "BW" + rowcount,
    "BX" + rowcount,
    "BY" + rowcount,
    "BZ" + rowcount,
    "CA" + rowcount,
    "CB" + rowcount,
    "CC" + rowcount,
    "CD" + rowcount,
    "CE" + rowcount,
    "CF" + rowcount,
    "CG" + rowcount,
    "CH" + rowcount,
    "CI" + rowcount,
    "CJ" + rowcount,
    "CK" + rowcount,
    "CL" + rowcount,
    "CM" + rowcount,
    "CN" + rowcount,
    "CO" + rowcount,
    "CP" + rowcount,
    "CQ" + rowcount,
    "CR" + rowcount,
    "CS" + rowcount,
    "CT" + rowcount,
    "CU" + rowcount,
    "CV" + rowcount,
    "CW" + rowcount,
    "CX" + rowcount,
    "CY" + rowcount,
    "CZ" + rowcount,
    "DA" + rowcount,
    "DB" + rowcount,
    "DC" + rowcount,
    "DD" + rowcount,
    "DE" + rowcount,
    "DF" + rowcount,
    "DG" + rowcount,
    "DH" + rowcount,
    "DI" + rowcount,
    "DJ" + rowcount,
    "DK" + rowcount,
    "DL" + rowcount,
    "DM" + rowcount,
    "DN" + rowcount,
    "DO" + rowcount,
    "DP" + rowcount,
    "DQ" + rowcount,
    "DR" + rowcount,
    "DS" + rowcount,
    "DT" + rowcount,
    "DU" + rowcount,
    "DV" + rowcount,
    "DW" + rowcount,
    "DX" + rowcount,
    "DY" + rowcount,
    "DZ" + rowcount,
    "EA" + rowcount,
    "EB" + rowcount,
    "EC" + rowcount,
    "ED" + rowcount,
    "EE" + rowcount,
    "EF" + rowcount,
    "EG" + rowcount,
    "EH" + rowcount,
    "EI" + rowcount,
    "EJ" + rowcount,
    "EK" + rowcount,
    "EL" + rowcount,
    "EM" + rowcount,
    "EN" + rowcount,
    "EO" + rowcount,
    "EP" + rowcount,
    "EQ" + rowcount,
    "ER" + rowcount,
    "ES" + rowcount,
    "ET" + rowcount,
    "EU" + rowcount,
    "EV" + rowcount,
    "EW" + rowcount,
    "EX" + rowcount,
    "EY" + rowcount,
    "EZ" + rowcount,
    "FA" + rowcount,
    "FB" + rowcount,
    "FC" + rowcount,
    "FD" + rowcount,
    "FE" + rowcount,
    "FF" + rowcount,
    "FG" + rowcount,
    "FH" + rowcount,
    "FI" + rowcount,
    "FJ" + rowcount,
    "FK" + rowcount,
    "FL" + rowcount,
    "FM" + rowcount,
    "FN" + rowcount,
    "FO" + rowcount,
    "FQ" + rowcount,
    "FR" + rowcount,
    "FT" + rowcount,
    "FU" + rowcount,
    "FV" + rowcount,
    "FW" + rowcount,
    "FX" + rowcount,
    "FY" + rowcount,
    "FZ" + rowcount,
    "GA" + rowcount,
    "GB" + rowcount,
    "GC" + rowcount,
    "GD" + rowcount,
    "GE" + rowcount,
    "GF" + rowcount,
    "GG" + rowcount,
    "GH" + rowcount,
    "GI" + rowcount,
    "GJ" + rowcount,
    "GK" + rowcount,
    "GL" + rowcount,
    "GM" + rowcount,
    "GN" + rowcount,
    "GO" + rowcount,
    "GP" + rowcount,
    "GQ" + rowcount,
    "GR" + rowcount,
    "GS" + rowcount,
    "GT" + rowcount,
    "GU" + rowcount,
    "GV" + rowcount,
    "GW" + rowcount,
    "GX" + rowcount,
    "GY" + rowcount,
    "GZ" + rowcount,
    "HA" + rowcount,
    "HB" + rowcount,
    "HC" + rowcount,
    "HD" + rowcount,
    "HE" + rowcount,
    "HF" + rowcount,
    "HG" + rowcount,
    "HH" + rowcount,
    "HI" + rowcount,
    "HJ" + rowcount,
    "HK" + rowcount,
    "HL" + rowcount
  ].map((key) => formatCell(dynamicsheet, key, "000000", 10, "middle", "center"));
["B" + rowcount,"FP" + rowcount,"FS" + rowcount].map((key) => formatCell(dynamicsheet, key, "000000", 10, "middle", "left"));
}

export function excelHeaders(dynamicsheet) {
  dynamicsheet.getCell("G5").value = "Broadband ";
  dynamicsheet.getCell("W5").value = "DIA";
  dynamicsheet.getCell("AO5").value = "edgeboot";
  dynamicsheet.getCell("AX5").value = "EPIK";
  dynamicsheet.getCell("BH5").value = "ePOTS";
  dynamicsheet.getCell("CE5").value = "Equipment";
  dynamicsheet.getCell("CN5").value = "GRID";
  dynamicsheet.getCell("DF5").value = "GSE";
  dynamicsheet.getCell("DT5").value = "Guardian";
  dynamicsheet.getCell("EG5").value = "Mobility";
  dynamicsheet.getCell("FA5").value = "PIP";
  dynamicsheet.getCell("FN5").value = "POTS";
  dynamicsheet.getCell("GB5").value = "Voice over Cable Line";
  dynamicsheet.getCell("GO5").value = "VOIP";
  dynamicsheet.getCell("A7").value = "Location / Store Number";
  dynamicsheet.getCell("B7").value = "Address 1";
  dynamicsheet.getCell("C7").value = "Address 2";
  dynamicsheet.getCell("D7").value = "City";
  dynamicsheet.getCell("E7").value = "State";
  dynamicsheet.getCell("F7").value = "ZIP";
  dynamicsheet.getCell("G7").value = "QTY"; // Starts Broadband
  dynamicsheet.getCell("H7").value = "Term";
  dynamicsheet.getCell("I7").value = "Provider";
  dynamicsheet.getCell("J7").value = "Bandwidth Download   Bandwidth Upload";
  dynamicsheet.getCell("K7").value = "Circuit";
  dynamicsheet.getCell("L7").value = "IP Type";
  dynamicsheet.getCell("M7").value = "IP Block";
  dynamicsheet.getCell("N7").value = "IP";
  dynamicsheet.getCell("O7").value = "Modem";
  dynamicsheet.getCell("P7").value = "Internet Access Recovery";
  dynamicsheet.getCell("Q7").value = "Service Add On";   
  dynamicsheet.getCell("R7").value = "Add On Service MRC";
  dynamicsheet.getCell("S7").value = "Total MRC";
  dynamicsheet.getCell("T7").value = "Current Total";
  dynamicsheet.getCell("U7").value = "Savings $";
  dynamicsheet.getCell("V7").value = "Savings %";
  dynamicsheet.getCell("W7").value = "QTY"; //Starts DIA
  dynamicsheet.getCell("X7").value = "Term";
  dynamicsheet.getCell("Y7").value = "Provider";
  dynamicsheet.getCell("Z7").value = "Access Type";
  dynamicsheet.getCell("AA7").value = "Bandwidth";
  dynamicsheet.getCell("AB7").value = "On Net";
  dynamicsheet.getCell("AC7").value = "Circuit";
  dynamicsheet.getCell("AD7").value = "IP Block";
  dynamicsheet.getCell("AE7").value = "IP";
  dynamicsheet.getCell("AF7").value = "Router Added";
  dynamicsheet.getCell("AG7").value = "Equipment";
  dynamicsheet.getCell("AH7").value = "Carrier Surcharge Recovery";
  dynamicsheet.getCell("AI7").value = "Service Add On";
  dynamicsheet.getCell("AJ7").value = "Add On Service MRC";
  dynamicsheet.getCell("AK7").value = "Total MRC";
  dynamicsheet.getCell("AL7").value = "Current Total";
  dynamicsheet.getCell("AM7").value = "Savings $";
  dynamicsheet.getCell("AN7").value = "Savings %";
  dynamicsheet.getCell("AO7").value = "QTY";//edgeboot start
  dynamicsheet.getCell("AP7").value = "Term";
  dynamicsheet.getCell("AQ7").value = "Provider";
  dynamicsheet.getCell("AR7").value = "Service MRC";
  dynamicsheet.getCell("AS7").value = "Port MRC";
  dynamicsheet.getCell("AT7").value = "Total MRC";
  dynamicsheet.getCell("AU7").value = "Current Total";
  dynamicsheet.getCell("AV7").value = "Savings $";
  dynamicsheet.getCell("AW7").value = "Savings %";
  dynamicsheet.getCell("AX7").value = "QTY"; //Starts EPIK
  dynamicsheet.getCell("AY7").value = "Term";
  dynamicsheet.getCell("AZ7").value = "EPIK Line Charge";
  dynamicsheet.getCell("BA7").value = "500 MB LTE Plan";
  dynamicsheet.getCell("BB7").value = "Guardian";
  dynamicsheet.getCell("BC7").value = "Non Pub/Listings";
  dynamicsheet.getCell("BD7").value = "Total MRC";
  dynamicsheet.getCell("BE7").value = "Current Total";
  dynamicsheet.getCell("BF7").value = "Savings $";
  dynamicsheet.getCell("BG7").value = "Savings %";
  dynamicsheet.getCell("BH7").value = "QTY"; //Starts ePOTS
  dynamicsheet.getCell("BI7").value = "Term";
  dynamicsheet.getCell("BJ7").value = "Service MRC";
  dynamicsheet.getCell("BK7").value = "QTY";
  dynamicsheet.getCell("BL7").value = "Local Usage Package";
  dynamicsheet.getCell("BM7").value = "QTY";
  dynamicsheet.getCell("BN7").value = "LD Usage Package";
  dynamicsheet.getCell("BO7").value = "QTY";
  dynamicsheet.getCell("BP7").value = "All Usage Package";
  dynamicsheet.getCell("BQ7").value = "QTY";
  dynamicsheet.getCell("BR7").value = "Voicemail";
  dynamicsheet.getCell("BS7").value = "QTY";
  dynamicsheet.getCell("BT7").value = "Easy AA";
  dynamicsheet.getCell("BU7").value = "QTY";
  dynamicsheet.getCell("BV7").value = "Premium AA";
  dynamicsheet.getCell("BW7").value = "Feature MRC";
  dynamicsheet.getCell("BX7").value = "EQUIP MRC";
  dynamicsheet.getCell("BY7").value = "NAC";
  dynamicsheet.getCell("BZ7").value = "ASF/PTA";
  dynamicsheet.getCell("CA7").value = "Total MRC";
  dynamicsheet.getCell("CB7").value = "Current Total";
  dynamicsheet.getCell("CC7").value = "Savings $";
  dynamicsheet.getCell("CD7").value = "Savings %";
  dynamicsheet.getCell("CE7").value = "QTY"; //Starts Equipment
  dynamicsheet.getCell("CF7").value = "Term";
  dynamicsheet.getCell("CG7").value = "Manufacturer";
  dynamicsheet.getCell("CH7").value = "Model";
  dynamicsheet.getCell("CI7").value = "Equipment MRC";
  dynamicsheet.getCell("CJ7").value = "Total MRC";
  dynamicsheet.getCell("CK7").value = "Current Total";
  dynamicsheet.getCell("CL7").value = "Savings $";
  dynamicsheet.getCell("CM7").value = "Savings %";
  dynamicsheet.getCell("CN7").value = "QTY"; //Starts GRID
  dynamicsheet.getCell("CO7").value = "Term";
  dynamicsheet.getCell("CP7").value = "Access Type";
  dynamicsheet.getCell("CQ7").value = "IP Type";
  dynamicsheet.getCell("CR7").value = "IP Block";
  dynamicsheet.getCell("CS7").value = "Voice/CPE Package";
  dynamicsheet.getCell("CT7").value = "Property Name";
  dynamicsheet.getCell("CU7").value = "Carrier";
  dynamicsheet.getCell("CV7").value = "Bandwidth";
  dynamicsheet.getCell("CW7").value = "Service MRC";
  dynamicsheet.getCell("CX7").value = "IP";
  dynamicsheet.getCell("CY7").value = "Voice MRC";
  dynamicsheet.getCell("CZ7").value = "Equipment MRC";
  dynamicsheet.getCell("DA7").value = "Carrier Surcharge Recovery";
  dynamicsheet.getCell("DB7").value = "Total MRC";
  dynamicsheet.getCell("DC7").value = "Current Total";
  dynamicsheet.getCell("DD7").value = "Savings $";
  dynamicsheet.getCell("DE7").value = "Savings %";
  dynamicsheet.getCell("DF7").value = "QTY"; //Starts GSE
  dynamicsheet.getCell("DG7").value = "Term";
  dynamicsheet.getCell("DH7").value = "Provider";
  dynamicsheet.getCell("DI7").value = "Access Type";
  dynamicsheet.getCell("DJ7").value = "Bandwidth";
  dynamicsheet.getCell("DK7").value = "Service Level Tier";
  dynamicsheet.getCell("DL7").value = "Circuit MRC";
  dynamicsheet.getCell("DM7").value = "Class Of Service MRC";
  dynamicsheet.getCell("DN7").value = "COS Type";
  dynamicsheet.getCell("DO7").value = "Carrier Surcharge Recovery";
  dynamicsheet.getCell("DP7").value = "Total MRC";
  dynamicsheet.getCell("DQ7").value = "Current Total";
  dynamicsheet.getCell("DR7").value = "Savings $";
  dynamicsheet.getCell("DS7").value = "Savings %";
  dynamicsheet.getCell("DT7").value = "QTY"; //Starts Guardian
  dynamicsheet.getCell("DU7").value = "Term";
  dynamicsheet.getCell("DV7").value = "Manufacturer";
  dynamicsheet.getCell("DW7").value = "Service";
  dynamicsheet.getCell("DX7").value = "Service MRC";
  dynamicsheet.getCell("DY7").value = "Feature QTY";
  dynamicsheet.getCell("DZ7").value = "Feature(s)";
  dynamicsheet.getCell("EA7").value = "Feature MRC";
  dynamicsheet.getCell("EB7").value = "High Availability";
  dynamicsheet.getCell("EC7").value = "Total MRC";
  dynamicsheet.getCell("ED7").value = "Current Total";
  dynamicsheet.getCell("EE7").value = "Savings $";
  dynamicsheet.getCell("EF7").value = "Savings %";
  dynamicsheet.getCell("EG7").value = "QTY"; //Starts Mobility
  dynamicsheet.getCell("EH7").value = "Term";
  dynamicsheet.getCell("EI7").value = "Service Category";
  dynamicsheet.getCell("EJ7").value = "Device Type";
  dynamicsheet.getCell("EK7").value = "Conversion Type";
  dynamicsheet.getCell("EL7").value = "Current Carrier";
  dynamicsheet.getCell("EM7").value = "New Carrier";
  dynamicsheet.getCell("EN7").value = "Mobility Plan";
  dynamicsheet.getCell("EO7").value = "Mobility Device";
  dynamicsheet.getCell("EP7").value = "Optional Services";
  dynamicsheet.getCell("EQ7").value = "EQUIP MRC";
  dynamicsheet.getCell("ER7").value = "Secondary SIM";
  dynamicsheet.getCell("ES7").value = "Secondary Carrier";
  dynamicsheet.getCell("ET7").value = "Secondary Mobility Plan";
  dynamicsheet.getCell("EU7").value = "Service MRC";
  dynamicsheet.getCell("EV7").value = "Static IP";
  dynamicsheet.getCell("EW7").value = "Total MRC";
  dynamicsheet.getCell("EX7").value = "Current Total";
  dynamicsheet.getCell("EY7").value = "Savings $";
  dynamicsheet.getCell("EZ7").value = "Savings %";
  dynamicsheet.getCell("FA7").value = "QTY"; //Starts PIP
  dynamicsheet.getCell("FB7").value = "Term";
  dynamicsheet.getCell("FC7").value = "Provider";
  dynamicsheet.getCell("FD7").value = "Access Type";
  dynamicsheet.getCell("FE7").value = "Bandwidth";
  dynamicsheet.getCell("FF7").value = "Service Level Tier";
  dynamicsheet.getCell("FG7").value = " Circuit MRC";
  dynamicsheet.getCell("FH7").value = "Class of Service";
  dynamicsheet.getCell("FI7").value = "Carrier Surcharge Recovery";
  dynamicsheet.getCell("FJ7").value = "Total MRC";
  dynamicsheet.getCell("FK7").value = "Current Total";
  dynamicsheet.getCell("FL7").value = "Savings $";
  dynamicsheet.getCell("FM7").value = "Savings %";
  dynamicsheet.getCell("FN7").value = "QTY"; //Starts POTS
  dynamicsheet.getCell("FO7").value = "Term";
  dynamicsheet.getCell("FP7").value = "Provider";
  dynamicsheet.getCell("FQ7").value = "Telephone #";
  dynamicsheet.getCell("FR7").value = "Flat Rate";
  dynamicsheet.getCell("FS7").value = "EUCL";
  dynamicsheet.getCell("FT7").value = "ARC";
  dynamicsheet.getCell("FU7").value = "LNP";
  dynamicsheet.getCell("FV7").value = "PTA/PTR";
  dynamicsheet.getCell("FW7").value = "PICC";
  dynamicsheet.getCell("FX7").value = "Total MRC";
  dynamicsheet.getCell("FY7").value = "Current Total";
  dynamicsheet.getCell("FZ7").value = "Savings $";
  dynamicsheet.getCell("GA7").value = "Savings %";
  dynamicsheet.getCell("GB7").value = "QTY"; // VOC
  dynamicsheet.getCell("GC7").value = "Term";
  dynamicsheet.getCell("GD7").value = "Provider";
  dynamicsheet.getCell("GE7").value = "Service MRC";
  dynamicsheet.getCell("GF7").value = "Feature(s)";
  dynamicsheet.getCell("GG7").value = "Feature MRC";
  dynamicsheet.getCell("GH7").value = "EUCL";
  dynamicsheet.getCell("GI7").value = "ARC";
  dynamicsheet.getCell("GJ7").value = "LNP";
  dynamicsheet.getCell("GK7").value = "Total MRC";
  dynamicsheet.getCell("GL7").value = "Current Total";
  dynamicsheet.getCell("GM7").value = "Savings $";
  dynamicsheet.getCell("GN7").value = "Savings %";
  //dynamicsheet.getCell("GO7").value = "";
  dynamicsheet.getCell("GP7").value = "Product Category"; //Start Voip
  dynamicsheet.getCell("GQ7").value = "QTY";
  dynamicsheet.getCell("GR7").value = "Term";
  dynamicsheet.getCell("GS7").value = "Service MRC";
  dynamicsheet.getCell("GT7").value = "Seat";
  dynamicsheet.getCell("GU7").value = "Call Path";
  dynamicsheet.getCell("GV7").value = "Feature QTY";
  dynamicsheet.getCell("GW7").value = "Feature(s)/ Usage";
  dynamicsheet.getCell("GX7").value = "Feature(s)-HPBX";
  dynamicsheet.getCell("GY7").value = "Feature MRC"
  dynamicsheet.getCell("GZ7").value = "Storage Options"
  dynamicsheet.getCell("HA7").value = "Equipment / Model #"
  dynamicsheet.getCell("HB7").value = "Equipment MRC"
  dynamicsheet.getCell("HC7").value = "NAC";
  dynamicsheet.getCell("HD7").value = "ASF/PTA";
  dynamicsheet.getCell("HE7").value = "Total MRC";
  dynamicsheet.getCell("HF7").value = "Current Total";
  dynamicsheet.getCell("HG7").value = "Savings $";
  dynamicsheet.getCell("HH7").value = "Savings %";  
  dynamicsheet.getCell("HI5").value = "Total Site MRC w/ All Services";
  dynamicsheet.getCell("HI7").value = "Total Site MRC";
  dynamicsheet.getCell("HJ5").value = "Current Total Site MRC w/ All Services";
  dynamicsheet.getCell("HK5").value = "Current Total Site Savings $ w/ All Services";
  dynamicsheet.getCell("HL5").value = "Current Total Site Savings % w/ All Services";
}
export function summarysect(ss,summryrow,worksheet,comparisionflag,sumfirstrowcv,sumlastrowcv,totQty,totGraMonthPrice,totHGraAnnuPrice,CurrentMonthlyTotal,CurrentAnnualTotal,CurrentSavingsDol,CurrentSavingsPer){
  if (ss.BBProdName === "Broadband") {
    worksheet.getCell("A" + summryrow).value = "Broadband";
    worksheet.getCell("C" + summryrow).value = ss.BBQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.BBMT, true);
    ss.BBAT = ss.BBMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.BBAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.BBCMT, true);
      ss.BBCAT = ss.BBCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.BBCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.BBCSD, true);
      ss.BBCSP = ss.BBCMT === 0 ? 0 : (ss.BBCSD / ss.BBCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.BBCSP, true);
    }
    summryrow++;
  }
  if (ss.DIAProdName === "DIA") {
    worksheet.getCell("A" + summryrow).value = "DIA";
    worksheet.getCell("C" + summryrow).value = ss.DIAQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.DIAMT, true);
    ss.DIAAT = ss.DIAMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.DIAAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.DAICMT, true);
      ss.DIACAT = ss.DAICMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.DIACAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.DAICSD, true);
      ss.DIACSP = ss.DAICMT === 0 ? 0 : (ss.DAICSD / ss.DAICMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.DIACSP, true);
    }
    summryrow++;
  }
  if (ss.EPIKProdName === "EPIK") {
    worksheet.getCell("A" + summryrow).value = "EPIK";
    worksheet.getCell("C" + summryrow).value = ss.EPIKQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EPIKMT, true);
    ss.EPIKAT = ss.EPIKMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EPIKAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EPIKCMT, true);
      ss.EPIKCAT = ss.EPIKCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EPIKCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EPIKCSD, true);
      ss.EPIKCSP = ss.EPIKCMT === 0 ? 0 : (ss.EPIKCSD / ss.EPIKCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EPIKCSP, true);
    }
    summryrow++;
  }
  if (ss.EquipmentProdName === "Equipment") {
    worksheet.getCell("A" + summryrow).value = "Equipment";
    worksheet.getCell("C" + summryrow).value = ss.EquipmentQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EQUIPMT, true);
    ss.EQUIPAT = ss.EQUIPMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EQUIPAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EQUIPCMT, true);
      ss.EQUIPCAT = ss.EQUIPCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EQUIPCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EQUIPCSD, true);
      ss.EQUIPCSP = ss.EQUIPCMT === 0 ? 0 : (ss.EQUIPCSD / ss.EQUIPCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EQUIPCSP, true);
    }
    summryrow++;
  }
  if (ss.EPOTSProdName === "ePOTS") {
    worksheet.getCell("A" + summryrow).value = "ePOTS";
    worksheet.getCell("C" + summryrow).value = ss.EPOTSQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EPOTSMT, true);
    ss.EPOTSAT = ss.EPOTSMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EPOTSAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EPOTCMT, true);
      ss.EPOTCAT = ss.EPOTCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EPOTCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EPOTCSD, true);
      ss.EPOTCSP = ss.EPOTCMT === 0 ? 0 : (ss.EPOTCSD / ss.EPOTCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EPOTCSP, true);
    }
    summryrow++;
  }
  if (ss.EDGEProdName === "edgeboot") {
    worksheet.getCell("A" + summryrow).value = "edgeboot";
    worksheet.getCell("C" + summryrow).value = ss.EDGEQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.EDGEMT, true);
    ss.EDGEAT = ss.EDGEMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.EDGEAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.EDGECMT, true);
      ss.EDGECAT = ss.EDGECMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.EDGECAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.EDGECSD, true);
      ss.EDGECSP = ss.EDGECMT === 0 ? 0 : (ss.EDGECSD / ss.EDGECMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.EDGECSP, true);
    }
    summryrow++;
  }
  if (ss.GSEProdName === "GSE") {
    worksheet.getCell("A" + summryrow).value = "GSE";
    worksheet.getCell("C" + summryrow).value = ss.GSEQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.GSEMT, true);
    ss.GSEAT = ss.GSEMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.GSEAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.GSECMT, true);
      ss.GSECAT = ss.GSECMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.GSECAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.GSECSD, true);
      ss.GSECSP = ss.GSECMT === 0 ? 0 : (ss.GSECSD / ss.GSECMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.GSECSP, true);
    }
    summryrow++;
  }
  if (ss.GRIDProdName === "GRID") {
    worksheet.getCell("A" + summryrow).value = "GRID";
    worksheet.getCell("C" + summryrow).value = ss.GRIDQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.GRIDMT, true);
    ss.GRIDAT = ss.GRIDMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.GRIDAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.GRIDCMT, true);
      ss.GRIDCAT = ss.GRIDCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.GRIDCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.GRIDCSD, true);
      ss.GRIDCSP = ss.GRIDCMT === 0 ? 0 : (ss.GRIDCSD / ss.GRIDCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.GRIDCSP, true);
    }
    summryrow++;
  }
  if (ss.GDNProdName === "Guardian") {
    worksheet.getCell("A" + summryrow).value = "Guardian";
    worksheet.getCell("C" + summryrow).value = ss.GDNQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.GDNMT, true);
    ss.GDNAT = ss.GDNMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.GDNAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.GDNCMT, true);
      ss.GDNCAT = ss.GDNCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.GDNCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.GDNCSD, true);
      ss.GDNCSP = ss.GDNCMT === 0 ? 0 : (ss.GDNCSD / ss.GDNCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.GDNCSP, true);
    }
    summryrow++;
  }
  if (ss.VOIPProdName === "HPBX") {
    worksheet.getCell("A" + summryrow).value = "HPBX";
    worksheet.getCell("C" + summryrow).value = ss.VOIPQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.VOIPMT, true);
    ss.VOIPAT = ss.VOIPMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.VOIPAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.VOIPCMT, true);
      ss.VOIPCAT = ss.VOIPCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.VOIPCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.VOIPCSD, true);
      ss.VOIPCSP = ss.VOIPCMT === 0 ? 0 : (ss.VOIPCSD / ss.VOIPCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.VOIPCSP, true);
    }
    summryrow++;
  }
  if (ss.MOBIProdName === "Mobility") {
    worksheet.getCell("A" + summryrow).value = "Mobility";
    worksheet.getCell("C" + summryrow).value = ss.MOBIQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.MOBIMT, true);
    ss.MOBIAT = ss.MOBIMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.MOBIAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.MOBICMT, true);
      ss.MOBICAT = ss.MOBICMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.MOBICAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.MOBICSD, true);
      ss.MOBICSP = ss.MOBICMT === 0 ? 0 : (ss.MOBICSD / ss.MOBICMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.MOBICSP, true);
    }
    summryrow++;
  }
  if (ss.OCTProdName === "Operator Connect for Microsoft Teams") {
    worksheet.getCell("A" + summryrow).value = "Operator Connect for Microsoft Teams";
    worksheet.getCell("C" + summryrow).value = ss.OCTQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.OCTMT, true);
    ss.OCTAT = ss.OCTMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.OCTAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.OCTCMT, true);
      ss.OCTCAT = ss.OCTCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.OCTCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.OCTCSD, true);
      ss.OCTCSP = ss.OCTCMT === 0 ? 0 : (ss.OCTCSD / ss.OCTCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.OCTCSP, true);
    }
    summryrow++;
  }
  if (ss.PIPProdName === "PIP") {
    worksheet.getCell("A" + summryrow).value = "PIP";
    worksheet.getCell("C" + summryrow).value = ss.PIPQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.PIPMT, true);
    ss.PIPAT = ss.PIPMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.PIPAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.PIPCMT, true);
      ss.PIPCAT = ss.PIPCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.PIPCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.PIPCSD, true);
      ss.PIPCSP = ss.PIPCMT === 0 ? 0 : (ss.PIPCSD / ss.PIPCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.PIPCSP, true);
    }
    summryrow++;
  }
  if (ss.POTSProdName === "POTS") {
    worksheet.getCell("A" + summryrow).value = "POTS";
    worksheet.getCell("C" + summryrow).value = ss.POTSQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.POTSMT, true);
    ss.POTSAT = ss.POTSMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.POTSAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.POTCMT, true);
      ss.POTCAT = ss.POTCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.POTCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.POTCSD, true);
      ss.POTCSP = ss.POTCMT === 0 ? 0 : (ss.POTCSD / ss.POTCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.POTCSP, true);
    }
    summryrow++;
  }
  if (ss.VOIPSIPProdName === "SIP") {
    worksheet.getCell("A" + summryrow).value = "SIP";
    worksheet.getCell("C" + summryrow).value = ss.VOIPSIPQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.VOIPSIPMT, true);
    ss.VOIPSIPAT = ss.VOIPSIPMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.VOIPSIPAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.VOIPSIPCMT, true);
      ss.VOIPSIPCAT = ss.VOIPSIPCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.VOIPSIPCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.VOIPSIPCSD, true);
      ss.VOIPSIPCSP = ss.VOIPSIPCMT === 0 ? 0 : (ss.VOIPSIPCSD / ss.VOIPSIPCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.VOIPSIPCSP, true);
    }
    summryrow++;
  }
  if (ss.VOCProdName === "Voice over Cable Line") {
    worksheet.getCell("A" + summryrow).value = "Voice over Cable Line";
    worksheet.getCell("C" + summryrow).value = ss.VOCQty;
    worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(ss.VOCMT, true);
    ss.VOCAT = ss.VOCMT * 12;
    worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(ss.VOCAT, true);
    if (comparisionflag === false) {
      worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(ss.VOCCMT, true);
      ss.VOCCAT = ss.VOCCMT * 12;
      worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(ss.VOCCAT, true);
      worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(ss.VOCCSD, true);
      ss.VOCCSP = ss.VOCCMT === 0 ? 0 : (ss.VOCCSD / ss.VOCCMT) * 100;
      worksheet.getCell("T" + summryrow).value = getpercentagefarmat(ss.VOCCSP, true);
    }
    summryrow++; 
  }
  totQty += Number(ss.BBQty) + Number(ss.DIAQty) + Number(ss.EPIKQty) + Number(ss.EquipmentQty) + Number(ss.GSEQty) + Number(ss.GRIDQty) + Number(ss.GDNQty) + Number(ss.MOBIQty) + Number(ss.PIPQty) + Number(ss.POTSQty) + Number(ss.EPOTSQty) + Number(ss.VOIPQty) + Number(ss.VOIPSIPQty)+ Number(ss.VOCQty)+ Number(ss.EDGEQty)+ Number(ss.OCTQty);
  totGraMonthPrice += Number(ss.BBMT) + Number(ss.DIAMT) + Number(ss.EPIKMT) + Number(ss.EQUIPMT) + Number(ss.GSEMT) + Number(ss.GRIDMT) + Number(ss.GDNMT) + Number(ss.MOBIMT) + Number(ss.PIPMT) + Number(ss.POTSMT) + Number(ss.EPOTSMT) + Number(ss.VOIPMT) + Number(ss.VOIPSIPMT)+ Number(ss.VOCMT)+ Number(ss.EDGEMT)+ Number(ss.OCTMT);
  totHGraAnnuPrice += Number(ss.BBAT) + Number(ss.DIAAT) + Number(ss.EPIKAT) + Number(ss.EQUIPAT) + Number(ss.GSEAT) + Number(ss.GRIDAT) + Number(ss.GDNAT) + Number(ss.MOBIAT) + Number(ss.PIPAT) + Number(ss.POTSAT) + Number(ss.EPOTSAT) + Number(ss.VOIPAT) + Number(ss.VOIPSIPAT)+ Number(ss.VOCAT)+ Number(ss.EDGEAT)+ Number(ss.OCTAT);
  CurrentMonthlyTotal += Number(ss.BBCMT) + Number(ss.DAICMT) + Number(ss.EPIKCMT) + Number(ss.EQUIPCMT) + Number(ss.GSECMT) + Number(ss.GRIDCMT) + Number(ss.GDNCMT) + Number(ss.MOBICMT) + Number(ss.PIPCMT) + Number(ss.POTCMT) + Number(ss.EPOTCMT) + Number(ss.VOIPCMT) + Number(ss.VOIPSIPCMT)+ Number(ss.VOCCMT)+ Number(ss.EDGECMT)+ Number(ss.OCTCMT);
  CurrentAnnualTotal += Number(ss.BBCAT) + Number(ss.DIACAT) + Number(ss.EPIKCAT) + Number(ss.EQUIPCAT) + Number(ss.GSECAT) + Number(ss.GRIDCAT) + Number(ss.GDNCAT) + Number(ss.MOBICAT) + Number(ss.PIPCAT) + Number(ss.POTCAT) + Number(ss.EPOTCAT) + Number(ss.VOIPCAT) + Number(ss.VOIPSIPCAT)+ Number(ss.VOCCAT)+ Number(ss.EDGECAT)+ Number(ss.OCTCAT);
  CurrentSavingsDol += Number(ss.BBCSD) + Number(ss.DAICSD) + Number(ss.EPIKCSD) + Number(ss.EQUIPCSD) + Number(ss.GSECSD) + Number(ss.GRIDCSD) + Number(ss.GDNCSD) + Number(ss.MOBICSD) + Number(ss.PIPCSD) + Number(ss.POTCSD) + Number(ss.EPOTCSD) + Number(ss.VOIPCSD) + Number(ss.VOIPSIPCSD)+ Number(ss.VOCCSD)+ Number(ss.EDGECSD)+ Number(ss.OCTCSD);
  CurrentSavingsPer += Number(ss.BBCSP) + Number(ss.DIACSP) + Number(ss.EPIKCSP) + Number(ss.EQUIPCSP) + Number(ss.GSECSP) + Number(ss.GRIDCSP) + Number(ss.GDNCSP) + Number(ss.MOBICSP) + Number(ss.PIPCSP) + Number(ss.POTCSP) + Number(ss.EPOTCSP) + Number(ss.VOIPCSP) + Number(ss.VOIPSIPCSP)+ Number(ss.VOCCSP)+ Number(ss.EDGECSP)+ Number(ss.OCTCSP);
  worksheet.getCell("A" + summryrow).value = "Total";
  worksheet.getCell("C" + summryrow).value = totQty;
  worksheet.getCell("E" + summryrow).value = getCurrencyfarmat(totGraMonthPrice, true);
  worksheet.getCell("H" + summryrow).value = getCurrencyfarmat(totHGraAnnuPrice, true);
  worksheet.getCell("K" + summryrow).value = getCurrencyfarmat(CurrentMonthlyTotal, true);
  worksheet.getCell("N" + summryrow).value = getCurrencyfarmat(CurrentAnnualTotal, true);
  worksheet.getCell("Q" + summryrow).value = getCurrencyfarmat(CurrentSavingsDol, true);
  CurrentSavingsPer = CurrentMonthlyTotal === 0 ? 0 : (CurrentSavingsDol / CurrentMonthlyTotal) * 100;
  worksheet.getCell("T" + summryrow).value = getpercentagefarmat(CurrentSavingsPer, true);
  
  if (comparisionflag === true) {
    ["K" + summryrow, "N" + summryrow, "Q" + summryrow, "T" + summryrow].map((key) => {
      worksheet.getCell(key).value = "";
    });}
  return summryrow++;
}
export function nrcSection(qlocOp,ss,objNRC,statrowcount, dynamicsheet,serAct,modelHpbx,equipQty,disEquip,hpbxqty,voipTn){
  if (objNRC.EquipProdName === "Equip") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Equipment";
    dynamicsheet.getCell("F" + statrowcount).value = "Modem $199.99 1 year cost will be loaded as an NRC";
    ["A" + statrowcount, "F" + statrowcount].map((key) => {
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
      formatCellBold(dynamicsheet, key, "000000", 10);
      if (key === "F" + statrowcount) dynamicsheet.getCell(key).alignment = { wrapText: true };
    });
  }
  if (objNRC.BBProdName === "Broadband") {
    console.log('test',objNRC.BBProdName)
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Broadband"; 
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.BBQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.BBTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.DIAProdName === "DIA") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "DIA";
    dynamicsheet.getCell("B" + statrowcount).value = objNRC.DIAAccessType;
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.DIAQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.DIATTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.EDGEProdName === "edgeboot") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "edgeboot";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.EDGEQty;
    dynamicsheet.getCell("D" + statrowcount).value = serAct;
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.EDGETTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.EPIKProdName === "EPIK") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "EPIK";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.EPIKQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.EPIKTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (ss.EquipmentProdName === "Equipment") {
    const NRCMAP = new Map();
    const NRCqtyMAP = new Map();
    const NRCcelMap = new Map();
    const NRCvalMAP = new Map();
    for (const [index, [key, value]] of Object.entries(Object.entries(qlocOp))) {
      for (let p = 0; p < value.length; p++) {
        if (value[p].Quote_Option_Item__r.Billing_Type__c === "NRC") {
          objNRC.EquipmentQty = objNRC.EquipmentQty + parseInt(value[p].Quote_Option_Item__r.Quantiy__c);
          objNRC.EquipmentTTNRC = objNRC.EquipmentTTNRC + Number(value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c);
          if (NRCMAP.has(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "")) {
            let temcel = NRCMAP.get(value[p].Quote_Option_Item__r.Product_Code__c);
            let existqty = NRCqtyMAP.get(value[p].Quote_Option_Item__r.Product_Code__c);
            let aval = existqty ? parseInt(existqty) : 0;
            console.log(p + "aval:", aval);
            let bval = value[p].Quote_Option_Item__r.Quantiy__c ? parseInt(value[p].Quote_Option_Item__r.Quantiy__c) : 0;
            console.log(p + "bval:", bval);
            dynamicsheet.getCell(temcel).value = aval + bval;
            let temNRCTTcel = NRCcelMap.get(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "");
            let existnrcval = NRCvalMAP.get(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "");
            let tempnrcval = existnrcval ? parseInt(existnrcval) : 0;
            let tempequipval = value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c ? parseInt(value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c) : 0;
            if (value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
              dynamicsheet.getCell(temNRCTTcel).value = getCurrencyfarmat(tempnrcval + tempequipval);
              NRCvalMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", tempnrcval + tempequipval);
            }
            NRCqtyMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", aval + bval);
          } else {
            statrowcount++;
            dynamicsheet.getCell("A" + statrowcount).value = "Equipment";
            dynamicsheet.getCell("B" + statrowcount).value = "";
            dynamicsheet.getCell("C" + statrowcount).value = value[p].Quote_Option_Item__r.Quantiy__c;
            dynamicsheet.getCell("D" + statrowcount).value = value[p].Quote_Option_Item__r.Product_Description__c;
            dynamicsheet.getCell("E" + statrowcount).value = value[p].Quote_Option_Item__r.Product_Code__c;
            if (value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
              dynamicsheet.getCell("F" + statrowcount).value = value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c;
            }
            let temrowcount = "C" + statrowcount;
            let temTTNRcount = "F" + statrowcount;
            NRCMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", temrowcount);
            NRCqtyMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", value[p].Quote_Option_Item__r.Quantiy__c);
            NRCcelMap.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", temTTNRcount);
            if (value[p].Quote_Request_Rates__r && value[p].Quote_Request_Rates__r.length > 0) {
              NRCvalMAP.set(value[p].Quote_Option_Item__r.Product_Code__c ? value[p].Quote_Option_Item__r.Product_Code__c : "", value[p].Quote_Request_Rates__r[0].EQUIP_NRC__c);
            }
          }
          ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
            formatCellBold(dynamicsheet, key, "000000", 10);
            dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
          });
        }
      }
    }
  }
  if (objNRC.GSEProdName === "GSE") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "GSE";
    dynamicsheet.getCell("B" + statrowcount).value = objNRC.GSEAccessType;
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.GSEQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GSETTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.GRIDProdName === "GRID") { 
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "GRID";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.GRIDQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GRIDTTNRC);

    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.GRIDProdName === "GRID") { 
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "GRID";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.SIgridNQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE INSTALL";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = "TBD";

    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.GDNProdName === "Guardian") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Guardian";
    const uniqueatarr = [...new Set(objNRC.GDNAccessType)];
    dynamicsheet.getCell("B" + statrowcount).value = uniqueatarr.join(' ');
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.GDNCQty;
    const uniqueadfarr = [...new Set(objNRC.GRIDNRCDes)];
    dynamicsheet.getCell("D" + statrowcount).value = uniqueadfarr.join(' ');
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GDNCTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  } 
  if (objNRC.GDNTIProdName === "GDNTI") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Guardian";
    const uniqueatarr = [...new Set(objNRC.GDNAccessType)];
    dynamicsheet.getCell("B" + statrowcount).value = uniqueatarr.join(' ');
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.GDNTIQty;
    const uniqueTIarr = [...new Set(objNRC.GRIDNRCTCDes)];
    dynamicsheet.getCell("D" + statrowcount).value = uniqueTIarr.join(' ');
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GDNTITTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  } 
  if (objNRC.GDNACProdName === "GDNAC") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Guardian";
    const uniqueatarr = [...new Set(objNRC.GDNAccessType)];
    dynamicsheet.getCell("B" + statrowcount).value = uniqueatarr.join(' ');
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.GDNQty;
    dynamicsheet.getCell("D" + statrowcount).value = 'SERVICE ACTIVATION'
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.GDNTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  } 
  if (objNRC.MOBIProdName === "Mobility") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Mobility";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.MOBIQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.MOBITTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.PIPProdName === "PIP") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "PIP";
    dynamicsheet.getCell("B" + statrowcount).value = objNRC.PIPAccessType;
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.PIPQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.PIPTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.POTSProdName === "POTS") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "POTS";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.POTSQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.POTSTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.EPOTSProdName === "ePOTS") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "ePOTS";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.EPOTSQty;
    dynamicsheet.getCell("D" + statrowcount).value = "";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.EPOTSTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.VOIPProdName === "HPBX") {
    const uniqueatarrm = [...new Set(modelHpbx)];
    for (var i = 0; i < uniqueatarrm.length; i++) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "HPBX";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    const uniqueatarrd = [...new Set(disEquip)];  
    dynamicsheet.getCell("C" + statrowcount).value = sumBy(equipQty,uniqueatarrd[i]);
    dynamicsheet.getCell("D" + statrowcount).value = uniqueatarrd[i];
    const uniqueatarr = [...new Set(modelHpbx)];
    dynamicsheet.getCell("E" + statrowcount).value = uniqueatarr[i]
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(sumBy(objNRC.VOIPTTNRC,uniqueatarrd[i]));;
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }}
  if (objNRC.VOIPHProdName === "HPBX1") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "HPBX";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.VOIPQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.VOIPTTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.VOIPSIPProdName === "SIP") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "SIP";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.VOIPSIPQty;
    dynamicsheet.getCell("D" + statrowcount).value = "";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.VOIPSIPTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  if (objNRC.VOCProdName === "VOC") {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Voice over Cable Line";
    dynamicsheet.getCell("B" + statrowcount).value = "";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.VOCQty;
    dynamicsheet.getCell("D" + statrowcount).value = "SERVICE ACTIVATION";
    dynamicsheet.getCell("E" + statrowcount).value = "";
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.VOCTTNRC);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  objNRC.TTNRCQty = objNRC.BBQty + objNRC.DIAQty + objNRC.EPIKQty + objNRC.EquipmentQty + objNRC.GSEQty + objNRC.GRIDQty + objNRC.GDNQty + objNRC.GDNTIQty + objNRC.GDNCQty + objNRC.PIPQty + objNRC.POTSQty + objNRC.EPOTSQty + objNRC.MOBIQty +objNRC.VOIPQty+ hpbxqty + objNRC.VOIPSIPQty+ objNRC.VOCQty + objNRC.EDGEQty+ objNRC.SIgridNQty;
  objNRC.TTNRCCost = objNRC.BBTTNRC + objNRC.DIATTNRC + objNRC.EPIKTTNRC + objNRC.EquipmentTTNRC + objNRC.GSETTNRC + objNRC.GRIDTTNRC + objNRC.GDNTTNRC + objNRC.GDNCTTNRC + objNRC.GDNTITTNRC + objNRC.MOBITTNRC + objNRC.PIPTTNRC + objNRC.POTSTTNRC + objNRC.EPOTSTTNRC + objNRC.VOIPSIPTTNRC + voipTn+ objNRC.VOIPTTTNRC+ objNRC.VOCTTNRC + objNRC.EDGETTNRC;
  if (objNRC.ProdName === "Total") {
    statrowcount++;  
    dynamicsheet.getCell("A" + statrowcount).value = "Total";
    dynamicsheet.getCell("C" + statrowcount).value = objNRC.TTNRCQty;
    dynamicsheet.getCell("F" + statrowcount).value = getCurrencyfarmat(objNRC.TTNRCCost,true);
    ["A" + statrowcount, "B" + statrowcount, "C" + statrowcount, "D" + statrowcount, "E" + statrowcount, "F" + statrowcount].map((key) => {
      formatCellBold(dynamicsheet, key, "000000", 10);
      dynamicsheet.getCell(key).alignment = { vertical: "middle", horizontal: "center" };
    });
  }
  footerrowcount = statrowcount;
}
export function footertext(statrowcount, dynamicsheet,vocFlagNosur,vocflagl,vocFlagsur, surchargeflag,EPIKflag, EPIKWholesaleflag,  POTSflag, POTSproductTypeflag, POTSproductTypeLocalLDflag,edgebootyes,edgebootno, DIAflag, BBflag, GSEPIPflag, GRIDflag, Mobilityflag, mobilitywirelessflag, VoIPflag, SHVoIPflag, SHVoIPflagsur,ocMflag) {
  console.log("JS1 statrowcount:", statrowcount);
  statrowcount = footerrowcount;
  statrowcount++;
  statrowcount++;
  statrowcount++;
  dynamicsheet.getCell("A" + statrowcount).value = "THIS QUOTE IS AN ESTIMATE.  Pricing is subject to change and is intended to be used for analysis purposes only. Applicable taxes, surcharges, fees, shipping, and delivery may not be included. All services are subject to the Terms and Conditions of Service set forth at http://granitenet.com/legal (as such may be modified from time to time).  This Quote contains confidential and proprietary information.";
  formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
  statrowcount++;
  dynamicsheet.getCell("A" + statrowcount).value = "Note:  In the event that an underlying carrier or supplier substantially alters the amounts charged to Granite for any Services being provided to the Customer, Granite reserves the right to propose different rates to the Customer. ";
  formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
  statrowcount++;
  if (surchargeflag === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Surcharges not included";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  statrowcount++;
  if (EPIKflag === true) {
    dynamicsheet.getCell("A" + statrowcount).value = "EPIK - MRC";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*THIS QUOTE IS AN ESTIMATE.  Pricing is subject to change and is intended to be used for analysis purposes only. Applicable taxes, fees, and shipping are not included. Additional lines/line sharing may incur an additional charge per the line rate. All services are subject to the Terms and Conditions of Service set forth at www.granitenet.com/legal(as such may be modified from time to time).  This Quote contains confidential and proprietary information. Data plans dependent on coverage and availability, some restrictions apply.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Analog Replacement Services are subject to a 36-month Initial Service Term.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*EPIK includes dual SIM cards and diverse cellular connections. Certain jurisdictions may require wireline connections for certain applications (Fire / Life Safety) and wireline connections may be necessary to furnish service at certain locations.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Granite Guardian includes 24x7 monitoring and emergency replacement.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "In the event that an underlying carrier or supplier substantially alters the amounts charged to Granite for any Services being provided to the Customer, Granite reserves the right to propose different rates to the Customer.    ";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "EPIK - NRC";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Pricing includes: (1) a basic site survey of up to 2 hours on-site, if necessary; and (2) actual installation of up to 3 hours on-site. Additional time on-site will be charged at a rate of $99.99 per hour and invoiced in 30-minute increments.  Customer may elect to self-install without additional charge";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Basic site survey consists of inspection of EPIK lines / services being replaced with EPIK services.  Further services, such as a comprehensive inventory of unrelated communications lines or systems, are not included in the basic site survey and will be charged at a rate of $99.99 per hour, invoiced in 30-minute increments";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Additional charges will apply for any additional services or equipment that may be necessary to complete the installation, such as a remote antenna or extended cabling. ";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*For installations needed to occur on an expedited basis (within 5 business days), Granite may charge expedited installation fees.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Standard configuration, testing, and shipping (ground) rates are $99 per device.  Additional fees may apply for expedited shipments or other circumstances that may result in higher shipping costs, such as shipment to locations outside the continental United States.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (EPIKWholesaleflag === true) {
    dynamicsheet.getCell("A" + statrowcount).value = "*In the case where installation and site survey exceed 5 hours, each additional hour will be $99 billed in 30 minute increments.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (POTSflag === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "POTS";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Installation charges may apply, for new lines.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Unless otherwise indicated, features and services such as long-distance usage, Non-Published Listings and Voicemails, may have an additional cost.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (POTSproductTypeflag) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*LD / PICC is not being quoted";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (POTSproductTypeflag && POTSproductTypeLocalLDflag) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*LD / PICC only quoted for some locations";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (VoIPflag === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "EPOTS installation of $199.99 includes: (1) a site survey of up to 1-hour onsite, if necessary ; and (2) actual installation of up to 2 hours onsite. Additional time onsite  will be charged at a rate of $99.99 per hour and invoiced in 30 min increments. Customer may elect to self-install without additional charge.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (SHVoIPflag === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "HPBX & SIP";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Surcharges ARE Quoted:";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Administrative Service Fee and Property Tax Allotment calculated as a percentage of seat, DID, and usage costs.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (SHVoIPflagsur === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "HPBX & SIP";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Surcharges are NOT Quoted:";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Network Access Charge will apply per line upon ordering. Administrative Service Fee and Property Tax Allotment calculated as a percentage of seat, DID, and usage costs.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (ocMflag === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Operator Connect for Microsoft Teams";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Administrative Service Fee and Property Tax Allotment calculated as a percentage of per user and usage costs.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    }
  if (edgebootyes === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "edgeboot";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Customer may elect to self-install; proposal includes Granite Installation for edgeboot product.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (edgebootno === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "edgeboot";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Customer plans to self-install. Granite dispatch service is available for an additional charge, by site.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (DIAflag === true) {
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "DIA";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Billing starts once DIA circuit loop is dropped.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Installation and construction charges may be quoted separately (if applicable) at an appropriate time.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (BBflag === true) {
    dynamicsheet.getCell("A" + statrowcount).value = "BB";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Charter/Time Warner pricing applies to new installs only.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Installation and construction charges may be quoted separately (if applicable) at an appropriate time.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if(vocflagl){
    dynamicsheet.getCell("A" + statrowcount).value = "VOC";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Quantity of eMTA devices needed will vary, dependent on service location and provider.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Features include call forwarding, caller ID, call transfer, hunting and 3-way calling. Additional features may be available depending on service location and provider.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;statrowcount++}
    if(vocFlagsur){
    dynamicsheet.getCell("A" + statrowcount).value = "Surcharges ARE Quoted:";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Please note that all prices quoted herein include surcharges and regulatory fees that may apply. Taxes are not included.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    }
    if(vocFlagNosur){
      dynamicsheet.getCell("A" + statrowcount).value = "Surcharges are NOT Quoted:";
      formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
      statrowcount++;
      dynamicsheet.getCell("A" + statrowcount).value = "Please note that all prices quoted herein do not include taxes, surcharges, and regulatory fees that may apply.";
      formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
      statrowcount++;
    }
  if (GSEPIPflag === true) {
    dynamicsheet.getCell("A" + statrowcount).value = "GSE/PIP";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Installation and construction charges may be quoted separately (if applicable) at an appropriate time.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (Mobilityflag && mobilitywirelessflag) {
    dynamicsheet.getCell("A" + statrowcount).value = "Mobility";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*No Granite Wireless VzW Domestic Roaming or International Services.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Wireless MRC does not include overage charges, SIM card or any equipment.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Unlimited Talk and Text, and Device access are included in all phone plans.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*If a line is disconnected prior to the contract end date, the customer is responsible for paying the remaining contract balance.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Dependent on coverage and availability, some restrictions apply.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Mobility - Wireless Broadband";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Verizon plans deprioritize at 50GB for 25Mbps and 150GB for 50Mbps Plans. After 300GB usage overage of $3.50/GB.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*AT&T May Slow Speeds after 100GB for 25Mbps, 125GB for 50Mbps, and 175GB for 100Mbps plans. After 300GB usage overage of $3.50/GB.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  } else if (mobilitywirelessflag) {
    dynamicsheet.getCell("A" + statrowcount).value = "Mobility - Wireless Broadband";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Verizon plans deprioritize at 50GB for 25Mbps and 150GB for 50Mbps Plans. After 300GB usage overage of $3.50/GB.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*AT&T May Slow Speeds after 100GB for 25Mbps, 125GB for 50Mbps, and 175GB for 100Mbps plans. After 300GB usage overage of $3.50/GB.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  } else if (Mobilityflag) {
    dynamicsheet.getCell("A" + statrowcount).value = "Mobility";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*No Granite Wireless VzW Domestic Roaming or International Services.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Wireless MRC does not include overage charges, SIM card or any equipment.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Unlimited Talk and Text, and Device access are included in all phone plans.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*If a line is disconnected prior to the contract end date, the customer is responsible for paying the remaining contract balance.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "*Dependent on coverage and availability, some restrictions apply.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
  if (GRIDflag === true) {
    dynamicsheet.getCell("A" + statrowcount).value = "GRID";
    formatCellwithBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Billing starts once DIA circuit loop is dropped.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Installation and construction charges may be quoted separately (if applicable) at an appropriate time.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
    dynamicsheet.getCell("A" + statrowcount).value = "Service Install to be determined; cost based on property facility practices.";
    formatCellBold(dynamicsheet, "A" + statrowcount, "000000", 10);
    statrowcount++;
  }
}