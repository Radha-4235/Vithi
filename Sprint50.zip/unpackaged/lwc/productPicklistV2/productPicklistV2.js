import { LightningElement, track, api } from "lwc";
import getProducts from "@salesforce/apex/ProductPicklistController.getProducts";
import getFirstProductPicklistValues from "@salesforce/apex/ProductPicklistController.getFirstProductPicklistValues";
import getNextProductPicklistsValues from "@salesforce/apex/ProductPicklistController.getNextProductPicklistsValues";
import getAllPicklistsFromData from "@salesforce/apex/ProductPicklistController.getAllPicklistsFromData";
import getAttributeIdsFromNames from "@salesforce/apex/ProductPicklistController.getAttributeIdsFromNames";
import getAvailableRouters from "@salesforce/apex/ProductPicklistController.getAvailableRouters";
import getATAEquipmentCall from "@salesforce/apex/ProductPicklistController.getATAEquipment";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import saveNoteCall from "@salesforce/apex/NotesHandler.saveNotes";
import addLocationsNote from "@salesforce/apex/NewQuoteRequestLocationHandler.AddLocationsNote";
import getpermission from "@salesforce/apex/NewQuoteRequestHandler.getpermission";
const EPOTS_ADDITIONAL_FEATURES = [
  "Local Usage Package",
  "LD Usage Package",
  "All Usage Package",
  "Voicemail",
  "Easy AA",
  "Premium AA"
];
const MOBILITY_OPTIONAL_SERVICES = [
  "Noverage - Overage Protection Paln (default Paln)",
  "Secondary SIM",
  "Static IP",
  "CyberReef",
  "Motus Management License",
  "AT&T International Services"
];

export default class ProductPicklistV2 extends LightningElement {
  @track productPicklist;
  @track maxLength = 2;
  shownotes = false;
  currentlyUpdatedPicklist;
  @track productPicklistValues = [];
  @track enableProductLinks = false;
  @track enableRouterData = false;
  @track enableRequestDiversity = false;
  hasDiversityRequested = false;
  _routerData;
  @api childProdData;
  _routerBackUpData;
  @track accessType = "";
  @track speedValue = "";
  @track contractTerm = 1;
  showDependentPicklists = false;
  @track product = {};
  data;
  hasData = false;
  parentPicklistIds;
  @track isOTYField = false;
  @track qtyValue = 1;
  @track deviceCategory = "";
  @track diversityValue = "";
  @track PRIHandoffValue = "";
//  @track picklistValues = "";
  noteContent;
  @api prodId;
  @api quoteId;
  @api recordId;
  _productConfig;
  @api edgebootProdFlag = 'No';
  @api telephonePopup;
  @track deleteChildData = [];

  //ATA Equipment
  showATAEquipments = false;
  ataEquipList = [];
  ataEquipExistingData = [];

  additionalFeatureExData = [];
  optionalServiceMobilityEXData = [];
  addOnFeaturesExData = [];
  addOnSeatFeaturesExData = [];
  addonSIPFeaturesExData = [];

  hpbxEquipList = [];
  gndOptionsList = [];
  edgebootList = [];
  hpbxEquipExistingData = [];
  hpbxBillingEquipType;
  hpbxTerm='3 YR';
 
  gdnOptionsExistingData = [];
  edgebootExistingData = [];
  showHPBXEquipmentsPopup = false;
  showEdgebootPopup = false;
  showGDNServicesPopup = false;
  addHPBXEquipmentCheckbox = false;
  addEdgebootCheckbox = false;
  addGDNOptionServicesCheckbox = false;
  editHPBXEquipmentCheckbox = false;
  editEdgebootCheckbox = false;
  addPRIHandoffCheckbox = false;
  hasPRIHandoffRequested = false;

  showAddFeatures = false;
  showOptionalServices = false;
  showVOCAddonFeatures = false;
  showEdgeboot = false;
  @track showHPBXoffers = false;
  @track showSeatOffers = false;
  @track showHPBXequipments = false;
  @track showSIPAdditionalFeatures = false;
  @track showSIPCallPathPRI = false;
  additionalFeatures = EPOTS_ADDITIONAL_FEATURES;
  optionalServices = MOBILITY_OPTIONAL_SERVICES;

  passwordHintClass =
    "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide";
  passwordHintClass1 =
    "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide";

  get showQtyTooltip() {
    return this.product && this.product.Name === "ePOTS" ? true : false;
  }

  @api get productConfig() {
    return this._productConfig;
  }

  set productConfig(value) {
    if (value) {
      value.forEach((elem) => {
        if (!this._productConfig) {
          this._productConfig = {};
        }
        if (elem.prodName == "Diversity_Type__c") {
          this.diversityValue = elem.prodValue;
          if (this.diversityValue != "No") {
            this.hasDiversityRequested = true;
          }
        }
        if (elem.prodName == "Notes__c") {
          this.noteContent = elem.prodValue;
        }
        if (elem.prodName == "Access_Type__c") {
          this.accessType = elem.prodValue;
        }
        if (elem.prodName == "Speed__c") {
          this.speedValue = elem.prodValue;
        }
        if (elem.prodName == "Contract_Term__c") {
          this.contractTerm = elem.prodValue;
        }
        if (elem.prodName == "QTY__c") {
          this.qtyValue = elem.prodValue;
        }
        if (elem.prodName == "Product_Type__c") {
          this.deviceCategory = elem.prodValue;
        }
        if (elem.prodName == "PRI_Handoff__c") {
          this.PRIHandoffValue = elem.prodValue;
          if (this.PRIHandoffValue == "true") {
            this.hasPRIHandoffRequested = true;
          }
        }
        let attributeName = elem.prodName;
        this._productConfig[attributeName] = elem.prodValue;
      });

      getAttributeIdsFromNames({ prodAttributes: this._productConfig })
        .then((response) => {
          this._productConfig = response;
          this.initialize();
          console.log(
            "getAttributeIdsFromNames ==> Response ==> " +
              JSON.stringify(response)
          );
        })
        .catch((error) => {
          console.log(
            "getAttributeIdsFromNames ==> Error ==> " + JSON.stringify(error)
          );
        });
    }
  }

  connectedCallback() {
    this.initialize();
    getpermission().then((result) => {
      if (result === "ChannelRep" || result === "premier" || result === "SE") {
        this.shownotes = true;
      } else {
        this.shownotes = false;
      }
    });
  }

  renderedCallback() {
    console.log("product", this.product);
  }

  togglePasswordHint() {
    this.passwordHintClass =
      this.passwordHintClass ==
      "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide"
        ? "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-rise-from-ground"
        : "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide";
  }

  togglePasswordHint1() {
    this.passwordHintClass1 =
      this.passwordHintClass1 ==
      "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide"
        ? "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-rise-from-ground"
        : "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide";
  }

  initialize() {
    getProducts().then((response) => {
      this.productPicklist = response;
      let prodValues = this.productPicklist.values;
      prodValues.forEach((prodVal) => {
        if(this.edgebootProdFlag == 'Yes' && prodVal.label == 'edgeboot' ){
           this.productPicklist.selectedValue = prodVal.value;
           this.productChange(prodVal.value,'Product__c');
        }
      });
      
      let a3LookupMap = response.a3LookupMap;
      if (
        a3LookupMap &&
        a3LookupMap["HPBX Equipment"] &&
        a3LookupMap["HPBX Equipment"].Feature__c
      ) {
        this.lstHPBXEquipments =
          a3LookupMap["HPBX Equipment"].Feature__c.split("~");
      }
      if (
        a3LookupMap &&
        a3LookupMap["Guardian"] &&
        a3LookupMap["Guardian"].Feature__c
      ) {
        this.lstOptionServices =
          a3LookupMap["Guardian"].Feature__c.split("~");
      }
    });

    if (this._productConfig) {
      for (const key in this._productConfig) {
        this.addToParentPicklistValues(key, this._productConfig[key]);
      }
      this._getAllPicklistsFromData(
        this._productConfig,
        "From Initialize",
        " ",
        " ",
        this.recordId
      );
    }
  }

  populateChildProductData() {
    if (this.childProdData && this.childProdData.length > 0) {
      let ataEquipList = [];
      let hpbxEquipList = [];
      let gndOptionsList = [];
      let edgebootList = [];
      this.childProdData.forEach((child) => {
        console.log(
          "populateChildProductData this.childProdData: " +
            JSON.stringify(this.childProdData)
        );
        if (
          child.prodtype == "Router" &&
          child.status == "upsert" &&
          child.prodFields
        ) {
          let routerRec = {};
          child.prodFields.forEach((attr) => {
            routerRec[attr.prodName] = attr.prodValue;
          });
          this._routerData = routerRec;
          this._routerBackUpData = routerRec;
          this.enableRouterData = true;
          this.enableProductLinks = false;
        } else if (
          child.prodtype == "AdditionalFeature" &&
          child.prodFields?.length > 0
        ) {
          //this.resetAllChildFlags();
          this.showAddFeatures = true;
        } else if (
          child.prodtype == "OptionalService" &&
          child.prodFields?.length > 0
        ) {
          //this.resetAllChildFlags();
          this.showOptionalServices = true;
        }
        else if (
          child.prodtype == "VOCFeatures" &&
          child.prodFields?.length > 0
        ) {
          this.showVOCAddonFeatures = true;
        }
        else if (
          child.prodtype == "AddOnFeatures" &&
          child.prodFields?.length > 0
        ) {
          //this.resetAllChildFlags();
          this.showHPBXoffers = true;
        } else if (child.prodtype == "Offer" && child.prodFields?.length > 0) {
          this.showSeatOffers = true;
        } else if (
          child.prodtype == "SIPAdditionalFeatures" &&
          child.prodFields?.length > 0
        ) {
          //this.resetAllChildFlags();
          this.showSIPAdditionalFeatures = true;
        } else if (
          child.prodtype === "GDN OptionalService" && 
          child.prodFields?.length > 0
        ) {
          let gdnOptionsData = {};
          child.prodFields.forEach((attr) => {
            gdnOptionsData[attr.prodName] = attr.prodValue;
          });
          gndOptionsList.push(gdnOptionsData);
        } else if (child.prodtype == "HPBX Equipment") {
          //this.resetAllChildFlags();
          this.showHPBXequipments = true;
          let hpbxEquipData = {};
          hpbxEquipData['MRC_Price__c']='';
          child.prodFields.forEach((attr) => {
         hpbxEquipData[attr.prodName] =attr.prodValue;
          });
       
          hpbxEquipList.push(hpbxEquipData);
         this.hpbxBillingEquipType=hpbxEquipList[0].Billing_Type__c=='MRC'?'EQUIP MRC':'EQUIP NRC';
        
          console.log("HPBX Data", hpbxEquipList)
        } else if (child.prodtype == "ATA Equipment") {
          let equipData = {};
          child.prodFields.forEach((attr) => {
            equipData[attr.prodName] = attr.prodValue;
          });
          ataEquipList.push(equipData);
        }else if (child.prodtype == "AddonEdgeboot") {
          let ebootData = {};
          child.prodFields.forEach((attr) => {
            ebootData[attr.prodName] = attr.prodValue;
          });
            edgebootList.push(ebootData);
        }
      });

      if (ataEquipList && ataEquipList.length > 0) {
        this.ataEquipList = ataEquipList;
        this.ataEquipExistingData = ataEquipList;
        this.showATAEquipments = true;
      } else {
        this.showATAEquipments = false;
      }

      //HPBX Equipments
      if (hpbxEquipList && hpbxEquipList.length > 0) {
        this.hpbxEquipList = hpbxEquipList;
        this.hpbxEquipExistingData = hpbxEquipList;
        this.hasHPBXEquipments = true;
      } else {
        this.hasHPBXEquipments = false;
      }
       //Guardian Optional Services
       if (gndOptionsList && gndOptionsList.length > 0) {
        this.gndOptionsList = gndOptionsList;
        this.gdnOptionsExistingData = gndOptionsList;
        this.hasGDNServices = true;
      } else {
        this.hasGDNServices = false;
      }
      //Edgeboot Product
      if (edgebootList && edgebootList.length > 0) {
        this.edgebootList = edgebootList;
        this.edgebootExistingData = edgebootList;
        this.hasEdgeboot = true;
      } else {
        this.hasEdgeboot = false;
      }
    }
  }
  openEdgebootPopup(event){
    this.showEdgebootPopup = event.target.checked;
    this.editEdgebootCheckbox = event.target.checked;
    this.addEdgebootCheckbox = event.target.checked;
  }
  handleEdgebootPopupClose(){
    this.showEdgebootPopup = false;
    this.editEdgebootCheckbox = false;
    this.addEdgebootCheckbox = false;
  }
  handleEdgebootPopupSave(event){
    let lstEdgeboot = event.detail.selectedEdgeboot;
    this.showEdgebootPopup = false;
    this.editEdgebootCheckbox = false;
    this.addEdgebootCheckbox = false;
    this.addEdgeboot(lstEdgeboot);
  }
  openHPBXEquipmetPopup(event) {
    this.showHPBXEquipmentsPopup = event.target.checked;
    this.editHPBXEquipmentCheckbox = event.target.checked;
    this.addHPBXEquipmentCheckbox = event.target.checked;
  }
  openGDNOptionsPopup(event){
    this.showGDNServicesPopup = event.target.checked;
    this.addGDNOptionServicesCheckbox = event.target.checked;
  }

  handlePopupClose(event) {
    this.showHPBXEquipmentsPopup = false;
    this.editHPBXEquipmentCheckbox = false;
    this.addHPBXEquipmentCheckbox = false;
    this.showGDNServicesPopup = false;
    this.addGDNOptionServicesCheckbox = false;
  }

  handlePopupSave(event) {
    let lstEquipments = event.detail.lstEquipments;
    this.addHpBXEquipment(lstEquipments);
    this.showHPBXEquipmentsPopup = false;
    this.editHPBXEquipmentCheckbox = false;
    this.addHPBXEquipmentCheckbox = false;
  }

  handleOptionsSave(event){
    let lstOptionServices = event.detail.lstOptionServices;
    //this.lstOptionServices = lstOptionServices;
    this.addGDNOptionServices(lstOptionServices);
    this.addGDNOptionServicesCheckbox = false;
    this.showGDNServicesPopup = false;
  }

  resetAllChildFlags() {
    this.showAddFeatures = false;
    this.showOptionalServices = false;
    this.showHPBXequipments = false;
    this.showHPBXoffers = false;
    this.showVOCAddonFeatures = false;
    this.showSeatOffers = false;
    this.showSIPAdditionalFeatures = false;
  }

  _getAllPicklistsFromData(
    productData,
    fromMethod,
    selectedpicklist,
    selectedValue,
    recordId
  ) {
    console.log("Inside _getAllPicklistsFromData");
    let isVoIP = false;
    var assignedPermission;
     getpermission().then((result) => {
       assignedPermission=result;
     })
    getAllPicklistsFromData({ productData, recordId })
      .then((response) => {
        this.hasData = true;
        this.productPicklistValues = [];
        this.product = {};
        if (response) {
          let tempIndex;
          response.forEach((picklist, index) => {
            if (picklist.apiName == selectedpicklist) {
              tempIndex = index;
            }
            if (picklist.isVisible && picklist.apiName != selectedpicklist) {
              if (!this.data) {
                this.data = {};
              }
              if (picklist.apiName == "Product__c" && picklist.selectedValue) {
                picklist.isDisable = true;
              } else {
                picklist.isDisable = false;
              }

              if (picklist.selectedValue) {
                this.data[picklist.apiName] = picklist.selectedValue;
              }
              if (picklist.apiName == "Grid_Voice_Package__c") {
                picklist.label = "Voice/Equipment Package";
                if (!picklist.selectedValue) {
                  picklist.selectedValue = "";
                }
              }

              if (picklist.apiName == "Product_Type__c") {
                picklist.label = "Service Category";
              }

              if (picklist.apiName == "Product_Detail1__c") {
                console.log(picklist);
              }

              if (picklist.apiName == "QTY__c") {
                if(this.product.Name == "edgeboot"){
                  this.isOTYField = false;
                  this.productPicklistValues.push(picklist);
                }
                else{
                this.isOTYField = true;
                if (
                  this.product.Name == "VoIP" &&
                  (this.product.Product_Detail1__c == "HPBX")
                ) {
                  this.isOTYField = false;
                }
                }
              } else {
                this.isOTYField = false;
                this.productPicklistValues.push(picklist);
              }

              if (picklist.selectedValue && picklist.values?.length > 0) {
                picklist.values.forEach((value) => {
                  if (picklist?.apiName == "Product__c") {
                    if (value.value == picklist.selectedValue) {
                      this.product.Id = value.value;
                      this.product.Name = value.label;
                      if (value.label == "ePOTS") {
                        isVoIP = true;
                        this.showAddFeatures = true;
                      }
                      if (value.label == "Mobility") {
                        this.showOptionalServices = true;
                        this.isOTYField = true;
                      }
                      if (value.label == "Voice over Cable Line") {
                        this.showVOCAddonFeatures = true;
                        this.isOTYField = true;

                      }
                      if (value.label == "Broadband" || value.label == "DIA") {
                        this.showEdgeboot = true;
                          }
                    }
                  } else if (picklist?.apiName == "Product_Detail1__c") {
                    if (
                      value.value == picklist.selectedValue &&
                      value.label == "HPBX"
                    ) {
                      this.product.Product_Detail1__c = value.label;
                      this.showHPBXequipments = true;
                      this.showHPBXoffers = true;
                      this.showSeatOffers = true;
                      this.showSIPAdditionalFeatures = false;
                      this.isOTYField = false;
                    } else if (
                      value.value == picklist.selectedValue &&
                      value.label == "SIP"
                    ) {
                      this.product.Product_Detail1__c = value.label;
                      this.showSIPAdditionalFeatures = true;
                      this.showHPBXequipments = false;
                      this.showHPBXoffers = false;
                      this.showSeatOffers = false;
                      this.isOTYField = true;
                    } 
                    else if(
                      value.value == picklist.selectedValue &&
                      value.label == "Operator Connect for Microsoft Teams" 
                    ){
                     this.product.Product_Detail1__c = value.label;
                      this.showSIPAdditionalFeatures = false;
                      this.showHPBXequipments = false;
                      this.showHPBXoffers = false;
                      this.showSeatOffers = false;
                      this.isOTYField = true;
                    }
                    else {
                      this.showHPBXequipments = true;
                      this.showHPBXoffers = true;
                      this.showSeatOffers = true;
                      this.showSIPAdditionalFeatures = false;
                    }
                  } else if (picklist?.apiName == "Preferred_Product_1__c") {
                    if (
                      value.value == picklist.selectedValue &&
                      value.label == "Standard Call Path"
                    ) {
                      this.showSIPCallPathPRI = true;
                    } else if (
                      value.value == picklist.selectedValue &&
                      value.label == "Teams Direct Routing Call Path"
                    ) {
                      this.showSIPCallPathPRI = false;
                    }
                  }
                  else if(picklist?.apiName == "Minimum_Speed__c" && this.product.Name == 'GRID'){
                   // if (value.value == picklist.selectedValue){
                      let values= picklist.values;
                        let permissions= picklist.permission;
                        let gridData = [];
                        values.forEach(v => {
                        let permission = permissions.find(p => p.label === v.value);
                        if (permission !=null && permission.value.includes("A3_GRID_SalesRep_CRE"))
                        {
                          gridData.push(v);
                        }
                        });
                        var finalGridData=values;
                        if(assignedPermission !="GRIDSalesRep" && assignedPermission !="Finance"){
                          finalGridData=values.filter(t => !gridData.some(obj => obj.value === t.value))
                        }
                        picklist.values=finalGridData;
                        var permissionValue = gridData.find(obj => obj.value === picklist.selectedValue);
                        if (permissionValue && (assignedPermission !="GRIDSalesRep" && assignedPermission !="Finance")) {
                          picklist.values.push(permissionValue);
                          picklist.values.sort((a, b) => a.label.localeCompare(b.label));
                        }
                       // }
                  }
                  if(picklist?.apiName == "Product_Detail1__c" && this.product.Name == 'VoIP' ){
                      let values= picklist.values;
                        let permissions= picklist.permission;
                        let gridData = [];
                        values.forEach(v => {
                        let permission = permissions.find(p => p.label === v.value);
                        if (permission !=null)
                        {
                          gridData.push(v);
                        }
                        });
                        var ocmtData=values;
                          if(assignedPermission !="Finance"){
                          ocmtData=values.filter(t => !gridData.some(obj => obj.value === t.value))
                        }
                        picklist.values=ocmtData;
                        var permissionValue = gridData.find(obj => obj.value === picklist.selectedValue);
                        if (permissionValue && (assignedPermission !="Finance")) {
                          picklist.values.push(permissionValue);
                          picklist.values.sort((a, b) => a.label.localeCompare(b.label));
                        }
                        if(this.product.Name == 'VoIP' &&  this.product.Product_Detail1__c =="Operator Connect for Microsoft Teams"  ){
                          this.showSIPAdditionalFeatures = false;
                          this.showHPBXequipments = false;
                          this.showHPBXoffers = false;
                          this.showSeatOffers = false;
                  }
                  }
                });
              }
            }
          });

          if (fromMethod == "From Initialize") {
            if (this.productPicklistValues[1]) {
              this.populateChildProductData();
              if (this.productPicklistValues[1].isReqDiversityChecked) {
                this.enableRequestDiversity =
                  this.productPicklistValues[1].isReqDiversityChecked;
                this.productPicklistValues[3].showTooltip = true;
              } 
              else {
                this.enableRequestDiversity = false;
              }
              if(this.product.Name == 'Broadband'){
              this.productPicklistValues[6].showTooltip = true;
              }
              if (this.productPicklistValues[1].isAddRouterChecked) {
                this.enableProductLinks =
                  this.productPicklistValues[1].isAddRouterChecked;
              } else {
                this.enableProductLinks = false;
              }
              //this.populateChildProductData();
            }
            if (this.productPicklistValues[3]) {
               //this.productPicklistValues[3].showTooltip = true;
            }
          }
          if (
            fromMethod == "From handle change" &&
            selectedpicklist == "Product__c"
          ) {
            if (selectedValue === "DIA") {
              if (this.productPicklistValues[3]) {
                this.productPicklistValues[3].showTooltip = true;
              }

              if (this.productPicklistValues[1]) {
                if (this.productPicklistValues[1].isAddRouterChecked) {
                  this.enableProductLinks =
                    this.productPicklistValues[1].isAddRouterChecked;
                } else {
                  this.enableProductLinks = false;
                }

                if (this.productPicklistValues[1].isReqDiversityChecked) {
                  this.diversityValue = "Carrier Diversity";
                  this.enableRequestDiversity =
                    this.productPicklistValues[1].isReqDiversityChecked;
                  this.hasDiversityRequested = false;
                } else {
                  this.enableRequestDiversity = false;
                  this.hasDiversityRequested = false;
                }
              }
            } else {
              this.accessType = "";
              this.speedValue = "";
              this.contractTerm = 1;
              this._routerData = {};
              this.enableRouterData = false;
              this.enableRequestDiversity = false;
              this.hasDiversityRequested = false;
              this.enableProductLinks = false;
            }
          }
        }
      })
      .catch((error) => {
        console.log("getAllPicklistsFromData ==> " + JSON.stringify(error));
      });
  }

  handleProductChange(event){
    this.productChange(event.target.value,event.target.name);
  }

  productChange(prodVal,prodApi) {
    this.product = {};
    this.data = {};
    this.showDependentPicklists = false;
    this.productPicklist.values.forEach((productPicklistVal) => {
      if (productPicklistVal.value == prodVal) {
        this.product.Id = prodVal;
        this.product.Name = productPicklistVal.label;
        // this.parentPicklistIds = [];
        this.addToParentPicklistValues("Product__c", this.product.Id);
        // this.parentPicklistIds.push( this.product.Id );
      }
    });
    this.productPicklistValues = [];
    this.productPicklistValues.forEach((picklistVal) => {
      picklistVal.isVisible = false;
    });

    this.data[prodApi] = prodVal;
    this.dispatchPicklistChangeEvent(
      "productfamilynextchange",
      prodApi,
      this.product.Name
    );
    this._getFirstProductPicklistValues(
      this.product.Name,
      this.product.Id,
      this.recordId
    );

    const displayEquipmentEvent = { detail: this.product.Name };
    const eventNameToPass =
      this.product.Name == "DIA"
        ? "nodisplayaddequipment"
        : "displayaddequipment";
    this.dispatchEvent(new CustomEvent(eventNameToPass, displayEquipmentEvent));

    if (this.product.Name === "ePOTS" && this.qtyValue) {
      this.addATAEquipment(this.product.Name);
    } else {
      this.removeEquipment(this.ataEquipExistingData, "ATA Equipment");
      this.ataEquipExistingData = [];
      this.ataEquipList = [];
      this.showATAEquipments = false;
    }
     if (this.product.Name !== "DIA" ) {
       this.syncRouterData("delete");
      this.enableRouterData = false;
    } 
    if(this.product.Name !== "Guardian"){
      this.removeEquipment(this.gdnOptionsExistingData, "GDN OptionalService");
      this.gdnOptionsExistingData = [];
      this.deleteChildData =[];
      this.gndOptionsList = [];
    }
    if (this.product.Name != "ePOTS") {
      this.removeAdditionalFeature();
      this.additionalFeatureExData = [];
    }
    if (this.product.Name != "Mobility") {
      this.removeMobilityOptionalServices();
      this.optionalServiceMobilityEXData = [];
    }

    if (this.product.Name != "VoIP") {
      this.removeAddOnFeatures();
      this.removeAddOnSeats();
      this.removeAddOnFeaturesSIP();
      this.addOnFeaturesExData = [];
      this.addOnSeatFeaturesExData = [];
      this.addonSIPFeaturesExData = [];
      this.removeEquipment(this.hpbxEquipExistingData,"HPBX Equipment");
      this.hpbxEquipExistingData = [];
      
    }
    // console.log('Product config => ' + JSON.stringify( this.data ));
  }

  addProductforQO(event){
    const eventToDispatch = new CustomEvent('addedgebootproduct', { detail :{qoId : this.quoteId}});
    this.dispatchEvent(eventToDispatch);
  }
  _getFirstProductPicklistValues(productName, productId, recordId) {
    this.productPicklistValues = [];
    var assignedPermission;
     getpermission().then((result) => {
       assignedPermission=result;
     })
    getFirstProductPicklistValues({ productName, productId, recordId }).then(
      (response) => {
        console.log("response", response);
        this.productPicklistValues[0] = response;
        if (this.product.Name == "Mobility") {
          this.productPicklistValues[0].label = "Service Category";
        }
        if (this.product.Name == "EPIK") {
          if (response.label == "Contract Term") {
            const contrcttermLabel = response.values.find(
              (item) => item.label === "3 Years"
            );
            response.selectedValue = contrcttermLabel.value;
            this.data["Contract_Term__c"] = contrcttermLabel.value;
            this.addToParentPicklistValues(
              "Contract_Term__c",
              contrcttermLabel.value
            );
            var parentValues = this.getParentPicklistValues();
            parentValues.push(contrcttermLabel);
            this.dispatchPicklistChangeEvent(
              "productnextchange",
              "Contract_Term__c",
              contrcttermLabel.label,
              this.parentPicklistIds.length - 1
            );
            this._getNextProductPicklistsValues(
              "Contract_Term__c",
              this.getParentPicklistValues(),
              this.product.Name
            );
          }
        }
        else if(this.product.Name == "GRID" && response.label == "Minimum Speed"){
                let values= response.values;
                let permissions= response.permission;
                let gridData = [];
                values.forEach(v => {
                let permission = permissions.find(p => p.label === v.value);
                if (permission !=null && permission.value.includes("A3_GRID_SalesRep_CRE"))
                {
                  gridData.push(v);
                }
                });
                var finalGridData=values;
                if(assignedPermission !="GRIDSalesRep" && assignedPermission !="Finance"){
                  finalGridData=values.filter(t => !gridData.some(obj => obj.value === t.value))
                }
                this.productPicklistValues[0].values=finalGridData;
        }
        else if(this.product.Name == "VoIP" && response.label == "Product Category"){
                let values= response.values;
                let permissions= response.permission;
                let gridData = [];
                values.forEach(v => {
                let permission = permissions.find(p => p.label === v.value);
                if (permission !=null)
                {
                  gridData.push(v);
                }
                });
                var finalGridData=values;
                if(assignedPermission !="Finance"){
                  finalGridData=values.filter(t => !gridData.some(obj => obj.value === t.value))
                }
                this.productPicklistValues[0].values=finalGridData;
        }
        else if(this.product.Name == "ePOTS" || this.product.Name == "Voice over Cable Line") {
          if (response.label == "Term") {
            var prdctterm = response.values[2].value;
            response.selectedValue = prdctterm;
            this.data["Term__c"] = prdctterm;
            this.addToParentPicklistValues("Term__c", prdctterm);
            var parentValues = this.getParentPicklistValues();
            parentValues.push(prdctterm);
            this.dispatchPicklistChangeEvent(
              "productnextchange",
              "Term__c",
              response.values[2].label,
              this.parentPicklistIds.length - 1
            );
            this._getNextProductPicklistsValues(
              "Term__c",
              this.getParentPicklistValues(),
              this.product.Name
            );
          }
        }

        else if(this.product.Name == "edgeboot") {
          if (response.label == "Term") {
            const contrcttermLabel = response.values.find(
              (item) => item.label === "3 Years"
            );
            response.selectedValue = contrcttermLabel.value;
            this.data["Term__c"] = contrcttermLabel.value;
            this.addToParentPicklistValues(
              "Term__c",
              contrcttermLabel.value
            );
            var parentValues = this.getParentPicklistValues();
            parentValues.push(contrcttermLabel);
            this.dispatchPicklistChangeEvent(
              "productnextchange",
              "Term__c",
              contrcttermLabel.label,
              this.parentPicklistIds.length - 1
            );
            this._getNextProductPicklistsValues(
              "Term__c",
              this.getParentPicklistValues(),
              this.product.Name
            );
          }
          else if(response.apiName == "QTY__c") {
            response.selectedValue = 1;
            this.data["QTY__c"] = 1;
            this.addToParentPicklistValues("QTY__c", 2);
            var parentValues = this.getParentPicklistValues();
            parentValues.push(1);
            //this.productPicklistValues.push(response);
            this.dispatchPicklistChangeEvent(
              "productnextchange",
              "QTY__c",
              1,
              this.parentPicklistIds.length - 1
            );
            this._getNextProductPicklistsValues(
              "QTY__c",
              this.getParentPicklistValues(),
              this.product.Name
            );
          }
          else if(response.apiName == "Ip_Block__c") {
            var prdctterm = response.values[0].value;
            response.selectedValue = prdctterm;
            this.data["Ip_Block__c"] = prdctterm;
            this.addToParentPicklistValues("Ip_Block__c", prdctterm);
            var parentValues = this.getParentPicklistValues();
            parentValues.push(prdctterm);
            this.dispatchPicklistChangeEvent(
              "productnextchange",
              "Ip_Block__c",
              response.values[0].label,
              this.parentPicklistIds.length - 1
            );
            this._getNextProductPicklistsValues(
              "Ip_Block__c",
              this.getParentPicklistValues(),
              this.product.Name
            );
          }
        }

        if (this.productPicklistValues[0].isAddRouterChecked) {
          this.enableProductLinks =
            this.productPicklistValues[0].isAddRouterChecked;
        } else {
          this.enableProductLinks = false;
        }
        if (this.productPicklistValues[0].isReqDiversityChecked) {
          this.enableRequestDiversity =
            this.productPicklistValues[0].isReqDiversityChecked;
        } else {
          this.enableRequestDiversity = false;
        }
        this.showDependentPicklists = true;
        this.showAddFeatures = false;
        this.showOptionalServices = false;
        this.showVOCAddonFeatures = false;
        this.showEdgeboot = false;
        this.showHPBXoffers = false;
        this.showSeatOffers = false;
        this.showSIPAdditionalFeatures = false;
        this.showHPBXequipments = false;
        this.showSIPCallPathPRI = false;
        if(this.product.Name === "Broadband" || this.product.Name === "DIA"){
          this.showEdgeboot = true;
        }else{
          this.showEdgeboot = false;
        }
        if (
          this.product.Name === "EPIK" ||
          this.product.Name === "POTS" ||
          this.product.Name === "ePOTS" ||
          this.product.Name === "Guardian" ||
          this.product.Name === "Mobility" ||
          this.product.Name === "Voice over Cable Line" //||
          //this.product.Name === "edgeboot"
        ) {
          this.isOTYField = true;
          if (this.product.Name === "ePOTS") {
            this.showAddFeatures = true;
            this.showOptionalServices = false;
            this.showVOCAddonFeatures = false;
            this.showHPBXoffers = false;
            this.showSeatOffers = false;
            this.showSIPAdditionalFeatures = false;
          } else if (this.product.Name === "Mobility") {
            this.showOptionalServices = true;
            this.showVOCAddonFeatures = false;
            this.showAddFeatures = false;
            this.showHPBXoffers = false;
            this.showSeatOffers = false;
            this.showSIPAdditionalFeatures = false;
          }          
          else if (this.product.Name === "Voice over Cable Line") {
            this.showOptionalServices = false;
            this.showVOCAddonFeatures = true;
            this.isOTYField = true;
            this.showAddFeatures = false;
            this.showHPBXoffers = false;
            this.showSeatOffers = false;
            this.showSIPAdditionalFeatures = false;
          } 
        } else {
          this.isOTYField = false;
        }
      }
    );
  }

  handleProductPicklistChange(event) {
    if (this.product.Name == "DIA" ){
      this.enableRouterData = false;
    this.enableProductLinks = true;
    this.showEdgeboot = true;
    }
    this.currentlyUpdatedPicklist = event.target.name;
    if (!this.data) {
      this.data = {};
    }
    this.data[event.target.name] = event.target.value;
    let indexToLeaveHiding = 0;
    let selectedFieldValue;
    let modelValues;
    this.productPicklistValues.forEach((picklistVal, index) => {
      if (picklistVal.apiName === event.target.name) {
        modelValues = picklistVal.modelValues;
        if (picklistVal.values) {
          picklistVal.values.forEach((availableValue) => {
            if (availableValue.value === event.target.value) {
              if (
                picklistVal.apiName == "Grid_Voice_Package__c" &&
                availableValue.label == "-None-"
              ) {
                selectedFieldValue = availableValue.value;
              } else {
                selectedFieldValue = availableValue.label;
              }
              return;
            }
          });
          if (picklistVal.apiName == "Access_Type__c") {
            this.accessType = selectedFieldValue;
          }
          if (picklistVal.apiName == "Speed__c") {
            this.speedValue = selectedFieldValue;
          }
          if (picklistVal.apiName == "Contract_Term__c") {
            this.contractTerm = selectedFieldValue;
          }
          if (picklistVal.apiName == "Product_Type__c") {
            this.deviceCategory = selectedFieldValue;
            if (this.template.querySelector("c-optional-services-container")) {
              this.template
                .querySelector("c-optional-services-container")
                .handleValueChange(this.deviceCategory);
            }
          } else if (picklistVal?.apiName == "Product_Detail1__c") {
            if (selectedFieldValue == "HPBX") {
              this.showHPBXequipments = true;
              this.showHPBXoffers = true;
              this.showSeatOffers = true;
              this.showSIPAdditionalFeatures = false;
              this.showSIPCallPathPRI = false;
              this.isOTYField = false;
              this.removeAddOnFeaturesSIP();
              this.addonSIPFeaturesExData = [];
            } else if (selectedFieldValue == "SIP") {
              this.showSIPAdditionalFeatures = true;
              this.showHPBXequipments = false;
              this.showHPBXoffers = false;
              this.showSeatOffers = false;
              this.showSIPCallPathPRI = false;
              this.isOTYField = true;
              this.removeAddOnFeatures();
              this.removeAddOnSeats();
              this.addOnFeaturesExData = [];
              this.addOnSeatFeaturesExData = [];
              this.removeEquipment(this.hpbxEquipExistingData,
                "HPBX Equipment");
              this.hpbxEquipExistingData = [];
            } 
            else if (selectedFieldValue == "Operator Connect for Microsoft Teams") {
              this.showSIPAdditionalFeatures = false;
              this.showHPBXequipments = false;
              this.showHPBXoffers = false;
              this.showSeatOffers = false;
              this.showSIPCallPathPRI = false;
              this.isOTYField = true;
              this.removeAddOnFeatures();
              this.removeAddOnSeats();
              this.removeAddOnFeaturesSIP();
              this.addOnFeaturesExData = [];
              this.addOnSeatFeaturesExData = [];
              this.addonSIPFeaturesExData = [];
              this.removeEquipment(this.hpbxEquipExistingData,
                "HPBX Equipment");
              this.hpbxEquipExistingData = [];
            } 
            else {
              this.removeEquipment(
                this.hpbxEquipExistingData,
                "HPBX Equipment"
              );
              this.hpbxEquipList = [];
              this.hpbxEquipExistingData = [];
              this.deleteChildData = [];
              this.showHPBXequipments = false;
            }
          } else if (picklistVal?.apiName == "Preferred_Product_1__c") {
            if (selectedFieldValue == "Standard Call Path") {
              this.showSIPCallPathPRI = true;
            } else if (selectedFieldValue == "Teams Direct Routing Call Path") {
              this.showSIPCallPathPRI = false;
              this.requestPRIHandoof(event, "false");
            }
          }
        }

        this.addToParentPicklistValues(event.target.name, event.target.value);
        this.hpbxTerm=event.target.name=="Term__c"?selectedFieldValue.replace(/[^0-9]/g,"")+' YR':this.hpbxTerm;
        console.log(this.hpbxTerm);
        this.dispatchPicklistChangeEvent(
          "productnextchange",
          event.target.name,
          selectedFieldValue,
          this.parentPicklistIds.length - 1
        );
        if (
          picklistVal.modelValues &&
          picklistVal.apiName == "Product_Code_Description__c"
        ) {
          picklistVal.modelValues.forEach((availableValue) => {
            if (availableValue.label === event.target.value) {
              this.addToParentPicklistValues(
                "Model_Number__c",
                availableValue.value
              );
              this.dispatchPicklistChangeEvent(
                "productnextchange",
                "Model_Number__c",
                availableValue.value,
                this.parentPicklistIds.length - 1
              );
              return;
            }
          });
        }

        indexToLeaveHiding = index;
      }
    });

    let allDisplayFields;
    this.productPicklistValues.forEach((picklistVal, index) => {
      if (index > indexToLeaveHiding) {
        picklistVal.isVisible = false;
        delete this.data[picklistVal.apiName];
      }
      if (!allDisplayFields) {
        allDisplayFields = picklistVal.allFields;
      }
    });

    let cIndex;
    allDisplayFields.forEach((apiName, index) => {
      if (apiName === event.target.name) {
        cIndex = index;
      }
      if (cIndex && index > cIndex) {
        this.addToParentPicklistValues(apiName, "");
        this.dispatchPicklistChangeEvent(
          "productnextchange",
          apiName,
          "",
          this.parentPicklistIds.length - 1
        );
      }
    });

    this.productPicklistValues.splice(
      indexToLeaveHiding + 1,
      this.productPicklistValues.length
    );

    this._getNextProductPicklistsValues(
      event.target.name,
      this.getParentPicklistValues(),
      this.product.Name
    );
  }

  handleProductInputChange(event) {
    this.addToParentPicklistValues(event.target.name, event.target.value);
    this.dispatchPicklistChangeEvent(
      "productnextchange",
      event.target.name,
      event.target.value,
      this.parentPicklistIds.length - 1
    );
  }

  handleOtyValue(event) {
    this.qtyValue = event.target.value;

    if(this.product.Name === "VoIP" || this.product.Name === "Voice over Cable Line"){
        this.maxLength = 4;
      }
    else{
      this.maxLength=2;
      }

    this.dispatchPicklistChangeEvent(
      "productnextchange",
      "QTY__c",
      this.qtyValue,
      this.parentPicklistIds.length - 1
    );
    if (this.product) {
      if (this.product.Name === "ePOTS") {
        this.addATAEquipment(this.product.Name);
      }
    } else {
      let productName;
      this.productPicklistValues.forEach((picklist) => {
        if (picklist.apiName == "Product__c" && picklist.values?.length > 0) {
          picklist.values.forEach((picklistItem) => {
            if (picklist.selectedValue === picklistItem.value) {
              productName = picklistItem.label;
              return;
            }
          });
        }
      });
      this.addATAEquipment(productName);
    }
  }

  addHpBXEquipment(lstEquipments) {
    this.hpbxEquipList = [];
    let hpbxEquipList = [];
    lstEquipments.forEach((item) => {
      if (item.isSelected) {
        hpbxEquipList.push({
          Name: item.name,
          Model_Number__c: item.modelNumber,
          Part_Number__c : item.partNumber,
          Child_Quote_item_Product_Type__c: "HPBX Equipment",
          Parent_Quote_Option_Item__c: item.parentId,
          Billing_Type__c:item.billingType,
          IP_Type__c: item.subBillingType,
          QTY__c: item.qtyValue,
          Product_Detail1_Description__c:item.equipType,
       MRC_Price__c:item.price
        });
      }
    });
     this.hpbxBillingEquipType=lstEquipments[0].billingType=='MRC'?'EQUIP MRC':'EQUIP NRC';
    if (this.hpbxEquipExistingData && this.hpbxEquipExistingData.length > 0) {
      this.syncEquipmentData(
        this.hpbxEquipExistingData,
        "delete",
        "HPBX Equipment"
      );
      this.hpbxEquipExistingData.forEach((data)=>{
        if(data.Id != null){
          this.deleteChildData.push(data.Id);
        }
      });
    }

    this.hpbxEquipList = hpbxEquipList;
    this.hpbxEquipExistingData = hpbxEquipList;
    if (this.hpbxEquipList && this.hpbxEquipList.length > 0) {
      this.syncEquipmentData(this.hpbxEquipList, "upsert", "HPBX Equipment");
      this.showHPBXequipments = true;
      this.hasHPBXEquipments = true;
    } else {
      this.showHPBXequipments = true;
      //this.showHPBXequipments = false;
      this.hasHPBXEquipments = false;
    }
  }
  addEdgeboot(lstEdgeboot) {
    this.edgebootList = [];
    let edgebootList = [];
    let ebootOption ={};
    lstEdgeboot.forEach((item) => {
        ebootOption = {
        Name: item.product,
        Child_Quote_item_Product_Type__c: "AddonEdgeboot",
        Parent_Quote_Option_Item__c: item.parentId,
        QTY__c: item.qty
        };
        edgebootList.push(ebootOption);
    });

    if (this.edgebootExistingData && this.edgebootExistingData.length > 0) {
      this.syncEquipmentData(
        this.edgebootExistingData,
        "delete",
        "AddonEdgeboot"
      );
      this.edgebootExistingData.forEach((data)=>{
        if(data.Id != null){
        this.deleteChildData.push(data.Id);
        }
      });
    }

    this.edgebootList = edgebootList;
    this.edgebootExistingData = edgebootList;
    if (this.edgebootList && this.edgebootList.length > 0) {
      this.syncEquipmentData(this.edgebootList, "upsert", "AddonEdgeboot");
      this.hasEdgeboot = true;
    } else {
      this.hasEdgeboot = false;
    }
  }

  addGDNOptionServices(lstOptionServices) {
    this.gndOptionsList = [];
    let gndOptionsList = [];
    lstOptionServices.forEach((item) => {
      if (item.isSelected) {
        let gndOption = {
        Name: item.name,
        Child_Quote_item_Product_Type__c: "GDN OptionalService",
        Parent_Quote_Option_Item__c: item.parentId
        };
        if(item.label === "VPN Client Add On"){
          gndOption.QTY__c = item.qty;
          }
          gndOptionsList.push(gndOption);
      }
    });

    if (this.gdnOptionsExistingData && this.gdnOptionsExistingData.length > 0) {
      this.syncEquipmentData(
        this.gdnOptionsExistingData,
        "delete",
        "GDN OptionalService"
      );
      this.gdnOptionsExistingData.forEach((data)=>{
        if(data.Id != null){
        this.deleteChildData.push(data.Id);
        }
      });
    }

    this.gndOptionsList = gndOptionsList;
    this.gdnOptionsExistingData = gndOptionsList;
    if (this.gndOptionsList && this.gndOptionsList.length > 0) {
      this.syncEquipmentData(this.gndOptionsList, "upsert", "GDN OptionalService");
      this.hasGDNServices = true;
    } else {
      this.hasGDNServices = false;
    }
  }

  
  get addedFeaturesCSV() {
    if (this.gndOptionsList && this.gndOptionsList.length > 0) {
      let addedFeaturesCSVToReturn = "";
      this.gndOptionsList.forEach((option, index) => {
          addedFeaturesCSVToReturn = this.constructFeaturesString(
            addedFeaturesCSVToReturn,
            option
          );
      });
      return addedFeaturesCSVToReturn;
    } else {
      return "";
    }
  }
  constructFeaturesString(existingString, newFeature) {
    if (existingString.length > 0) {
      existingString += ", ";
    }
    if(newFeature.Name === "VPN Client Add On" ){
      existingString += newFeature.Name + `(${newFeature.QTY__c})`;
    }
    else {
    existingString += newFeature.Name;
    }
    
    return existingString;
  }

  handleEditOptions(){
    this.showGDNServicesPopup = true;
  }
  handleDeleteOptions(){
    this.gdnOptionsExistingData.forEach((data)=>{
        if(data.Id != null){
          this.deleteChildData.push(data.Id);
        }
      });
    this.removeEquipment(this.gdnOptionsExistingData, "GDN OptionalService");
    this.gdnOptionsExistingData = [];
    this.gndOptionsList = [];
    this.hasGDNServices = false;
    //this.lstOptionServices = this.lstOptionServices;
  }
  handleDeleteChildEdgeboot(event){
    this.edgebootExistingData.forEach((data)=>{
      if(data.Id != null){
        this.deleteChildData.push(data.Id);
      }
    });
    this.removeEquipment(this.edgebootExistingData, "AddonEdgeboot");
    this.edgebootExistingData = [];
    this.edgebootList = [];
    this.hasEdgeboot = false;
  }
  addATAEquipment(productName) {
    this.ataEquipList = [];
    getATAEquipmentCall({
      productName,
      qty: this.qtyValue
    })
      .then((result) => {
        let ataEquipList = [];
        if (result) {
          for (let i = 0; i < result.length; i++) {
            let ataEquip = result[i];
            if (!ataEquip.doNotInclude) {
              ataEquipList.push({
                Name: ataEquip.modelNumber,
                Model_Number__c: ataEquip.modelNumber,
                QTY__c: ataEquip.displayQty,
                Child_Quote_item_Product_Type__c: "ATA Equipment",
                Parent_Quote_Option_Item__c: this.recordId
              });
            }
          }
        }

        if (this.ataEquipExistingData && this.ataEquipExistingData.length > 0) {
          this.syncEquipmentData(
            this.ataEquipExistingData,
            "delete",
            "ATA Equipment"
          );
        }

        this.ataEquipList = ataEquipList;
        this.ataEquipExistingData = ataEquipList;
        if (this.ataEquipList && this.ataEquipList.length > 0) {
          this.syncEquipmentData(this.ataEquipList, "upsert", "ATA Equipment");
          this.showATAEquipments = true;
        } else {
          this.showATAEquipments = false;
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }

  removeEquipment(equipExistingData, prodType) {
    if (equipExistingData && equipExistingData.length > 0) {
      this.syncEquipmentData(equipExistingData, "delete", prodType);
    }
  }

  _getNextProductPicklistsValues(
    currentFieldApiName,
    currentPicklistValues,
    productName
  ) {
    getNextProductPicklistsValues({
      currentFieldApiName,
      currentPicklistValues,
      productName
    })
      .then((response) => {
        if (response) {
          if (response.isVisible) {
            let indexToUpdate;
            this.productPicklistValues.forEach((picklist, index) => {
              if (picklist.apiName === response.apiName) {
                indexToUpdate = index;
                return;
              }
            });
            if (indexToUpdate && indexToUpdate > 0) {
              if (
                this.product.Name == "VoIP" &&
                response.apiName == "Preferred_Product__c"
              ) {
                var prdtCodeDesc = response.values[0].value;
                response.selectedValue = prdtCodeDesc;

                this.productPicklistValues[indexToUpdate] = response;
                this.data["Preferred_Product__c"] = prdtCodeDesc;
                this.addToParentPicklistValues(
                  "Preferred_Product__c",
                  prdtCodeDesc
                );
                var parentValues = this.getParentPicklistValues();
                parentValues.push(prdtCodeDesc);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "Preferred_Product__c",
                  response.values[0].label,
                  this.parentPicklistIds.length - 1
                );
                this._getNextProductPicklistsValues(
                  "Preferred_Product__c",
                  this.getParentPicklistValues(),
                  this.product.Name
                );
              } 
              else if (
                this.product.Name == "DIA" &&
                response.apiName == "ProductCode_Description__c"
              ) {
                response.showTooltip = true;
                var prdtCodeDesc = response.values[0].value;
                response.selectedValue = prdtCodeDesc;

                this.productPicklistValues[indexToUpdate] = response;
                this.data["ProductCode_Description__c"] = prdtCodeDesc;
                this.addToParentPicklistValues(
                  "ProductCode_Description__c",
                  prdtCodeDesc
                );
                var parentValues = this.getParentPicklistValues();
                parentValues.push(prdtCodeDesc);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "ProductCode_Description__c",
                  response.values[0].label,
                  this.parentPicklistIds.length - 1
                );
                this._getNextProductPicklistsValues(
                  "ProductCode_Description__c",
                  this.getParentPicklistValues(),
                  this.product.Name
                );
              } else if (
                this.product.Name == "Mobility" &&
                response.apiName == "Product_Type__c"
              ) {
                console.log("test-test--", JSON.stringify(response));
                var gridPackage = response.values[1].value;
                response.selectedValue = gridPackage;
                this.productPicklistValues[indexToUpdate] = response;
                this.data["Product_Type__c"] = gridPackage;
                this.addToParentPicklistValues("Product_Type__c", gridPackage);
                var parentValues = this.getParentPicklistValues();
                parentValues.push(gridPackage);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "Product_Type__c",
                  "",
                  this.parentPicklistIds.length - 1
                );
                this._getNextProductPicklistsValues(
                  "Product_Type__c",
                  this.getParentPicklistValues(),
                  this.product.Name
                );
              } else if (
                this.product.Name == "GRID" &&
                response.apiName == "Grid_Voice_Package__c"
              ) {
                console.log("test-test--", JSON.stringify(response));
                var gridPackage = response.values[0].value;
                response.selectedValue = gridPackage;
                console.log("test-response.selectedValue ", response.label);
                response.label = "Voice/Equipment Package";
                this.productPicklistValues[indexToUpdate] = response;
                this.data["Grid_Voice_Package__c"] = gridPackage;
                this.addToParentPicklistValues(
                  "Grid_Voice_Package__c",
                  gridPackage
                );
                var parentValues = this.getParentPicklistValues();
                parentValues.push(gridPackage);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "Grid_Voice_Package__c",
                  response.values[0].label,
                  this.parentPicklistIds.length - 1
                );
                this._getNextProductPicklistsValues(
                  "Grid_Voice_Package__c",
                  this.getParentPicklistValues(),
                  this.product.Name
                );
              } else if (
                this.product.Name == "GRID" &&
                response.apiName == "IP_Type__c"
              ) {
                console.log("test-test--", JSON.stringify(response));
                var ipType = response.values[0].value;
                response.selectedValue = ipType;
                console.log("test-response.selectedValue ", response.label);
                this.productPicklistValues[indexToUpdate] = response;
                this.data["IP_Type__c"] = ipType;
                this.addToParentPicklistValues("IP_Type__c", ipType);
                var parentValues = this.getParentPicklistValues();
                parentValues.push(ipType);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "IP_Type__c",
                  response.values[0].label,
                  this.parentPicklistIds.length - 1
                );
                this._getNextProductPicklistsValues(
                  "IP_Type__c",
                  this.getParentPicklistValues(),
                  this.product.Name
                );
              } else {
                this.productPicklistValues[indexToUpdate] = response;
              }
            } else {
              if (
                (this.product.Name === "EPIK" ||
                  this.product.Name === "POTS" ||
                  this.product.Name === "ePOTS" ||
                  this.product.Name === "Mobility" ||
                  this.product.Name === "Guardian" ||
                  this.product.Name === "VoIP" ||
                  this.product.Name === "Voice over Cable Line") &&
                response.apiName == "QTY__c"
              ) {
                //this.qtyValue=1;
                //this.addATAEquipment(this.product.Name);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "QTY__c",
                  this.qtyValue,
                  this.parentPicklistIds.length - 1
                );
              } else if (
                this.product.Name === "ePOTS" &&
                response.apiName == "QTY__c"
              ) {
                this.addATAEquipment(this.product.Name);
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "QTY__c",
                  this.qtyValue,
                  this.parentPicklistIds.length - 1
                );
              } else if (
                this.product.Name === "Mobility" &&
                response.apiName == "Product_Description__c"
              ) {
                this.productPicklistValues.push(response);
                this.addToParentPicklistValues("Product_Description__c", "");
                this.dispatchPicklistChangeEvent(
                  "productnextchange",
                  "Product_Description__c",
                  this.qtyValue,
                  this.parentPicklistIds.length - 1
                );
                this._getNextProductPicklistsValues(
                  "Product_Description__c",
                  this.getParentPicklistValues(),
                  this.product.Name
                );
              } else {
                if (
                  this.product.Name == "DIA" &&
                  response.apiName == "ProductCode_Description__c"
                ) {
                  console.log(JSON.stringify(response));
                  response.showTooltip = true;
                  var prdtCodeDesc = response.values[0].value;
                  response.selectedValue = prdtCodeDesc;
                  this.productPicklistValues.push(response);
                  this.data["ProductCode_Description__c"] = prdtCodeDesc;
                  this.addToParentPicklistValues(
                    "ProductCode_Description__c",
                    prdtCodeDesc
                  );
                  var parentValues = this.getParentPicklistValues();
                  parentValues.push(prdtCodeDesc);
                  this.dispatchPicklistChangeEvent(
                    "productnextchange",
                    "ProductCode_Description__c",
                    response.values[0].label,
                    this.parentPicklistIds.length - 1
                  );
                  this._getNextProductPicklistsValues(
                    "ProductCode_Description__c",
                    this.getParentPicklistValues(),
                    this.product.Name
                  );
                }
                else if (
                  this.product.Name == "VoIP" &&
                  response.apiName == "Preferred_Product__c"
                ) {
                  var prdtCodeDesc = response.values[0].value;
                  response.selectedValue = prdtCodeDesc;
                  this.productPicklistValues.push(response);
                  this.data["Preferred_Product__c"] = prdtCodeDesc;
                  this.addToParentPicklistValues(
                    "Preferred_Product__c",
                    prdtCodeDesc
                  );
                  var parentValues = this.getParentPicklistValues();
                  parentValues.push(prdtCodeDesc);
                  this.dispatchPicklistChangeEvent(
                    "productnextchange",
                    "Preferred_Product__c",
                    response.values[0].label,
                    this.parentPicklistIds.length - 1
                  );
                  this._getNextProductPicklistsValues(
                    "Preferred_Product__c",
                    this.getParentPicklistValues(),
                    this.product.Name
                  );
                } 
                else if (
                  this.product.Name == "Broadband" &&
                  response.apiName == "Ip_Block__c"
                ) {
                  console.log(JSON.stringify(response));
                  response.showTooltip = true;
                  this.productPicklistValues.push(response);
                } 
                else if (
                  this.product.Name == "GRID" &&
                  response.apiName == "Grid_Voice_Package__c"
                ) {
                  console.log("test-test--", JSON.stringify(response));
                  var gridPackage = response.values[0].value;
                  response.selectedValue = gridPackage;
                  console.log("test-response.selectedValue ", response.label);
                  response.label = "Voice/Equipment Package";
                  this.productPicklistValues.push(response);
                  this.data["Grid_Voice_Package__c"] = gridPackage;
                  this.addToParentPicklistValues(
                    "Grid_Voice_Package__c",
                    gridPackage
                  );
                  var parentValues = this.getParentPicklistValues();
                  parentValues.push(gridPackage);
                  this.dispatchPicklistChangeEvent(
                    "productnextchange",
                    "Grid_Voice_Package__c",
                    "",
                    this.parentPicklistIds.length - 1
                  );
                  this._getNextProductPicklistsValues(
                    "Grid_Voice_Package__c",
                    this.getParentPicklistValues(),
                    this.product.Name
                  );
                } else if (
                  this.product.Name == "GRID" &&
                  response.apiName == "IP_Type__c"
                ) {
                  console.log("test-test--", JSON.stringify(response));
                  var ipType = response.values[0].value;
                  response.selectedValue = ipType;
                  console.log("test-response.selectedValue ", response.label);
                  this.productPicklistValues.push(response);
                  this.data["IP_Type__c"] = ipType;
                  this.addToParentPicklistValues("IP_Type__c", ipType);
                  var parentValues = this.getParentPicklistValues();
                  parentValues.push(ipType);
                  this.dispatchPicklistChangeEvent(
                    "productnextchange",
                    "IP_Type__c",
                    response.values[0].label,
                    this.parentPicklistIds.length - 1
                  );
                  this._getNextProductPicklistsValues(
                    "IP_Type__c",
                    this.getParentPicklistValues(),
                    this.product.Name
                  );
                }else if ((this.product.Name == "edgeboot")) {
                  if(response.apiName == "Ip_Block__c") {
                    var prdTerm = response.values[0].value;
                    response.selectedValue = prdTerm;
                    this.productPicklistValues.push(response);
                    this.data["Ip_Block__c"] = prdTerm;
                    this.addToParentPicklistValues("Ip_Block__c", prdTerm);
                    var parentValues = this.getParentPicklistValues();
                    parentValues.push(prdTerm);
                    this.dispatchPicklistChangeEvent(
                      "productnextchange",
                      "Ip_Block__c",
                      response.values[0].label,
                      this.parentPicklistIds.length - 1
                    );
                    this._getNextProductPicklistsValues(
                      "Ip_Block__c",
                      this.getParentPicklistValues(),
                      this.product.Name
                    );
                  }
                  else if(response.apiName == "Term__c") {
                    const contrcttermLabel = response.values.find(
                      (item) => item.label === "3 Years"
                    );
                    response.selectedValue = contrcttermLabel.value;
                    this.productPicklistValues.push(response);
                    this.data["Term__c"] = contrcttermLabel.value;
                    this.addToParentPicklistValues(
                      "Term__c",
                      contrcttermLabel.value
                    );
                    var parentValues = this.getParentPicklistValues();
                    parentValues.push(contrcttermLabel);
                    this.dispatchPicklistChangeEvent(
                      "productnextchange",
                      "Term__c",
                      contrcttermLabel.label,
                      this.parentPicklistIds.length - 1
                    );
                    this._getNextProductPicklistsValues(
                      "Term__c",
                      this.getParentPicklistValues(),
                      this.product.Name
                    );
                  }
                }
                else if (this.product.Name == "VoIP" && response.apiName == "Term__c") {
                  var prdTerm = response.values[2].value;
                 
                  response.selectedValue = prdTerm;
                  this.productPicklistValues.push(response);
                  this.data["Term__c"] = prdTerm;
                  this.addToParentPicklistValues("Term__c", prdTerm);
                  var parentValues = this.getParentPicklistValues();
                  parentValues.push(prdTerm);
                  this.dispatchPicklistChangeEvent(
                    "productnextchange",
                    "Term__c",
                    response.values[2].label,
                    this.parentPicklistIds.length - 1
                  );
                  this._getNextProductPicklistsValues(
                    "Term__c",
                    this.getParentPicklistValues(),
                    this.product.Name
                  );
                } else {
                  this.productPicklistValues.push(response);
                }
              }
            }
          } else {
            this._getNextProductPicklistsValues(
              response.apiName,
              currentPicklistValues,
              productName
            );
          }
        }
      })
      .catch((err) => {
        console.log(err);
      });
  }

  addToParentPicklistValues(apiName, value) {
    if (apiName) {
      if (!this.parentPicklistIds) {
        this.parentPicklistIds = [];
      }
      let hasMatchFound = false;
      this.parentPicklistIds.forEach((picklistVal) => {
        if (picklistVal.apiName == apiName) {
          hasMatchFound = true;
          picklistVal.value = value;
        }
      });
      if (hasMatchFound != true) {
        this.parentPicklistIds.push({ apiName, value });
      }
    }
  }

  getParentPicklistValues() {
    let values = [];
    this.parentPicklistIds.forEach((picklistVal) => {
      if(picklistVal.value){
        values.push(picklistVal.value);
      }
    });
    return values;
  }

  @api validateInputFields() {
    let combos = this.template.querySelectorAll("lightning-combobox");
    let inputF = this.template.querySelectorAll("lightning-input");
    let inputTa = this.template.querySelectorAll("lightning-textarea");
    let isFormValid = true;
    if (combos) {
      combos.forEach((combo) => {
        if (combo.checkValidity() != true) {
          combo.reportValidity();
          isFormValid = false;
        }
      });
    }
    if (inputF) {
      inputF.forEach((inp) => {
        if (inp.checkValidity() != true) {
          inp.reportValidity();
          isFormValid = false;
        }
      });
    }
    if (inputTa) {
      inputTa.forEach((inp) => {
        if (inp.checkValidity() != true) {
          inp.reportValidity();
          isFormValid = false;
        }
      });
    }

    let addFeatures = this.template.querySelectorAll(
      "c-add-features-container"
    );
    if (addFeatures) {
      addFeatures.forEach((feature) => {
        let isAddFeatureFormValid = feature.validateForm();
        isFormValid = isFormValid && isAddFeatureFormValid;
      });
    }
    let addFeatureVOC = this.template.querySelectorAll(
      "c-add-on-features-v-o-c"
    );
    if (addFeatureVOC) {
      addFeatureVOC.forEach((feature) => {
        let isAddFeatureFormValidVOC = feature.validateForm();
        isFormValid = isFormValid && isAddFeatureFormValidVOC;
      });
    }


    let addSeats = this.template.querySelectorAll(
      "c-add-seat-offers-container"
    );
    if (addSeats) {
      addSeats.forEach((seat) => {
        let isAddSeatFormValid = seat.validateSeats();
        isFormValid = isFormValid && isAddSeatFormValid;
      });
    }

    return { prodId: this.prodId, isInputsCorrect: isFormValid };
  }

  dispatchPicklistChangeEvent(eventName, fieldApiName, fieldValue, fieldIndex) {
    let detail = {};
    detail.prodId = this.prodId;
    detail.quotId = this.quoteId;
    detail.fieldName = fieldApiName;
    detail.fieldValue = fieldValue;
    if (fieldIndex) {
      detail.fieldIndex = fieldIndex;
    }
    const eventToDispatch = new CustomEvent(eventName, { detail });
    this.dispatchEvent(eventToDispatch);
  }

  async showRouterData() {
    console.log(
      this.accessType + " " + this.speedValue + " " + this.contractTerm
    );
    if (this.accessType != "" && this.speedValue != "") {
      await getAvailableRouters({
        accessTypeValue: this.accessType,
        speedValue: this.speedValue
      })
        .then((res) => {
          console.log("Got routers", res);
          if (res && res.length > 0) {
            let data = res[0];
            this._routerData = Object.assign(
              {},
              this._routerBackUpData ? this._routerBackUpData : data,
              data,
              { Name: "Router" }
            );
            this._routerData["Child_Quote_item_Product_Type__c"] = "Router";
            this._routerData["Equipment_Term__c"] = this.contractTerm;
            if (data.Id == this._routerData.Id) delete this._routerData.Id;
            if (this._routerBackUpData)
              this._routerData["Id"] = this._routerBackUpData.Id;

            this._routerBackUpData = this._routerData;
            this.enableRouterData = true;
            this.enableProductLinks = false;
            this.syncRouterData("upsert");
          } else {
            this.enableRouterData = false;
            this.enableProductLinks = true;
            const evt = new ShowToastEvent({
              title: "No router found!",
              message:
                "No router found with the combination of Access Type and Speed.",
              variant: "error",
              mode: "dismissable"
            });
            this.dispatchEvent(evt);
            this._routerData = undefined;
            this.syncRouterData("delete");
          }
          //TODO to clarify what if user changes the speed /access type should the router change as well?
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      const evt = new ShowToastEvent({
        title: "Error",
        message: "Please select Access Type and Speed.",
        variant: "error",
        mode: "dismissable"
      });
      this.dispatchEvent(evt);
    }
  }

  syncEquipmentData(equipList, status, prodType) {
    if (equipList && equipList.length > 0) {
      equipList.forEach((prod) => {
        let outputProdData = [];
        if (prod) {
          outputProdData = Object.keys(prod).map(function (i) {
            return { prodName: i, prodValue: prod[i] };
          });
        }

        let productNxtEvt = new CustomEvent("childproductchange", {
          detail: {
            quotId: this.quoteId,
            prodId: this.prodId,
            prodData: outputProdData,
            productType: prodType,
            dmlOperation: status
          }
        });
        this.dispatchEvent(productNxtEvt);
      });
    }
  }

  syncRouterData(dmlVal) {
    let outputProdData = [];
    let data = this._routerData;
    if (data) {
      outputProdData = Object.keys(data).map(function (i) {
        return { prodName: i, prodValue: data[i] };
      });
    }
    const productNxtEvt = new CustomEvent("childproductchange", {
      detail: {
        quotId: this.quoteId,
        prodId: this.prodId,
        prodData: outputProdData,
        productType: "Router",
        dmlOperation: dmlVal
      }
    });
    this.dispatchEvent(productNxtEvt);
  }

  hideRouterData() {
    this.enableRouterData = false;
    this.enableProductLinks = true;
    //this._routerData = undefined;
    this.syncRouterData("delete");
  }

  populateDiversityData() {
    const productNxtEvt1 = new CustomEvent("productnextchange", {
      detail: {
        fieldIndex: this.data.length - 1,
        quotId: this.quoteId,
        prodId: this.prodId,
        fieldName: "Diversity_Requested__c",
        fieldValue: this.hasDiversityRequested ? "Yes" : "No"
      }
    });
    this.dispatchEvent(productNxtEvt1);

    const productNxtEvt2 = new CustomEvent("productnextchange", {
      detail: {
        fieldIndex: this.data.length - 1,
        quotId: this.quoteId,
        prodId: this.prodId,
        fieldName: "Diversity_Type__c",
        fieldValue: this.hasDiversityRequested ? this.diversityValue : "No"
      }
    });
    this.dispatchEvent(productNxtEvt2);
  }

  requestDiversity(event, existValue) {
    this.hasDiversityRequested = event.target.checked;
    if (!this.hasDiversityRequested) {
      this.populateDiversityData();
    }

    /*if (event && this.enableRequestDiversity) {
            const productNxtEvt = new CustomEvent("productnextchange", {
                detail: {
                    fieldIndex: this.data.length - 1,
                    quotId: this.quoteId,
                    prodId: this.prodId,
                    fieldName: 'Diversity_Type__c',
                    fieldValue: this.diversityValue
                }
            });
            this.dispatchEvent(productNxtEvt);
        }
        
        // if(!this.hasDiversityRequested && this.diversityValue){
        //     const productNxtEvt = new CustomEvent("productnextchange", {
        //         detail:{
        //             fieldIndex : this.data.length - 1,
        //             quotId : this.quoteId,
        //             prodId : this.prodId,
        //             fieldName  : 'Diversity_Type__c',
        //             fieldValue : 'No'
        //         }
        //     });
        //     this.dispatchEvent(productNxtEvt);
        // }

        if(this.hasDiversityRequested && this.diversityValue){
            const productNxtEvt = new CustomEvent("productnextchange", {
                detail:{
                    fieldIndex : this.data.length - 1,
                    quotId : this.quoteId,
                    prodId : this.prodId,
                    fieldName  : 'Diversity_Type__c',
                    fieldValue : this.diversityValue
                }
            });
            this.dispatchEvent(productNxtEvt);
        }*/
  }

  get diversityOptions() {
    return [
      { label: "Carrier Diversity", value: "Carrier Diversity" },
      { label: "Path Diversity", value: "Path Diversity" },
      { label: "Building Entry Diversity", value: "Building Entry Diversity" }
    ];
  }
  handleDiversity(event) {
    this.diversityValue = event.detail.value;

    this.populateDiversityData();
    /*console.log('has diversity value : ',this.diversityValue);
        if(event && this.diversityValue) {
            const productNxtEvt = new CustomEvent("productnextchange", {
                detail:{
                    fieldIndex : this.data.length - 1,
                    quotId : this.quoteId,
                    prodId : this.prodId,
                    fieldName  : 'Diversity_Type__c',
                    fieldValue : this.diversityValue
                }
            });
            this.dispatchEvent(productNxtEvt);
        }*/
  }

  notesChange(event) {
    console.log("event target : ", event.target, event.detail);
    this.noteContent = event.detail.value;

    this.data["Notes__c"] = event.target.value;
    this.data["Notes_Source__c"] = "Diversity Request";
    /*console.log('Note Content : ',this.noteContent);
        const noteDiversityEvent = new CustomEvent("diversitynotechange", {
            detail: this.noteContent
        });
        // Dispatches the event
        this.dispatchEvent(noteDiversityEvent);*/

    const productNxtEvt = new CustomEvent("productnextchange", {
      detail: {
        fieldIndex: this.data.length - 1,
        quotId: this.quoteId,
        prodId: this.prodId,
        fieldName: "Notes__c",
        fieldValue: this.noteContent
      }
    });
    this.dispatchEvent(productNxtEvt);

    const productNxtEvt1 = new CustomEvent("productnextchange", {
      detail: {
        fieldIndex: this.data.length - 1,
        quotId: this.quoteId,
        prodId: this.prodId,
        fieldName: "Notes_Source__c",
        fieldValue: "Diversity Request"
      }
    });
    this.dispatchEvent(productNxtEvt1);
  }

  removeAdditionalFeature() {
    if (
      this.additionalFeatureExData &&
      this.additionalFeatureExData.length > 0
    ) {
      this.additionalFeatureExData.forEach((prod) => {
        let detailObj = {
          quotId: prod.quotId,
          prodId: prod.prodId,
          prodData: prod.prodData,
          productType: prod.productType,
          dmlOperation: "delete"
        };
        let productNxtEvt = new CustomEvent("childproductchange", {
          detail: detailObj
        });

        this.dispatchEvent(productNxtEvt);
      });
    }
  }
   removeMobilityOptionalServices() {
    if (
      this.optionalServiceMobilityEXData &&
      this.optionalServiceMobilityEXData.length > 0
    ) {
      this.optionalServiceMobilityEXData.forEach((prod) => {
        let detailObj = {
          quotId: prod.quotId,
          prodId: prod.prodId,
          prodData: prod.prodData,
          productType: prod.productType,
          dmlOperation: "delete"
        };
        let productNxtEvt = new CustomEvent("childproductchange", {
          detail: detailObj
        });

        this.dispatchEvent(productNxtEvt);
      });
    }
  }

  removeAddOnFeatures() {
    if (this.addOnFeaturesExData && this.addOnFeaturesExData.length > 0) {
      this.addOnFeaturesExData.forEach((prod) => {
        let detailObj = {
          quotId: prod.quotId,
          prodId: prod.prodId,
          prodData: prod.prodData,
          productType: prod.productType,
          dmlOperation: "delete"
        };
        let productNxtEvt = new CustomEvent("childproductchange", {
          detail: detailObj
        });

        this.dispatchEvent(productNxtEvt);
      });
    }
  }

  removeAddOnSeats() {
    if (
      this.addOnSeatFeaturesExData &&
      this.addOnSeatFeaturesExData.length > 0
    ) {
      this.addOnSeatFeaturesExData.forEach((prod) => {
        let detailObj = {
          quotId: prod.quotId,
          prodId: prod.prodId,
          prodData: prod.prodData,
          productType: prod.productType,
          dmlOperation: "delete"
        };
        let productNxtEvt = new CustomEvent("childproductchange", {
          detail: detailObj
        });

        this.dispatchEvent(productNxtEvt);
      });
    }
  }

  removeAddOnFeaturesSIP() {
    if (this.addonSIPFeaturesExData && this.addonSIPFeaturesExData.length > 0) {
      this.addonSIPFeaturesExData.forEach((prod) => {
        let detailObj = {
          quotId: prod.quotId,
          prodId: prod.prodId,
          prodData: prod.prodData,
          productType: prod.productType,
          dmlOperation: "delete"
        };
        let productNxtEvt = new CustomEvent("childproductchange", {
          detail: detailObj
        });

        this.dispatchEvent(productNxtEvt);
      });
    }
  }

  hndlAddtnlFtrDtChng(event) {
    if (event.detail) {
      if (event.detail.productType == "AdditionalFeature") {
        if (event.detail.features && event.detail.features.length > 0) {
          event.detail.features.forEach((prod) => {
            let detailObj = {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: prod.prodFields,
              productType: prod.prodtype,
              dmlOperation: prod.status
            };
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: detailObj
            });

            this.additionalFeatureExData.push(detailObj);
            this.dispatchEvent(productNxtEvt);
          });
        } else if (event.detail.features && event.detail.features.length <= 0) {
          let productNxtEvt = new CustomEvent("childproductchange", {
            detail: {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: [],
              productType: "AdditionalFeature",
              dmlOperation: "truncate"
            }
          });
          this.dispatchEvent(productNxtEvt);
        }
      } else {
        if (event.detail.length > 0) {
          event.detail.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        }
      }
    }
  }

  handleOptionalServices(event) {
    if (event.detail) {
      if (event.detail.productType == "OptionalService") {
        if (event.detail.features && event.detail.features.length > 0) {
          event.detail.features.forEach((prod) => {
             let detailObj = {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
            };
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: detailObj
            });
            this.optionalServiceMobilityEXData.push(detailObj);
            this.dispatchEvent(productNxtEvt);
          });
        } else if (event.detail.features && event.detail.features.length <= 0) {
          let productNxtEvt = new CustomEvent("childproductchange", {
            detail: {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: [],
              productType: "OptionalService",
              dmlOperation: "truncate"
            }
          });
          this.dispatchEvent(productNxtEvt);
        }
      } else {
        if (event.detail.length > 0) {
          event.detail.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        }
      }
    }
  }
  handleVOCFeatures(event) {
    if (event.detail) {
      if (event.detail.productType == "VOCFeatures") {
        if (event.detail.features && event.detail.features.length > 0) {
          event.detail.features.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        } else if (event.detail.features && event.detail.features.length <= 0) {
          let productNxtEvt = new CustomEvent("childproductchange", {
            detail: {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: [],
              productType: "VOCFeatures",
              dmlOperation: "truncate"
            }
          });
          this.dispatchEvent(productNxtEvt);
        }
      } else {
        if (event.detail.length > 0) {
          event.detail.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        }
      }
    }
  }
  handleHPBXFeatures(event) {
    if (event.detail) {
      if (event.detail.productType == "AddOnFeatures") {
        if (event.detail.features && event.detail.features.length > 0) {
          event.detail.features.forEach((prod) => {
            let detailObj = {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: prod.prodFields,
              productType: prod.prodtype,
              dmlOperation: prod.status
            };
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: detailObj
            });

            this.addOnFeaturesExData.push(detailObj);
            this.dispatchEvent(productNxtEvt);
          });
        } else if (event.detail.features && event.detail.features.length <= 0) {
          let productNxtEvt = new CustomEvent("childproductchange", {
            detail: {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: [],
              productType: "AddOnFeatures",
              dmlOperation: "truncate"
            }
          });
          this.dispatchEvent(productNxtEvt);
        }
      } else {
        if (event.detail.length > 0) {
          event.detail.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        }
      }
    }
  }

  handleSeatOffers(event) {
    if (event.detail) {
      if (event.detail.productType == "Offer") {
        if (event.detail.features && event.detail.features.length > 0) {
          event.detail.features.forEach((prod) => {
            let detailObj = {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: prod.prodFields,
              productType: prod.prodtype,
              dmlOperation: prod.status
            };
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: detailObj
            });

            this.addOnSeatFeaturesExData.push(detailObj);
            this.dispatchEvent(productNxtEvt);
          });
        } else if (event.detail.features && event.detail.features.length <= 0) {
          let productNxtEvt = new CustomEvent("childproductchange", {
            detail: {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: [],
              productType: "Offer",
              dmlOperation: "truncate"
            }
          });
          this.dispatchEvent(productNxtEvt);
        }
      } else {
        if (event.detail.length > 0) {
          event.detail.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        }
      }
    }
  }

  handleSIPFeatures(event) {
    if (event.detail) {
      if (event.detail.productType == "SIPAdditionalFeatures") {
        if (event.detail.features && event.detail.features.length > 0) {
          event.detail.features.forEach((prod) => {
            let detailObj = {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: prod.prodFields,
              productType: prod.prodtype,
              dmlOperation: prod.status
            };
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: detailObj
            });

            this.addonSIPFeaturesExData.push(detailObj);
            this.dispatchEvent(productNxtEvt);
          });
        } else if (event.detail.features && event.detail.features.length <= 0) {
          let productNxtEvt = new CustomEvent("childproductchange", {
            detail: {
              quotId: this.quoteId,
              prodId: this.prodId,
              prodData: [],
              productType: "SIPAdditionalFeatures",
              dmlOperation: "truncate"
            }
          });
          this.dispatchEvent(productNxtEvt);
        }
      } else {
        if (event.detail.length > 0) {
          event.detail.forEach((prod) => {
            let productNxtEvt = new CustomEvent("childproductchange", {
              detail: {
                quotId: this.quoteId,
                prodId: this.prodId,
                prodData: prod.prodFields,
                productType: prod.prodtype,
                dmlOperation: prod.status
              }
            });
            this.dispatchEvent(productNxtEvt);
          });
        }
      }
    }
  }
  requestPRIHandoof(event, existValue) {
    if (event.target.checked === true) {
      this.hasPRIHandoffRequested = event.target.checked;
    } else {
      this.hasPRIHandoffRequested = false;
    }
    const productNxtEvt1 = new CustomEvent("productnextchange", {
      detail: {
        fieldIndex: this.data.length - 1,
        quotId: this.quoteId,
        prodId: this.prodId,
        fieldName: "PRI_Handoff__c",
        fieldValue: this.hasPRIHandoffRequested
      }
    });
    this.dispatchEvent(productNxtEvt1);
  }

  handleGDNCheckbox(event){
    this.showGDNServices = event.target.checked;
  }
}