import { LightningElement, track, api, wire } from "lwc";
import fetchFieldLabels from "@salesforce/apex/QuoteOptionsController.getFieldLabels";
import QUOTE_OPTION_ITEM_OBJECT from "@salesforce/schema/Quote_Option_Item__c";
import QUOTE_REQUEST_RATES_OBJECT from "@salesforce/schema/Quote_Request_Rates__c";
import QUOTE_REQUEST_OBJECT from "@salesforce/schema/Quote_Request_2__c";
import fetchA3lookupCall from "@salesforce/apex/QuoteOptionsController.fetchA3LookupMap";
import { getPicklistValues } from "lightning/uiObjectInfoApi";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import QRR_ID from "@salesforce/schema/Quote_Request_Rates__c.Id";
import PARENTQRR_ID from "@salesforce/schema/Quote_Request_Rates__c.Parent_Quote_Request_Rates__c";
import UNIT_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Unit__c";
import PICCPRICING_FIELD from "@salesforce/schema/Quote_Request_Rates__c.PICC_Pricing_Tier__c";
import NACPRICING_FIELD from "@salesforce/schema/Quote_Request_Rates__c.NAC_Pricing_Tier__c";
import ON_NET_FIELD from "@salesforce/schema/Quote_Request_Rates__c.On_Net__c";
import ACTIVATION_COST_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Activation_Cost__c";
import ACTIVATION_MRC_NRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Activation_MRC_NRC_Rate__c";
import GC_MRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.GC_MRC__c";
import GC_NRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.GC_NRC__c";
import CURRENT_TOTAL_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Current_Total__c";
import IP_MRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.IP_MRC_Rate__c";
import EQUIP_MRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Equip_MRC_Rate__c";
import COS_MRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.COS_MRC__c";
import COS_COST_FIELD from "@salesforce/schema/Quote_Request_Rates__c.COS_Cost__c";
import TOTAL_MRC_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Total_MRC__c";
import SAVING_AMOUNT_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Saving_Amount__c";
import SAVING_PERCENTAGE_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Saving_Percentage__c";
import SURCHARGE_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Surcharge__c";
import ID_FIELD from "@salesforce/schema/Quote_Request_2__c.Id";
import Special_Pricing__Field from "@salesforce/schema/Quote_Request_2__c.Special_Pricing__c";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getRecord, getFieldValue, updateRecord } from "lightning/uiRecordApi";
import getQuoteRequestRates from "@salesforce/apex/NQRLocationsTableController.getQuoteRequestRates";
import updateVendorQRRatesCall from "@salesforce/apex/NQRLocationsTableController.updateVendorQRRates";
import updateChildQRRates from "@salesforce/apex/NQRLocationsTableController.updateChildQRRates";
import getActionStatuses from "@salesforce/apex/NewQuoteRequestHandler.getActionStatuses";
import spAppliedValueRefresh from "@salesforce/apex/NewQuoteRequestHandler.spAppliedValueChange";
import { publish, createMessageContext } from "lightning/messageService";
import A3QuotingMessageChannel from "@salesforce/messageChannel/A3QuotingMessageChannel__c";
import QR_Status from "@salesforce/schema/Quote_Request_2__c.Quote_Request_Status__c";
import SPAppliedRule from "@salesforce/apex/QuoteOptionsController.isSPApplied";
import markerIcon from "@salesforce/resourceUrl/MarkerIcon";
import updateRateBasedOnDownSpeed from "@salesforce/apex/NQRLocationsTableController.updateRateBasedOnDownSpeed";


const fields = [
  QRR_ID,
  UNIT_FIELD,
  PICCPRICING_FIELD,
  NACPRICING_FIELD,
  ACTIVATION_COST_FIELD,
  ACTIVATION_MRC_NRC_FIELD,
  ON_NET_FIELD,
  GC_MRC_FIELD,
  GC_NRC_FIELD,
  CURRENT_TOTAL_FIELD,
  IP_MRC_FIELD,
  EQUIP_MRC_FIELD,
  TOTAL_MRC_FIELD,
  SAVING_AMOUNT_FIELD,
  SAVING_PERCENTAGE_FIELD,
  COS_MRC_FIELD,
  COS_COST_FIELD,
  SURCHARGE_FIELD
];
export default class ChildExpand extends LightningElement {
  @api quoteRequestQuoteType;
  @api quoteRequestBusinessUnit;
  @api loggedInUser;
  @api dwnSpeedWrapperList;
  showLoading = false;
  showSpinner = false;
  qrrFields = [
    UNIT_FIELD,
    PICCPRICING_FIELD,
    NACPRICING_FIELD,
    ACTIVATION_COST_FIELD,
    ACTIVATION_MRC_NRC_FIELD,
    ON_NET_FIELD,
    SURCHARGE_FIELD,
    GC_MRC_FIELD,
    GC_NRC_FIELD,
    CURRENT_TOTAL_FIELD,
    IP_MRC_FIELD,
    EQUIP_MRC_FIELD,
    TOTAL_MRC_FIELD,
    SAVING_AMOUNT_FIELD,
    SAVING_PERCENTAGE_FIELD,
    COS_MRC_FIELD,
    COS_COST_FIELD
  ];
  @track finalProdArray = [];
  @track childColumn = [];
  @track quoteRequestRatesId = "";
  @api recordId;
  @api isQuoteSubmitted;
  @track isQuotePendingSPSESumitted = false;
  @api isPendingSpOrSeReview;
  @track helpTextEasyAA = false;
  surchargeChild = false;
  isEquipMRC = false;
  isEquipNRC = false;
  isSPApplied = "No";
  epikPricingTierValue;
  qoiFeatureMap = new Map();
  @track isSecondarySIM = false;
  isCallPath = false;
  isHighAvail = false;
  isCurrentCarrier = false;
  isConversionType = false;
  isSurcharge = false;
  isNewInstall = false;
  @api qrrObjPrefix;
  srimage = markerIcon;
  @api disbaleChildCheckbox;

  quoteRequest = QUOTE_REQUEST_OBJECT;

  @api childResponseJson;
  @api locationCheckedType = 'All';	
  @api isLocationSelected = false;

  @api configWrap;
  @api qoiVendorsMap;
  @api qoiRatesMap;
  @api childQoiRateMap;
  @api qoiList;
  @api qloProdIdMap;
  @api quoteOptionId;
  passwordHintClass1 =
    "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide";

  potsFieldMap = new Map([
    ["Circuit_MRC_Rate1__c", "Flat Rate"],
    ["IP_MRC_Rate__c", "EUCL"],
    ["Default_Router_Rate__c", "ARC"],
    ["Default_Router_Cost__c", "LNP"],
    ["COS_MRC__c", "PTA/PTR"],
    ["COS_Cost__c", "PICC"]
  ]);

  @wire(getRecord, { recordId: "$quoteRequestRatesId", fields })
  quoteRequestRates;
  @wire(getObjectInfo, { objectApiName: QUOTE_REQUEST_RATES_OBJECT })
  quoteRequestRates;

  @wire(getPicklistValues, {
    recordTypeId: "$quoteRequestRates.data.defaultRecordTypeId",
    fieldApiName: ON_NET_FIELD
  })
  onNetPicklist;
  @api get locationId() {
    return this._locationId;
  }
  set locationId(value) {
    this._locationId = value;
  }

  @wire(getRecord, { recordId: '$recordId', fields: [QR_Status] })
  QuoteRequest;
  get qrstatus() {
    return getFieldValue(this.QuoteRequest.data, QR_Status);
  }

  arePricesReadOnly = false;

  productIds;
  isViewUpdated = false;
  actionStatuses;
  messageContext = createMessageContext();

  @api getRatesData(locationId, productIds, isSelected) {
    if (locationId === this._locationId) {
      this.productIds = productIds;
      if (
        this.loggedInUser &&
        this.loggedInUser.lstPermissionSet &&
        (this.loggedInUser.lstPermissionSet.includes("SalesRep") ||
          this.loggedInUser.lstPermissionSet.includes("GRID_SalesRep") ||
          this.loggedInUser.lstPermissionSet.includes("SalesRepManager") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelSalesRep") ||
          this.loggedInUser.lstPermissionSet.includes(
            "ChannelSalesRepManager"
          ) ||
          this.loggedInUser.lstPermissionSet.includes("SplPricing") ||
          this.loggedInUser.lstPermissionSet.includes("OMAnalyst") ||
          this.loggedInUser.lstPermissionSet.includes("OMAnalystManager") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelSalesEng") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelsDirector") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelsQuoter") ||
          this.loggedInUser.lstPermissionSet.includes("ChannelsSupport") ||
          this.loggedInUser.lstPermissionSet.includes("SplPricingManager") ||
          this.loggedInUser.lstPermissionSet.includes("Premier"))
      ) {
        this.getRequestRateApexCall(
          this.loggedInUser.lstPermissionSet,
          isSelected
        );
      } else {
        let arrValue = [];
        this.getRequestRateApexCall(arrValue, isSelected);
      }
    }
  }

  getRequestRateApexCall(permissions, isSelected) {
    this.showLoading = true;
    getQuoteRequestRates({
		qrId: this.recordId,
      quoteOptionItemIds: this.productIds,
      locationId: this.locationId,
      userPermissions: permissions
    })
      .then((response) => {
        console.log("child response sur: ", JSON.parse(response));
        //this.finalProdArray = [];
        if (response) {
          //this.renderProducts(response, isSelected);
          this.showLoading = false;
        }
      })
      .catch((error) => {
        this.showLoading = false;
        console.log("getRatesData error ==>" + JSON.stringify(error));
      });
  }

  @track _selectedProdId = [];
  @track _selectedProdLoacMap = new Map();
  @api get selectedProdLoacMap() {
    return this._selectedProdLoacMap;
  }
  set selectedProdLoacMap(value) {
    this._selectedProdLoacMap = value;
  }

  connectedCallback() {
    this.onLoad();
  }
  
  @api
  refreshChildData(configWrap,qoiList,qoiVendorsMap,qoiRatesMap,childQoiRateMap,qloProdIdMap){
    this.configWrap = configWrap;
    this.qoiVendorsMap = qoiVendorsMap;
    this.qoiRatesMap = qoiRatesMap;
    this.childQoiRateMap=childQoiRateMap;
    this.qoiList = qoiList;
    this.qloProdIdMap = qloProdIdMap;

    this.onLoad();
  }

  permissionCheck(permissionList){
    let permissionExisted = false;
    let userPermissionsList = this.loggedInUser && this.loggedInUser.lstPermissionSet ? this.loggedInUser.lstPermissionSet : [];
    for(let i=0;i<permissionList.length;i++){
      let perm = permissionList[i];
      if(userPermissionsList.includes(perm)){
        permissionExisted = true;
        break;
      }
    } 

    return permissionExisted;
  }

  get downloadSpeedText(){
    return true;
  }

  getdownloadSpeedOptions(dwnSpeedWrapperList){
    let options = [];
    options.push({ label: "Select", value: "" });
    for (let i = 0; i < dwnSpeedWrapperList.length; i++) {
      let dwnSpeedObj = dwnSpeedWrapperList[i];
      options.push({ label: dwnSpeedObj.downloadSpeed, value: dwnSpeedObj.rateId+'~'+dwnSpeedObj.locationId+'~'+dwnSpeedObj.prodId });
    }
    return options;
  }

  getVendorOptions(prodName,prodId,a3LookupMap,qoiVendorMap){
    let vendorOptions = [];      
    let hasDIALocalVendors = false;
    let vendorList = [];
    let permissionList = ["SplPricing","OMAnalyst","OMAnalystManager","SplPricingManager","ChannelsQuoter"];
    let permissionExisted = this.permissionCheck(permissionList);
    if(prodName == 'DIA' && permissionExisted && a3LookupMap && a3LookupMap[prodName] && a3LookupMap[prodName].Vendor__c) {
      vendorList = a3LookupMap[prodName].Vendor__c.split("~");
      hasDIALocalVendors = true;
    }

    if(qoiVendorMap && qoiVendorMap[prodId]) {
      let vendorRatesList = qoiVendorMap[prodId];
      vendorOptions = this.generateDropdownOptionsFromRates(vendorRatesList,hasDIALocalVendors);
    }

    if(hasDIALocalVendors) {
      let a3VendorOptions = this.generateDropdownOptions(vendorOptions,vendorList);
      vendorOptions.push(a3VendorOptions);
    }

    return vendorOptions;
  }

  getGridVoicPackageValue(fieldValue){
    let fValue = '-';
    if (fieldValue == "Grid Voice Package A - Netvanta 3140 - HT812") {
      fValue = "A";
    }
    else if(fieldValue == "Grid Voice Package B - Netvanta 3140 - HT814") {
      fValue = "B";
    } 
    else if (fieldValue == "Grid Voice Package C - Netvanta 3140 - HT818") {
      fValue = "C";
    }
    else if (fieldValue == "Grid Voice Package D - Adtran 908.B") {
      fValue = "D";
    }
    else if (fieldValue == "Grid Voice Package E - Adtran 916.B") {
      fValue = "E";
    }
    return fValue;
  }

  includeProdFieldCheck(prodName,fieldAPI,fieldValue,prodItem){
    let includeField = true;
    if(prodName == "GRID"){
      if(fieldAPI == 'Minimum_Speed__c' && this.isQuoteSubmitted){
        includeField = false;
      }
      else if(fieldAPI == 'Ip_Block__c' && !fieldValue){
        includeField = false;
      }
    }
    else if(prodName == "VoIP"){
      let isCallPath = prodItem["Product_Detail1__c"] == 'SIP' ? true : false;
      if(fieldAPI == "Preferred_Product_1__c" && !isCallPath){
        includeField = false;
      }
      if(fieldAPI === "Preferred_Product__c" && prodItem["Product_Detail1__c"] != "Operator Connect for Microsoft Teams"){
        includeField = false;
      }
    }
    else if(prodName == "Guardian"){
      if(fieldAPI == "Billing_Type__c"){
        let tempVal = prodItem["Product_Code_Description__c"];
        if(!(tempVal == "Managed - SD WAN Branch" || tempVal == "Managed - SD WAN HQ")){
          includeField = false;
        }
      }
    }
    else if(prodName == "Mobility"){
      if(fieldAPI == "Ip_Block__c" && !prodItem["Ip_Block__c"]){
        includeField = false;
      }else if(fieldAPI == "IP_Type__c" || fieldAPI == "Display_Speed__c"){
        let tempVal = prodItem["Ip_Block__c"];
        if(tempVal != "Yes"){
          includeField = false;
        }
      }
      else if(fieldAPI == "ProductCode_Description__c"){
        let tempVal = prodItem["Billing_Type__c"];
        let tempVal1 = prodItem["Product_Type__c"];
        if(tempVal == "New Install" || tempVal1 == "Wireless Broadband") {
          includeField = false;
        }
      }
      else if(fieldAPI == "Billing_Type__c"){
        let tempVal = prodItem["Product_Type__c"];
        if(tempVal == "Wireless Broadband") {
          includeField = false;
        }
      }
      else if(fieldAPI == 'Product_Description__c' && !fieldValue){
        includeField = false;
      }
    }
    else if(prodName == "Broadband"){
      if(fieldAPI == 'Ip_Block__c' && !fieldValue){
        includeField = false;
      }
    }

    return includeField;
  }

  getProdFields(prodName,fieldItem,prodItem){
    let fieldAPI = fieldItem.Field_API__c;
    let fieldLabel = fieldItem.Display_Label__c;
    let objectAPI = fieldItem.Object__c;
    let defaultValue = fieldItem.Default_Value__c;
    let ishelpTextUsageOption = false;

    let fieldValue
    if(fieldAPI){
      fieldValue = prodItem[fieldAPI];
    }
    else{
      console.log(defaultValue);
      fieldValue = defaultValue;
    }

    if(prodName == "GRID"){
      if(fieldAPI == "Grid_Voice_Package__c") {
        fieldValue = this.getGridVoicPackageValue(fieldValue);
      }
    }
    if(prodName === 'VoIP' && prodItem.Product_Detail1__c == "Operator Connect for Microsoft Teams" && fieldAPI == "Preferred_Product__c" && fieldValue == "Per Minute"){
      ishelpTextUsageOption = true;
    }
    let includeField = this.includeProdFieldCheck(prodName,fieldAPI,fieldValue,prodItem);

    let productData;
    if(includeField){
      productData = {
        fieldName: fieldAPI,
        fieldValue: fieldValue,
        fieldLabel: fieldLabel,
        ishelpTextUsageOption: ishelpTextUsageOption,
        showEditableRow: false,
        showInput: "SHOW_INPUT"
      };
    } 

    return productData;  
  }

  includeRateFieldCheck(prodName,fieldAPI,fieldValue,prodItem,qrrItem){
    let isSurchargeEnabled = prodItem.Is_Surcharge__c;
    let isPricingTier = prodItem.Product_Detail1__c;
    let childQuoteItem = prodItem.Child_Quote_Option_Items__r? prodItem.Child_Quote_Option_Items__r.records : null;
    let isEboot = false;
    if(childQuoteItem){
        isEboot=childQuoteItem.some((rec)=>{
          return rec.Child_Quote_item_Product_Type__c == 'AddonEdgeboot';
        })
    }
    let includeField = true;
    if(fieldAPI == "Vendor__c"){
      let permissionList = ["SalesRep","GRID_SalesRep"];
      let permissionExisted = this.permissionCheck(permissionList);

      if(permissionExisted && !(prodName == "Broadband" || prodName == "POTS" ||
                  prodName == "Mobility" || prodName == "DIA" ||
                  prodName == "GSE" || prodName == "PIP" || prodName == "GRID" 
                  || prodName == "Mobility" || prodName == "Voice over Cable Line" || prodName == "edgeboot")){
        includeField = false;
      }
    }
    else if(fieldAPI == 'On_Net__c'){
      if(prodName != 'DIA'){
        includeField = false;
      }
    }
    else if(fieldAPI == 'Unit__c'){
      if((prodItem.Product__c == 'VoIP' && isPricingTier == 'HPBX') ||(prodItem.Product__c == 'VoIP' && isPricingTier == 'SIP') ){
        includeField = false;
      }
    }
    else if (fieldAPI === 'NAC_Pricing_Tier__c' ){
            if((prodName == "Broadband" || prodName == "DIA" )&& !isEboot){
              includeField = false;
              }
    }
    else if(fieldAPI == "COS_MRC__c"){
      if(!(prodItem.Product__c == "GSE" || prodItem.Product__c == "PIP")){
        includeField = false;
      }
    }
    else if(fieldAPI == "COS_Cost__c"){
      let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter"];
      let permissionExisted = this.permissionCheck(permissionList);
      if((prodItem.Product__c == "GSE" || prodItem.Product__c == "PIP")){
        if(!permissionExisted){
          includeField = false;
        }
      }else if(!(prodItem.Product__c == "GSE" || prodItem.Product__c == "PIP")){
          includeField = false;
      }
    }
    else if((fieldAPI == "Current_Total__c" || fieldAPI == "Saving_Amount__c" 
                || fieldAPI == "Saving_Percentage__c") && !(this.quoteRequestQuoteType == "Comparison")){
      includeField = false;
    }
    else if(fieldAPI == "GC_MRC_Rate__c" || fieldAPI == "Activation_MRC_NRC_Rate__c"){
      let permissionList = ["SalesEng","SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter","SalesEngManager"];
      let permissionExisted = this.permissionCheck(permissionList);
      if(!permissionExisted){
        includeField = false;
      }
    }
    else if(fieldAPI == "Default_Router_Cost__c"){
      let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter"];
      let permissionExisted = this.permissionCheck(permissionList);
      if(!permissionExisted){
        includeField = false;
      }
    }
    else if(fieldAPI == "PICC_Pricing_Tier__c" && !(prodItem.Product_Type__c == "Local + LD")){
      includeField = false;
    }
    else if(fieldAPI == "RFQ_Number__c"){
      let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter"];
      let permissionExisted = this.permissionCheck(permissionList);
      if(!permissionExisted){
        includeField = false;
      }
    }
    else if(fieldAPI == "EUCL__c" || fieldAPI == "ARC__c" || fieldAPI == "LNP__c" 
                                  || fieldAPI == "PTA_PTR__c" || fieldAPI == "Surcharge__c"){
      if(!isSurchargeEnabled){
        includeField = false;
      }
    }
    if(prodName == 'Mobility'){
      let serviceCategory = prodItem.Product_Type__c;
      let isWirelessBroadband = serviceCategory == "Wireless Broadband" ? true : false;
      if(fieldAPI == "Surcharge__c" && isWirelessBroadband){
        includeField = false;
      }
    }
    if(prodName == "Mobility"){
      let tempVal = prodItem["Ip_Block__c"];
      if(fieldAPI == "Mobility_Plan_2_MRC__c" && tempVal != "Yes"){
        includeField = false;
      }
    }
    else if(prodName == 'Broadband'){
      if(fieldAPI == "Surcharge__c" && this.quoteRequestBusinessUnit == "Wholesale"){
        includeField = false;
      }
    }
    else if(prodName == 'VoIP'){
      if(fieldAPI == 'PTA__c' && !isSurchargeEnabled){
        includeField = false;
      }
      let productCategory = prodItem["Product_Detail1__c"];
      if(fieldAPI === 'EQUIP_NRC__c' || fieldAPI === 'Default_Router_Rate__c'){
        if(productCategory != 'HPBX'){
          includeField = false;
        }
      }
      if(fieldAPI == 'Default_Router_Cost__c'){
        if(productCategory == "Operator Connect for Microsoft Teams"){
          includeField = false;
        }
      }
      if(fieldAPI === 'NAC_Pricing_Tier__c' || fieldAPI === 'Unit__c' || fieldAPI === 'Surcharge__c' || fieldAPI === 'PTA__c'){
        if(productCategory == "Operator Connect for Microsoft Teams" && this.quoteRequestBusinessUnit == "Wholesale"){
          includeField = false;
        }
      }
    }
    else if(prodName == "ePOTS"){
      if(fieldAPI == "PTA__c" || fieldAPI == "ASF__c"){
        if(!isSurchargeEnabled){
          includeField = false;
        }
      }
    }
    else if(prodName == "Equipment"){
      let equipBillingType = prodItem.Billing_Type__c;
      if(fieldAPI == "EQUIP_NRC__c" && equipBillingType != "NRC"){
        includeField = false;
      }
    }
    return includeField;
  }

  currencyFieldCheck(prodName,fieldItem,prodItem,qrrItem){
    let fieldAPI = fieldItem.Field_API__c;
    let isCurrencyField = true;
    let isCurrencyReadOnlyField = false;
    
    let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter"];
    let permissionExisted = this.permissionCheck(permissionList);
    let fieldList = ["IP_MRC_Rate__c","Default_Router_Rate__c","COS_MRC__c","Circuit_MRC_Rate1__c",
                    "Activation_Cost__c","Default_Router_Cost__c","Surcharge__c","Flat_Rate__c","GC_MRC_Rate__c",
                    "Activation_MRC_NRC_Rate__c","EUCL__c","ARC__c","LNP__c","PTA_PTR__c","PICC__c",
                    "EQUIP_NRC__c","Voice_MRC__c","Voice_Package_cost__c","Noverage_Overage_Protection_Plan_defa__c",
                    "Static_IP__c","CyberReef__c","Motus_Management_License__c","AT_T_International_Services__c",
                    "Netcloud_Manager_Advanced_Upgrade__c","Mobile_Device_Management__c","Local_Usage_Package__c",
                    "LD_Usage_Package__c","All_Usage_Package__c","Voicemail__c","Easy_AA__c","Premium_AA__c",
                    "Base_Seat__c","Additional_Call_Path__c","Business_Seat__c","Executive_Seat__c","Soft_Seat__c",
                     "Meeting_Size_Upgrade__c","Multi_Line_Hunt_Group__c","Voice_Operator_Panel__c","Mobility_Plan_2_MRC__c","Mobility_Plan_1_MRC__c",
                    "Granite_Connector__c","Call_Recording__c","DID__c","Additional_e911_Registration__c",
                    "Direct_Trunk_Failover__c","Bursting_SIP_Call_Path__c","SIP_Comm_Portal__c","Feature_MRC__c","Add_On_Service_MRC__c",
                    "Toll_Free_Number__c","Cloud_Contact_Center__c"];
    if(!permissionExisted && fieldList.includes(fieldAPI)){
      isCurrencyField = false;
      isCurrencyReadOnlyField = true;
    }
    else if(fieldAPI == "Total_MRC__c" || fieldAPI == "Feature_MRC__c" || fieldAPI == "PTA__c" 
                                      || fieldAPI == "ASF__c" || fieldAPI == "Saving_Amount__c"){
      isCurrencyReadOnlyField = true;
      isCurrencyField = false;
    }
    else if(fieldAPI == "PICC_Pricing_Tier__c") {
      isCurrencyReadOnlyField = false;
      isCurrencyField = false;
    }
     else if(prodName == 'Mobility' && fieldAPI == "Circuit_MRC_Rate1__c" ) {
       isCurrencyReadOnlyField = true;
      isCurrencyField = false;
       
    }
    else if(prodName == 'Guardian' && fieldAPI == "Feature_NRC__c" ) {
       isCurrencyReadOnlyField = true;
      isCurrencyField = false;
       
    }
    else if(fieldAPI == "NAC_Pricing_Tier__c") {
      isCurrencyReadOnlyField = false;
      isCurrencyField = false;
    }
    else if (fieldAPI == "Saving_Percentage__c") {
      isCurrencyReadOnlyField = false;
      isCurrencyField = false;
    } 
    else if(fieldAPI == "Record_Error_Info__c") {
      isCurrencyReadOnlyField = true;
      isCurrencyField = false;
    }
    else if(fieldAPI == "RFQ_Number__c"){
      isCurrencyField = false;
    }
    if(prodName == 'VoIP' && prodItem.Product_Detail1__c=="HPBX" && (fieldAPI=="Default_Router_Rate__c" || fieldAPI=="EQUIP_NRC__c" || fieldAPI=="Circuit_MRC_Rate1__c" ) ){
      isCurrencyReadOnlyField = true;
      isCurrencyField = false;
    }
    if((prodName == 'edgeboot' || prodName == 'Voice over Cable Line') && (fieldList.includes(fieldAPI))){
      let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter","SalesEngManager","SalesEng"];
      let permissionExisted = this.permissionCheck(permissionList);
      if(permissionExisted){
        isCurrencyReadOnlyField = false;
        isCurrencyField = true;
      };
    }
    let currencyMap = {"isCurrencyField":isCurrencyField,"isCurrencyReadOnlyField":isCurrencyReadOnlyField};
    return currencyMap;
  }

  percentFieldCheck(prodName,fieldItem,prodItem,qrrItem){
    let fieldAPI = fieldItem.Field_API__c;
    let isPercentField = false;
    let isPercentReadonlyField = false;
    if(fieldAPI == "Saving_Percentage__c") {
      isPercentReadonlyField = true;
      isPercentField = false;
    } 

    let percentMap = {"isPercentField":isPercentField,"isPercentReadonlyField":isPercentReadonlyField};
    return percentMap;
  }

  picklistFieldCheck(prodName,fieldItem,prodItem,qrrItem,fieldValue,seatCounter,selectedEasyAA){
    let fieldAPI = fieldItem.Field_API__c;
    let isPicklist = false;
    let isPicklistReadonly = false;
    

    if(fieldAPI == "Vendor__c"){ 
      if(prodName == "Broadband" || prodName == "DIA" || prodName === 'GRID'){
        if(fieldValue === 'Granite'){
          let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter","SalesEng"];
          let permissionExisted = this.permissionCheck(permissionList);
          if(permissionExisted){
            isPicklist = true;
            isPicklistReadonly = false;
          }else{
            isPicklistReadonly = true;
          }
        }else{
          isPicklist = true;
          isPicklistReadonly = false;
        }
      }else if(prodName == "Mobility"){
        isPicklist = false;
        isPicklistReadonly = true;
      }else if(prodName == "Voice over Cable Line"){
         isPicklist = true;
         isPicklistReadonly = false;
      }
      else{
        let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter"];
        let permissionExisted = this.permissionCheck(permissionList);
        if(permissionExisted && prodName != "VoIP"){
          isPicklist = true;
          isPicklistReadonly = false;
        }
        else{
          isPicklist = false;
          isPicklistReadonly = true;
        }
      }
    }
    
    else if(fieldAPI == "Unit__c"){
      if(prodName === 'EPIK'){
        let qty = prodItem.QTY__c ? Number(prodItem.QTY__c):0;
          let permissionList = ["SplPricing","OMAnalyst","SplPricingManager","OMAnalystManager","ChannelsQuoter","SalesEng","SalesEngManager"];
          let permissionExisted = this.permissionCheck(permissionList);
          if(!permissionExisted && qty == 1){
            isPicklist = false;
            isPicklistReadonly = true;
          }else{
            isPicklist = true;
            isPicklistReadonly = false;
          }
      }else if(prodName === 'edgeboot'){
            isPicklist = true;
            isPicklistReadonly = false;
      }
      else if(prodName === 'VoIP'){
            isPicklist = true;
            isPicklistReadonly = false;
      }
      else{
      let permissionList = ["SalesEng"];
      let permissionExisted = this.permissionCheck(permissionList);
      if(permissionExisted){
        isPicklistReadonly = true;
        isPicklist = false;
      }
      else{
        isPicklist = true;
      }
    }
    }
    else if(fieldAPI == "PICC_Pricing_Tier__c" || fieldAPI == "NAC_Pricing_Tier__c") {
      isPicklist = true;
    }
    else if (fieldAPI == "On_Net__c") {
      isPicklistReadonly = true;
    }

    /*else if (fieldAPI == "Download_Speed__c") {
      isPicklist = true;
    }*/

    let picklistMap = {"isPicklist":isPicklist,"isPicklistReadonly":isPicklistReadonly};
    return picklistMap;

  }

  getRateFields(objQr,fieldItem,prodItem,qrrItem,configWrap,featureApiMap,featureHPBXorSIPApiMap,optionServiceApiMap,
                  pricingTierMap,selectedFeature,slectedAdditionalFeatures,selectedOptionalServices,seatCounter,selectedEasyAA){
    let prodName = prodItem.Product__c;
    let fieldAPI = fieldItem.Field_API__c;
    let fieldLabel = fieldItem.Display_Label__c;
    let objectAPI = fieldItem.Object__c;
    let defaultValue = fieldItem.Default_Value__c;

    let fieldValue = (qrrItem[fieldAPI] || qrrItem[fieldAPI] == 0) ? qrrItem[fieldAPI] : '';
    let includeField = this.includeRateFieldCheck(prodName,fieldAPI,fieldValue,prodItem,qrrItem);

    let rateData;
    if(includeField){
      let currencyMap = this.currencyFieldCheck(prodName,fieldItem,prodItem,qrrItem);
      let isCurrencyField = currencyMap["isCurrencyField"];
      let isCurrencyReadOnlyField = currencyMap["isCurrencyReadOnlyField"];

      let percentMap = this.percentFieldCheck(prodName,fieldItem,prodItem,qrrItem);
      let isPercentField = percentMap["isPercentField"];
      let isPercentReadonlyField = percentMap["isPercentReadonlyField"];

      let picklistMap = this.picklistFieldCheck(prodName,fieldItem,prodItem,qrrItem,fieldValue,seatCounter,selectedEasyAA);
      let isPicklist = picklistMap["isPicklist"];
      let isPicklistReadonly = picklistMap["isPicklistReadonly"];

      let addFieldtoList = true;
      if (fieldAPI == "Record_Error_Info__c") {
        if(fieldValue == "AddressStdError") {
          fieldValue = "TBD";
        } 
        else{
          addFieldtoList = false;
        }
      }
      else if (fieldAPI == "On_Net__c") {
        fieldValue = qrrItem["Building_Status__c"] ? qrrItem["Building_Status__c"] : "No";
      }

      if(prodName == "ePOTS" || prodName == "Voice over Cable Line"){
        let featureKeys = Object.keys(featureApiMap);
        if (featureKeys.includes(fieldAPI)) {
          let featureLabel = featureApiMap[fieldAPI];
          if (!selectedFeature.includes(featureLabel)) {
            addFieldtoList = false;
          } else {
            fieldLabel = prodItem.QTY__c ? fieldLabel +" "+ "(" + this.qoiFeatureMap.get(featureLabel) + ")" : fieldLabel;
          }
        }
      }
      else if(prodName == "VoIP"){
        let additionalFeatureKeys = Object.keys(featureHPBXorSIPApiMap);
        if (additionalFeatureKeys.includes(fieldAPI)) {
          let additionalFeatureLabel = featureHPBXorSIPApiMap[fieldAPI];
          if (!slectedAdditionalFeatures.includes(additionalFeatureLabel)) {
            addFieldtoList = false;
          } else {
            if(additionalFeatureLabel == 'Meeting Size Upgrade' && this.qoiFeatureMap.get(additionalFeatureLabel).Provider__c != null){
              fieldLabel = fieldLabel +" "+ "(" + this.qoiFeatureMap.get(additionalFeatureLabel).QTY__c +')' + ' :'+ this.qoiFeatureMap.get(additionalFeatureLabel).Provider__c;
            }else if((additionalFeatureLabel == 'Granite Connector' &&  this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c != null) || 
                      (additionalFeatureLabel == 'Cloud Contact Center' && this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c != null)|| 
                      (additionalFeatureLabel == 'LD Usage Package' && this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c != null) ){
              fieldLabel = fieldLabel +" "+ "(" + this.qoiFeatureMap.get(additionalFeatureLabel).QTY__c +')' + ' :'+ this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c ;
            }
            else if(additionalFeatureLabel == 'Call Recording' && this.qoiFeatureMap.get(additionalFeatureLabel).Minimum_Speed__c !=null){
              fieldLabel = fieldLabel +" "+ "(" + this.qoiFeatureMap.get(additionalFeatureLabel).QTY__c +')' + '  :'+ this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c + ' :'+ this.qoiFeatureMap.get(additionalFeatureLabel).Minimum_Speed__c;
            }
            else if(additionalFeatureLabel == 'Call Recording' && this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c !=null){
              fieldLabel = fieldLabel +" "+ "(" + this.qoiFeatureMap.get(additionalFeatureLabel).QTY__c +')' + ' :'+ this.qoiFeatureMap.get(additionalFeatureLabel).IP_Type__c ;
            }
            else{
              fieldLabel = fieldLabel +" "+ "(" + this.qoiFeatureMap.get(additionalFeatureLabel).QTY__c +')';
            }
          }
        }
      }
      else if(prodName == "Mobility" || prodName == "Guardian"){
        let serviceKeys = Object.keys(optionServiceApiMap);
        if(serviceKeys.includes(fieldAPI)) {
          let optionServiceLabel = optionServiceApiMap[fieldAPI];
          if (!selectedOptionalServices.includes(optionServiceLabel)) {
            addFieldtoList = false;
          }else if(optionServiceLabel == 'VPN Client Add On'){
            fieldLabel = fieldLabel +" "+ "(" + this.qoiFeatureMap.get(optionServiceLabel) +')';
          } 
          else {
            fieldLabel = fieldLabel;
          }
        }
      }

      let pricingTierOption = pricingTierMap["tierOptions"];
      let defaultPricingValue = pricingTierMap["defaultPricingValue"];

      let piccPricingTierOption = pricingTierMap["piccTierOptions"];
      let defaultPICCPricingValue = pricingTierMap["defaultPICCPricingValue"];

      let nacPricingTierOption = pricingTierMap["nacTierOptions"];
      let defaultNACPricingValue = pricingTierMap["defaultNACPricingValue"];

      let picklistFieldValue = qrrItem[fieldAPI] ? qrrItem[fieldAPI] : "Select";
      if(fieldAPI == "Unit__c") {
        if(picklistFieldValue == "Select" ) {
          picklistFieldValue = defaultPricingValue ? defaultPricingValue : "Select";
          if(prodName == "EPIK" && this.quoteRequestBusinessUnit == "Wholesale"){
            if(prodItem.Contract_Term__c == "3 Years" || prodItem.Contract_Term__c == "5 Years") {
              picklistFieldValue = "1";
            }
          }else if(prodName == "EPIK"){
            let permissionList = ["SalesEng","SalesRep","GRID_SalesRep","SalesRepEng","ChannelsQuoter","ChannelSalesRep",
                                  "ChannelSalesRepManager","ChannelSalesEng","ChannelSupport","ChannelsDirector"];
            let permissionExisted = this.permissionCheck(permissionList);
            if(prodItem.Contract_Term__c == "3 Years" && permissionExisted) {
              pricingTierOption = pricingTierOption.filter( (item) => item.value != "0.5");
              picklistFieldValue = "3";
            } else if(prodItem.Contract_Term__c == "3 Years"){
              picklistFieldValue = "3";
            }
            else if(prodItem.Contract_Term__c == "5 Years") {
              picklistFieldValue = "1";
            } else if(prodItem.Contract_Term__c == "4 Years") {
              picklistFieldValue = "2";
            } else if(prodItem.Contract_Term__c == "2 Years") {
              picklistFieldValue = "9";
            } else if(prodItem.Contract_Term__c == "1 Year") {
              picklistFieldValue = "10";
            } 
          }
        }

        let permissionList = ["SalesEng","SalesRep","GRID_SalesRep","SalesRepEng","ChannelsQuoter","ChannelSalesRep",
                                  "ChannelSalesRepManager","ChannelSalesEng","ChannelSupport","ChannelsDirector"];
        let permissionExisted = this.permissionCheck(permissionList);
        if(prodItem.Product__c == "EPIK" && prodItem.Contract_Term__c == "3 Years" 
                                    && permissionExisted){
          pricingTierOption = pricingTierOption.filter((item) => item.value != "0.5");
        }
        if(prodItem.Product__c == "EPIK"){
          fieldValue = qrrItem[fieldAPI] ? qrrItem[fieldAPI] : (defaultPricingValue ? picklistFieldValue : fieldValue);
        }
        if(prodItem.Product__c != "EPIK"){
          fieldValue = qrrItem[fieldAPI] ? qrrItem[fieldAPI] : (defaultPricingValue ? defaultPricingValue : fieldValue);
        }

        if(pricingTierOption && pricingTierOption.length > 0 && pricingTierOption.length == 1) {
          isPicklistReadonly = true;
          isPicklist = false;
          fieldValue = defaultPricingValue ? defaultPricingValue : fieldValue;
        }
      }

      if (fieldAPI == "PICC_Pricing_Tier__c") {
        if(picklistFieldValue == "Select") {
          picklistFieldValue = defaultPICCPricingValue != "" ? defaultPICCPricingValue : "Select";
        }
        fieldValue = qrrItem[fieldAPI] ? qrrItem[fieldAPI] : defaultPICCPricingValue ? defaultPICCPricingValue : fieldValue;

        if(piccPricingTierOption && piccPricingTierOption.length > 0 && piccPricingTierOption.length == 1) {
          isPicklistReadonly = true;
          isPicklist = false;
          fieldValue = defaultPICCPricingValue ? defaultPICCPricingValue : fieldValue;
        }
      }

      if (fieldAPI == "NAC_Pricing_Tier__c") {
        if(picklistFieldValue == "Select") {
          picklistFieldValue = defaultNACPricingValue ? defaultNACPricingValue : "Select";
        }
        fieldValue = qrrItem[fieldAPI] ? qrrItem[fieldAPI] : (defaultNACPricingValue ? defaultNACPricingValue : fieldValue);

        if(nacPricingTierOption && nacPricingTierOption.length > 0 && nacPricingTierOption.length == 1) {
          isPicklistReadonly = true;
          isPicklist = false;
          fieldValue = defaultNACPricingValue ? defaultNACPricingValue : fieldValue;
        }
      }

      

      if (addFieldtoList) {
        const isSavingField = fieldAPI == "Saving_Amount__c" || fieldAPI == "Saving_Percentage__c";
        rateData = {
          quoteRqRatesId: qrrItem.Id,
          fieldName: fieldAPI,
          fieldValue: fieldValue,
          picklistFieldValue: picklistFieldValue,
          fieldLabel: fieldAPI == "Record_Error_Info__c" ? "Status" : fieldLabel,
          isUnitField: fieldAPI == "Unit__c" ? true : false,
          isPICCPricingField: fieldAPI == "PICC_Pricing_Tier__c" ? true : false,
          isNACPricingField: fieldAPI == "NAC_Pricing_Tier__c" ? true : false,
          isOnNetField: fieldAPI == "On_Net__c" ? true : false,
          isVendor: fieldAPI == "Vendor__c" ? true : false,
          isCurrencyField: isCurrencyField,
          isTextField: fieldAPI == "Record_Error_Info__c" ? true : false,
          isAvailableSpeed: fieldAPI == "Download_Speed__c" ? true : false,
          isUploadSpeed: fieldAPI == "Upload_Speed__c" ? true : false,
          isRFQNumber: fieldAPI == "RFQ_Number__c" ? true : false,
          isPropertyName: fieldAPI == "PropertyName__c" ? true : false,
          isAccessType: fieldAPI == "Access_Type__c" ? true : false,
          className: fieldAPI == "Current_Total__c" ? "grey-color" : isSavingField ? "green-color" : "default-label",
          valClassName: isSavingField && fieldValue < 0 ? "red-color" : "default-label",
          isSavingAmt: fieldAPI == "Saving_Amount__c" ? true : false,
          isSavingPer: fieldAPI == "Saving_Percentage__c" ? true : false,
          isCurrencyReadOnlyField: isCurrencyReadOnlyField,
          showEditableRow: false,
          showInput: "SHOW_INPUT",
          isPicklistField: isPicklist,
          isPicklistReadonly: isPicklistReadonly,
          isPercentField: isPercentField,
          isPercentReadonlyField: isPercentReadonlyField,
          pricingTierOption: pricingTierOption
        };
      }
    } 

    return rateData;
  }

  actionStatusesCheck(actionStatusesMap){
    this.actionStatuses = actionStatusesMap.childExpand;
    if (this.actionStatuses.byLocationEditProductFields.disabled == true) {
      this.arePricesReadOnly = true;
    } else {
      this.arePricesReadOnly = false;
    }
  }

  togglePasswordHint1() {
    this.passwordHintClass1 =
      this.passwordHintClass1 ==
      "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide"
        ? "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-rise-from-ground"
        : "slds-popover slds-popover_tooltip slds-nubbin_bottom-left slds-fall-into-ground slds-hide";
  }
  getTierDetails(objQR,prodItem,pricingMap){
    let prodName = prodItem.Product__c;
    let pricingList = pricingMap ? pricingMap[prodName] : null;
    let tierOptions = [];
    let piccTierOptions = [];
    let nacTierOptions = [];

    let userPermissionList = [];
    if(this.loggedInUser && this.loggedInUser.lstPermissionSet) {
      userPermissionList = this.loggedInUser.lstPermissionSet;
    }

    if(pricingList){
      pricingList.forEach((tierItem) => {
        let objWrap = {"label":tierItem.Rate_Type__c,"value":tierItem.Rate_Type__c,"title":tierItem.Rate_Value__c};    
        if(prodName == 'Guardian'){
          let identifier = prodItem.Product_Code_Description__c+'~';
          if(tierItem.Identifier__c && tierItem.Identifier__c.includes(identifier)){
            tierOptions.push(objWrap);
          }
        }
        else if(prodName == 'EPIK' && objQR.Business_Unit__c == 'Wholesale'){
          if(tierItem.Business_unit__c == 'Wholesale'){
            tierOptions.push(objWrap);
          }
        }
        else if(prodName == 'VoIP' && objQR.Business_Unit__c == 'Channels'){
          if(tierItem.Business_unit__c == 'Channels' && tierItem.Type_Of_Product__c == null){
            tierOptions.push(objWrap);
          }
        }
        else if(prodName == 'VoIP' && objQR.Business_Unit__c != 'Channels'){
          if(tierItem.Business_unit__c != 'Channels' && tierItem.Type_Of_Product__c == null){
            tierOptions.push(objWrap);
          }
        }
        else if(prodName == 'edgeboot' && userPermissionList ){
          if(objQR.Business_Unit__c == 'Wholesale'){
            if(tierItem.Business_unit__c == 'Wholesale'){
            let permList = tierItem.Permission__c ? tierItem.Permission__c.split(",") : []; 
              let eFlag = this.getTierPermissionCheck(permList,userPermissionList);
              if(eFlag){
              tierOptions.push(objWrap); 
              }
            }
          }
          if(objQR.Business_Unit__c !='Wholesale'){
            if(!tierItem.Business_unit__c){
              let permList = tierItem.Permission__c ? tierItem.Permission__c.split(",") : []; 
              let eFlag = this.getTierPermissionCheck(permList,userPermissionList);
              if(eFlag){
              tierOptions.push(objWrap); 
              }
            }
          }
        }
        else if(objQR.Business_Unit__c == 'Channels'){
          if(tierItem.Business_unit__c == 'Channels'){
            tierOptions.push(objWrap);
          }
        }
        else{    
          if(userPermissionList && !tierItem.Type_Of_Product__c && (!tierItem.Business_unit__c 
                                                      || tierItem.Business_unit__c == 'Channels')){
            let permList = tierItem.Permission__c ? tierItem.Permission__c.split(",") : []; 
            let eFlag = this.getTierPermissionCheck(permList,userPermissionList);
            if(eFlag){
              tierOptions.push(objWrap); 
            }                                          
          }
        }

        if(tierItem.Type_Of_Product__c == 'Local + LD'){
          let permList = tierItem.Permission__c ? tierItem.Permission__c.split(",") : [];
          let eFlag = this.getTierPermissionCheck(permList,userPermissionList);
          if(eFlag){
            piccTierOptions.push(objWrap); 
          } 
        }
        let productCategory = prodItem.Product_Detail1__c;
        if(tierItem.Type_Of_Product__c == 'NAC' ||  tierItem.Type_Of_Product__c == 'edgeboot' || tierItem.Type_Of_Product__c == 'HPBX' && productCategory == 'HPBX'
            || tierItem.Type_Of_Product__c == 'SIP' && productCategory == 'SIP' ){
          let permList = tierItem.Permission__c ? tierItem.Permission__c.split(",") : []; 
          let eFlag = this.getTierPermissionCheck(permList,userPermissionList);
          if(eFlag){
            nacTierOptions.push(objWrap); 
          } 
        }

        if(tierItem.Type_Of_Product__c == 'Operator Connect for Microsoft Teams' && productCategory == 'Operator Connect for Microsoft Teams'){
          let permList = tierItem.Permission__c ? tierItem.Permission__c.split(",") : []; 
          let eFlag = this.getTierPermissionCheck(permList,userPermissionList);
          if(objQR.Business_Unit__c == 'Channels'){
            console.log('Business',objQR.Business_Unit__c);
            if(tierItem.Business_unit__c == 'Channels'){
              if(eFlag){
              nacTierOptions.push(objWrap); 
              }
            }
          }else{
            if(tierItem.Business_unit__c != 'Channels'){
              if(eFlag){
                nacTierOptions.push(objWrap); 
              }
            }
          }
        }
      });
    }

    let tierOptionsMap = {"tierOptions":tierOptions,"piccTierOptions":piccTierOptions,"nacTierOptions":nacTierOptions};
    return tierOptionsMap;
  }

  getTierPermissionCheck(permList,userPermissionList){
    let eFlag = false;
    if(permList){
      for(let i = 0;i<permList.length;i++){
        let permItem = permList[i];
        var perm = permItem.replace('A3_','').replace('_CRE','');
        if(userPermissionList.includes(perm)){
          eFlag = true;
          break;
        }
      }
    }

    return eFlag;
  }

  onLoad() {
    let qoiList = this.qoiList;
    let qoiRatesMap = this.qoiRatesMap;
    let childQoiRatesMap=this.childQoiRateMap;
    let qoiVendorMap = this.qoiVendorsMap;
    let prodConfigMap = this.configWrap.prodConfigMap;
    let a3LookupMap = this.configWrap.a3LookupMap;
    let pricingMap = this.configWrap.pricingMap;
    let actionStatusesMap = this.configWrap.actionStatusesMap;
    let featureApiMap = this.configWrap.featureApiMap;
    let featureHPBXorSIPApiMap = this.configWrap.featureHPBXorSIPApiMap;
    let optionServiceApiMap = this.configWrap.optionServiceApiMap;
    let objQr = this.configWrap.objQr;
    this.finalProdArray = [];
    qoiList.forEach((prodItem) => {
      let prodFields = [];
      let rateFields = [];
      let childProds = [];
      //prodItem.isSelected = this.isSelected;
      let prodName = prodItem.Product__c;
      let qrrItem = qoiRatesMap ? qoiRatesMap[prodItem.Id] : {};
      let prodConfigList = prodConfigMap[prodName];

      this.actionStatusesCheck(actionStatusesMap);

      let vendorOptions = [];
      vendorOptions = this.getVendorOptions(prodName,prodItem.Id,a3LookupMap,qoiVendorMap);

      let pricingTierMap = this.getTierDetails(objQr,prodItem,pricingMap);
      let pricingTierOption = pricingTierMap["tierOptions"];
      let defaultPricingValue = pricingTierOption && pricingTierOption.length > 0 ? pricingTierOption[0].value : '';
      pricingTierMap['defaultPricingValue'] = defaultPricingValue;

      let piccPricingTierOption = pricingTierMap["piccTierOptions"];
      let defaultPICCPricingValue = piccPricingTierOption && piccPricingTierOption.length > 0 ? piccPricingTierOption[0].value : '';
      pricingTierMap['defaultPICCPricingValue'] = defaultPICCPricingValue;

      let nacPricingTierOption = pricingTierMap["nacTierOptions"];
      let defaultNACPricingValue = nacPricingTierOption && nacPricingTierOption.length > 0 ? nacPricingTierOption[0].value : '';
      pricingTierMap['defaultNACPricingValue'] = defaultNACPricingValue;


      let childProdName;
      if (prodItem.Product__c == "ePOTS") {
        childProdName = "ATA Equipment";
      } 
      else if(prodItem.Product__c == "VoIP"){
        childProdName = "HPBX Equipment";
      }else if(prodItem.Product__c == "Broadband" || prodItem.Product__c == "DIA"){
        childProdName = "AddonEdgeboot";
      }

      let selectedFeature = [];
      let selectedOptionalServices = [];
      let slectedAdditionalFeatures = [];
      let seatCounter = 0;
      let selectedEasyAA = 0;
      if(prodItem.Child_Quote_Option_Items__r){
        const childProdList = prodItem.Child_Quote_Option_Items__r.records;
        let prodChildConfigList = prodConfigMap[childProdName];
        childProdList.forEach((childItem) => { 
          if(childItem["Child_Quote_item_Product_Type__c"] == "AddonEdgeboot"){
            childProdName = "AddonEdgeboot";
            prodChildConfigList = prodConfigMap[childProdName];
          }else if(childItem["Child_Quote_item_Product_Type__c"] == "Router"){
            childProdName = "ROUTER";
            prodChildConfigList = prodConfigMap[childProdName];
          }
          if(childItem["Child_Quote_item_Product_Type__c"] == "AdditionalFeature"
                      || childItem["Child_Quote_item_Product_Type__c"] == "VOCFeatures") {
            selectedFeature.push(childItem["Name"]);
            this.qoiFeatureMap.set(
              childItem["Name"],
              childItem["QTY__c"]
            );
          } 
          else if(childItem["Child_Quote_item_Product_Type__c"] == "OptionalService" 
                          || childItem["Child_Quote_item_Product_Type__c"] == "GDN OptionalService" ){
            selectedOptionalServices.push(childItem["Name"]);
            this.qoiFeatureMap.set(
              childItem["Name"],
              childItem["QTY__c"]
            );
          }
          else if (childItem["Child_Quote_item_Product_Type__c"] == "AddOnFeatures" 
                            || childItem["Child_Quote_item_Product_Type__c"] == "SIPAdditionalFeatures") {
            slectedAdditionalFeatures.push(childItem["Name"]); 
            this.qoiFeatureMap.set(
              childItem["Name"],
              childItem
            );  
            if(childItem["Name"] == 'Easy AA'){
              selectedEasyAA ++;
            }                
          }
          else if (childItem["Child_Quote_item_Product_Type__c"] == "Offer"){
            if(childItem["Name"] == "Additional Call Path"  ){
              slectedAdditionalFeatures.push(childItem["Name"]+'~'+ childItem["Product_Offering__c"]);
              this.qoiFeatureMap.set(
              childItem["Name"] +'~' +childItem["Product_Offering__c"],
              childItem
            );
            } else if(childItem["Name"] == "Voicemail Transcription"  ){
              slectedAdditionalFeatures.push(childItem["Name"]+'~'+ childItem["Product_Offering__c"]);
              this.qoiFeatureMap.set(
              childItem["Name"] +'~' +childItem["Product_Offering__c"],
              childItem
            );            
            }
            else{
              slectedAdditionalFeatures.push(childItem["Name"]);
              this.qoiFeatureMap.set(
              childItem["Name"],
              childItem
            );
            if(childItem["Name"] == 'Base Seat' || childItem["Name"] == 'Business Seat' ||childItem["Name"] == 'Executive Seat'||childItem["Name"] == 'Soft Seat'){
              seatCounter +=childItem["QTY__c"];
            }
            }
          }
          else if (childItem.Child_Quote_item_Product_Type__c == "Router" ||
                        childItem.Child_Quote_item_Product_Type__c == "ATA Equipment" || 
                        childItem.Child_Quote_item_Product_Type__c == "HPBX Equipment" ||
                        childItem.Child_Quote_item_Product_Type__c == "AddonEdgeboot") {
            let childPrdFields = [];
            let childRecordId;
            let  childParentId;
            let permissionList = ["SplPricing","OMAnalyst","OMAnalystManager","SplPricingManager","ChannelsQuoter","SalesEng","SalesEngManager"];
            let permissionExisted = this.permissionCheck(permissionList);
            if(prodChildConfigList && prodChildConfigList.length > 0){
               prodChildConfigList.forEach((childFieldItem) => {
                let prodName = childFieldItem.Product__c;
                let fieldAPI = childFieldItem.Field_API__c;
                let fieldLabel = childFieldItem.Display_Label__c;
                let objectAPI = childFieldItem.Object__c;
                let defaultValue = childFieldItem.Default_Value__c;
                let editData = false;
                let currencyField = false;
                let fieldValue;
                if(fieldAPI){
                  fieldValue = childItem[fieldAPI];
                  if(fieldAPI == "Equipment_Term__c"){
                    fieldValue = prodItem.Contract_Term__c;
                  }else if(fieldAPI == "Product_Detail1_Description__c" && childItem[fieldAPI] == undefined){
                    fieldValue = 'HPBX Equipment';
                  }
                  if(fieldAPI=="Default_Router_Rate__c" || fieldAPI=="EQUIP_NRC__c"){

                    let qoiId=childItem?childItem["Id"]:[];
                    let singleChildQrr=qoiId && childQoiRatesMap? childQoiRatesMap[qoiId]:[];
                    childRecordId=singleChildQrr?singleChildQrr["Id"]:'';
                    childParentId=singleChildQrr?singleChildQrr["Parent_Quote_Request_Rates__c"]:'';
                    if(childItem["Billing_Type__c"]=="MRC" && fieldAPI=="Default_Router_Rate__c" && childRecordId){

                      fieldValue= singleChildQrr[fieldAPI]?singleChildQrr[fieldAPI]:0;
                      if(permissionExisted){
                          editData=true;
                      }
                      currencyField=true;
                    }else if(childItem["Billing_Type__c"]=="NRC" && fieldAPI=="EQUIP_NRC__c" && childRecordId){
                      
                      fieldValue= singleChildQrr[fieldAPI]?singleChildQrr[fieldAPI]:0;
                      if(permissionExisted){
                          editData=true;
                      }
                      currencyField=true;
                    }
                  }
                  console.log(fieldValue);
                }
                else{
                  fieldValue = defaultValue;
                }
               if(fieldValue !=undefined){
                childPrdFields.push({
                  fieldName: fieldAPI,
                  fieldValue: fieldValue,
                  fieldLabel: fieldLabel,
                  showEditableRow: false,
                  isEditable :editData,
                  currencyField:currencyField,
                  showInput: "SHOW_INPUT"
                });
               }
              });
            }  
            
            childProds.push({
              Index: childProds.length,
              childRecordId:childRecordId,
              childParentId:childParentId,
              childFields: childPrdFields
            });
          }  
        });
      }

      if(prodConfigList && prodConfigList.length > 0){
        prodConfigList.forEach((fieldItem) => {
          let objectAPI = fieldItem.Object__c;
          if(objectAPI == 'Quote_Option_Item__c'){
            let productData = this.getProdFields(prodName,fieldItem,prodItem);
            if(productData){
              console.log(productData);
              prodFields.push(productData);
            } 
          }
          else if(objectAPI == 'Quote_Request_Rates__c' && qrrItem){
            let rateData = this.getRateFields(objQr,fieldItem,prodItem,qrrItem,this.configWrap,
                                              featureApiMap,featureHPBXorSIPApiMap,optionServiceApiMap,
                                              pricingTierMap,selectedFeature,slectedAdditionalFeatures,
                                              selectedOptionalServices,seatCounter,selectedEasyAA);
            if(rateData){
              console.log(rateData);
              rateFields.push(rateData);
            }
          }
        });
      }

      let isChecked = false;
	  let locCertifiedColorIndicatorClass = ''
	  let uniqueKey = this.quoteOptionId+'~'+this.locationId;
        let prefQLO = this.qloProdIdMap[uniqueKey] ? this.qloProdIdMap[uniqueKey] : null;
        if(prefQLO && prefQLO.includes(prodItem.Id)){ 
			locCertifiedColorIndicatorClass = 'colorOrangeIndicator';
		}
      /*if(this.isLocationSelected && this.locationCheckedType == 'All'){
        //isChecked = true;
        this.dispatchEvent(
          new CustomEvent("productselected", {
            detail: {'checkedFlag': true,'originalFlag':false,'locId':this.locationId,'prodId':prodItem.Id}
          })
        )
      }
      else{
        let key = this.quoteOptionId+'~'+this.locationId;
        let prefProdList = this.qloProdIdMap[key] ? this.qloProdIdMap[key] : null;
        if(prefProdList && prefProdList.includes(prodItem.Id)){ 
			//locCertifiedColorIndicatorClass = colorOrangeIndicator;
          //isChecked = true;
          this.dispatchEvent(
            new CustomEvent("productselected", {
              detail: {'checkedFlag': true,'originalFlag':true,'locId':this.locationId,'prodId':prodItem.Id}
            })
          )
        }
      }*/
      let downloadSpeedOptions = this.getdownloadSpeedOptions(this.dwnSpeedWrapperList);
      this.finalProdArray.push({
        isChecked: isChecked,
        isClosedWon: qrrItem && qrrItem.Quote_Location_Option__c != null? qrrItem.Quote_Location_Option__r.Closed_Won_Flag__c : true,
        providerLabel: "Provider",
        ProviderName: "Granite",
        showLocationsLabel: "ShowTable",
        showLocationTableCheck: false,
        showEditDeletePopoverLabel: "ShowPopover",
        showEditDeletePopoverCheck: false,
        product: prodItem,
        prodFields: prodFields,
        ratesFields: rateFields,
        childPrdsFields: childProds,
        vendorList: vendorOptions,
        downloadSpeedList: downloadSpeedOptions,
        pricingTierOption: pricingTierOption,
        piccPricingTierOption: piccPricingTierOption,
        nacPricingTierOption: nacPricingTierOption,
		locCertifiedColorIndicator: locCertifiedColorIndicatorClass,
		quoteRequestLocationId: qrrItem && qrrItem.Quote_Location_Option__c != null ? qrrItem.Quote_Location_Option__r.Quote_Request_Location__c : ''
      });
    });
  }
  
  renderedCallback() {
    if (this.isViewUpdated) {
      this.showSpinner = false;
    }
    if (this.isPendingSpOrSeReview || this.isQuoteSubmitted) {
      this.isQuotePendingSPSESumitted = true;
    } else {
      this.isQuotePendingSPSESumitted = false;
    }
  } 

  getFieldValue(fieldName, rateObj) {
    if (
      fieldName &&
      rateObj &&
      (rateObj[fieldName] || rateObj[fieldName] == 0)
    ) {
      return rateObj[fieldName];
    }
    return "";
  }

  generateDropdownOptions(vendorOps, lstVendors) {
    //let options = [];
    //options.push({ label: 'Select', value: '' });
    let existingVendors = [];
    for (let j = 0; j < vendorOps.length; j++) {
      existingVendors.push(vendorOps[j].label);
    }
    for (let i = 0; i < lstVendors.length; i++) {
      if (
        !(
          existingVendors.includes("* " + lstVendors[i]) ||
          existingVendors.includes(lstVendors[i])
        )
      ) {
        vendorOps.push({ label: lstVendors[i], value: lstVendors[i] });
      }
    }

    return vendorOps;
  }

  generateDropdownOptionsFromRates(lstRateVendors, hasDiaVendors) {
    let options = [];
    options.push({ label: "Select", value: "" });
    for (let i = 0; i < lstRateVendors.length; i++) {
      let rateObj = lstRateVendors[i];
      if (hasDiaVendors && (rateObj.createdBy == "QE IntegrationUser" 
                            || rateObj.lastmodifiedBy == "QE IntegrationUser")) {
        options.push({ label: "* " + rateObj.vendor, value: rateObj.rateId});
      } else {
        options.push({ label: rateObj.vendor, value: rateObj.rateId });
      }
    }
    return options;
  }

  enableEditField(event) {
    this.onChangeVal = event.currentTarget.dataset.fvalue;
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    let prodId = event.target.dataset.recordId;
    this.finalProdArray.forEach((pItem) => {
      if (prodId == pItem.product.Id) {
        if (label == "SHOW_INPUT") {
          pItem.ratesFields[itemIndex].showInput = "HIDE_INPUT";
          pItem.ratesFields[itemIndex].showEditableRow = true;
        } else if (label == "HIDE_INPUT") {
          pItem.ratesFields[itemIndex].showInput = "SHOW_INPUT";
          pItem.ratesFields[itemIndex].showEditableRow = false;
        }
      }
    });
  }

  enableChildEditField(event){
    this.onChangeVal = event.currentTarget.dataset.fvalue;
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    let childId = event.target.dataset.recordId;
    this.finalProdArray.forEach((pItem) => {
      let cItemEquips=pItem.childPrdsFields;
      cItemEquips.forEach((cItem) => {
        if(childId == cItem.childRecordId ){
          if(label == "SHOW_INPUT") {
              cItem.childFields[itemIndex].showInput ="HIDE_INPUT";
              cItem.childFields[itemIndex].showEditableRow =true;
            } else if (label == "HIDE_INPUT") {
              cItem.childFields[itemIndex].showInput = "SHOW_INPUT";
              cItem.childFields[itemIndex].showEditableRow = false;
            }
          
        }
		
      })

    });
  }

  @api	
  updateProdCheckFlag(checkedFlag,checkedType){	
    this.finalProdArray.forEach((pItem) => {	
      let originalFlag = false;	
      let key = this.quoteOptionId+'~'+this.locationId;	
      let prefProdList = this.qloProdIdMap[key] ? this.qloProdIdMap[key] : null;	
      if(prefProdList && prefProdList.includes(pItem.product.Id)){ 	
        originalFlag = true;	
      }	
      pItem.isChecked = checkedFlag;	
      this.dispatchEvent(	
        new CustomEvent("productselected", {	
          detail: {'checkedFlag': checkedFlag,'originalFlag':originalFlag,'locId':this.locationId,'prodId':pItem.product.Id}	
        })	
      );	
    });  	
  }

  onProdCheck(event){
    let checkedFlag = event.target.checked;
    let selectedIndex = event.target.dataset.index;
    let prodId = event.target.name;
    let locId = this.locationId;
	let closedWonFlag = false;
    this.finalProdArray.forEach((pItem) => {
      if(prodId == pItem.product.Id) {
        pItem.isChecked = checkedFlag;
		closedWonFlag = pItem.isClosedWon;
      }
    });

    let originalFlag = false;
    let key = this.quoteOptionId+'~'+this.locationId;
    let prefProdList = this.qloProdIdMap[key] ? this.qloProdIdMap[key] : null;
    if(prefProdList && prefProdList.includes(prodId)){ 
      originalFlag = true;
    }

    this.dispatchEvent(
      new CustomEvent("productselected", {
        detail: {'checkedFlag': checkedFlag,'originalFlag':closedWonFlag,'locId':locId,'prodId':prodId}
      })
    );
  }

  handleVendorChange(event) {
    this.onChangeVal = event.target.value;
    let prodName = event.target.dataset.productName;
    if (prodName == "DIA") {
      this.handleUpdateRates(event, true);
    } else {
      this.handleUpdateRates(event, false);
    }
  }

  handleDownSpeedChange(event) {
    let ids = event.target.value;
    updateRateBasedOnDownSpeed({ids:ids}).then((response) => {
      if(response){
        this.dispatchEvent(
          new CustomEvent("refreshtableevent", {
            detail: {locationId:this._locationId}
          })
        ); 
      }
    });
  }

  onChangePICCPricingValue(event) {
    this.onChangeVal = event.target.value;
    console.log("onChangePICCPricingValue::" + this.onChangeVal);
    this.handleUpdateRates(event, false);
  }

  onChangeNACPricingValue(event) {
    this.onChangeVal = event.target.value;
    console.log("onChangeNACPricingValue::" + this.onChangeVal);
    this.handleUpdateRates(event, false);
  }

  onChangePricingValue(event) {
    this.onChangeVal = event.target.value;
    console.log("pricingVal::" + this.onChangeVal);
    this.handleUpdateRates(event, true);
  }


  onChangeOnNetValue(event) {
    this.onChangeVal = event.target.value;
    this.handleUpdateRates(event, false);
  }

  onSaveRates(event) {
    //.onChangeVal=event.target.value;
    console.log("this.onChangeVal" + this.onChangeVal);
    this.handleUpdateRates(event, false);
  }

  async handleUpdateRates(event, isPIMUpdateRequired) {
    //if (this.onChangeVal) {
    this.showLoading = true;

    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    let fieldNm = event.currentTarget.dataset.id;
    let quoteRqRatesId = event.target.dataset.recordId;
    let prodId = event.target.accessKey;
    let prodName = event.target.dataset.productName;
    let pricingRateValue = 0;
    let piccPricingRateValue = 0;
    let nacPricingRateValue = 0;
    let productId = event.currentTarget.dataset.productId;
    let locationId = event.currentTarget.dataset.locationId;
    
      if (prodName == "Broadband" && this.quoteRequestBusinessUnit == 'Wholesale') {
        this.isSPApplied = "Yes";
      } else {
        let piconterm;
        this.finalProdArray.forEach((pItem, index) => {
          if(pItem.ratesFields && pItem.ratesFields.length > 0){
            if (pItem.ratesFields[index] && quoteRqRatesId === pItem.ratesFields[index].quoteRqRatesId) {
              piconterm = pItem.product.Contract_Term__c;
            }
          }
        });

        await SPAppliedRule({
          PrdName: prodName,
          FieldName: fieldNm,
          BusinessUnit: this.quoteRequestBusinessUnit,
          FieldValue: this.onChangeVal,
          ConTerm: piconterm
        })
          .then(result => {
            if (result === true) {
              this.isSPApplied = "Yes";
            }
          })
          .catch(error => {
            console.log("SP Applied error ==>" + JSON.stringify(error));
          });
      }

    this.finalProdArray.forEach((pItem) => {
      if (prodId == pItem.product.Id) {
        if (label == "SHOW_INPUT") {
          pItem.ratesFields[itemIndex].showInput = "HIDE_INPUT";
          pItem.ratesFields[itemIndex].showEditableRow = true;
        } else if (label == "HIDE_INPUT") {
          pItem.ratesFields[itemIndex].showInput = "SHOW_INPUT";
          pItem.ratesFields[itemIndex].showEditableRow = false;
        }

        if (fieldNm == "Unit__c") {
          if (pItem.pricingTierOption && pItem.pricingTierOption.length > 0) {
            for (let k = 0; k < pItem.pricingTierOption.length > 0; k++) {
              if (this.onChangeVal == pItem.pricingTierOption[k].value) {
                pricingRateValue = pItem.pricingTierOption[k].title;
              }
            }
            console.log("pricingRateValue::" + pricingRateValue);
          }
        }
        if (fieldNm == "PICC_Pricing_Tier__c") {
          if (
            pItem.piccPricingTierOption &&
            pItem.piccPricingTierOption.length > 0
          ) {
            for (let k = 0; k < pItem.piccPricingTierOption.length > 0; k++) {
              if (this.onChangeVal == pItem.piccPricingTierOption[k].value) {
                piccPricingRateValue = pItem.piccPricingTierOption[k].title;
              }
            }
            console.log("piccPricingRateValue::" + piccPricingRateValue);
          }
        }

        if (fieldNm == "NAC_Pricing_Tier__c") {
          if (
            pItem.nacPricingTierOption &&
            pItem.nacPricingTierOption.length > 0
          ) {
            for (let k = 0; k < pItem.nacPricingTierOption.length > 0; k++) {
              if (this.onChangeVal == pItem.nacPricingTierOption[k].value) {
                nacPricingRateValue = pItem.nacPricingTierOption[k].title;
              }
            }
            console.log("nacPricingRateValue::" + nacPricingRateValue);
          }
        }
      }
    });

    let qrrUpdateList = [];
    if (
      fieldNm !=
      "Vendor__c" /*|| (fieldNm == 'Vendor__c' && prodName == 'DIA')*/
    ) {
      const objRate = {};
      objRate["type"] = "Quote_Request_Rates__c";
      objRate[QRR_ID.fieldApiName] = quoteRqRatesId;
      objRate[fieldNm] = this.onChangeVal;

      if (this.isSPApplied == "Yes") {
        objRate["SP_Applied__c"] = "Yes";
        console.log("rates SP APplied : ", objRate["SP_Applied__c"]);
        this.updateSPAppliedSave();
      } else {
        objRate["SP_Applied__c"] = "No";
        console.log("rates no sp applied : ", objRate["SP_Applied__c"]);
        //this.updateSPAppliedSave();
      }

      qrrUpdateList.push(objRate);
      console.log("qrr Update List : ", qrrUpdateList);
    } else if (fieldNm == "Vendor__c" && prodName == "DIA") {
      if (quoteRqRatesId) {
        const objRate1 = {};
        objRate1["type"] = "Quote_Request_Rates__c";
        objRate1[QRR_ID.fieldApiName] = quoteRqRatesId;
        objRate1["Cheapest_Product__c"] = false;

        qrrUpdateList.push(objRate1);
      }
      let hasId =
        event.detail.value && event.detail.value.startsWith(this.qrrObjPrefix)
          ? true
          : false;

      const objRate2 = {};
      objRate2["type"] = "Quote_Request_Rates__c";
      if (hasId) {
        objRate2["Id"] = event.detail.value;
      } else {
        objRate2["Vendor__c"] = event.detail.value;
      }

      objRate2["Cheapest_Product__c"] = true;
      objRate2["Previous_Active_Rate__c"] = quoteRqRatesId;

      qrrUpdateList.push(objRate2);
    } else {
      const objRate1 = {};
      objRate1["type"] = "Quote_Request_Rates__c";
      objRate1[QRR_ID.fieldApiName] = quoteRqRatesId;
      objRate1["Cheapest_Product__c"] = false;

      qrrUpdateList.push(objRate1);

      const objRate2 = {};
      objRate2["type"] = "Quote_Request_Rates__c";
      objRate2["Id"] = event.detail.value;
      objRate2["Cheapest_Product__c"] = true;
      objRate2["Previous_Active_Rate__c"] = quoteRqRatesId;

      qrrUpdateList.push(objRate2);
    }
    let userPermission = [];
    if (this.loggedInUser && this.loggedInUser.lstPermissionSet) {
      userPermission = this.loggedInUser.lstPermissionSet;
    }

    updateVendorQRRatesCall({
      lstQRRUpdate: qrrUpdateList,
      productName: prodName,
      isPIMUpdateRequired: isPIMUpdateRequired,
     pricingTierRateValue: pricingRateValue,
      piccPricingRateValue: piccPricingRateValue,
      nacPricingRateValue: nacPricingRateValue,
      userPermissions: userPermission,
      locationId: locationId,
      productId: productId,
      qrId: this.recordId
    })
      .then((response) => {
        if(response == false){
          this.updateSPAppliedSave();
        }
        this.showLoading = false;
        this.isViewUpdated = !this.isViewUpdated;
        this.getRatesData(this._locationId, this.productIds);
        this.dispatchEvent(
          new CustomEvent("updateratesdata", {
            detail: { ratesIndex: itemIndex }
          })
        );
        this.dispatchEvent(
          new CustomEvent("refreshtableevent", {
            detail: {locationId:this._locationId}
          })
        );

        if (fieldNm == "Current_Total__c") {
          let flag = false;
          if (this.onChangeVal > 0) {
            flag = true;
          }
          publish(this.messageContext, A3QuotingMessageChannel, {
            eventData: { source: "childExpand" },
            eventTitle: "editCurrentTotal"
          });
          // this.dispatchEvent(new CustomEvent('updatecurrenttotal', {
          // 	detail: { enableGenerateQuote: flag}
          // }));
        }
      })
      .catch((error) => {
        this.showLoading = false;
        console.log("getRatesData error ==>" + JSON.stringify(error));
      });

    //}
  }

  saveEditedField(event) {
    if (event.keyCode === 13) {
      this.onSaveRates(event);
    }
  }

  @track onChangeVal;
  onChangeRatesValue(event) {
    this.onChangeVal = event.target.value;
  }

  //child  Records  Update

  onChildSaveRates(event) {
     console.log("this.onChangeVal" + this.onChangeVal);
    this.handleChildUpdateRates(event);
  }

  saveChildEditedField(event) {
    if(event.keyCode===13){
      this.handleChildUpdateRates(event);
    }
  }

  handleChildUpdateRates(event) {
    this.showLoading = true;
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    let fieldNm = event.currentTarget.dataset.id;
    let quoteRqRatesId = event.target.dataset.recordId;
    let prodId = event.target.accessKey;
    let prodName = event.target.dataset.productName;
    let parentId = event.target.dataset.parentId;
    let locationId = event.currentTarget.dataset.locationId;

    this.finalProdArray.forEach((pItem) => {
      let cItemEquips=pItem.childPrdsFields;
      cItemEquips.forEach((cItem) => {
        if(quoteRqRatesId == cItem.childRecordId ){
          if(label == "SHOW_INPUT") {
              cItem.childFields[itemIndex].showInput ="HIDE_INPUT";
              cItem.childFields[itemIndex].showEditableRow =true;
            }else if (label == "HIDE_INPUT") {
              cItem.childFields[itemIndex].showInput = "SHOW_INPUT";
              cItem.childFields[itemIndex].showEditableRow = false;
              cItem.childFields[itemIndex].isEditable = true ;
              }
          
        }
		
      })

    });
    
    let qrrUpdateList = [];
    const objRate = {};
    objRate[QRR_ID.fieldApiName] = quoteRqRatesId;
    objRate[PARENTQRR_ID.fieldApiName] = parentId;
    objRate[fieldNm] = this.onChangeVal;
    qrrUpdateList.push(objRate);

    updateChildQRRates({updateChildQrr:qrrUpdateList}).then((response)=>{
    this.showLoading=false;
    this.isViewUpdated = !this.isViewUpdated;
    this.isSPApplied = 'Yes';
    this.updateSPAppliedSave();
    this.dispatchEvent(
            new CustomEvent("refreshtableevent", {
              detail: {locationId:locationId}
            })
          );
    })
    .catch((error) => {
      this.showLoading = false;
      console.log("error while updating rates ==>" + JSON.stringify(error));
    });
    
  }

  onCheck(event) {
    const itemIndex = event.currentTarget.dataset.index;
    if (event.target.checked) {
      this._selectedProdId.push(event.target.name);
      if (this._selectedProdLoacMap.has(this.locationId)) {
        this._selectedProdLoacMap.get(this.locationId).push(event.target.name);
      } else {
        let arr = [];
        arr.push(event.target.name);
        this._selectedProdLoacMap.set(this.locationId, arr);
      }
    } else {
      this._selectedProdId.splice(event.target.name, itemIndex);
      let arr = this._selectedProdLoacMap.get(this.locationId);
      for (let j = 0; j < arr.length; j++) {
        if (arr[j] == event.target.name) {
          arr.splice(j, 1);
          this._selectedProdLoacMap.set(this.locationId, arr);

          if (arr.length === 0) {
            this._selectedProdLoacMap.delete(this.locationId);
          }
        }
      }
    }

    this.dispatchEvent(
      new CustomEvent("selectedproductcheeck", {
        detail: {
          selectedProdId: this._selectedProdId,
          locationId: this.locationId,
          selectedProdLoacMap: this._selectedProdLoacMap
        }
      })
    );
  }

  updateSPAppliedSave() {
    const fields = {};
    fields[ID_FIELD.fieldApiName] = this.recordId;
    fields[Special_Pricing__Field.fieldApiName] = this.isSPApplied;
    const recordInput = { fields };

    updateRecord(recordInput)
      .then(() => {
        console.log("Updated Special Pricing value");
        publish(this.messageContext, A3QuotingMessageChannel, {
          eventData: { source: "childExpand" },
          eventTitle: "spApplied",
          eventValue: this.isSPApplied
      });
        spAppliedValueRefresh({ qrId: this.recordId });
      })
      .catch((error) => {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error Updating Special Pricing",
            message: error.body.message,
            variant: "error"
          })
        );
      });
	  
	}

	@api setCertfiedLocation(locationMap) {
		console.log('locationMap== ' + locationMap);
		this.finalProdArray.forEach(item => {
			console.log('item== ' + item);
			console.log('locationMap== Inside' + locationMap);
			if(locationMap.hasOwnProperty(item.quoteRequestLocationId)) {
				if(Object.fromEntries(locationMap[item.quoteRequestLocationId]).hasOwnProperty(item.product.Id)) {
					if(!Object.fromEntries(locationMap[item.quoteRequestLocationId])[item.product.Id]) {
						item.locCertifiedColorIndicator = '';
						item.isClosedWon = !Object.fromEntries(locationMap[item.quoteRequestLocationId])[item.product.Id];
					} else {
						item.locCertifiedColorIndicator = 'colorOrangeIndicator';
						item.isClosedWon = Object.fromEntries(locationMap[item.quoteRequestLocationId])[item.product.Id];
					}
					item.isChecked = false;
				}
			}
		});
	}

  }