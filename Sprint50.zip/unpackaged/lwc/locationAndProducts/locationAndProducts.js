import { LightningElement, track, api, wire } from "lwc";
import fetchQuoteRequestRelatedData from "@salesforce/apex/NewQuoteRequestHandler.quoteRequestRelatedData";
import getLocationsAndRelatedProdDataForSelectedLocs from "@salesforce/apex/NewQuoteRequestHandler.getLocationsAndRelatedProdDataForSelectedLocs";
import { deleteRecord } from "lightning/uiRecordApi";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { exportCSVFile } from "c/utils";
import Id from "@salesforce/schema/Account.Id";
import getQuoteRequestLocations from "@salesforce/apex/NewQuoteRequestLocationHandler.getQuoteRequestLocations";
import renameQuoteOptionApex from "@salesforce/apex/NewQuoteRequestHandler.renameQuoteOption";
import QUOTE_REQUEST_OBJECT from "@salesforce/schema/Quote_Request_2__c";
import deleteAllLocation from "@salesforce/apex/NewQuoteRequestHandler.deleteAllRecords";
import deleteQuoteOptionFromQuote from "@salesforce/apex/NewQuoteRequestHandler.deleteQuoteOptionFromQuote";
import deleteRecordsFromQuoteOption from "@salesforce/apex/NewQuoteRequestHandler.deleteRecordsFromQuoteOption";
import QUOTE_REQUEST_RATES_OBJECT from "@salesforce/schema/Quote_Request_Rates__c";
import { getPicklistValues } from "lightning/uiObjectInfoApi";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import UNIT_FIELD from "@salesforce/schema/Quote_Request_Rates__c.Unit__c";
import { NavigationMixin } from "lightning/navigation";
import getReportId from "@salesforce/apex/NewQuoteRequestHandler.getReportId";
import { publish, createMessageContext } from "lightning/messageService";
import A3QuotingMessageChannel from "@salesforce/messageChannel/A3QuotingMessageChannel__c";

const SUBMITTED_QUOTE_STATUSES = [
  "Pending Pricing",
  "Pending Rate Request",
  "Pricing Complete",
  "Closed - WON",
  "Sent To Customer",
  "Cancelled",
  "Closed - LOST",
  "Under Negotiation",
  "Pending Finance Review",
  "Pending SE Review"
];
const SUCCESS_TITLE = "Success";
const SUCCESS_VARIANT = "success";
const ERROR_TITLE = "Error";
const GENERIC_ERROR_MSG = "Something went wrong";
const ERROR_VARIANT = "error";

export default class Location_And_Products extends NavigationMixin(
  LightningElement
) {
  @api recordId;
  @api quoteRequestId;
  @api quoteRequestStatus;
  @track isPendingSpOrSeReview = false;
  @api quoteRequestQuoteType;
  @api quoteRequestBusinessUnit;
  @api loggedInUser;
  @api isEditQuoteRequest;
  @track disabledAll = false;
  @track isSummaryClick = false;
  @track showNoProductsError = false;
  _backupLocations = [];
  hasrendered = false;
  confirmDelete = false;
  OpenLocProdValidator = false;
  @api quoteRequest = QUOTE_REQUEST_OBJECT;
  OpenLocProdValidator = false;
  @track exportPopup = "popuphide";
  @api selectAll = false;
  @track _hideTabs = false;
  @track subHeader;
  @track openAddProduct = false;
  @track openModalTabName = "";
  openCustomizeColumns = false;
  isSubmittedQuote = false;
  _quoteOptionStructureMap = new Map();
  isImport = false;
  recordIdToDelete;
  deleteModalMessage = "";
  deleteModalHeader = "";
  listOfAllProductWithQuoteOption = [];
  @track productDetail = [];
  @track quoteOptionsDataWrapper = [];
  @track productsStr = "";
  locationSize = "";
  @track selectedLocation;
  isRename = false;
  popupButtonPositive = "YES";
  popupButtonNegative = "NO";
  idToRenameQuoteOption;
  quoteOptionToRename = "";
  @track showAddlocationModalCheck = false;
  @track showAddlocationModal = false;
  @track isSingleLocationProductsView = false;
  @track locationsAndProductsView = true;
  @track mapOfColumnValues;
  columnsCheck = [];
  columnsValues = [];
  openDeleteAllPopup = false;
  singleLocationDelete = false;
  //Added to manage delete all location functionality
  isDeleteAll = false;
  @track locations = [];
  @track locationAndProducts;
  _backUpData = [];
  @track locationIDs = [];

  //list to manage all filter column name
  @track groupNameOption = [];
  @track locationNameOption = [];
  @track cityOption = [];
  @track stateOption = [];
  @track zipOption = [];
  @track nPAOption = [];
  @track productsOption = [];
  @track activationOption = [];
  @track mrcpriceOption = [];
  @track onnetOption = [];
  @track vendorOption = [];
  ///Start - Added for US Customize.
  @track address = [];
  @track buildingApt = [];
  @track floorSuite = [];
  @track glcCode = [];
  @track locationStoreNum = [];
  @track units = [];
  @track selectedLocations = [];
  @track tempSelectedLocations = [];
  ///End - Added for US Customize.
  _handler;
  isAnyPopupDisplayed = false;
  @track xlsHeader = [];
  @track xlsData = [];
  @track fieldName = [];
  @track workSheetNameList = [];
  @track checkedQuoteOptionsIds = [];
  @track filename = "SalesRep Summary";
  @track isEnabledEditPriceTier = true;
  @track unitPickListValue = 0.55;
  @track isEditPricing = false;
  @track isProductSelect = false;
  @track totalError;
  @track filteredQRLocations = [];
  @track showSpinner = false;
  @wire(getObjectInfo, { objectApiName: QUOTE_REQUEST_RATES_OBJECT })
  quoteRequestRates;
  reportId;
  error;
  reportQuoteOptionId;
  surchargeCheckValue = false;
  emptyFlag = true;
  messageContext = createMessageContext();

  @wire(getReportId, { reportName: "Quote Request Rates Error Info1" })
  report({ data, error }) {
    if (data) {
      this.reportId = data;
    } else if (error) {
      this.error = error;
    }
  }

  viewReport(event) {
    this[NavigationMixin.Navigate]({
      type: "standard__recordPage",
      attributes: {
        recordId: this.reportId,
        objectApiName: "Report",
        actionName: "view"
      },
      state: {
        fv0: this.reportQuoteOptionId.slice(0, -3)
      }
    });
  }

  @wire(getPicklistValues, {
    recordTypeId: "$quoteRequestRates.data.defaultRecordTypeId",
    fieldApiName: UNIT_FIELD
  })
  unitPicklist;

  handleEditPricingTier(event) {
    this.unitPickListValue = 0.55;
    this.isEditPricing = true;
  }
  savePricingTier() {
    this.isEditPricing = false;
    if (this.template.querySelector("c-nqr-locations-table")) {
      console.log("in querySelector");
      this.template
        .querySelector("c-nqr-locations-table")
        .updatePricingTier(this.unitPickListValue);
    }
    this.isProductSelect = false;
    this.isEnabledEditPriceTier =
      typeof this.selectedLocations != "undefined" &&
      this.selectedLocations?.length > 0
        ? false
        : true;
  }
  onPricingTierChange(event) {
    this.unitPickListValue = event.target.value;
    console.log("this.unitPickListValue::" + this.unitPickListValue);
  }
  cancelPricingTier(event) {
    this.isEditPricing = false;
  }
  @track isProductSelect = false;
  handleProductSelected(event) {
    this.isProductSelect = event.detail.isSelected;
    this.isEnabledEditPriceTier =
      this.isProductSelect ||
      (typeof this.selectedLocations != "undefined" &&
        this.selectedLocations?.length > 0)
        ? false
        : true;
  }

  getErrorRecords(event) {
    console.log("value from child++:", this.totalError);
    this.totalError = event.detail;
  }

  /**
   * Added by Pranav for customizable columns
   */
  @track selectedColumns = [];
  isLocationTableVisible = false;
  handleColumnChange(event) {
    this.selectedColumns = event.detail.selectedColumns;
    this.isLocationTableVisible = !this.isLocationTableVisible;
    this.openCustomizeColumns = !this.openCustomizeColumns;
  }
  handleColumnChangeCancel(event) {
    this.openCustomizeColumns = !this.openCustomizeColumns;
  }
  handleEditPricingTier(event) {
    this.unitPickListValue = 0.55;
    this.isEditPricing = true;
    if (this.selectedLocations?.length > 1) {
      this.isDeleteAll = true;
    } else {
      this.isDeleteAll = false;
    }
    this.isEnabledEditPriceTier =
      this.isProductSelect ||
      (typeof this.selectedLocations != "undefined" &&
        this.selectedLocations?.length > 0)
        ? false
        : true;

    console.log(
      "handleRowSelection event ==> " + JSON.stringify(this.selectedLocations)
    );
  }
  savePricingTier() {
    this.isEditPricing = false;
    if (this.template.querySelector("c-nqr-locations-table")) {
      this.template
        .querySelector("c-nqr-locations-table")
        .updatePricingTier(this.unitPickListValue);
    }
    this.isProductSelect = false;
    this.isEnabledEditPriceTier =
      typeof this.selectedLocations != "undefined" &&
      this.selectedLocations?.length > 0
        ? false
        : true;
  }
  onPricingTierChange(event) {
    this.unitPickListValue = event.target.value;
  }
  handleUpdateLocation() {
    this.notifyChanges();
    this.fetchQuoteRequestData();
  }
  /**
   * Added by Pranav to delete a location-item record
   * @param {*} rowId
   */
  deleteItemsV2(rowId) {
    this.deleteModalMessage =
      "You are about to delete this location from " + this.selectedQuoteOption;
    this.openDeleteAllPopup = true;
    this.singleLocationDelete = true;
    this.recordIdToDelete = rowId;
    // this.closeAllPopups();
    // this.refreshLocationTable();
  }

  cancelPricingTier(event) {
    this.isEditPricing = false;
  }

  handleUpdatecurrentTotal(event) {
    this.dispatchEvent(
      new CustomEvent("updatecurrenttotal", {
        detail: { enableGenerateQuote: event.detail.enableGenerateQuote }
      })
    );
  }

  handleProductSelected(event) {
    this.isProductSelect = event.detail.isSelected;
    this.isEnabledEditPriceTier =
      this.isProductSelect ||
      (typeof this.selectedLocations != "undefined" &&
        this.selectedLocations?.length > 0)
        ? false
        : true;
  }
  /**
   * Added by Pranav for customizable columns
   */
  @track selectedColumns = [];
  isLocationTableVisible = false;
  handleColumnChange(event) {
    this.selectedColumns = event.detail.selectedColumns;
    this.isLocationTableVisible = !this.isLocationTableVisible;
    this.openCustomizeColumns = !this.openCustomizeColumns;
  }
  handleColumnChangeCancel(event) {
    this.openCustomizeColumns = !this.openCustomizeColumns;
  }
  handleRowSelection(event) {
    this.selectedLocations = event.detail.locations;

    if (this.selectedLocations?.length > 1) {
      this.isDeleteAll = true;
    } else {
      this.isDeleteAll = false;
    }
    this.isEnabledEditPriceTier =
      this.isProductSelect ||
      (typeof this.selectedLocations != "undefined" &&
        this.selectedLocations?.length > 0)
        ? false
        : true;

    console.log(
      "handleRowSelection event ==> " +
        this.isProductSelect +
        "" +
        typeof this.selectedLocations !=
        "undefined" + "" + JSON.stringify(this.selectedLocations)
    );
  }
  handleRowAction(event) {
    if (event?.detail) {
      if (event.detail.actionName === "delete") {
        this.deleteItemsV2(event.detail.rowId);
      }
      if (event.detail.actionName === "edit") {
        this.handleEditLocationV2(event.detail.record);
      }
    }
  }
  handleUpdateLocation() {
    this.notifyChanges();
    this.fetchQuoteRequestData();
  }
  /**
   * Added by Pranav to delete a location-item record
   * @param {*} rowId
   */
  deleteItemsV2(rowId) {
    this.deleteModalMessage =
      "You are about to delete this location from " + this.selectedQuoteOption;
    this.openDeleteAllPopup = true;
    this.singleLocationDelete = true;
    this.recordIdToDelete = rowId;
    //this.fetchQuoteRequestData();
  }
  /**
   * Added by Pranav to edit a location-item record
   * @param {*} rowId
   */
  handleEditLocationV2(record) {
    let selectedLocations = [];
    let selectedData = record;
    selectedLocations.push(selectedData);
    this.redirectToProductAdd(selectedLocations);
    // this.refreshLocationTable();
  }

  @track selectedProdData = [];
  prodMap = new Map([
    ["BROADBAND", "BB"],
    ["GUARDIAN", "GDN"],
    ["GUARDIAN SERVICES", "GDN"],
    ["NETWORK INTEGRATION", "NI"]
  ]);

  connectedCallback() {
    this.xlsFormatter(
      [
        {
          Product: "Broadband",
          QTY: "0",
          Activation: "0",
          "MRC(G,$)": "0",
          Surcharge: "0",
          Taxes: "0"
        },
        {
          Product: "DIA",
          QTY: "0",
          Activation: "0",
          "MRC(G,$)": "0",
          Surcharge: "0",
          Taxes: "0"
        }
      ],
      "Summary"
    );
    this.getAllLocations();
    document.addEventListener("click", (this._handler = this.close.bind(this)));
  }

  @api
  refreshWhenCancelAndSave() {
    console.log(
      this.quoteOptionsDataWrapper.length +
        "this.quoteOptionsDataWrapper.length"
    );
    this.fetchQuoteRequestData();
  }
  @api async handleExportExcelFile(quoteRequestName) {
    let filename = quoteRequestName + "-SalesRep Summary";
    if (this.checkedQuoteOptionsIds.length > 0) {
      await this.template.querySelector("c-xlsx-main").download(filename);
    } else {
      this.dispatchEvent(
        new ShowToastEvent({
          title: "Warning",
          message: "Select quote options to download",
          variant: "warning"
        })
      );
    }
  }
  handleCheckedQuoteOptions(event) {
    let qoID = event.detail.quoteOptionId;
    //this.reportQuoteOptionId = qoID;
    let qoName;
    let isQuoteChecked = event.detail.isQuoteChecked;

    if (isQuoteChecked) {
      this.selectedQuoteOptionId = qoID;
      this.checkedQuoteOptionsIds.push(qoID);
    } else {
      let qoIndex = this.checkedQuoteOptionsIds.indexOf(qoID);

      if (qoIndex >= -1) {
        this.checkedQuoteOptionsIds.splice(qoIndex, 1);
        this.xlsHeader.splice(qoIndex + 1, 1);
        this.workSheetNameList.splice(qoIndex + 1, 1);
        this.xlsData.splice(qoIndex + 1, 1);
      }
    }
    this.quoteOptionList.forEach((item) => {
      if (item.Id == qoID) {
        qoName = item.name;
      }
    });

    this.populateLocationProductsOnQuoteOptionChange(
      this.quoteOptionsDataWrapper,
      isQuoteChecked,
      qoName
    );
  }
  @track headers = [];
  xlsFormatter(data, sheetName) {
    if (data && data.length > 0) {
      let tempData = [];
      tempData = data;
      let Header = Object.keys(tempData[0]);
      let tempheaders = [...Header];
      this.xlsHeader.push(tempheaders);
      this.workSheetNameList.push(sheetName);
      this.xlsData.push(tempData);
    }
  }
  renderedCallback() {
    if (!this.hasrendered) {
      if (this.isEditQuoteRequest && this.isEditQuoteRequest == true) {
        this.isSummaryClick = true;
      } else {
      }
      // console.log('quoterequeststatus::'+this.quoteOptionsDataWrapper.length+'ss');
      if (this.quoteOptionsDataWrapper.length == 0) {
        this.fetchQuoteRequestData();
      } else {
        this.hasrendered = true;
      }
    }
  }

  // Resizable table

  fixedWidth = "width:15rem;";

  //FOR HANDLING THE HORIZONTAL SCROLL OF TABLE MANUALLY
  tableOuterDivScrolled(event) {
    this._tableViewInnerDiv = this.template.querySelector(".tableViewInnerDiv");
    if (this._tableViewInnerDiv) {
      if (
        !this._tableViewInnerDivOffsetWidth ||
        this._tableViewInnerDivOffsetWidth === 0
      ) {
        this._tableViewInnerDivOffsetWidth =
          this._tableViewInnerDiv.offsetWidth;
      }
      this._tableViewInnerDiv.style =
        "width:" +
        (event.currentTarget.scrollLeft + this._tableViewInnerDivOffsetWidth) +
        "px;" +
        this.tableBodyStyle;
    }
    this.tableScrolled(event);
  }

  tableScrolled(event) {
    if (this.enableInfiniteScrolling) {
      if (
        event.target.scrollTop + event.target.offsetHeight >=
        event.target.scrollHeight
      ) {
        this.dispatchEvent(
          new CustomEvent("showmorerecords", {
            bubbles: true
          })
        );
      }
    }
    if (this.enableBatchLoading) {
      if (
        event.target.scrollTop + event.target.offsetHeight >=
        event.target.scrollHeight
      ) {
        this.dispatchEvent(
          new CustomEvent("shownextbatch", {
            bubbles: true
          })
        );
      }
    }
  }

  //#region ***************** RESIZABLE COLUMNS *************************************/
  handlemouseup(e) {
    this._tableThColumn = undefined;
    this._tableThInnerDiv = undefined;
    this._pageX = undefined;
    this._tableThWidth = undefined;
  }

  handlemousedown(e) {
    if (!this._initWidths) {
      this._initWidths = [];
      let tableThs = this.template.querySelectorAll(
        "table thead .dv-dynamic-width"
      );
      tableThs.forEach((th) => {
        this._initWidths.push(th.style.width);
      });
    }

    this._tableThColumn = e.target.parentElement;
    this._tableThInnerDiv = e.target.parentElement;
    while (this._tableThColumn.tagName !== "TH") {
      this._tableThColumn = this._tableThColumn.parentNode;
    }
    while (!this._tableThInnerDiv.className.includes("slds-cell-fixed")) {
      this._tableThInnerDiv = this._tableThInnerDiv.parentNode;
    }
    console.log(
      "handlemousedown this._tableThColumn.tagName => ",
      this._tableThColumn.tagName
    );
    this._pageX = e.pageX;

    this._padding = this.paddingDiff(this._tableThColumn);

    this._tableThWidth = this._tableThColumn.offsetWidth - this._padding;
    console.log(
      "handlemousedown this._tableThColumn.tagName => ",
      this._tableThColumn.tagName
    );
  }

  handlemousemove(e) {
    if (this._tableThColumn && this._tableThColumn.tagName === "TH") {
      this._diffX = e.pageX - this._pageX;

      this.template.querySelector("table").style.width =
        this.template.querySelector("table") - this._diffX + "px";

      this._tableThColumn.style.width = this._tableThWidth + this._diffX + "px";
      this._tableThInnerDiv.style.width = this._tableThColumn.style.width;

      let tableThs = this.template.querySelectorAll(
        "table thead .dv-dynamic-width"
      );
      let tableBodyRows = this.template.querySelectorAll("table tbody tr");
      let tableBodyTds = this.template.querySelectorAll(
        "table tbody .dv-dynamic-width"
      );
      tableBodyRows.forEach((row) => {
        let rowTds = row.querySelectorAll(".dv-dynamic-width");
        rowTds.forEach((td, ind) => {
          rowTds[ind].style.width = tableThs[ind].style.width;
        });
      });
    }
  }

  handledblclickresizable() {
    let tableThs = this.template.querySelectorAll(
      "table thead .dv-dynamic-width"
    );
    let tableBodyRows = this.template.querySelectorAll("table tbody tr");
    tableThs.forEach((th, ind) => {
      th.style.width = this._initWidths[ind];
      th.querySelector(".slds-cell-fixed").style.width = this._initWidths[ind];
    });
    tableBodyRows.forEach((row) => {
      let rowTds = row.querySelectorAll(".dv-dynamic-width");
      rowTds.forEach((td, ind) => {
        rowTds[ind].style.width = this._initWidths[ind];
      });
    });
  }

  paddingDiff(col) {
    if (this.getStyleVal(col, "box-sizing") === "border-box") {
      return 0;
    }

    this._padLeft = this.getStyleVal(col, "padding-left");
    this._padRight = this.getStyleVal(col, "padding-right");
    return parseInt(this._padLeft, 10) + parseInt(this._padRight, 10);
  }

  getStyleVal(elm, css) {
    return window.getComputedStyle(elm, null).getPropertyValue(css);
  }

  // Resizable table

  @api
  falseByProductView() {
    this.isByProduct = false;
  }

  @api
  handleSummaryVariable() {
    this.isSummaryClick = true;
    for (let i = 0; i < this.quoteOptionList.length; i++) {
      this.quoteOptionList[i].selected = "notselected";
    }
    this.updateChild();
    console.log("in handle summary");
    console.log(this.quoteOptionList);
  }
  disconnectedCallback() {
    document.removeEventListener("click", this._handler);
  }

  ignore(event) {
    event.stopPropagation();
    return false;
  }
  close() {
    if (this.isAnyPopupDisplayed) {
      console.log("we should close now");
      this.closeAllPopups();
    }
  }
  async getAllLocations() {
    try {
      let loc = [];
      loc = await getQuoteRequestLocations({ QuoteRequestId: this.recordId });
      loc.forEach((item) => {
        this._backupLocations.push(item.Id);
        this.locations.push(item.Id);
      });
      this.locationAndProducts = true;
      console.log("this.locations 1", this.locations);
    } catch (error) {
      this.error = error;
    } finally {
      this.isLoaded = true;
    }
  }

  //by Location handler
  @track isByProduct = false;
  @track isByLocation = true;
  @track childColumn = [
    "Provider",
    "Product",
    "Access Type",
    "Speed",
    "Unit",
    "Quality",
    "Term"
  ];
  handleProductorLocationView(event) {
    if (event.detail == "ByProduct") {
      this.isByProduct = true;
    } else {
      this.isByLocation = true;
      this.isByProduct = false;
    }
  }
  @track selectedQuoteOption = "";
  selectedQuoteOptionId = "";
  @api quoteOptionList;

  @track allData = [];
  @track data = [
    {
      isChecked: false,
      address: "test Address",
      city: "test Address",
      state: "test Address",
      zip: "test Address",
      npanxx: "test Address",
      products: "test Address",
      action: "test Address",
      address: "test Address",
      buildingApt: "test Address",
      floorSuite: "test Address",
      glcCode: "test Address",
      locationStoreNum: "test Address",
      units: "test Address",
      activation: "1234.00",
      mrcprice: "1234.90",
      activationEditCheck: false,
      activationIOEnable: "ShowActivationLabel",
      mrcEditCheck: false,
      mrcIOEnable: "ShowMRCLabel",
      isExpand: false,
      popup: "productPopupHide",
      productsData: [
        {
          pname: "product1",
          ptype: "type"
        },
        {
          pname: "product2",
          ptype: "type2"
        }
      ]
    },
    {
      isChecked: false,
      address: "2 test Address",
      city: "2 test Address",
      state: "2 test Address",
      zip: "2 test Address",
      npanxx: "2 test Address",
      products: "2 test Address",
      address: "2 test Address",
      buildingApt: "2 test Address",
      floorSuite: "2 test Address",
      glcCode: "2 test Address",
      locationStoreNum: "2 test Address",
      units: "2 test Address",
      activation: "1298.00",
      mrcprice: "1934.90",
      activationEditCheck: false,
      activationIOEnable: "ShowActivationLabel",
      mrcEditCheck: false,
      mrcIOEnable: "ShowMRCLabel",
      action: "2 test Address",
      isExpand: false,
      popup: "productPopupHide",
      productsData: [
        {
          pname: "product1",
          ptype: "type"
        },
        {
          pname: "product2",
          ptype: "type2"
        }
      ]
    }
  ];
  headers = {
    groupName: "All Group Name",
    address: "All Locations",
    city: "All City Name",
    state: "All State Name",
    zip: "All ZIP",
    npanxx: "All NPA/NXX",
    products: "All Products",
    address: "All Address",
    buildingApt: "All Building/Apt",
    floorSuite: "All Floor/Suite",
    glcCode: "All GL Code",
    locationStoreNum: "All Location/Store Number",
    units: "All Units",
    activation: "Activation",
    mrcprice: "MRC(G,$)",
    onnet: "On-Net",
    vendor: "Vendor"
  };

  headersforexport = {
    groupName: "All Group Name",
    address: "All Locations",
    city: "All City Name",
    state: "All State Name",
    zip: "All ZIP",
    npanxx: "All NPA/NXX",
    products: "All Products",
    address: "All Address",
    buildingApt: "All Building/Apt",
    floorSuite: "All Floor/Suite",
    glcCode: "All GL Code",
    locationStoreNum: "All Location/Store Number",
    units: "All Units",
    activation: "Activation",
    mrcprice: "MRC(G $)",
    onnet: "On-Net",
    vendor: "Vendor"
  };

  @track columns = [
    {
      label: "Group Name",
      value: "groupname",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "Location Name",
      value: "locationname",
      isAddress: true,
      isColVisible: false
    },
    {
      label: "City",
      value: "city",
      isAddress: false,
      isColVisible: true
    },
    {
      label: "State",
      value: "state",
      isAddress: false,
      isColVisible: true
    },
    {
      label: "Zip",
      value: "zip",
      isAddress: false,
      isColVisible: true
    },
    {
      label: "NPA/NXX",
      value: "NPANXX",
      isAddress: false
    },
    {
      label: "Products",
      value: "products",
      isAddress: false,
      isColVisible: true
    },
    {
      label: "Address",
      value: "address",
      isAddress: false,
      isColVisible: true
    },
    {
      label: "Building/Apt",
      value: "buildingApt",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "Floor/Suite",
      value: "floorSuite",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "GL Code",
      value: "glcCode",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "Location/Store Number",
      value: "locationStoreNum",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "Units",
      value: "units",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "Activation",
      value: "activation",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "MRC(G,$)",
      value: "mrcprice",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "On-Net",
      value: "onnet",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "Vendor",
      value: "vendor",
      isAddress: false,
      isColVisible: false
    },
    {
      label: "",
      value: "actions",
      isAddress: false
    }
  ];

  onExpand(event) {
    let indx = event.target.dataset.recordId;
    console.log("index " + indx);
    this.data[indx].isExpand = !this.data[indx].isExpand;
    this.selectedProdData = this.allData[indx].productsData;
  }
  selectedQoClick() {
    var popup = this.template.querySelectorAll("div[data-my-id=in4]");
    popup.classList.toggle("show");
  }
  updateChild() {
    this.template
      .querySelector("c-location-and-products-header")
      .processMyData(this.quoteOptionList);
  }
  async updateRatesData(event) {
    let indx = event.detail.ratesIndex;
    await this.fetchQuoteRequestData(indx);
  }
  selectQuoteOption(event) {
    this.isSummaryClick = false;
    let quoteOptionId = event.detail;
    console.log("Inside selectQuoteOption" + quoteOptionId);
    this.reportQuoteOptionId = quoteOptionId;
    console.log("report quote option id : ", this.reportQuoteOptionId);
    if (!this.isEditQuoteRequest) {
      if (this.selectedQuoteOptionId === quoteOptionId) {
        return;
      }
    }
    this.selectedQuoteOptionId = quoteOptionId;
    if (this.isByProduct) {
      if (this.template.querySelector("c-by-product-view-component")) {
        this.template
          .querySelector("c-by-product-view-component")
          .displayQuotesInProductView(quoteOptionId);
      }
    }
    for (let i = 0; i < this.quoteOptionList.length; i++) {
      if (this.quoteOptionList[i].Id == quoteOptionId) {
        this.quoteOptionList[i].selected = "selected";
        this.selectedQuoteOption = this.quoteOptionList[i].name;
      } else {
        this.quoteOptionList[i].selected = "notselected";
      }
    }
    this.productDetail = [];
    this.productsStr = "";
    let productsSet = [];
    this.productsOption = ["All Products"];
    for (let i = 0; i < this.listOfAllProductWithQuoteOption.length; i++) {
      if (
        this.listOfAllProductWithQuoteOption[i].Quote_Option__c ==
        this.selectedQuoteOptionId
      ) {
        console.log(
          this.listOfAllProductWithQuoteOption[i].Quote_Option__c ==
            this.selectedQuoteOptionId
        );
        this.productDetail.push(this.listOfAllProductWithQuoteOption[i]);
        if (this.productsStr == "") {
          this.productsStr = this.listOfAllProductWithQuoteOption[i].Name;
        } else {
          this.productsStr =
            this.productsStr +
            ", " +
            this.listOfAllProductWithQuoteOption[i].Name;
        }
        productsSet.push(this.listOfAllProductWithQuoteOption[i]);
      }
    }

    productsSet.sort();
    this.productsStr = productsSet ? productsSet.join() : this.productsStr;

    this.productsOption.push(this.productsStr);
    this.updateChild();
    for (let i = 0; i < this.data.length; i++) {
      this.data[i].products = this.productsStr;
    }
    console.log("all Data" + this.selectedQuoteOption);
    this.populateLocationProductsOnQuoteOptionChange(
      this.quoteOptionsDataWrapper
    );

    const selectedEvent = new CustomEvent("quoteoptionsclick", {
      detail: quoteOptionId
    });
    //this.ignore(event);
    // Dispatches the event.
    this.dispatchEvent(selectedEvent);

    this.isLocationTableVisible = !this.isLocationTableVisible;
  }
  exportPopupHandle() {
    this.closeAllPopups();
    if (this.exportPopup == "popupshow") {
      this.exportPopup = "popuphide";
    } else {
      this.exportPopup = "popupshow";
      this.isAnyPopupDisplayed = true;
    }
  }
  deleteSelectedLocation() {
    this.singleLocationDelete = false;
    this.openDeleteAllPopup = true;
  }

  closeDeleteAll() {
    this.openDeleteAllPopup = false;
    this.singleLocationDelete = false;
  }

  renameDeletePopupHandle(event) {
    console.log("all Qo " + JSON.stringify(this.quoteOptionList));
    let indx = event.detail.qoIndex;
    for (let i = 0; i < this.quoteOptionList.length; i++) {
      if (i == parseInt(indx)) {
        console.log("sindhu " + i + " " + indx);
        console.log("sindhu1 " + this.quoteOptionList[indx].popup);
        if (this.quoteOptionList[indx].popup == "renameDeleteHide") {
          this.quoteOptionList[indx].popup = "renameDeleteShow";
          this.isAnyPopupDisplayed = true;
          console.log(
            "quoteOptionList[indx]" + JSON.stringify(this.quoteOptionList[indx])
          );
          this.selectedQuoteOptionId = this.quoteOptionList[indx].Id;
          this.selectedQuoteOption = this.quoteOptionList[indx].name;
        } else {
          console.log("sindhu2 " + i + " " + this.quoteOptionList[i].popup);
          this.quoteOptionList[indx].popup = "renameDeleteHide";
        }
      } else {
        console.log("sindhu3 " + i + " " + this.quoteOptionList[i].popup);
        this.quoteOptionList[i].popup = "renameDeleteHide";
      }
    }
    this.isLocationTableVisible = !this.isLocationTableVisible;
    this.updateChild();
  }

  productPopupHandle(event) {
    this.closeAllPopups();
    let indx = event.target.dataset.recordId;
    for (let i = 0; i < this.data.length; i++) {
      if (i == indx) {
        if (this.data[indx].popup == "productPopupHide") {
          this.data[indx].popup = "productPopupShow";
          this.isAnyPopupDisplayed = true;
          console.log("isAnyPopupDisplayed" + this.isAnyPopupDisplayed);
        } else {
          this.data[indx].popup = "productPopupHide";
        }
      } else {
        this.data[i].popup = "productPopupHide";
      }
    }
  }

  enableAddProductBtn(event) {
    let lctsCheck = event.detail.locationsSelected;
    this.template
      .querySelector("c-location-and-products-header")
      .addProductButtonState(lctsCheck);
  }

  onSelectAll(event) {
    let isAllChecked = event.target.checked;

    if (isAllChecked) {
      this.isDeleteAll = true;
    } else {
      this.isDeleteAll = false;
    }
    this.selectAll = isAllChecked;
    for (let i = 0; i < this.data.length; i++) {
      this.data[i].isChecked = isAllChecked;
    }
    this.template
      .querySelector("c-location-and-products-header")
      .addProductButtonState(this.selectAll);
  }
  async onSelect(event) {
    let locSelect;
    let isChecked = event.target.checked;
    let indx = event.target.dataset.recordId;
    let idVar = event.target.dataset.recordId;
    for (let i = 0; i < this.data.length; i++) {
      if (this.data[i].Id == idVar) {
        this.data[i].isChecked = isChecked;
      }
    }
    if (!isChecked) {
      this.selectAll = false;
      this.template
        .querySelector("c-location-and-products-header")
        .addProductButtonState(!this.selectAll);
    } else {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].isChecked) {
          locSelect = true;
        } else {
          locSelect = false;
          break;
        }
      }
      this.selectAll = locSelect;
    }

    this.checkSelectedNumberOfLocations(this.data);
  }
  //check selected Number Of locations
  checkSelectedNumberOfLocations(data) {
    let selectedLocation = 0;
    for (let item = 0; item < data.length; item++) {
      if (selectedLocation > 1) {
        break;
      }
      if (data[item].isChecked) {
        selectedLocation++;
      }
    }
    if (selectedLocation > 1) {
      this.isDeleteAll = true;
    } else {
      this.isDeleteAll = false;
    }
  }

  async fetchQuoteRequestData(rateIndx) {
    await fetchQuoteRequestRelatedData({ recordId: this.recordId })
      .then((result) => {
        this.dispatchEvent(
          new CustomEvent("updateqrstatus", {
            detail: {
              qrStatus: result.objQr.Quote_Request_Status__c,
              qrSubStatus: result.objQr.Sub_Status__c,
              qrLastSavedDate: result.objQr.Last_Saved__c
            }
          })
        );
        var quoteOptionLocationProdctwrapper = result;
        this.quoteOptionsDataWrapper = result;
        this.surchargeCheckValue = result.quoteProductList[0].Is_Surcharge__c;
        console.log(
          "Final Loc And Prod Surcharge : ",
          this.surchargeCheckValue
        );
        this._backUpData = this.data;
        this.data = [];
        this.productDetail = [];
        try {
          //Started populating Quote request locations
          var listOfLocation =
            quoteOptionLocationProdctwrapper.quoteLocationList;
          //Populate location Size
          this.locationSize = " (" + this.data.length + ")";
          //Started populating Quote Options
          this.quoteOptionList = [];
          var listOfQuoteOption =
            quoteOptionLocationProdctwrapper.quoteOptionList;
          var quoteOptionId = "";
          let _quoteOptionItemMap = new Map();
          let _quoteOptionLocationMap = new Map();
          this.productsOption = ["All Products"];
          this.listOfAllProductWithQuoteOption =
            quoteOptionLocationProdctwrapper.quoteProductList;
          for (
            let i = 0;
            i < this.listOfAllProductWithQuoteOption.length;
            i++
          ) {
            // if (this.listOfAllProductWithQuoteOption[i].Quote_Option__c == this.selectedQuoteOptionId) {
            //this.productDetail.push(this.listOfAllProductWithQuoteOption[i]);
            _quoteOptionItemMap.set(
              this.listOfAllProductWithQuoteOption[i].Id,
              this.listOfAllProductWithQuoteOption[i]
            );
            // }
          }
          this._quoteOptionStructureMap = new Map();
          //console.log(_quoteOptionItemMap);
          for (let i = 0; i < listOfQuoteOption.length; i++) {
            if (i == 0) {
              this.selectedQuoteOptionId = listOfQuoteOption[i].Id;
              this.selectedQuoteOption = listOfQuoteOption[i].Name;
            }
            console.log("sindhu initial values set" + this.isEditQuoteRequest);

            this.quoteOptionList.push({
              name: listOfQuoteOption[i].Name,
              Id: listOfQuoteOption[i].Id,
              variantName:
                i == 0 && this.isEditQuoteRequest == false
                  ? "brand"
                  : "neutrel",
              selected:
                i == 0 && this.isEditQuoteRequest == false
                  ? "selected"
                  : "notselected",
              popup: "renameDeleteHide"
            });
            quoteOptionId = listOfQuoteOption[i].Id;
            let _quoteProductsByLocation = new Map();
            if (listOfQuoteOption[i].Quote_Location_Option__r) {
              listOfQuoteOption[i].Quote_Location_Option__r.forEach((elem) => {
                if (typeof elem.Quote_Option_Item__r === "undefined") return;
                let _tempProdArray = _quoteProductsByLocation.has(
                  elem.Quote_Request_Location__c
                )
                  ? _quoteProductsByLocation.get(elem.Quote_Request_Location__c)
                  : [];
                _tempProdArray.push(
                  _quoteOptionItemMap.get(elem.Quote_Option_Item__c)
                );
                _quoteProductsByLocation.set(
                  elem.Quote_Request_Location__c,
                  _tempProdArray
                );
              });
            }
            this._quoteOptionStructureMap.set(
              listOfQuoteOption[i].Id,
              _quoteProductsByLocation
            );
          }
          var selectedLocationsForQuoteOption = [];
          let _locProductsMap = new Map();
          //	console.log(_quoteOptionLocationMap);
          //	console.log(this._quoteOptionStructureMap);

          this.updateChild();
          //Started populating Products with Quote Option
          this.productsStr = "";
          this.productDetail = [];
          for (
            let i = 0;
            i < quoteOptionLocationProdctwrapper.quoteLocationOptions.length;
            i++
          ) {
            if (
              quoteOptionId ==
              quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                .Quote_Option__c
            ) {
              let _locationId =
                quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                  .Quote_Request_Location__c;
              if (
                typeof quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                  .Quote_Option_Item__r !== "undefined"
              ) {
                _locProductsMap.set(
                  _locationId,
                  _locProductsMap.has(_locationId)
                    ? _locProductsMap.get(_locationId) +
                        ", " +
                        quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                          .Quote_Option_Item__r.Name
                    : quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                        .Quote_Option_Item__r.Name
                );
              } else {
                _locProductsMap.set(_locationId, "");
              }

              selectedLocationsForQuoteOption.push(_locationId);
              let _existingProduct = _quoteOptionLocationMap.has(_locationId)
                ? _quoteOptionLocationMap.get(_locationId)
                : [];
              if (
                _quoteOptionItemMap.has(
                  quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                    .Quote_Option_Item__c
                )
              )
                _existingProduct.push(
                  _quoteOptionItemMap.get(
                    quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
                      .Quote_Option_Item__c
                  )
                );
              _quoteOptionLocationMap.set(_locationId, _existingProduct);
            }
          }
          this.productsOption.push(this.productsStr);
          //Started populating Quote request locations
          var listOfLocation =
            quoteOptionLocationProdctwrapper.quoteLocationList;
            console.log('Test21');
          this.populateLocationData(quoteOptionLocationProdctwrapper, rateIndx);
          console.log('Test23');
          this.isLocationTableVisible = !this.isLocationTableVisible;
        } catch (error) {
          console.log("error while processing quote request data: ", error);
        }
      })
      .catch((error) => {
        this.errorMsg = error;
      });
  }
  populateLocationData(quoteOptionLocationProdctwrapper, rateIndx) {
    var listOfLocation = quoteOptionLocationProdctwrapper.quoteLocationList;
    this.data = [];
    var selectedLocationsForQuoteOption = [];
    for (
      let i = 0;
      i < quoteOptionLocationProdctwrapper.quoteLocationOptions.length;
      i++
    ) {
      if (
        this.selectedQuoteOptionId ==
        quoteOptionLocationProdctwrapper.quoteLocationOptions[i].Quote_Option__c
      ) {
        selectedLocationsForQuoteOption.push(
          quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
            .Quote_Request_Location__c
        );
      }
    }
    console.log('Test24');
    for (let i = 0; i < listOfLocation.length; i++) {
      let backUpData;
      if (this._backUpData) {
        backUpData = this._backUpData.find(
          (item) => item.Id == listOfLocation[i].Id
        );
      }

      if (
        selectedLocationsForQuoteOption &&
        selectedLocationsForQuoteOption.indexOf(listOfLocation[i].Id) > -1
      ) {
        this.data.push({
          isChecked: false,
          isDisabled:
            this.quoteRequestStatus &&
            this.quoteRequestStatus == "Pending Rate Request" &&
            (this.getActivation(
              this._quoteOptionStructureMap
                .get(this.selectedQuoteOptionId)
                .get(listOfLocation[i].Id)
            ) == "" ||
              this.getMRCPrice(
                this._quoteOptionStructureMap
                  .get(this.selectedQuoteOptionId)
                  .get(listOfLocation[i].Id)
              ) == "")
              ? true
              : false,
          selected: true,
          Id: listOfLocation[i].Id,
          groupName: listOfLocation[i].Group_Name__c,
          address: listOfLocation[i].Address__c,
          city: listOfLocation[i].City__c,
          state: listOfLocation[i].State__c,
          zip: listOfLocation[i].Zip__c,
          npanxx: listOfLocation[i].Telephone_Number__c,
          products: this.getProductNamesString(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          address: listOfLocation[i].Address__c,
          buildingApt: listOfLocation[i].BuildingApt__c,
          floorSuite: listOfLocation[i].FloorSuite__c,
          glcCode: listOfLocation[i].GL_Code__c,
          locationStoreNum: listOfLocation[i].LocationStore_Number__c,
          units: listOfLocation[i].Unit__c,
          activation: this.getActivation(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          mrcprice: this.getMRCPrice(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          activationEditCheck: false,
          activationIOEnable: "ShowActivationLabel",
          mrcEditCheck: false,
          mrcIOEnable: "ShowMRCLabel",
          onnet: this.getOnNet(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          vendor: this.getVendor(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          action: "",
          isExpand: backUpData ? backUpData.isExpand : false,
          popup: backUpData ? backUpData.popup : "productPopupHide",
          showPopover: backUpData ? true : false,
          productsData: this._quoteOptionStructureMap
            .get(this.selectedQuoteOptionId)
            .get(listOfLocation[i].Id)
        });
      }
    }
    this.allData = this.data;
    console.log('Test26: '+JSON.stringify(this.allData));
    if (rateIndx) {
      this.template
        .querySelector("c-child-expand")
        .renderProducts(this.allData[rateIndx].productsData);
    }
    if (
      this.quoteRequestStatus &&
      (this.quoteRequestStatus == "Pending Pricing" ||
        this.quoteRequestStatus == "Pricing Complete" ||
        this.quoteRequestStatus == "Closed - WON" ||
        this.quoteRequestStatus == "Sent To Customer" ||
        this.quoteRequestStatus == "Cancelled" ||
        this.quoteRequestStatus == "Closed - LOST" ||
        this.quoteRequestStatus == "Under Negotiation" ||
        this.quoteRequestStatus == "Pending Finance Review" ||
        this.quoteRequestStatus == "Pending SE Review")
    ) {
      let disabledData = this.data.filter(function (e) {
        return e.isDisabled === true;
      });
      if (disabledData && disabledData.length == this.data.length) {
        this.disabledAll = true;
      } else {
        this.disabledAll = false;
      }

      this.isSubmittedQuote = true;
      this.isActivationColVisible = true;
      this.isMRCPriceColVisible = true;
      this.isOnNetColVisible = true;
      this.isVendorColVisible = true;
      this.nonmandatoryColVal = "activation,mrcprice,onnet,vendor";
      this.colSelected = this.nonmandatoryColVal;
    } else {
      this.isSubmittedQuote = false;
      this.isActivationColVisible = false;
      this.isMRCPriceColVisible = false;
      this.isOnNetColVisible = true;
      this.isVendorColVisible = true;
      this.nonmandatoryColVal = this.nonmandatoryColVal;
      this.colSelected = this.nonmandatoryColVal;
    }
    if (
      (this.quoteRequestStatus &&
        this.quoteRequestStatus == "Pending Finance Review") ||
      this.quoteRequestStatus == "Pending SE Review"
    ) {
      this.isPendingSpOrSeReview = true;
    } else {
      this.isPendingSpOrSeReview = false;
    }
    console.log("selectedLocationsForQuoteOption", JSON.stringify(this.data));
    //	console.log('selectedLocationsForQuoteOption' , this.data);
    try {
      this.populateFilterOptionValues(this.data);
    } catch (ex) {}
    //Populate location Size
    //	console.log('selectedLocationsForQuoteOptions' + JSON.stringify(this.data));
    this.locationSize = " (" + this.data.length + ")";
  }

  getProductNamesString(prods) {
    let productsSet = [];
    let _prodStr = "";
    if (prods) {
      prods.forEach((elem) => {
        let hasShortName = false;
        for (let [key, value] of this.prodMap) {
          let prodVal = elem.Product__c ? elem.Product__c.toUpperCase() : "";
          if (prodVal && key == prodVal) {
            productsSet.push(value);
            hasShortName = true;
            break;
          }
        }
        if (!hasShortName) {
          productsSet.push(elem.Product__c);
        }
      });
      productsSet.sort();
      _prodStr = "";
      for (let i = 0; i < productsSet.length; i++) {
        if (i == 0) {
          _prodStr = productsSet[i];
        } else if (i < 4) {
          _prodStr = _prodStr + ", " + productsSet[i];
        } else {
          _prodStr = _prodStr + "...";
          break;
        }
      }
    }
    return _prodStr;
  }

  getActivation(prods) {
    let activation = "";
    if (prods) {
      prods.forEach((elem) => {
        activation += elem.Activation__c
          ? activation == ""
            ? elem.Activation__c
            : ", " + elem.Activation__c
          : "";
      });
    }
    return activation;
  }
  getMRCPrice(prods) {
    let mrcprice = "";
    if (prods) {
      prods.forEach((elem) => {
        mrcprice += elem.MRC_Price__c
          ? mrcprice == ""
            ? elem.MRC_Price__c
            : ", " + elem.MRC_Price__c
          : "";
      });
    }
    return mrcprice;
  }
  getOnNet(prods) {
    let onnet = "";
    if (prods) {
      prods.forEach((elem) => {
        onnet += elem.On_Net__c
          ? onnet == ""
            ? elem.On_Net__c
            : ", " + elem.On_Net__c
          : "";
      });
    }
    return onnet;
  }
  getVendor(prods) {
    let vendor = "";
    if (prods) {
      prods.forEach((elem) => {
        vendor += elem.Vendor__c
          ? vendor == ""
            ? elem.Vendor__c
            : ", " + elem.Vendor__c
          : "";
      });
    }
    return vendor;
  }
  handleEditLocation(event) {
    let selectedLocations = [];
    let selectedData = this.data[event.target.dataset.recordId];
    selectedLocations.push(selectedData);
    //	console.log('>>>locationsdata>>', selectedLocations);
    this.redirectToProductAdd(selectedLocations);
  }
  async handleRedirectProductEvent() {
    let locIDs = [];
    let emptyList = true;

    let sLocations = [];
    if (this.selectedLocations && this.selectedLocations.length > 0) {
      //Add product validator
      this.selectedLocations.forEach((item) => {
        if (item.isChecked) {
          locIDs.push(item.Id);
        }
      });
      sLocations = this.selectedLocations;
      emptyList = !locIDs.length > 0;
    } else {
      sLocations = this.getTransfromedData();
      this.tempSelectedLocations = sLocations;
      if (sLocations && sLocations.length > 0) {
        //Add product validator
        sLocations.forEach((item) => {
          locIDs.push(item.Id);
        });
      }
    }

    sLocations = locIDs.length > 0 ? sLocations : this.allData;
    if (sLocations && sLocations.length > 0) {
      this.getHasSameProductsCheck(locIDs, sLocations, emptyList);
    } else {
      this.showNoProductsError = true;
    }
  }

  handleFilterLocationsData(event) {
    this.filteredQRLocations = event.detail.filteredQRLocations;
  }

  getTransfromedData() {
    let sLocations = [];
    this.filteredQRLocations.forEach((location) => {
      let record = {};
      record.Id = location.Id;
      record.address = location.Address__c;
      record.city = location.City__c;
      record.state = location.State__c;
      record.zip = location.Zip__c;
      record.glcCode = location.GL_Code__c;
      record.groupName = location.Group_Name__c;
      record.isChecked = false;
      record.isDisabled = false;
      record.showProducts = location.showProducts;
      record.products = location.productsString;
      record.productsData = location.products;
      record.popup = "productPopupShow";

      sLocations.push(record);
    });

    return sLocations;
  }

  async getHasSameProductsCheck(locIDs, selectedLocations, emptyList) {
    this.emptyFlag = emptyList;
    await getLocationsAndRelatedProdDataForSelectedLocs({ locIds: locIDs })
      .then((result) => {
        if (result) {
          const addProductcheck = result.every((val, i, arr) => val === arr[0]);

          if (addProductcheck) {
            this.redirectToProductAdd(selectedLocations, emptyList);
          } else {
            this.locationIDs = locIDs;
            this.OpenLocProdValidator = true;
          }
        }
      })
      .catch((error) => {
        this.errorMsg = error;
      });
  }

  proceedToAddProduct() {
    if (this.selectedLocations && this.selectedLocations.length > 0) {
      this.redirectToProductAdd(this.selectedLocations);
    } else {
      this.redirectToProductAdd(this.tempSelectedLocations);
    }

    this.OpenLocProdValidator = false;
  }
  closeLpValidator() {
    this.OpenLocProdValidator = false;
  }

  //Ended Fetch Quote Option
  //Handle Add Product Screen Redirection
  redirectToProductAdd(selectedLocations, emptyList) {
    emptyList = this.emptyFlag;
    this.locations = [];

    selectedLocations.forEach((elem) => this.locations.push(elem.Id));
    if (!emptyList) {
      if (selectedLocations.length > 0) {
        this.openModalTabName = "AddProduct";

        this.selectedLocations = selectedLocations;

        if (selectedLocations.length == 1) {
          this._hideTabs = true;
          this.subHeader = `${selectedLocations[0].address} ${selectedLocations[0].city} ${selectedLocations[0].state} ${selectedLocations[0].zip}`;
        }
      }
    } else {
      this.openModalTabName = "AddQRLocation";
    }

    this.openAddProduct = true;
    this.closeAllPopups();
  }
  //Handle Add Locations screen redirection
  redirectToAddLocations() {
    this.showAddlocationModal = true;
    this.isImport = true;
  }
  closeLocationModal(event) {
    this.showAddlocationModal = false;
  }
  closeAllPopups(closeQo) {
    //Close Location Popups
    for (let i = 0; i < this.data.length; i++) {
      this.data[i].popup = "productPopupHide";
    }
    //Close Quote Popups
    if (closeQo != null) {
      console.log("sindhu close qo call");
      for (let i = 0; i < this.quoteOptionList.length; i++) {
        this.quoteOptionList[i].popup = "renameDeleteHide";
      }
    }

    this.exportPopup = "popuphide";
    console.log("close all popup");
    //this.updateChild();
  }

  openSingleLocationProducts(event) {
    this.selectedLocation = event.detail.clickedLocation;
    this.closeAllPopups();
    this.locationsAndProductsView = false;
    this.isSingleLocationProductsView = true;
    this.showhideSummaryTab();
  }

  showhideSummaryTab() {
    this.dispatchEvent(
      new CustomEvent("singlelocationproductsview", {
        detail: {
          isSingleLocationProductsView: this.isSingleLocationProductsView
        }
      })
    );
  }

  deleteItems(event) {
    this.deleteModalMessage =
      "You are about to delete this location from " + this.selectedQuoteOption;
    this.openDeleteAllPopup = true;
    this.singleLocationDelete = true;
    this.recordIdToDelete = event.target.dataset.recordId;
    this.closeAllPopups();
  }
  deleteQuoteOptionPopup(event) {
    this.deleteModalMessage =
      "You are about to delete " + this.selectedQuoteOption;
    this.confirmDelete = true;
    this.recordIdToDelete = event.detail;
    this.deleteModalHeader = "Delete Quote Option";
    this.isRename = false;
    this.popupButtonPositive = "YES";
    this.popupButtonNegative = "NO";
    this.closeAllPopups();
    this.updateChild();
  }

  closeModalPopup() {
    this.confirmDelete = false;
    this.showNoProductsError = false;
    //	console.log('Inside close modal' + this.confirmDelete);
  }

  deleteEvent() {
    if (this.deleteModalHeader == "Rename Quote Option") {
      this.renameQuoteOption();
    } else if (this.deleteModalHeader == "Delete Quote Option") {
      if (this.quoteOptionList.length > 1) {
        console.log("Delete quote Option");
        this.deleteQuoteOption();
      } else {
        this.closeModalPopup();
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Error",
            message: "Atleast 1 quote Option Should be present",
            variant: "error"
          })
        );
      }
    } else {
      this.deleteLocation();
    }
  }
  deleteLocation() {
    var deleteId = this.recordIdToDelete;
    //	console.log('Inside delete location' + deleteId);
    deleteRecord(deleteId)
      .then(() => {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Success",
            message: "Location deleted successfully",
            variant: "success"
          })
        );
        this.closeModalPopup();
        // To delete the record from UI
        for (let item in this.data) {
          if (this.data[item].Id == deleteId) {
            this.data.splice(item, 1);
            break;
          }
        }
        //populate location size after deleting
        this.locationSize = " (" + this.data.length + ")";
      })
      .catch((error) => {
        console.log(error);
      });
    this.updateChild();
  }
  deleteQuoteOption() {
    var deleteId = this.recordIdToDelete;
    deleteQuoteOptionFromQuote({ recordId: deleteId })
      .then((result) => {
        this.dispatchEvent(
          new ShowToastEvent({
            title: "Success",
            message: "Quote Option deleted successfully",
            variant: "success"
          })
        );

        this.closeModalPopup();
        // To delete the record from UI
        for (let item in this.quoteOptionList) {
          if (this.quoteOptionList[item].Id == deleteId) {
            this.quoteOptionList.splice(item, 1);
            break;
          }
        }
        this.selectQuoteOption({
          detail: this.quoteOptionList[0].Id
        });
        this.fetchQuoteRequestData();
        this.notifyChanges();
      })
      .catch((error) => {
        console.log(error);
      });
  }

  closeAddProductModal() {
    this.openAddProduct = false;
    this._hideTabs = false;
    this.subHeader = undefined;
    if (this.isByProduct) {
      this.template
        .querySelector("c-by-product-view-component")
        .displayQuotesInProductView(this.selectedQuoteOptionId);
    }
    this.locationsAndProductsView = true;
    this.isSingleLocationProductsView = false;
    this.selectedLocations = [];
    this.showhideSummaryTab();

    this.closeAllPopups();
  }

  saveAddProductData() {
    this.openAddProduct = false;
    this._hideTabs = false;
    this.subHeader = undefined;
    if (this.isByProduct) {
      this.template
        .querySelector("c-by-product-view-component")
        .displayQuotesInProductView(this.selectedQuoteOptionId);
    }
    this.locationsAndProductsView = true;
    this.isSingleLocationProductsView = false;
    this.showAddlocationModal = false;
    this.selectedLocations = [];
    this.showhideSummaryTab();
    this.fetchQuoteRequestData();
    this.closeAllPopups();
    this.notifyChanges();
  }

  notifyChanges() {
    // to close modal set isModalOpen tarck value as false
    const custEvent = new CustomEvent("productdatachange", {});
    this.dispatchEvent(custEvent);
  }

  //rename quoteOption
  handleRenameQuoteOption(event) {
    this.idToRenameQuoteOption = event.detail;
    this.isRename = true;
    this.quoteOptionToRename = this.selectedQuoteOption;
    this.popupButtonPositive = "Rename";
    this.popupButtonNegative = "Cancel";
    this.deleteModalMessage = "";
    this.deleteModalHeader = "Rename Quote Option";
    this.confirmDelete = true;
    this.closeAllPopups();
  }
  onQuoteOptionChange(event) {
    this.quoteOptionToRename = event.target.value;
  }
  renameQuoteOption() {
    for (let i = 0; i < this.quoteOptionList.length; i++) {
      if (this.quoteOptionList[i].Id == this.idToRenameQuoteOption) {
        this.quoteOptionList[i].name = this.quoteOptionToRename;
      }
    }
    this.selectedQuoteOptionId = this.idToRenameQuoteOption;
    this.selectedQuoteOption = this.quoteOptionToRename;
    //this.isLocationTableVisible = !this.isLocationTableVisible;
    this.renameQuoteOptionApexHandle();
    this.closeModalPopup();
  }

  renameQuoteOptionApexHandle() {
    var qOList = [];
    for (let i = 0; i < this.quoteOptionList.length; i++) {
      qOList.push({
        Id: this.quoteOptionList[i].Id,
        Name: this.quoteOptionList[i].name
      });
    }
    renameQuoteOptionApex({ listOfQo: qOList })
      .then((result) => {
        this.quoteRequest = result;
        this.showSpinner = false;

        this.dispatchEvent(
          new ShowToastEvent({
            title: "Success",
            message: "Quote Option Renamed",
            variant: "Success"
          })
        );
      })
      .catch((error) => {
        this.errorMsg = error;
        this.showSpinner = false;
      });
    this.updateChild();
  }

  //method to filter using group name
  filterGroupName(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "group");
    }
    //	console.log('selectedValue ' + selectedValue);
  }
  filterLocationName(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "location");
    }
    //	console.log('selectedValue ' + selectedValue);
  }
  filterCity(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "city");
    }
    //	console.log('selectedValue ' + selectedValue);
  }
  filterState(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "state");
    }
    //	console.log('selectedValue ' + selectedValue);
  }
  filterZip(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "zip");
    }
    //	console.log('selectedValue ' + selectedValue);
  }
  filterNPA(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "npanxx");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterProducts(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "products");
    }
    console.log("selectedValue " + selectedValue);
  }
  filteraddress(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "address");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterbuildingApt(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "buildingApt");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterfloorSuite(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "floorSuite");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterglcCode(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "glcCode");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterlocationStoreNum(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "locationStoreNum");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterunits(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "units");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterOnNet(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "onnet");
    }
    console.log("selectedValue " + selectedValue);
  }

  filterVendor(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "Vendor");
    }
    console.log("selectedValue " + selectedValue);
  }
  filterActivation(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "activation");
    }
    console.log("selectedValue " + selectedValue);
  }

  filterMRCPrice(event) {
    var selectedValue = event.detail;
    if (selectedValue.indexOf("All") > -1) {
      this.allData = this.data;
      this.populateFilterOptionValues(this.allData);
      this.callChildMethodToResetEditText();
    } else {
      this.filterData(selectedValue, "mrcprice");
    }
    console.log("selectedValue " + selectedValue);
  }

  filterData(selectedValue, fieldName) {
    this.allData = [];
    if (fieldName == "group") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].groupName == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "location") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].address == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "city") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].city == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "state") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].state == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "zip") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].zip == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "npanxx") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].npanxx == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "products") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].products == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "address") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].address == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "buildingApt") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].buildingApt == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "floorSuite") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].floorSuite == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "glcCode") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].glcCode == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "locationStoreNum") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].locationStoreNum == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "units") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].locationStoreNum == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "activation") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].activation == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "mrcprice") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].mrcprice == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else if (fieldName == "onnet") {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].onnet == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    } else {
      for (let i = 0; i < this.data.length; i++) {
        if (this.data[i].vendor == selectedValue) {
          this.allData.push(this.data[i]);
        }
      }
    }

    this.populateFilterOptionValues(this.allData);
  }

  //dynamic filter related values
  populateFilterOptionValues(locationData) {
    // Group Name
    var arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.groupName;
          }
        })
      )
    ];
    this.groupNameOption = ["All Groups"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.groupNameOption.push(arraycheck[item]);
      }
    }

    // Location Name
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.address;
          }
        })
      )
    ];
    this.locationNameOption = ["All Locations"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.locationNameOption.push(arraycheck[item]);
      }
    }

    //city
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.city;
          }
        })
      )
    ];
    this.cityOption = ["All Cities"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.cityOption.push(arraycheck[item]);
      }
    }

    //State
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.state;
          }
        })
      )
    ];
    this.stateOption = ["All States"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.stateOption.push(arraycheck[item]);
      }
    }

    //zip
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.zip;
          }
        })
      )
    ];
    this.zipOption = ["All Zip Codes"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.zipOption.push(arraycheck[item]);
      }
    }

    //npaOption
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.npanxx;
          }
        })
      )
    ];
    this.nPAOption = ["All NPA?NXX"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.nPAOption.push(arraycheck[item]);
      }
    }
    ///Start - Added for US Customize.

    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.address;
          }
        })
      )
    ];
    this.addressOption = ["All Address"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.addressOption.push(arraycheck[item]);
      }
    }

    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.buildingApt;
          }
        })
      )
    ];
    this.buildingAptOption = ["All Building/Apt"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.buildingAptOption.push(arraycheck[item]);
      }
    }

    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.floorSuite;
          }
        })
      )
    ];
    this.floorSuiteOption = ["All Floor/Suite"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.floorSuiteOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.glcCode;
          }
        })
      )
    ];
    this.glcCodeOption = ["All Floor/Suite"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.glcCodeOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.locationStoreNum;
          }
        })
      )
    ];
    this.locationStoreNumOption = ["All Location/Store Number"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.locationStoreNumOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.units;
          }
        })
      )
    ];
    this.unitsOption = ["All Units"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.unitsOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.activation;
          }
        })
      )
    ];
    this.activationOption = ["Activation"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.activationOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.mrcprice;
          }
        })
      )
    ];
    this.mrcpriceOption = ["MRC(G,$)"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.mrcpriceOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.onnet;
          }
        })
      )
    ];
    this.onnetOption = ["On-Net"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.onnetOption.push(arraycheck[item]);
      }
    }
    arraycheck = [
      ...new Set(
        locationData.map((x) => {
          if (x.selected) {
            return x.vendor;
          }
        })
      )
    ];
    this.vendorOption = ["On-Net"];
    for (let item in arraycheck) {
      if (arraycheck[item] != "" && arraycheck[item] != undefined) {
        this.vendorOption.push(arraycheck[item]);
      }
    }
    ///End - Added for US Customize.
  }
  callChildMethodToResetEditText() {
    var autoComp = this.template.querySelectorAll("c-auto-complete-text");
    for (let i = 0; i < autoComp.length; i++) {
      autoComp[i].reserFilterColumns();
    }
  }

  ///Start - Added for US Customize.
  fetchSelColumns = [];

  isColVisible = false;
  isStateColVisible = false;
  isGroupNameColVisible = false;
  isLocationNameColVisible = false;
  isNpanxxColVisible = false;
  isBuildingAptColVisible = false;
  isFloorSuiteColVisible = false;
  isGLCodeColVisible = false;
  isLocStoreColVisible = false;
  isActivationColVisible = false;
  isMRCPriceColVisible = false;
  isOnNetColVisible = false;
  isVendorColVisible = false;
  mandatoryColVal = ["address", "city", "state", "zip", "products", "units"];
  nonmandatoryColVal = [];
  colSelected;

  get requiredOptions() {
    return [
      { label: "Address", value: "address" },
      { label: "City", value: "city" },
      { label: "State", value: "state" },
      { label: "Zip", value: "zip" },
      { label: "Products", value: "products" },
      { label: "Unit", value: "units" },
      { label: "Activation", value: "activation" },
      { label: "MRC(G,$)", value: "mrcprice" },
      { label: "On-Net", value: "onnet" },
      { label: "Vendor", value: "vendor" }
    ];
  }

  get requiredOptionsWithoutPricing() {
    return [
      { label: "Address", value: "address" },
      { label: "City", value: "city" },
      { label: "State", value: "state" },
      { label: "Zip", value: "zip" },
      { label: "Products", value: "products" },
      { label: "Unit", value: "units" }
    ];
  }

  get nonReqOptions() {
    return [
      { label: "Group Name", value: "groupname" },
      { label: "Location Name", value: "locationname" },
      { label: "Building/Apt", value: "buildingApt" },
      { label: "Floor/Suite", value: "floorSuite" },
      { label: "NPA/NXX", value: "npanxx" },
      { label: "GL Code", value: "glcCode" },
      { label: "Location/Store Number", value: "locationStoreNum" }
    ];
  }

  get nonReqOptionsWithPricing() {
    return [
      { label: "Group Name", value: "groupname" },
      { label: "Location Name", value: "locationname" },
      { label: "Building/Apt", value: "buildingApt" },
      { label: "Floor/Suite", value: "floorSuite" },
      { label: "NPA/NXX", value: "npanxx" },
      { label: "GL Code", value: "glcCode" },
      { label: "Location/Store Number", value: "locationStoreNum" },
      { label: "Activation", value: "activation" },
      { label: "MRC(G,$)", value: "mrcprice" },
      { label: "On-Net", value: "onnet" },
      { label: "Vendor", value: "vendor" }
    ];
  }

  get selectedValues() {
    return this.nonmandatoryColVal.join(",");
  }

  handleChange(e) {
    this.openCustomizeColumns = true;
    this.nonmandatoryColVal = e.detail.value;
    this.colSelected = this.nonmandatoryColVal;
    //	console.log('Checkbox' + this.colSelected);
  }
  //not being used - for tesing only
  handleColumnListChangeEvent(e) {
    this.fetchSelColumns = e.detail;
    //console.log('fetchColumns'+this.fetchSelColumns);
    for (let rec of this.columns) {
      var jsonString = JSON.parse(JSON.stringify(rec));
      //console.log('JsonValue' +jsonString.value);
      if (this.fetchSelColumns.indexOf(jsonString.value) != -1) {
        rec.isAddress = true;
      }
    }
    for (let rec of this.columns) {
      //	console.log('Rec2 is ' + JSON.stringify(rec));
      var jsonString = JSON.parse(JSON.stringify(rec));
    }
  }
  saveColumns(event) {
    this.isGroupNameColVisible = false;
    this.isLocationNameColVisible = false;
    this.isNpanxxColVisible = false;
    this.isBuildingAptColVisible = false;
    this.isFloorSuiteColVisible = false;
    this.isGLCodeColVisible = false;
    this.isLocStoreColVisible = false;
    this.isActivationColVisible = false;
    this.isMRCPriceColVisible = false;
    this.isOnNetColVisible = false;
    this.isVendorColVisible = false;
    var lstisColVisible = [];
    var custColListStore = this.mandatoryColVal;
    if (this.nonmandatoryColVal != "") {
      custColListStore = custColListStore + "," + this.nonmandatoryColVal;
    }

    //console.log(this.mandatoryColVal+','+this.nonmandatoryColVal);
    localStorage.setItem("CustListKey", custColListStore);
    const selectedEvent = new CustomEvent("saveColumns", {
      detail: custColListStore
    });
    //	console.log('Split' + custColListStore);

    lstisColVisible = custColListStore.toString().split(",");
    for (let i = 0; i < lstisColVisible.length; i++) {
      if (lstisColVisible[i] == "groupname") {
        this.isGroupNameColVisible = true;
      }

      if (lstisColVisible[i] == "locationname") {
        this.isLocationNameColVisible = true;
      }

      if (lstisColVisible[i] == "buildingApt") {
        this.isBuildingAptColVisible = true;
      }

      if (lstisColVisible[i] == "floorSuite") {
        this.isFloorSuiteColVisible = true;
      }

      if (lstisColVisible[i] == "glcCode") {
        this.isGLCodeColVisible = true;
      }

      if (lstisColVisible[i] == "locationStoreNum") {
        this.isLocStoreColVisible = true;
      }

      if (lstisColVisible[i] == "npanxx") {
        this.isNpanxxColVisible = true;
      }

      if (lstisColVisible[i] == "activation") {
        this.isActivationColVisible = true;
      }

      if (lstisColVisible[i] == "mrcprice") {
        this.isMRCPriceColVisible = true;
      }

      if (lstisColVisible[i] == "onnet") {
        this.isOnNetColVisible = true;
      }

      if (lstisColVisible[i] == "vendor") {
        this.isVendorColVisible = true;
      }
    }

    /*    let isColVisibileMap = new Map();
																									for(let i=0;i < lstisColVisible.length;i++){    
																										isColVisibileMap.set({"id":i,"name":lstisColVisible[i], "value":true});            
																										console.log('Val'+i+'-'+lstisColVisible[i]);
																										//console.log(isColVisibileMap.name);
																									}
																									*/
    this.openCustomizeColumns = false;
  }

  closeModal() {
    this.openCustomizeColumns = false;
  }

  redirectToCustomizeColumns() {
    if (
      this.quoteRequestStatus &&
      SUBMITTED_QUOTE_STATUSES.indexOf(this.quoteRequestStatus) >= 0
    ) {
      this.isSubmittedQuote = true;
    } else {
      this.isSubmittedQuote = false;
    }
    this.openCustomizeColumns = true;
    //	console.log('openCustomizeColumns');

    // Latest updates
    // let i;
    // let checkboxes = this.template.querySelectorAll('[data-id="checkbox"]')
    // for(i=0; i<checkboxes.length; i++) {
    // checkboxes[i].checked = e.target.checked;
    // console.log('checkbox is checked', checkboxes[i].checked);
    // }

    console.log(
      "checkbox checked",
      this.template.querySelector('[data-id="checkbox"]')
    );
  }

  ///End - Added for US Customize.

  handleExport() {
    console.log("download triggered.");
    try {
      if (this.allData.length == 0) {
        this.allData = [
          {
            isChecked: false,
            address: "test Address",
            city: "test Address",
            state: "test Address",
            zip: "test Address",
            npanxx: "test Address",
            products: "test Address",
            activation: 1200.0,
            mrcprice: 1234.0,
            activationEditCheck: false,
            activationIOEnable: "ShowActivationLabel",
            mrcEditCheck: false,
            mrcIOEnable: "ShowMRCLabel",
            action: "test Address",
            isExpand: false,
            popup: "productPopupHide",
            productsData: [
              {
                pname: "product1",
                ptype: "type"
              },
              {
                pname: "product2",
                ptype: "type2"
              }
            ]
          },
          {
            isChecked: false,
            address: "2 test Address",
            city: "2 test Address",
            state: "2 test Address",
            zip: "2 test Address",
            npanxx: "2 test Address",
            products: "2 test Address",
            activation: 1100.0,
            mrcprice: 1300.0,
            activationEditCheck: false,
            activationIOEnable: "ShowActivationLabel",
            mrcEditCheck: false,
            mrcIOEnable: "ShowMRCLabel",
            action: "2 test Address",
            isExpand: false,
            popup: "productPopupHide",
            productsData: [
              {
                pname: "product1",
                ptype: "type"
              },
              {
                pname: "product2",
                ptype: "type2"
              }
            ]
          }
        ];
      }
      var selectedList = [
        ...new Set(
          this.allData.map((x) => {
            if (x.selected) {
              return x;
            }
          })
        )
      ];
      if (this.isSubmittedQuote) {
        exportCSVFile(
          this.headersforexport,
          selectedList,
          this.selectedQuoteOption
        );
      } else {
        let headers = this.headersforexport;
        delete headers.mrcprice;
        delete headers.activation;
        exportCSVFile(headers, selectedList, this.selectedQuoteOption);
      }
    } catch (ex) {
      console.log("ex " + ex);
    }
  }

  deleteAllEvent(event) {
    let isDeleteFrom = event.detail;
    let ListOfId = [];
    let deleteAllLocFlag = false;
    if (this.selectedLocations) {
      this.selectedLocations.forEach((location) => {
        ListOfId.push(location.Id);
      });
    }

    if (this.recordIdToDelete != null) {
      ListOfId.push(this.recordIdToDelete);
    }
    //if( this.quoteOptionList.length > 0){
    //	isDeleteFrom = true;
    //}

    this.removeLocFromSelectedFilter(ListOfId);

    if (isDeleteFrom) {
      this.deleteAllLocationApexHandler(ListOfId);
    } else {
      this.deleteAllLocationFromQuoteOptions(ListOfId);
    }
  }

  removeLocFromSelectedFilter(locIdSet) {
    let tempFLocations = [];
    this.filteredQRLocations.forEach((location) => {
      if (!locIdSet.includes(location.Id)) {
        tempFLocations.push(location);
      }
    });

    this.filteredQRLocations = JSON.parse(JSON.stringify(tempFLocations));

    let sTempLocations = [];
    this.selectedLocations.forEach((location) => {
      if (!locIdSet.includes(location.Id)) {
        sTempLocations.push(location);
      }
    });

    this.selectedLocations = JSON.parse(JSON.stringify(sTempLocations));
  }

  deleteAllLocationApexHandler(listOfIds) {
    this.showSpinner = true;
    deleteAllLocation({ listOfLocation: listOfIds })
      .then((result) => {
        const successEvent = new ShowToastEvent({
          title: SUCCESS_TITLE,
          message:
            "Selected locations were deleted from all selected Quote Options",
          variant: SUCCESS_VARIANT
        });
        this.dispatchEvent(successEvent);

        this.hasrendered = true;

        this.selectQuoteOption({ detail: this.selectedQuoteOptionId });

        this.closeDeleteAll();
        this.notifyChanges();
        this.fetchQuoteRequestData();
        publish(this.messageContext, A3QuotingMessageChannel, {
          eventData: { source: "byLocationComponent" },
          eventTitle: "deleteLocation"
        });
        this.showSpinner = false;
      })
      .catch((error) => {
        console.log(
          "deleteAllLocationApexHandler error: " + JSON.stringify(error)
        );
        const errorEvent = new ShowToastEvent({
          title: ERROR_TITLE,
          message: GENERIC_ERROR_MSG,
          variant: ERROR_VARIANT
        });
        this.dispatchEvent(errorEvent);
        this.showSpinner = false;
      });
  }

  deleteAllLocationFromQuoteOptions(listOfIds) {
    this.showSpinner = true;
    deleteRecordsFromQuoteOption({
      listOfLocation: listOfIds,
      recordId: this.selectedQuoteOptionId
    })
      .then((result) => {
        const successEvent = new ShowToastEvent({
          title: SUCCESS_TITLE,
          message: "Selected locations were deleted",
          variant: SUCCESS_VARIANT
        });
        this.dispatchEvent(successEvent);

        this.hasrendered = true;

        this.selectQuoteOption({ detail: this.selectedQuoteOptionId });

        this.closeDeleteAll();
        this.notifyChanges();
        this.fetchQuoteRequestData();
        publish(this.messageContext, A3QuotingMessageChannel, {
          eventData: { source: "byLocationComponent" },
          eventTitle: "deleteLocation"
        });
        this.showSpinner = false;
      })
      .catch((error) => {
        console.log(
          "deleteAllLocationApexHandler error: " + JSON.stringify(error)
        );
        const errorEvent = new ShowToastEvent({
          title: ERROR_TITLE,
          message: GENERIC_ERROR_MSG,
          variant: ERROR_VARIANT
        });
        this.dispatchEvent(errorEvent);
        this.showSpinner = false;
      });
  }

  populateLocationProductsOnQuoteOptionChange(
    quoteOptionLocationProdctwrapper,
    isQuoteChecked,
    qoName
  ) {
    this.data = [];
    var selectedLocationsForQuoteOption = [];
    for (
      let i = 0;
      i < quoteOptionLocationProdctwrapper.quoteLocationOptions.length;
      i++
    ) {
      if (
        this.selectedQuoteOptionId ==
        quoteOptionLocationProdctwrapper.quoteLocationOptions[i].Quote_Option__c
      ) {
        selectedLocationsForQuoteOption.push(
          quoteOptionLocationProdctwrapper.quoteLocationOptions[i]
            .Quote_Request_Location__c
        );
      }
    }
    this.updateChild();
    //Started populating Products with Quote Option
    this.productsStr = "";
    let productsSet = [];
    this.productDetail = [];
    this.productsOption = ["All Products"];
    this.listOfAllProductWithQuoteOption =
      quoteOptionLocationProdctwrapper.quoteProductList;
    for (let i = 0; i < this.listOfAllProductWithQuoteOption.length; i++) {
      if (
        this.listOfAllProductWithQuoteOption[i].Quote_Option__c ==
        this.selectedQuoteOptionId
      ) {
        this.productDetail.push(this.listOfAllProductWithQuoteOption[i]);
        if (this.productsStr == "") {
          this.productsStr = this.listOfAllProductWithQuoteOption[i].Name;
        } else {
          this.productsStr =
            this.productsStr +
            ", " +
            this.listOfAllProductWithQuoteOption[i].Name;
        }
        productsSet.push(this.listOfAllProductWithQuoteOption[i]);
      }
    }

    productsSet.sort();
    this.productsStr = productsSet ? productsSet.join() : this.productsStr;
    this.productsOption.push(this.productsStr);
    //Started populating Quote request locations
    var listOfLocation = quoteOptionLocationProdctwrapper.quoteLocationList;
    for (let i = 0; i < listOfLocation.length; i++) {
      let backUpData;
      if (this._backUpData) {
        backUpData = this._backUpData.find(
          (item) => item.Id == listOfLocation[i].Id
        );
      }
      if (selectedLocationsForQuoteOption.indexOf(listOfLocation[i].Id) > -1) {
        this.data.push({
          isChecked: backUpData ? backUpData.isChecked : false,
          isDisabled:
            this.quoteRequestStatus &&
            this.quoteRequestStatus == "Pending Rate Request" &&
            (this.getActivation(
              this._quoteOptionStructureMap
                .get(this.selectedQuoteOptionId)
                .get(listOfLocation[i].Id)
            ) == "" ||
              this.getMRCPrice(
                this._quoteOptionStructureMap
                  .get(this.selectedQuoteOptionId)
                  .get(listOfLocation[i].Id)
              ) == "")
              ? true
              : false,
          selected:
            selectedLocationsForQuoteOption.indexOf(listOfLocation[i].Id) > -1
              ? true
              : false,
          Id: listOfLocation[i].Id,
          groupName: listOfLocation[i].Group_Name__c,
          address: listOfLocation[i].Address__c,
          city: listOfLocation[i].City__c,
          state: listOfLocation[i].State__c,
          zip: listOfLocation[i].Zip__c,
          npanxx: listOfLocation[i].Telephone_Number__c,
          products: this.getProductNamesString(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          address: listOfLocation[i].Address__c,
          buildingApt: listOfLocation[i].BuildingApt__c,
          floorSuite: listOfLocation[i].FloorSuite__c,
          glcCode: listOfLocation[i].GL_Code__c,
          locationStoreNum: listOfLocation[i].LocationStore_Number__c,
          units: listOfLocation[i].Unit__c,
          activation: this.getActivation(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          mrcprice: this.getMRCPrice(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          activationEditCheck: false,
          activationIOEnable: "ShowActivationLabel",
          mrcEditCheck: false,
          mrcIOEnable: "ShowMRCLabel",
          onnet: this.getOnNet(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          vendor: this.getVendor(
            this._quoteOptionStructureMap
              .get(this.selectedQuoteOptionId)
              .get(listOfLocation[i].Id)
          ),
          action: "",
          isExpand: backUpData ? backUpData.isExpand : false,
          popup: backUpData ? backUpData.popup : "productPopupHide",
          productsData: this.productDetail
        });
      }
    }
    this.allData = this.data;

    if (
      this.quoteRequestStatus &&
      SUBMITTED_QUOTE_STATUSES.indexOf(this.quoteRequestStatus) >= 0
    ) {
      let disabledData = this.data.filter(function (e) {
        return e.isDisabled === true;
      });
      if (disabledData && disabledData.length == this.data.length) {
        this.disabledAll = true;
      } else {
        this.disabledAll = false;
      }

      this.isSubmittedQuote = true;
      this.isActivationColVisible = true;
      this.isMRCPriceColVisible = true;
      this.isOnNetColVisible = true;
      this.isVendorColVisible = true;
      this.nonmandatoryColVal = "activation,mrcprice,onnet,vendor";
      this.colSelected = this.nonmandatoryColVal;
    } else {
      this.isSubmittedQuote = false;
      this.isActivationColVisible = false;
      this.isMRCPriceColVisible = false;
      this.isOnNetColVisible = false;
      this.isVendorColVisible = false;
      this.nonmandatoryColVal = this.nonmandatoryColVal;
      this.colSelected = this.nonmandatoryColVal;
    }
    //	console.log('selectedLocationsForQuoteOption' + JSON.stringify(this.data));

    try {
      this.populateFilterOptionValues(this.data);
    } catch (ex) {}
    if (isQuoteChecked) {
      let tempData = this.data;
      this.xlsFormatter(tempData, qoName);
    }
    //Populate location Size
    this.locationSize = " (" + this.data.length + ")";
  }

  handleProductEditView(event) {
    this.selectedLocations = event.detail.selectedLocations;
    let selectedLocs = event.detail.selectedLocations;
    selectedLocs.forEach((itemSelectedLoc) => {
      this.allData.find((o, i) => {
        if (o.Id === itemSelectedLoc.locKey) {
          this.allData[i].isChecked = true;
        }
      });
    });
    //this.openModalTabName = 'AddProduct';
    this.openAddProduct = false;
    this.proceedToAddProduct();
  }

  handleDeleteProductOnView() {
    this.fetchQuoteRequestData();
    // eval("$A.get('e.force:refreshView').fire();");
  }
  editActivationPrice(event) {
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    if (label == "ShowActivationLabel") {
      this.allData[itemIndex].activationIOEnable = "HideActivationLabel";
      this.allData[itemIndex].activationEditCheck = true;
    } else if (label == "HideActivationLabel") {
      this.allData[itemIndex].activationIOEnable = "ShowActivationLabel";
      this.allData[itemIndex].activationEditCheck = false;
    }
  }
  saveActivationInput(event) {
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    if (label == "ShowActivationLabel") {
      this.allData[itemIndex].activationIOEnable = "HideActivationLabel";
      this.allData[itemIndex].activationEditCheck = true;
    } else if (label == "HideActivationLabel") {
      this.allData[itemIndex].activationIOEnable = "ShowActivationLabel";
      this.allData[itemIndex].activationEditCheck = false;
    }
  }
  editMRCPrice(event) {
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    if (label == "ShowMRCLabel") {
      this.allData[itemIndex].mrcIOEnable = "HideMRCLabel";
      this.allData[itemIndex].mrcEditCheck = true;
    } else if (label == "HideMRCLabel") {
      this.allData[itemIndex].mrcIOEnable = "ShowMRCLabel";
      this.allData[itemIndex].mrcEditCheck = false;
    }
  }
  saveMRCInput(event) {
    const itemIndex = event.currentTarget.dataset.index;
    let label = event.target.name;
    if (label == "ShowMRCLabel") {
      this.allData[itemIndex].mrcIOEnable = "HideMRCLabel";
      this.allData[itemIndex].mrcEditCheck = true;
    } else if (label == "HideMRCLabel") {
      this.allData[itemIndex].mrcIOEnable = "ShowMRCLabel";
      this.allData[itemIndex].mrcEditCheck = false;
    }
  }

  handlenqrrefresh(){
    this.handleUpdateLocation();
  }
  handleeleclocationsandprod(event) {
    const selectedGUIIds = event.detail.selectedGUIIds;
    this.dispatchEvent(
      new CustomEvent("seleclocationsandprod", {
        detail: {
        locandprod: event.detail.locandprod ,selectedGUIIds : selectedGUIIds
        }
      })
    );
  }
  // getSurchargeUpdate(event){
  //   this.surchargeCheckValue = event.detail;
  //   console.log('surcharge locations and products : ',this.surchargeCheckValue);
  //   const surchargeEventToSummary = new CustomEvent("surchargeeventtosummary", {
  //               detail: this.surchargeCheckValue
  //           });
  //           // Dispatches the event
  //           this.dispatchEvent(surchargeEventToSummary);
  // }
}