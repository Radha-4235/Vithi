import checkPermission from "@salesforce/apex/AddEquipmentController.checkPermission";
import fetchQuoteRequestRelatedData from "@salesforce/apex/NewQuoteRequestHandler.quoteRequestRelatedData";
import deleteRecordsWithId from "@salesforce/apex/QuoteOptionsController.deleteRecordsWithIDs";
import deleteQuoteProduct from "@salesforce/apex/QuoteOptionsController.deleteQuoteProduct";
import deleteChildRecordsWithId from "@salesforce/apex/QuoteOptionsController.deleteChildRecordsWithIds";
import saveQuoteOptionsData from "@salesforce/apex/QuoteOptionsController.saveQuoteOptionsData";
import QUOTE_REQUEST_OBJECT from "@salesforce/schema/Quote_Request_2__c";
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { deleteRecord } from
 "lightning/uiRecordApi";
import { api, LightningElement, track, wire } from "lwc";
import saveNoteCall from "@salesforce/apex/NotesHandler.saveNotes";
const FINANCELIST=['SplPricing','SalesEng','OMAnalyst','OMAnalystManager','SplPricingManager','ChannelsQuoter','SalesEngManager'];
import Telephone_Number__c from "@salesforce/schema/Quote_Request_Location_2__c.Telephone_Number__c";
const DELETE_PRODUCT_ERROR_MSG =
  "You are tyring to delete the last product in the Quote Option {0}. A quote option should have at least one product.";
export default class AddProduct extends LightningElement {
  @track qoMap = new Map();
  @api openModal = false;
  @api openLocationsModal = false;
  @track telephonePopup = false;
  @track telephoneNumberMissing = false;
  _deleteChildProdIds = [];
  @api recordId;
  @api quoteRequest;
  @api subHeader;
  @api addProductContext;
  @api newUploadedLocations;
  @api docIdList;
  @api hideTabs = false;
  @api quoteOptionDataWrapper;
  @track prdFamilyNxtValue = "";
  @track prdFamilyValue = "";
  @track qoIndex;
  @track isSelected = false;
  @track productValue = "Select a Product";
  @track showLoading;
  @track quoteOptionKey = 1;
  @track quoteOptionName = "Quote Option";
  @track quoteOptionList1 = [];
  @track productVariant = "brand";
  @track applyToAllCheck = false;
  @track applyToAllConftn = false;
  @track showAllLocCheckpopup = false;
  @track fromCopyProducts = false;
  @track selectedProductFromDropdown;
  @track displayaddequipmentlink = false;
  @track fullProdInfo = [];
  @track prodNxtArray = [];
  @api selectedLocations = [];
  _selectedLocations = [];
  @track surchargeCheck = true;
  @track taxesCheck = false;
  activeSections = [];
  activeSectionsEQ = [];
  _quoteOptionItemToProducts = new Map();
  @track isDisabledSave = true;
  @track isShowEquipmentdata = false;
  @track isDisabledEquipment = false;
  @track equipmentData = [];
  @track resultData = [];
  @track selectedEquipmentMap = new Map();
  @track selectedEquipmentList = [];
  @track isDelete = false;
  @track isRemove = false;
  @track isAddEquipmentPermission = false;
  @track noteContent;
  @track edgebootProdFlag = 'No';
  @track voipPermission = false;
  @api loggedInUser;

  hanldeProductFamilyValueChange(event) {
    this.prdFamilyValue = event.detail.fieldValue;
    console.log(
      "hanldeProductFamilyValueChange ==> " + JSON.stringify(event.detail)
    );
    let quoteKey = event.detail.quotId;
    let productKey = event.detail.prodId;
    let prodArray = this.qoMap.get(quoteKey).productData;
    prodArray.forEach((pItem) => {
      if (pItem.prodID == productKey) {
        pItem.isShowEquipmentdata = false;
        pItem.isDisabledEquipment = false;
        if (
          pItem.prdFamilyValue == "" ||
          typeof pItem.prdFamilyValue == "undefined"
        ) {
          pItem.equipmentData = [];
          pItem.resultData = [];
          pItem.selectedEquipmentMap = new Map();
          pItem.prdFamilyValue = event.detail.fieldValue;
          pItem.selectedEquipmentList = [];
          pItem.isShowEquipmentdata = false;
          pItem.openEquipmentModal = false;
        } else if (pItem.prdFamilyValue != event.detail.fieldValue) {
          pItem.equipmentData = [];
          pItem.resultData = [];
          pItem.selectedEquipmentMap = new Map();
          pItem.prdFamilyValue = event.detail.fieldValue;
          let arraySelected = [];
          pItem.selectedEquipmentList = JSON.parse(
            JSON.stringify(arraySelected)
          );
          pItem.isShowEquipmentdata = true;
          pItem.openEquipmentModal = false;
        }
        if (!pItem.prodRecId) {
          if (pItem.prodFields.length > 1)
            pItem.prodFields.splice(1, pItem.prodFields.length - 1);
          pItem.prodFields.splice(0, 1, {
            prodName: event.detail.fieldName,
            prodValue: event.detail.fieldValue
          });
        } else {
          this.flashProductFieldValues(
            pItem.prodFields,
            [],
            [event.detail.fieldName],
            event.detail.fieldValue
          );
        }
      }
    });
  }

  flashProductFieldValues(prodFields, constValues, fieldsChanged, fieldVal) {
    let constFields = ["Id", "Name", "Quote_Option__c"];
    constFields = constFields.concat(constValues);
    prodFields.forEach((item) => {
      if (constFields.includes(item.prodName)) return;

      item.prodValue = fieldsChanged.includes(item.prodName) ? fieldVal : null;
    });
  }

  applyToAllVal() {
    this.applyToAllCheck = !this.applyToAllCheck;
    this.applyToAllCheck
      ? (this.applyToAllConftn = true)
      : (this.applyToAllConftn = false);
  }

  hanldeProductFamilyNxtValueChange(event) {
    let quoteKey = event.detail.quotId;
    let productKey = event.detail.prodId;
    console.log(
      "hanldeProductFamilyNxtValueChange ==> " + JSON.stringify(event.detail)
    );
    let prodArray = this.qoMap.get(quoteKey).productData;
    if (event.detail.fieldValue == "POTS" && this.telephoneNumberMissing) {
      this.telephonePopup = true;
      const pIndex = prodArray.findIndex((elem) => elem.prodID == productKey);
      this.deleteProduct(quoteKey, productKey, pIndex);
      return;
    }
    console.log("telephonePopup", this.telephonePopup);
    prodArray.forEach((pItem, pIndex) => {
      if (pItem.prodID == productKey) {
        if (!pItem.prodRecId) {
          if (pItem.prodFields.length > 2)
            pItem.prodFields.splice(1, pItem.prodFields.length - 1);
          pItem.prodFields.splice(1, 1, {
            prodName: event.detail.fieldName,
            prodValue: event.detail.fieldValue
          });
        } else {
          this.flashProductFieldValues(
            pItem.prodFields,
            ["Family"],
            [event.detail.fieldName],
            event.detail.fieldValue
          );
        }
        this.qoMap.get(quoteKey).productData[pIndex].prodDisplayName =
          event.detail.fieldValue;
        this.qoMap.get(quoteKey).productData[pIndex].fullProdName =
          this.qoMap.get(quoteKey).productData[pIndex].prodDisplayName;
        this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
          qoKey,
          qoValue
        }));
      }
    });
  }
  handleProductNxtValueChange(event) {
    let quoteKey = event.detail.quotId;
    let productKey = event.detail.prodId;
    let insertIndex = parseInt(event.detail.fieldIndex) + 2;
    let prodNxtArray = this.qoMap.get(quoteKey).productData;
    console.log(
      "handleProductNxtValueChange ==> " + JSON.stringify(event.detail)
    );
    prodNxtArray.forEach((pItem, pIndex) => {
      if (pItem.prodID == productKey) {
        let fieldLists = pItem.prodFields.map((item) => {
          return item.prodName;
        });
        let fieldNameIndex = fieldLists.indexOf(event.detail.fieldName);
        if (fieldNameIndex == -1)
          fieldNameIndex = fieldLists.indexOf(
            event.detail.fieldName.toLowerCase()
          );
        if (fieldNameIndex > -1) {
          pItem.prodFields[fieldNameIndex].prodValue = event.detail.fieldValue;
        } else {
          pItem.prodFields.splice(insertIndex, 0, {
            prodName: event.detail.fieldName,
            prodValue: event.detail.fieldValue
          });
        }

        if (event.detail.fieldIndex == 0) {
          this.qoMap.get(quoteKey).productData[pIndex].prodNxtDisplayName =
            event.detail.fieldValue;
          this.qoMap.get(quoteKey).productData[pIndex].fullProdName =
            this.qoMap.get(quoteKey).productData[pIndex].prodDisplayName +
            " " +
            this.qoMap.get(quoteKey).productData[pIndex].prodNxtDisplayName;
          this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
            qoKey,
            qoValue
          }));
        }
      }
    });
  }

  handleChildProductUpdate(event) {
    let quoteKey = event.detail.quotId;
    let productKey = event.detail.prodId;
    let prodNxtArray = this.qoMap.get(quoteKey).productData;
    prodNxtArray.forEach((pItem, pIndex) => {
      if (pItem.prodID == productKey) {
        let prodData = event.detail.prodData;
        let product = event.detail.productType;
        // let additionalFeaturesToTruncate = false;
        if (pItem.childProds) {
          let exitProdindex = pItem.childProds.findIndex((element) => {
            if (element["prodtype"] === product) {
              if (product === "AdditionalFeature") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (transformedElement.Name == transformedProd.Name) {
                  return true;
                }
              } else if (product === "OptionalService") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (transformedElement.Name == transformedProd.Name) {
                  return true;
                }
              }else if (product === "AddOnFeatures") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (transformedElement.Name == transformedProd.Name) {
                  return true;
                }
              }else if (product === "VOCFeatures") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (transformedElement.Name == transformedProd.Name) {
                  return true;
                }
              }
              else if (product === "Offer") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (transformedElement.Name == transformedProd.Name && transformedElement.Product_Offering__c == transformedProd.Product_Offering__c) {
                  return true;
                }
              }else if (product === "SIPAdditionalFeatures") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (transformedElement.Name == transformedProd.Name) {
                  return true;
                }
              }
              else if (product === "ATA Equipment") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (
                  element.status != "delete" &&
                  transformedElement.Model_Number__c ==
                    transformedProd.Model_Number__c
                ) {
                  return true;
                }
              } 
              else if (product === "HPBX Equipment") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (
                  element.status != "delete" &&
                  transformedElement.Model_Number__c ==
                    transformedProd.Model_Number__c
                ) {
                  return true;
                }
              } else if (product === "AddonEdgeboot") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (
                  element.status != "delete" && 
                  transformedElement.Name ==
                  transformedProd.Name
                ) {
                  return true;
                }
              }else if (product === "GDN OptionalService") {
                let transformedElement = this.tranformToFunction(
                  element.prodFields
                );
                let transformedProd = this.tranformToFunction(
                  event.detail.prodData
                );
                if (
                  element.status != "delete" &&
                  transformedElement.Name == transformedProd.Name) {
                  return true;
                }
              }
              else {
                return true;
              }
            }
          });
          if (exitProdindex >= 0) {
            pItem.childProds[exitProdindex]["status"] = event.detail.dmlOperation;
            let existProdData = pItem.childProds[exitProdindex]["prodFields"];
            let idValue = existProdData.find((val) => val.prodName == "Id")?.prodValue;
            if (!idValue && pItem.childProds[exitProdindex]["status"] == "delete") {
              pItem.childProds.splice(exitProdindex, 1);
            } else if (idValue && pItem.childProds[exitProdindex]["status"] == "upsert") {
              console.log("upsert");
              this._deleteChildProdIds.splice(this._deleteChildProdIds.indexOf(idValue),1);
              pItem.childProds[exitProdindex]["prodFields"] = prodData;
            } else {
              pItem.childProds[exitProdindex]["prodFields"] = prodData;
            }
          } else if (
            prodData &&
            prodData.length > 0 &&
            exitProdindex == -1 &&
            event.detail.dmlOperation !== "delete"
          ) {
            pItem.childProds.push({
              status: event.detail.dmlOperation,
              prodtype: product,
              prodFields: prodData
            });
          } else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "truncate" &&
              event.detail.productType == "AdditionalFeature"
            ) {
              let nonAdditionalFeatures = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "AdditionalFeature") {
                  nonAdditionalFeatures.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonAdditionalFeatures)
              );
            }
          } else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "truncate" &&
              event.detail.productType == "OptionalService"
            ) {
              let nonOptionalServices = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "OptionalService") {
                  nonOptionalServices.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonOptionalServices)
              );
            }
          }else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "truncate" &&
              event.detail.productType == "AddOnFeatures"
            ) {
              let nonAddOnfeatures = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "AddOnFeatures") {
                  nonAddOnfeatures.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonAddOnfeatures)
              );
            }
          }else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "truncate" &&
              event.detail.productType == "VOCFeatures"
            ) {
              let nonVOCFeatures = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "VOCFeatures") {
                  nonVOCFeatures.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonVOCFeatures)
              );
            }
          }
          else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "truncate" &&
              event.detail.productType == "Offer"
            ) {
              let nonAddOnSeatfeatures = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "Offer") {
                  nonAddOnSeatfeatures.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonAddOnSeatfeatures)
              );
            }
          }
          else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "truncate" &&
              event.detail.productType == "SIPAdditionalFeatures"
            ) {
              let nonAddOnSIPfeatures = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "SIPAdditionalFeatures") {
                  nonAddOnSIPfeatures.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonAddOnSIPfeatures)
              );
            }
          }else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "delete" &&
              event.detail.productType == "GDN OptionalService"
            ) {
              let nonGDNOptionalServices = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "GDN OptionalService") {
                  nonGDNOptionalServices.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonGDNOptionalServices)
              );
            }
          }else if (prodData && prodData.length <= 0 && exitProdindex == -1) {
            if (
              event.detail.dmlOperation == "delete" &&
              event.detail.productType == "AddonEdgeboot"
            ) {
              let nonEdgebootlist = [];

              for (let index = 0; index < pItem.childProds.length; index++) {
                if (pItem.childProds[index].prodtype != "AddonEdgeboot") {
                  nonEdgebootlist.push(pItem.childProds[index]);
                }
              }
              pItem.childProds = JSON.parse(
                JSON.stringify(nonEdgebootlist)
              );
            }
          }
        }
        try {
          this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
            qoKey,
            qoValue
          }));
        } catch (err) {
          console.log(err);
        }
      }
    });
  }

  get modalClass() {
    return `slds-modal ${this.openModal ? "slds-fade-in-open" : ""}`;
  }
  get modalBackdropClass() {
    return `slds-backdrop slds-backdrop_open`;
  }
  async connectedCallback() {
    this.showLoading = true;
    this.isSelected = true;
    this.fetchAndSetExistingData();
    this.checkAddEquipmentPermission();
    this.showLoading = false;
  }
  renderedCallback() {
    //this.showLoading = false;
  }
  @api showModal(allSelectedRows, selectedRows) {
    this.openModal = true;
    let sLocations = [];
    if (selectedRows.length > 0) {
      selectedRows.forEach((loc) => {
        sLocations.push(loc.Id);
      });
    } else if (allSelectedRows.length > 0) {
      allSelectedRows.forEach((loc) => {
        sLocations.push(loc);
      });
    } else {
      sLocations = [];
    }
    this.selectedLocations = sLocations;
  }
  closeModal() {
    //this.openModal=false;
    this.openLocationsModal = false;
    // this.openAddProductModal = false;
    this.quoteOptionList1 = [
      {
        quoteNumber: 1
      }
    ];
    this.qoMap.clear();
    this.QOArray.splice(1, this.QOArray.length - 1);
    this.qoNum = 1;
    this.pNum = 1;
    this.dispatchEvent(new CustomEvent("addcompleteproductclose"));
    this.dispatchEvent(new CustomEvent("closeaddproductmodal"));
    //this.dispatchEvent(new CustomEvent('addproductclose'));
  }
  handleLocationsClick() {
    this.dispatchEvent(
      new CustomEvent("tabchange", {
        detail: {
          tabName: "AddQRLocation",
          context: this.addProductContext ? this.addProductContext : "",
          //selectedLocations : this.addProductContext ? [] : this.selectedLocations,
          docIdList: this.docIdList
        }
      })
    );
  }
  displayaddequipment(event) {
    this.selectedProductFromDropdown = event.detail;
    console.log("displayaddequipment ==> " + JSON.stringify(event.detail));
    if (this.selectedProductFromDropdown != "DIA") {
      this.displayaddequipmentlink = true;
    } else {
      this.displayaddequipmentlink = false;
    }
  }
  enableQOInput(event) {
    event.preventDefault(event);
    let label = event.target.name;
    let qokey = event.target.dataset.recordId;
    if (label == "ShowLabel") {
      this.qoMap.get(qokey).qoInputEnableLabel = "HideLabel";
      this.qoMap.get(qokey).qoInputCheck = true;
      this.qoMap.get(qokey).qoPopoverCheck = false;
    } else if (label == "HideLabel") {
      this.qoMap.get(qokey).qoInputEnableLabel = "ShowLabel";
      this.qoMap.get(qokey).qoInputCheck = false;
    }
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }
  //Hide show rename input field
  saveQOInput(event) {
    event.preventDefault(event);
    let label = event.target.name;
    let qokey = event.target.accessKey;
    if (label == "HideLabel") {
      this.qoMap.get(qokey).qoInputEnableLabel = "ShowLabel";
      this.qoMap.get(qokey).qoInputCheck = false;
      this.qoMap.get(qokey).clickedPopOverLabel = "Show";
      this.qoMap.get(qokey).qoPopoverCheck = false;
    }
    for (const [key, value] of this.qoMap.entries()) {
      if (this.qoMap.get(key).quoteOptionName != "Quote Option ") {
        this.qoMap.get(key).quoteOptionNum = "";
      }
    }
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }
  renameQOInput(event) {
    let onChangeAccessKey = event.target.dataset.id;
    let onChangeQO = event.target.value;
    this.qoMap.get(onChangeAccessKey).quoteOptionName = onChangeQO;
  }
  //Open edit and rename popover
  openQOPopOver(event) {
    event.preventDefault(event);
    let label = event.target.name;
    let accessKey = event.target.accessKey;
    for (let [qokey, qovalue] of this.qoMap) {
      if (qokey == accessKey) {
        if (label == "Show") {
          this.qoMap.get(qokey).clickedPopOverLabel = "Hide";
          this.qoMap.get(qokey).qoPopoverCheck = true;
        } else if (label == "Hide") {
          this.qoMap.get(qokey).clickedPopOverLabel = "Show";
          this.qoMap.get(qokey).qoPopoverCheck = false;
        }
      } else {
        this.qoMap.get(qokey).clickedPopOverLabel = "Show";
        this.qoMap.get(qokey).qoPopoverCheck = false;
      }
    }
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }

  @track qoName;
  @track qoNum;
  @track pNum;
  @track pName;
  @track eqNum;
  @track eqName;
  @track QOArray = [];
  //----------new code with maps----------------------//
  setQuoteOption() {
    this.qoNum = 1;
    this.pNum = 1;
    this.eqNum = 1;
    let quoteOptionKey = "QuoteOption" + this.qoNum;
    this.pName = "prod" + Math.floor(Math.random() * (999 - 100 + 1) + 100);
    let prodKey = quoteOptionKey + this.pName;
    this.eqName = "equip" + this.eqNum;
    let eqKey = quoteOptionKey + this.eqName;
    this.activeSections.push(prodKey);
    this.activeSectionsEQ.push(eqKey);
    let quoteData = {
      quoteOptionName: "Quote Option ",
      quoteOptionNum: this.qoNum,
      productData: [
        {
          prodID: prodKey,
          prodDisplayName: "",
          prodNxtDisplayName: "",
          fullProdName: "Select a Product",
          prodFields: [],
          childProds: [],
          equipmentData: [],
          resultData: [],
          prdFamilyValue: "",
          selectedEquipmentMap: new Map(),
          openEquipmentModal: false,
          isDisabledEquipment: true
        }
      ],
      equipmentDataDetails: [
        {
          equipmentId: eqKey,
          equipmentData: [],
          resultData: [],
          prdFamilyValue: "",
          selectedEquipmentMap: new Map(),
          openEquipmentModal: false,
          isDisabledEquipment: true
        }
      ],
      qoPopoverCheck: false,
      clickedPopOverLabel: "Show",
      qoInputCheck: false,

      qoInputEnableLabel: "ShowLabel"
    };
    this.qoMap.set(quoteOptionKey, quoteData);
    let qoArr = [];
    this.qoMap.forEach(function (value, key, map) {
      qoArr.push({
        qoKey: key,
        qoValue: value
      });
    });
    this.QOArray = qoArr;
  }

  fetchAndSetExistingData() {
    let tempLocations = "";
    if (this.docIdList && this.docIdList.length > 0) {
      tempLocations = "";
    } else if (
      this.newUploadedLocations &&
      this.newUploadedLocations.length > 0
    ) {
      let sLocations =
        this.newUploadedLocations && this.newUploadedLocations.length
          ? this.newUploadedLocations
          : this.selectedLocations
          ? this.selectedLocations
          : this._selectedLocations;
      let _selectedTempLocations =
        this.applyToAllCheck === true
          ? this.quoteOptionDataWrapper.quoteLocationList.map((a) => a.Id)
          : sLocations;
      tempLocations = JSON.stringify(_selectedTempLocations);
    }
    fetchQuoteRequestRelatedData({
      recordId: this.recordId,
      docIdList: this.docIdList,
      locations: tempLocations
    })
      .then((result) => {
        this.quoteOptionDataWrapper = result;
        this.setLocations();
        this.setExistingQOItemData();
      })
      .catch((error) => {
        this.errorMsg = error;

        //alert(''+JSON.stringify(error))
      });
  }
  tnPopupClose() {
    this.telephonePopup = false;
  }
  setLocations() {
    const locationintelephonenumber = [];
    console.log("this is setLocations", this._selectedLocations);
    let multiLocation = this.selectedLocations ? true : false;
    if (
      this.quoteOptionDataWrapper &&
      this.quoteOptionDataWrapper.quoteLocationList &&
      this.quoteOptionDataWrapper.quoteLocationList.length > 0
    ) {
      this.quoteOptionDataWrapper.quoteLocationList.forEach((item) => {
        if (item.Telephone_Number__c) {
          locationintelephonenumber.push(item.Id);
        }
        console.log("item", item);
        this._selectedLocations.push(item.Id);
      });
    }
    if (this._selectedLocations.length != locationintelephonenumber.length) {
      this.telephoneNumberMissing = true;
    } else {
      this.telephoneNumberMissing = false;
    }
    if (this.selectedLocations)
      this._selectedLocations = this.selectedLocations;
  }

  //harsha
  setExistingQOItemData() {
    if (
      typeof this.quoteOptionDataWrapper === "undefined" ||
      this.quoteOptionDataWrapper.quoteProductList === "undefined" ||
      this.quoteOptionDataWrapper.quoteProductList.length == 0
    ) {
      this.setQuoteOption();
    } else {
      this.isDisabledSave = false;
      //process
      this.qoNum = 1;
      this.pNum = 1;
      this.eqNum = 1;
      let qoEquipMap = new Map();
      let qoProdMap = new Map();
      let _permissibleQOProducts = new Map();

      this.quoteOptionDataWrapper.quoteLocationOptions.forEach((elem) => {
        if (
          this._selectedLocations.indexOf(elem.Quote_Request_Location__c) == -1
        )
          return;
        let _products = _permissibleQOProducts.has(elem.Quote_Option__c)
          ? _permissibleQOProducts.get(elem.Quote_Option__c)
          : [];
        let financeCheck = FINANCELIST.some(finance => this.loggedInUser.lstPermissionSet.includes(finance));
         if(!financeCheck && elem.Quote_Option_Item__r.Name =='VoIP' && elem.Quote_Option_Item__r.Product_Detail1__c == 'Operator Connect for Microsoft Teams'){
        
        }else{
        _products.push(elem.Quote_Option_Item__c);
        }
       // _products.push(elem.Quote_Option_Item__c);
        _permissibleQOProducts.set(elem.Quote_Option__c, _products);
      });

      this.quoteOptionDataWrapper.quoteProductList.forEach((item) => {
        if (!_permissibleQOProducts.has(item.Quote_Option__c)) return;
        let permissibleProds = _permissibleQOProducts.get(item.Quote_Option__c);
        let existingProductData = qoProdMap.get(item.Quote_Option__c)
          ? qoProdMap.get(item.Quote_Option__c)
          : [];
        if (permissibleProds.indexOf(item.Id) > -1)
          existingProductData.push(item);
        qoProdMap.set(item.Quote_Option__c, existingProductData);
      });
      this.quoteOptionDataWrapper.quoteOptionList.forEach((item) => {
        let quoteOptionKey = item.QuoteOptionID__c;
        if (!_permissibleQOProducts.has(item.Id)) {
          this.qoMap.set(quoteOptionKey, {});
        }
        let prodData = [];
        let equipData = [];
        if (qoProdMap.get(item.Id)) {
          qoProdMap.get(item.Id).forEach((item, index) => {
            this.surchargeCheck = item.Is_Surcharge__c;
            if (!item.isEquipment__c) {
              this.pName =
                "prod" + Math.floor(Math.random() * (999 - 100 + 1) + 100);
              let prodKey = quoteOptionKey + this.pName;
              let prodAttrs = this.objectifyProductAttributes(item);
              let prodDataObj = {
                prodID: prodKey,
                prodDisplayName: "",
                prodRecId: item.Id,
                prodNxtDisplayName: "",
                fullProdName: item.Name,
                prodFields: prodAttrs,
                equipmentData: [],
                resultData: [],
                prdFamilyValue: "",
                selectedEquipmentMap: new Map(),
                openEquipmentModal: false,
                isDisabledEquipment: true,
                childProds: this.objectifyChildProductAttributes(item)
              };
              prodData.push(prodDataObj);
              this.pNum++;
            }
          });
        }

        let objEqMapDetails = new Map();
        let selectedEq = [];
        if (qoProdMap.get(item.Id)) {
          let arr = [...qoProdMap.get(item.Id)];
          for (let i = 0; i < arr.length; i++) {
            // alert('in if');
            if (arr[i].isEquipment__c) {
              arr[i].Name = arr[i].Product_Catalog__c;
              arr[i].IP_Quantity__c = arr[i].Quantiy__c;
              if (objEqMapDetails.has(arr[i].Product_Description__c)) {
                let arr1 = [];
                arr1 = objEqMapDetails.get(arr[i].Product_Description__c);
                arr1.push(arr[i]);
              } else {
                let arr1 = [];
                arr1.push(arr[i]);
                objEqMapDetails.set(arr[i].Product_Description__c, arr1);
              }
            }
          }
          if (objEqMapDetails) {
            for (const key of objEqMapDetails.keys()) {
              selectedEq.push({
                key: key,
                values: objEqMapDetails.get(key),
                isDelete: true
              });
            }
          }
        }
        //need to set map based on the condition and wrraper from apex also need to set equipmentId----kalyani
        if (qoProdMap.get(item.Id)) {
          this.eqName = "equip" + this.eqNum;
          let eqKey = quoteOptionKey + this.eqName;
          let eqDataObj = {
            equipmentId: eqKey,
            equipmentData: [],
            resultData: [],
            prdFamilyValue: "",
            selectedEquipmentMap: objEqMapDetails ? objEqMapDetails : new Map(),
            selectedEquipmentList:
              selectedEq.length > 0
                ? JSON.parse(JSON.stringify(selectedEq))
                : [],
            isShowEquipmentdata: true,
            openEquipmentModal: false,
            isDisabledEquipment: true
          };
          if (selectedEq.length > 0) {
            eqDataObj.isShowEquipmentdata = true;
          } else {
            eqDataObj.isShowEquipmentdata = false;
          }
          equipData.push(eqDataObj);
          this.eqNum++;
        }
        //this.activeSections.push(prodKey);
        let quoteData = {
          quoteOptionName: item.Name,
          // ,quoteOptionNum : item.Name.match(/\d+/)[0]
          quoteOptionNum: "",
          quoteOptionId: item.Id,
          productData: prodData,
          equipmentDataDetails: equipData,
          qoPopoverCheck: false,
          clickedPopOverLabel: "Show",
          qoInputCheck: false,
          qoInputEnableLabel: "ShowLabel"
        };
        this.qoMap.set(quoteOptionKey, quoteData);
        this.qoNum++;
      });
      let qoArr = [];
      this.qoMap.forEach(function (value, key, map) {
        qoArr.push({
          qoKey: key,
          qoValue: value
        });
      });
      this.QOArray = qoArr;

      if (this.addProductContext == "FROMCOPYPRODUCTS") {
        this.addNewProductsForExistingQuoteOptions();
      }
    }
  }
  objectifyChildProductAttributes(item) {
    let childProds = item.Child_Quote_Option_Items__r
      ? item.Child_Quote_Option_Items__r
      : [];
    let childProductSplit = [];
    childProds.forEach((cItem) => {
      let outputProdData = Object.keys(cItem).map(function (i) {
        return { prodName: i, prodValue: cItem[i] };
      });

      let prdType;
      if (cItem.Child_Quote_item_Product_Type__c) {
        if (cItem.Child_Quote_item_Product_Type__c == "Router") {
          prdType = "Router";
        } else if (
          cItem.Child_Quote_item_Product_Type__c == "AdditionalFeature"
        ) {
          prdType = "AdditionalFeature";
        } else if (
          cItem.Child_Quote_item_Product_Type__c == "OptionalService"
        ) {
          prdType = "OptionalService";
        }else if (
          cItem.Child_Quote_item_Product_Type__c == "AddOnFeatures"
        ) {
          prdType = "AddOnFeatures";
        }
        else if (
          cItem.Child_Quote_item_Product_Type__c == "VOCFeatures"
        ) {
          prdType = "VOCFeatures";
        }
        else if (
          cItem.Child_Quote_item_Product_Type__c == "Offer"
        ) {
          prdType = "Offer";
        }else if (
          cItem.Child_Quote_item_Product_Type__c == "SIPAdditionalFeatures"
        ) {
          prdType = "SIPAdditionalFeatures";
        }else if (
          cItem.Child_Quote_item_Product_Type__c == "GDN OptionalService"
        ) {
          prdType = "GDN OptionalService";
        }
        else if(cItem.Child_Quote_item_Product_Type__c == "HPBX Equipment"){
          prdType = "HPBX Equipment";
        } else if(cItem.Child_Quote_item_Product_Type__c == "AddonEdgeboot"){
          prdType = "AddonEdgeboot";
        }else {
          prdType = "ATA Equipment";
        }
      }

      childProductSplit.push({
        status: "upsert",
        prodtype: prdType,
        prodFields: outputProdData
      });
    });
    return childProductSplit;
  }

  objectifyProductAttributes(prod) {
    let prodObj = [];
    Object.entries(prod).map((item) => {
      if (!item[0].includes("__r"))
        prodObj.push({
          prodName: item[0] == "Product_Family__c" ? "Family" : item[0],
          prodValue: item[1]
        });
    });
    return prodObj;
  }

  addQuoteOption() {
    ++this.qoNum;
    let quoteOptionKey = "QuoteOption" + this.qoNum;
    let prodKey = quoteOptionKey + this.pName;
    let eqKey = quoteOptionKey + this.eqName;
    let tempActiveSec = this.activeSectionsEQ;
    tempActiveSec.splice(0, 1, eqKey);
    this.activeSectionsEQ = [...this.activeSectionsEQ, tempActiveSec];
    let quoteData = {
      quoteOptionName: "Quote Option ",
      quoteOptionNum: this.qoNum,
      productData: [
        {
          prodID: prodKey,
          prodDisplayName: "",
          prodNxtDisplayName: "",
          fullProdName: "Select a Product",
          prodFields: [],
          childProds: [],
          equipmentData: [],
          resultData: [],
          prdFamilyValue: "",
          selectedEquipmentMap: new Map(),
          openEquipmentModal: false,
          isDisabledEquipment: true
        }
      ],
      equipmentDataDetails: [
        {
          equipmentId: eqKey,
          equipmentData: [],
          resultData: [],
          prdFamilyValue: "",
          selectedEquipmentMap: new Map(),
          openEquipmentModal: false,
          isDisabledEquipment: true
        }
      ],
      qoPopoverCheck: false,
      clickedPopOverLabel: "Show",
      qoInputCheck: false,
      qoInputEnableLabel: "ShowLabel"
    };
    if (!this.qoMap.has(quoteOptionKey)) {
      this.qoMap.set(quoteOptionKey, quoteData);
    }
    let updQN = 1;
    for (const [key, value] of this.qoMap.entries()) {
      if (this.qoMap.get(key).quoteOptionName == "Quote Option ") {
        this.qoMap.get(key).quoteOptionNum = updQN;
      }
      updQN++;
    }
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  } 
  addEdgeBootProduct(event){
    this.edgebootProdFlag = 'Yes';
    let prodQOKey = event.detail.qoId;
    this.addProduct(prodQOKey);
  }

  addProductforQO(event) {
    this.edgebootProdFlag = 'No';
    let prodQOKey = event.target.accessKey;
    this.addProduct(prodQOKey);
  }

  addProduct(prodQOId) {
    let prodQOKey = prodQOId;
    ++this.pNum;
    let prodNm = "prod" + Math.floor(Math.random() * (999 - 100 + 1) + 100);
    let prodKey = prodQOKey + prodNm;
    let tempActiveSec = this.activeSections;
    tempActiveSec.splice(0, 1, prodKey);
    this.activeSections = [...this.activeSections, tempActiveSec];
    let addProdArray = this.qoMap.get(prodQOKey).productData;
    addProdArray.push({
      prodID: prodKey,
      prodDisplayName: "",
      prodNxtDisplayName: "",
      fullProdName: "Select a Product",
      prodFields: [],
      childProds: [],
      equipmentData: [],
      resultData: [],
      prdFamilyValue: "",
      selectedEquipmentMap: new Map(),
      openEquipmentModal: false,
      isDisabledEquipment: true
    });
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }
  @track deletedProdIds = [];

  deleteProductforQO(event) {
    event.preventDefault(event);
    let prodQOKey = event.target.dataset.id;
    let prodKey = event.target.accessKey;
    let prodIndex = event.target.dataset.index;
    let productRecordId = event.target.dataset.recordId;

    let deleProdArray = this.qoMap.get(prodQOKey).productData;
    //if(deleProdArray && deleProdArray.length > 1){
    this.deleteProduct(prodQOKey, productRecordId, prodIndex);
    // }
    /* else{
            this.showLoading = false;
            
            const evt = new ShowToastEvent({
                title: 'Error',
                message: 'Quote Option(s) should have at least one product to save.',
                variant: 'error',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
        } */
  }

  showDeleteProductError(quoteOptionName) {
    let messageToDisplay = DELETE_PRODUCT_ERROR_MSG.replace(
      "{0}",
      '"' + quoteOptionName + '"'
    );

    const errorMsgEvent = new ShowToastEvent({
      title: "Error",
      message: messageToDisplay,
      variant: "error"
    });

    this.dispatchEvent(errorMsgEvent);
  }

  hasEquipmentsAdded(prodQOKey) {
    let eqArray = this.qoMap.get(prodQOKey).equipmentDataDetails;
    if (!eqArray) {
      return false;
    } else if (!eqArray[0]) {
      return false;
    } else if (!eqArray[0].selectedEquipmentList) {
      return false;
    } else if (eqArray[0]?.selectedEquipmentList?.length == 0) {
      return false;
    }
    return true;
  }

  deleteProduct(prodQOKey, productRecordId, prodIndex) {
    let quoteOption = this.qoMap.get(prodQOKey);
    let deleProdArray = quoteOption.productData;

    if (!this.hasEquipmentsAdded(prodQOKey) && deleProdArray.length <= 1) {
      this.showDeleteProductError(quoteOption.quoteOptionName);
    } else {
      deleProdArray.splice(prodIndex, 1);

      if (productRecordId) {
        this.deletedProdIds.push(productRecordId);
        //check for child product data as well
        this.checkForChildProducts(deleProdArray, prodIndex, productRecordId);
      }

      this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
        qoKey,
        qoValue
      }));
      this.pNum--;
    }
  }

  checkForChildProducts(deleProdArray, prodIndex, productRecordId) {
    if (deleProdArray && deleProdArray[prodIndex]) {
      let childProdArray = deleProdArray[prodIndex].childProds
        ? deleProdArray[prodIndex].childProds
        : [];
      if (childProdArray.length > 0) {
        childProdArray.forEach((indx) => {
          if (indx.prodFields) {
            let objId = indx.prodFields.find((prod) => prod.prodName == "Id");
            if (objId)
              this.deletedProdIds.push(objId.prodValue + ":" + productRecordId);
          }
        });
      }
    }
  }
  deleteRelatedQOItemLocations(qoId, _selectedLocations) {
    let _deleteLocationsPromises = [];
    this.quoteOptionDataWrapper.quoteLocationOptions.forEach((item) => {
      if (
        item.Quote_Option_Item__c == qoId &&
        _selectedLocations.indexOf(item.Quote_Request_Location__c) > -1
      )
        _deleteLocationsPromises.push(item.Id);
    });
    return _deleteLocationsPromises;
  }

  deleteQuoteOption(event) {
    event.preventDefault(event);
    let qoKey = event.target.dataset.recordId;
    this.qoMap.delete(qoKey);
    let updQN = 1;
    this.deletedProdIds.push(qoKey);
    for (const [key, value] of this.qoMap.entries()) {
      if (this.qoMap.get(key).quoteOptionName == "Quote Option ") {
        this.qoMap.get(key).quoteOptionNum = updQN;
        updQN++;
      }
    }
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
    this.qoNum--;
  }

  //adding new products for existing quote options 12/13/2021
  addNewProductsForExistingQuoteOptions() {
    if (this.qoMap) {
      for (let qokey of this.qoMap) {
        this.qoMap.get(qokey[0]).productData = [];
        //this.qoMap.get(qokey[0]).equipmentDataDetails = [];
      }
      this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
        qoKey,
        qoValue
      }));
    }
  }
  showSpinner() {
    // Setting boolean variable to true, this will show the Spinner
    this.showLoading = true;
  }

  hideSpinner() {
    // Setting boolean variable to false, this will hide the Spinner
    this.showLoading = false;
  }
  ignore(event) {
    event.stopPropagation();
    return false;
  }
  getSurchargeVal(event) {
    this.surchargeCheck = event.target.checked;
    //  const surchargeEvent = new CustomEvent("surchargeevent", {
    //         detail: this.surchargeCheck
    //     });
    //     // Dispatches the event
    //     this.dispatchEvent(surchargeEvent);
  }
  // getTaxVal(event){
  //     this.taxesCheck = event.target.checked;
  // }

  handleDiversityNoteUpdate(event) {
    console.log("add product Note : ", event.detail);
    this.noteContent = event.detail;
    console.log("Add Notes : ", this.noteContent);
  }

  async saveQuoteOptions() {
    console.log("Save Notes : ", this.noteContent);
    this.addNote();
    if (!this.applyToAllConftn) {
      this.showLoading = true;
      this._selectedLocations =
        this.newUploadedLocations && this.newUploadedLocations.length
          ? this.newUploadedLocations
          : this.selectedLocations
          ? this.selectedLocations
          : this._selectedLocations;
      //console.log('>>>> selected locations : >>> ',this._selectedLocations);
      let _selectedTempLocations =
        this.applyToAllCheck === true
          ? this.quoteOptionDataWrapper.quoteLocationList.map((a) => a.Id)
          : this._selectedLocations;
      //console.log('>>> this.selectedLocations>>>',JSON.stringify(_selectedTempLocations));

      let _delelePromises = [];
      let deleteproductquote = [];
      if (this.deletedProdIds) {
        this.deletedProdIds.forEach((item) => {
          //skipping collecting the child products to be deleted along with the real one until we find out if the parent item has to be deleted
          if (item.includes(":")) return;
          let _locationsToDelete = this.deleteRelatedQOItemLocations(
            item,
            _selectedTempLocations
          );
          for (let i = 0; i < _locationsToDelete.length; i++) {
            _delelePromises.push(_locationsToDelete[i]);
          }
          if (
            this.quoteOptionDataWrapper &&
            this.quoteOptionDataWrapper.quoteLocationList &&
            this.quoteOptionDataWrapper.quoteLocationList.length ==
              _locationsToDelete.length
          ) {
            deleteproductquote.push(item);
          }
        });

        this.deletedProdIds.forEach((item) => {
          //trying to find its parent items in the delete array, if found adding it's child to be deleted along with it.
          if (
            item.includes(":") &&
            _delelePromises.indexOf(item.split(":")[0]) > -1
          ) {
            //parent found to be deleted as well
            //add child too for deletion
            _delelePromises.push(item.split(":")[1]);
          }
        });
      }
      if (this._deleteChildProdIds) {
        await deleteChildRecordsWithId({ idLists: this._deleteChildProdIds })
          .then(() => {
            console.log(
              "deleteChildRecordsWithId::" + this._deleteChildProdIds
            );
          })
          .catch((err) => {
            console.log(err);
          });
      }
      if (deleteproductquote.length > 0) {
        await deleteQuoteProduct({ idLists: deleteproductquote });
        await deleteRecordsWithId({ idLists: _delelePromises })
          .then(() => {})
          .catch((err) => {
            console.log(err);
          });
      }
      if (deleteproductquote.length === 0 && _delelePromises) {
        await deleteRecordsWithId({ idLists: _delelePromises })
          .then(() => {})
          .catch((err) => {
            console.log(err);
          });
      }

      const obj = Object.fromEntries(this.qoMap);

      let isInputsCorrect = true;

      if (
        this.template.querySelectorAll("c-product-picklist-v2") &&
        this.template.querySelectorAll("c-product-picklist-v2").length > 0
      ) {
        let proPicklist = this.template.querySelectorAll(
          "c-product-picklist-v2"
        );
        for (let i = 0; i < proPicklist.length; i++) {
          let objRetValue = {};
          objRetValue = proPicklist[i].validateInputFields();
          isInputsCorrect = isInputsCorrect && objRetValue.isInputsCorrect;
          let element = this.template.querySelector(
            '[data-id="' + objRetValue.prodId + '"]'
          );
          element.classList.remove("acc-sec-bordercolor");
          if (!isInputsCorrect) {
            let elementI = this.template.querySelector(
              '[data-id="' + objRetValue.prodId + '"]'
            );
            elementI.classList.add("acc-sec-bordercolor");
            break;
          }
        }

        // alert('Form is Valid => ' + isInputsCorrect);

        if (isInputsCorrect) {
          this.saveQuoteOptionsApexCall(_selectedTempLocations, obj);
        } else {
          this.showLoading = false;
        }
      } else {
        this.saveQuoteOptionsApexCall(_selectedTempLocations, obj);
      }
    } else {
      this.openModal = false;
      this.showAllLocCheckpopup = true;
    }
  }
  addNote() {
    console.log("Note value add product Method: ", this.noteContent);

    if (this.noteContent && this.noteContent.length > 0) {
      saveNoteCall({
        qrId: this.recordId,
        title: "Diversity Request",
        notes: this.noteContent
      })
        .then((result) => {
          this.dispatchEvent(
            new ShowToastEvent({
              title: "SUCCESS",
              message: "Notes has been created Successfully.",
              variant: "success"
            })
          );
        })
        .catch((error) => {
          this.error = error;
          this.dispatchEvent(
            new ShowToastEvent({
              title: "error!!",
              message: error.body.message,
              variant: "error"
            })
          );
        });
    }
  }

  saveQuoteOptionsApexCall(_selectedTempLocations, obj) {
    let tempLocations = "";
    if (this.docIdList && this.docIdList.length > 0) {
      tempLocations = "";
    } else {
      tempLocations = JSON.stringify(_selectedTempLocations);
    }

    saveQuoteOptionsData({
      quoteData: JSON.stringify(obj),
      quoteReqId: this.recordId,
      docIdList: this.docIdList,
      locations: tempLocations,
      surcharge: this.surchargeCheck,
      taxes: this.taxesCheck
    })
      .then((result) => {
        this.showLoading = false;
        this.openModal = false;
        const evt = new ShowToastEvent({
          title: "Success",
          message: "Quote Options created sucessfully",
          variant: "success",
          mode: "dismissable"
        });
        this.dispatchEvent(evt);
        this.saveAddProductModal();
      })
      .catch((error) => {
        this.error = error;
        this.showLoading = false;
        const evt = new ShowToastEvent({
          title: "Error",
          message: "Some unexpected error",
          variant: "error",
          mode: "dismissable"
        });
        this.dispatchEvent(evt);
      });
  }

  //Save for apply to all
  saveApplytoAllLocations() {
    this.applyToAllConftn = false;
    this.saveQuoteOptions();
    this.showAllLocCheckpopup = false;
  }
  //No for apply to all Locations
  NoApplyToAllLocations() {
    this.applyToAllConftn = false;
    this.applyToAllCheck = false;
    this.showAllLocCheckpopup = false;
    this.openModal = true;
  }
  saveAddProductModal() {
    if (this.addProductContext == "FROMCOPYPRODUCTS") {
      const custEvent = new CustomEvent("updateproductdata", {
        detail: "product"
      });
      this.dispatchEvent(custEvent);
    } else {
      const custEvent = new CustomEvent("saveproductdata", {
        detail: "product"
      });
      this.dispatchEvent(custEvent);
    }
  }
  closeAddProductModal() {
    const custEvent = new CustomEvent("closeaddproductmodal", {
      detail: "product"
    });
    this.dispatchEvent(custEvent);
  }

  openAddProductModal() {
    const custEvent = new CustomEvent("openaddproductmodal", {
      detail: false
    });
    this.dispatchEvent(custEvent);
  }
  //Handle Equipement starts
  handleAddEquipementClick(event) {
    let eqQOKey = event.target.accessKey;
    let eqNm = "equip" + this.eqNum;
    let eqKey = eqQOKey + eqNm;
    if(this.qoMap === null || this.qoMap === undefined){
      return;
    }
   let addEqArray = this.qoMap.get(eqQOKey).equipmentDataDetails;
   if(addEqArray && addEqArray.length >0){
     addEqArray[0].isShowEquipmentdata = false;
      addEqArray[0].openEquipmentModal = true;
   }
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }
  handleDeleteEquipment(event) {
    let quoteKey = event.detail.quotId;
    let eqKey = event.detail.equipmentIdVar;
    let indx = event.detail.equipmentId;
    let equipmentKey = event.detail.equipmentKey;
    let prodId = event.detail.prodId;
    let arraySelected = [];
    let equipmentSelected = [];
    this.deletedProdIds.push(prodId);
    let eqArray = this.qoMap.get(quoteKey).equipmentDataDetails;
    let products = this.qoMap.get(quoteKey).productData;

    if (
      eqArray[0]?.selectedEquipmentList?.length <= 1 &&
      products.length == 0
    ) {
      let quoteOption = this.qoMap.get(quoteKey);
      this.showDeleteProductError(quoteOption.quoteOptionName);
    } else {
      eqArray.forEach((pItem) => {
        if (pItem.equipmentId == eqKey) {
          if (pItem.selectedEquipmentMap.has(equipmentKey)) {
            let array = [];
            array = pItem.selectedEquipmentMap.get(equipmentKey);
            if (array && array.length > 0) {
              if (array.length <= 1) {
                pItem.selectedEquipmentMap.delete(equipmentKey);
              } else {
                for (let i = 0; i < array.length; i++) {
                  if (array[i].Name == indx) {
                    array.splice(i, 1);
                  }
                }
              }
            }
          }
          if (pItem.selectedEquipmentMap) {
            for (const key of pItem.selectedEquipmentMap.keys()) {
              arraySelected.push({
                key: key,
                values: pItem.selectedEquipmentMap.get(key),
                isDelete: true
              });
              let values = pItem.selectedEquipmentMap.get(key);
              values.forEach((object) => {
                //delete object['isSelected'];
                equipmentSelected.push(object);
              });
            }
            pItem.selectedEquipmentList = JSON.parse(
              JSON.stringify(arraySelected)
            );
            pItem.equipmentSelected = equipmentSelected;

            if (arraySelected.length > 0) {
              pItem.isShowEquipmentdata = true;
            } else {
              pItem.isShowEquipmentdata = false;
            }
          }
          if (pItem.equipmentData && pItem.equipmentData.length > 0) {
            for (let i = 0; i < pItem.equipmentData.length; i++) {
              if (pItem.equipmentData[i].Name == indx) {
                pItem.equipmentData[i].isSelected = false;
              }
            }
          }
          if (
            pItem.resultData?.productCatalogList &&
            pItem.resultData?.productCatalogList?.length > 0
          ) {
            for (
              let i = 0;
              i < pItem.resultData.productCatalogList.length;
              i++
            ) {
              if (pItem.resultData.productCatalogList[i].Name == indx) {
                pItem.resultData.productCatalogList[i].isSelected = false;
              }
            }
          }
          if (
            pItem.resultData?.selectedEquipmentTypes &&
            pItem.resultData?.selectedEquipmentTypes.length > 0
          ) {
            let eq = pItem.resultData.selectedEquipmentTerm
              ? pItem.resultData.selectedEquipmentTerm
              : "";
            let keyVar = pItem.resultData.selectedEquipmentValue + "" + eq;
            if (pItem.resultData.selectedEquipmentTypes.includes(keyVar)) {
              pItem.resultData.selectedEquipmentTypes.splice(
                pItem.resultData.selectedEquipmentTypes.indexOf(keyVar),
                1
              );
            }
          }
        }
      });

      this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
        qoKey,
        qoValue
      }));
    }
  }
  handleCloseEquipmentModal(event) {
    let quoteKey = event.detail.quotId;
    let eqKey = event.detail.equipmentId;
    let eqArray = this.qoMap.get(quoteKey).equipmentDataDetails;
    let selectedArray = [];
    let equipmentSelected = [];
    eqArray.forEach((pItem) => {
      if (pItem.equipmentId == eqKey) {
        pItem.equipmentData = event.detail.equipmentData;
        pItem.resultData = event.detail.resultData;
        pItem.selectedEquipmentMap = event.detail.selectedEquipmentMap;
        if (event.detail.selectedEquipmentMap) {
          for (const key of event.detail.selectedEquipmentMap.keys()) {
            let values = event.detail.selectedEquipmentMap.get(key);
            selectedArray.push({ key: key, values: values, isDelete: true });
            values.forEach((object) => {
              //delete object['isSelected'];
              equipmentSelected.push(object);
            });
            // equipmentSelected=values;
          }
          pItem.equipmentSelected = equipmentSelected;
          pItem.selectedEquipmentList = selectedArray;
          if (selectedArray.length > 0) {
            pItem.isShowEquipmentdata = true;
          } else {
            pItem.isShowEquipmentdata = false;
          }
        }
        pItem.openEquipmentModal = false;
      }
    });
    this.isDelete = true;
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }

  handleInnerAddEquipementClick(event) {
    let quoteKey = event.target.accessKey;

    let productKey = event.target.dataset.id;
    let prodArray = this.qoMap.get(quoteKey).productData;
    prodArray.forEach((pItem) => {
      if (pItem.prodID == productKey) {
        pItem.openEquipmentModal = true;
        pItem.isShowEquipmentdata = false;
      }
    });
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }

  handleRemoveEquipment(event) {
    let quoteKey = event.detail.quotId;
    let productKey = event.detail.prodId;
    let indx = event.detail.equipmentId;
    let equipmentKey = event.detail.equipmentKey;
    let arraySelected = [];
    let equipmentSelected = [];
    let prodArray = this.qoMap.get(quoteKey).productData;

    prodArray.forEach((pItem) => {
      if (pItem.prodID == productKey) {
        if (pItem.selectedEquipmentMap.has(equipmentKey)) {
          let array = [];
          array = pItem.selectedEquipmentMap.get(equipmentKey);
          if (array && array.length > 0) {
            if (array.length <= 1) {
              pItem.selectedEquipmentMap.delete(equipmentKey);
            } else {
              for (let i = 0; i < array.length; i++) {
                if (array[i].Name == indx) {
                  array.splice(i, 1);
                }
              }
            }
          }
        }

        if (pItem.selectedEquipmentMap) {
          for (const key of pItem.selectedEquipmentMap.keys()) {
            arraySelected.push({
              key: key,
              values: pItem.selectedEquipmentMap.get(key),
              isDelete: true
            });
            let values = pItem.selectedEquipmentMap.get(key);
            values.forEach((object) => {
              //delete object['isSelected'];
              equipmentSelected.push(object);
            });
          }
          pItem.equipmentSelected = JSON.parse(
            JSON.stringify(equipmentSelected)
          );
          pItem.selectedEquipmentList = JSON.parse(
            JSON.stringify(arraySelected)
          );
          pItem.isShowEquipmentdata = true;
        }

        if (pItem.equipmentData && pItem.equipmentData.length > 0) {
          for (let i = 0; i < pItem.equipmentData.length; i++) {
            if (pItem.equipmentData[i].Name == indx) {
              pItem.equipmentData[i].isSelected = false;
            }
          }
        }
        if (
          pItem.resultData.productCatalogList &&
          pItem.resultData.productCatalogList.length > 0
        ) {
          for (let i = 0; i < pItem.resultData.productCatalogList.length; i++) {
            if (pItem.resultData.productCatalogList[i].Name == indx) {
              pItem.resultData.productCatalogList[i].isSelected = false;
            }
          }
        }
        if (
          pItem.resultData.selectedEquipmentTypes &&
          pItem.resultData.selectedEquipmentTypes.length > 0
        ) {
          let eq = pItem.resultData.selectedEquipmentTerm
            ? pItem.resultData.selectedEquipmentTerm
            : "";
          let keyVar = pItem.resultData.selectedEquipmentValue + "" + eq;

          if (pItem.resultData.selectedEquipmentTypes.includes(keyVar)) {
            pItem.resultData.selectedEquipmentTypes.splice(
              pItem.resultData.selectedEquipmentTypes.indexOf(keyVar),
              1
            );
          }
        }
      }
    });
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }
  handleInnerCloseEquipmentModal(event) {
    let quoteKey = event.detail.quotId;
    let productKey = event.detail.prodId;
    let prodArray = this.qoMap.get(quoteKey).productData;
    let selectedArray = [];
    let equipmentSelected = [];
    prodArray.forEach((pItem) => {
      if (pItem.prodID == productKey) {
        pItem.equipmentData = event.detail.equipmentData;
        pItem.resultData = event.detail.resultData;
        pItem.selectedEquipmentMap = event.detail.selectedEquipmentMap;

        if (event.detail.selectedEquipmentMap) {
          for (const key of event.detail.selectedEquipmentMap.keys()) {
            let values = event.detail.selectedEquipmentMap.get(key);
            selectedArray.push({ key: key, values: values, isDelete: true });
            values.forEach((object) => {
              //delete object['isSelected'];
              equipmentSelected.push(object);
            });
          }
          pItem.equipmentSelected = equipmentSelected;
          pItem.selectedEquipmentList = selectedArray;
          pItem.isShowEquipmentdata = true;
        }

        pItem.openEquipmentModal = false;
      }
    });
    this.isRemove = true;
    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
  }
  checkAddEquipmentPermission() {
    checkPermission()
      .then((result) => {
        if (result) {
          this.isAddEquipmentPermission = result;
          this.showLoading = false;
        }
      })
      .catch((error) => {
        this.error = error;
        this.showLoading = false;
      });
  }
  drag(event) {
    event.dataTransfer.setData("divId", event.target.id);
    event.dataTransfer.setData("qoId", event.target.dataset.qoid);
    event.dataTransfer.setData("prodRecId", event.target.dataset.recordId);
    event.dataTransfer.setData("index", event.target.dataset.index);

    // add class name to item on drag
    let divId = event.dataTransfer.getData("divId");
    let draggedElement = this.template.querySelector("#" + divId);
    draggedElement.classList.add("dragged-item");
  }
  allowDrop(event) {
    event.preventDefault();
  }
  drop(event) {
    event.preventDefault();
    let divId = event.dataTransfer.getData("divId");
    let qoId = event.dataTransfer.getData("qoId");
    let prodRecId = event.dataTransfer.getData("prodRecId");
    let index = event.dataTransfer.getData("index");
    let draggedElement = this.template.querySelector("#" + divId);
    let destQoId = event.target.getAttribute("data-key");

    draggedElement.classList.add("completed");
    draggedElement.classList.remove("dragged-item");

    // item which is dragged
    let sourceProdArray = this.qoMap.get(qoId).productData;
    // this is where the dragged item is dropped
    let destProdArray = this.qoMap.get(destQoId).productData;
    // remove the item from source and add it to destProdArray
    let sourceProd = sourceProdArray.filter(
      (sprodItem) => sprodItem.prodID == divId.split("-")[0]
    );
    for (let item of sourceProd) {
      destProdArray.push(item);
      this.checkForChildProducts(sourceProdArray, index, prodRecId);
      sourceProdArray.splice(sourceProdArray.indexOf(item), 1);
    }

    //this.deleteProduct(qoId,prodId,index);

    if (prodRecId) {
      this.deletedProdIds.push(prodRecId);
    }

    this.QOArray = Array.from(this.qoMap, ([qoKey, qoValue]) => ({
      qoKey,
      qoValue
    }));
    this.pNum--;
  }

  tranformToFunction(sourceData) {
    let objToReturn = {};
    sourceData.forEach((data) => {
      objToReturn[data.prodName] = data.prodValue;
    });
    return objToReturn;
  }
}