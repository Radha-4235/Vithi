import UserPreferencesRecordHomeSectionCollapseWTShown from "@salesforce/schema/User.UserPreferencesRecordHomeSectionCollapseWTShown";
import { LightningElement, api, track } from "lwc";
const TAB_ADDLOCATION = "AddLocation";
const TAB_ADDQRLOCATION = "AddQRLocation";
const TAB_ADDPRODUCT = "AddProduct";
const TAB_COPYPRODUCTCHECK = "CopyProductCheck";

export default class AddProductsAndLocationsContainer extends LightningElement {
  @api isImport;
  @api modalActiveTab = TAB_ADDLOCATION;
  @api recordId;
  @api quoteRequest;
  @api selectedLocations = [];
  @api locationAndProducts;
  @api subHeader;
  @api hideProductTabs;
  @api existingLocationsProducts;
  @track _selectedLocations;
  @track addProductContext = "";
  @track newUploadedLocations;
  @track docIdList = [];
  @track openCopyLoctnPopup = false;
  _selectedTabName;
  _isInitialized = false;
  @api loggedInUser;

  /* getters */
  renderedCallback() {
    if (this._isInitialized === false) {
      this._selectedTabName = this.modalActiveTab;
      this._isInitialized = true;
      this.existingData = this.existingLocationsProducts;
    }
  }
  constructor() {
    super();
    this.existingData = this.existingLocationsProducts;
  }
  connectedCallback() {
    this._selectedLocations = this.selectedLocations;
  }

  get openAddProductModal() {
    return this._selectedTabName === TAB_ADDPRODUCT;
  }

  get openLocationsModal() {
    return this._selectedTabName === TAB_ADDLOCATION;
  }

  get openAddQRLocationsModal() {
    return this._selectedTabName === TAB_ADDQRLOCATION;
  }

  get openCopyProductCheckModal() {
    return this._selectedTabName === TAB_COPYPRODUCTCHECK;
  }
  hideTabs(event) {
    this.hideProductTabs = event.detail.hideAddProductsTabs;
  }
  /* event handlers */
  handleCancelModalEvent() {
    let hasLocations = false;
    if (
      (this.docIdList && this.docIdList.length > 0) ||
      (this.newUploadedLocations && this.newUploadedLocations.length) ||
      (this._selectedLocations && this._selectedLocations.length)
    ) {
      hasLocations = true;
    }
    this.dispatchEvent(
      new CustomEvent("closeaddlocationandproductmodal", {
        detail: {
          hasLocations: hasLocations ? true : false
        }
      })
    );
  }
  saveProductDataEvent() {
    let hasLocations = false;
    if (
      (this.docIdList && this.docIdList.length > 0) ||
      (this.newUploadedLocations && this.newUploadedLocations.length) ||
      (this._selectedLocations && this._selectedLocations.length)
    ) {
      hasLocations = true;
    }
    console.log("in save p");
    this.dispatchEvent(
      new CustomEvent("saveaddlocationandproductmodal", {
        composed: true,
        detail: {
          hasLocations: hasLocations ? true : false
        }
      })
    );
    console.log("in save p after");
  }
  updateProductDataEvent() {
    console.log("in uodate p");
    let hasLocations = false;
    if (
      (this.docIdList && this.docIdList.length > 0) ||
      (this.newUploadedLocations && this.newUploadedLocations.length) ||
      (this._selectedLocations && this._selectedLocations.length)
    ) {
      hasLocations = true;
    }
    this.dispatchEvent(
      new CustomEvent("updateaddlocationandproductmodal", {
        detail: {
          hasLocations: hasLocations
        }
      })
    );
  }
  handleCopyTabChange(event) {
    this._selectedTabName = event.detail.tabName;
    this.addProductContext = event.detail.context;
    this.newUploadedLocations = event.detail.fromQrLocation
      ? []
      : event.detail.selectedLocations;
    //this.newUploadedLocations = event.detail.selectedLocations;
    //this.selectedLocations = event.detail.selectedLocations;
    this.docIdList = event.detail.docIdList ? event.detail.docIdList : [];
    if (this._selectedTabName === TAB_ADDPRODUCT) {
      this.newUploadedLocations = event.detail.fromQrLocation
        ? []
        : event.detail.selectedLocations
        ? event.detail.selectedLocations
        : this.newUploadedLocations;
      //this.newUploadedLocations = event.detail.selectedLocations ? event.detail.selectedLocations : this.newUploadedLocations;
    }
    this.dispatchEvent(
      new CustomEvent("manuallocation", {
        detail: {
          selectedLocations: this.newUploadedLocations
        }
      })
    );
  }
  handleTabChange(event) {
    this._selectedTabName = event.detail.tabName;
    this.newUploadedLocations = event.detail.fromQrLocation
      ? []
      : event.detail.selectedLocations;
    this.docIdList = event.detail.docIdList ? event.detail.docIdList : [];
    if (this.locationAndProducts) {
      this._selectedLocations = this.selectedLocations;
    } else {
      if (this._selectedTabName === TAB_ADDPRODUCT) {
        this._selectedLocations = event.detail.selectedLocations
          ? event.detail.selectedLocations
          : this._selectedLocations;
      }
    }
    this.dispatchEvent(
      new CustomEvent("manuallocation", {
        detail: {
          selectedLocations: this.newUploadedLocations
        }
      })
    );
  }

  handleLocationOnFileUpload(event) {
    this.dispatchEvent(
      new CustomEvent("selectedlocationonfileupload", {
        detail: {
          //selectedLocations : event.detail.selectedLocations,
          docIdList: event.detail.docIdList,
          hasLocations: event.detail.hasLocations
        }
      })
    );
  }

  // surchargeValueUpdate(event){
  //     this.surchargeCheck = event.detail;
  //     console.log('Surcharge in product and loc container : ',this.surchargeCheck);
  //     const surchargeEventLoc = new CustomEvent("surchargeeventloc", {
  //             detail: this.surchargeCheck
  //         });
  //         // Dispatches the event
  //         this.dispatchEvent(surchargeEventLoc);
  // }
}