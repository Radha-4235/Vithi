<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Broadband Edgeboot Highest</label>
    <protected>false</protected>
    <values>
        <field>Business_unit__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Identifier__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Permission__c</field>
        <value xsi:type="xsd:string">A3_ChannelSalesRep_CRE,A3_ChannelSalesRepManager_CRE,A3_ChannelSalesEng_CRE,A3_ChannelsDirector_CRE,A3_ChannelsQuoter_CRE,A3_ChannelsSupport_CRE,A3_SalesRep_CRE,A3_SalesRepManager_CRE,A3_OMAnalyst_CRE,A3_OMAnalystManager_CRE,A3_Premier_CRE,A3_SplPricing_CRE,A3_SplPricingManager_CRE,A3_GRID_SalesRep_CRE</value>
    </values>
    <values>
        <field>Product_Type__c</field>
        <value xsi:type="xsd:string">Broadband</value>
    </values>
    <values>
        <field>Rate_Type__c</field>
        <value xsi:type="xsd:string">Highest Tier</value>
    </values>
    <values>
        <field>Rate_Value__c</field>
        <value xsi:type="xsd:double">54.95</value>
    </values>
    <values>
        <field>Sort_Order__c</field>
        <value xsi:type="xsd:double">2.0</value>
    </values>
    <values>
        <field>Type_Of_Product__c</field>
        <value xsi:type="xsd:string">edgeboot</value>
    </values>
</CustomMetadata>
