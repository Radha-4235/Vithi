<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>VoIP_Pricing_Tier</label>
    <protected>false</protected>
    <values>
        <field>Default_Value__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Display_Label__c</field>
        <value xsi:type="xsd:string">Pricing Tier</value>
    </values>
    <values>
        <field>Display_Order__c</field>
        <value xsi:type="xsd:double">5.4</value>
    </values>
    <values>
        <field>Edit_MRC_Total_MRC__c</field>
        <value xsi:type="xsd:boolean">false</value>
    </values>
    <values>
        <field>Field_API__c</field>
        <value xsi:type="xsd:string">Unit__c</value>
    </values>
    <values>
        <field>Object__c</field>
        <value xsi:type="xsd:string">Quote_Request_Rates__c</value>
    </values>
    <values>
        <field>Product__c</field>
        <value xsi:type="xsd:string">VoIP</value>
    </values>
</CustomMetadata>
