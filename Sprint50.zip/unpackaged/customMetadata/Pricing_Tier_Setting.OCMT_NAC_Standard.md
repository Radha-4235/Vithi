<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>OCMT_NAC_Standard</label>
    <protected>false</protected>
    <values>
        <field>Business_unit__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Identifier__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Permission__c</field>
        <value xsi:type="xsd:string">A3_ChannelsQuoter_CRE,A3_OMAnalyst_CRE,A3_OMAnalystManager_CRE,A3_SalesEng_CRE,A3_SalesEngManager_CRE,A3_SplPricing_CRE,A3_SplPricingManager_CRE</value>
    </values>
    <values>
        <field>Product_Type__c</field>
        <value xsi:type="xsd:string">VoIP</value>
    </values>
    <values>
        <field>Rate_Type__c</field>
        <value xsi:type="xsd:string">Standard</value>
    </values>
    <values>
        <field>Rate_Value__c</field>
        <value xsi:type="xsd:double">2.8</value>
    </values>
    <values>
        <field>Sort_Order__c</field>
        <value xsi:type="xsd:double">1.0</value>
    </values>
    <values>
        <field>Type_Of_Product__c</field>
        <value xsi:type="xsd:string">Operator Connect for Microsoft Teams</value>
    </values>
</CustomMetadata>
