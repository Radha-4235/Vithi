<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Mobility IP MRC</label>
    <protected>false</protected>
    <values>
        <field>Business_Unit__c</field>
        <value xsi:type="xsd:string">Channels, Wholesale, Standard, SLED</value>
    </values>
    <values>
        <field>Field_API_Name__c</field>
        <value xsi:type="xsd:string">IP_MRC_Rate__c</value>
    </values>
    <values>
        <field>Field_Value__c</field>
        <value xsi:nil="true"/>
    </values>
    <values>
        <field>Product__c</field>
        <value xsi:type="xsd:string">Mobility</value>
    </values>
    <values>
        <field>Term__c</field>
        <value xsi:nil="true"/>
    </values>
</CustomMetadata>
